# Boris Agent Architecture

## Perception
- Accessibility tree (when enabled)
- Android intents
- notifications (when enabled)
- calendar (when enabled)
- voice transcript
- local memory and conversation state

## Planning
The agent decomposes a user goal into small actions. Each action should be observable and verifiable.

## Action policy
- Safe navigation/read actions can run directly when the user enabled the required capability.
- Sending messages, deleting data, purchases, financial transfers, publishing content, or other irreversible actions require an explicit confirmation step.
- Authentication secrets and protected Android surfaces are never bypassed.

## Recovery
After each UI action the agent should re-read the accessibility tree and verify that the expected state changed. If not, it can choose a different action or ask the user.

## Learning
EvolutionEngine stores local preference signals and recent failures. It may change routing/prompt behavior, but it does not silently rewrite or self-sign the APK.

## Updates
New code is distributed as signed Android releases. Android remains the authority for installation/update consent.
