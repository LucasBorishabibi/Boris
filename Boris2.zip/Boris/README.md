# Boris — Personal Executive AI Agent

Boris is an independent, privacy-first Android personal-agent project inspired by the *capabilities* publicly associated with modern Jarvis-style assistants. It does not copy proprietary code or private implementations.

## Core vision

Boris is designed around an **agent loop** rather than a chat-only interface:

**Understand → plan → observe → act → verify → recover → remember**

The phone-control layer prefers public Android APIs and uses Accessibility only after the user explicitly enables it.

## Included in this release

- Executive-style animated Boris UI
- German voice input + Android Text-to-Speech
- “Boris” / “Hey Boris” wake interaction while the app is active
- Local chat history and long-term memory
- Adaptive Core for automatically inferred preferences and failure signals
- Morning briefing + routines + reboot-safe scheduling
- Calendar context (with permission)
- Notification listener (with explicit Android permission)
- Free web search and Open-Meteo weather
- OpenAI-compatible provider interface for a user-selected endpoint
- Phone Agent facade
- Accessibility actions: back, home, recents, tap visible text, tap descriptions, long press, type into focused field, scroll
- Android settings / URI launching
- Safety boundaries around irreversible actions
- GitHub Actions build workflow
- Update checker for user-configured GitHub releases

## Important reality check

Android does not allow a third-party app to literally do *everything* the owner can do. Secure surfaces, system UI, protected authentication, DRM, some payment flows and certain permissions are intentionally restricted. Boris therefore uses the strongest legitimate Android mechanisms available and asks the user to take over when Android requires it.

Boris is not sentient. The Adaptive Core is functional self-modeling and learning from local interaction signals, not a claim of consciousness.

## Free-first architecture

No paid SDK is required by the app. The default design avoids ads and tracking. External model use is optional and provider-agnostic; users are responsible for any third-party endpoint they choose.

## Build

Push the repository to GitHub. The included workflow builds a debug APK with GitHub Actions. Android Studio can also open the project directly.
