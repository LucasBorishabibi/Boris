# Boris — Android Assistant

Boris is an Android assistant project written in Kotlin with Jetpack Compose, targeting phone-sized screens including the Samsung Galaxy A24.

## Build in GitHub Actions

Upload the **contents** of this `Boris` directory to the repository root, so `app/`, `build.gradle.kts` and `.github/` are at the root. Push a commit or run **Actions → Android CI** manually. Download the `boris-debug-apk` artifact from the successful run.

The workflow uses JDK 17 and Gradle 8.9 and runs a clean debug build. A successful build is a compile check only; it does not prove all device permissions, speech, provider APIs, accessibility actions, or interruption behavior work on a phone.

## Build locally

Requirements: JDK 17, Android SDK with platform 34, and Gradle 8.9.

```bash
gradle --no-daemon clean assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Project map

- `MainActivity.kt` — Compose dashboard, chat, memory, settings, quick actions
- `Jarvis.kt`, `Core.kt`, `Brain.kt`, `Learning.kt` — assistant runtime, orchestration and memory
- `WakeListener.kt`, `ListenService.kt`, `VoiceAnalyzer.kt`, `VoiceFace.kt` — voice runtime and animated face
- `PhoneAgent.kt`, `AutoSendService.kt`, `AgentCursor.kt` — Android agent and animated cursor
- `GeminiClient.kt`, `Providers.kt`, `Tools.kt`, `Skills.kt` — model/provider and tool integrations

## Privacy and setup notes

- API credentials are configured by the user on-device; never commit real API keys.
- The app now requests microphone permission at startup only. Contacts, SMS, calls, calendar and notifications should be granted only when the corresponding feature is intentionally used.
- Android accessibility, microphone, notification, contacts, call/SMS and calendar features depend on Android permissions and device settings.
- Treat this project as not device-verified until GitHub Actions completes successfully and the app is tested on the target phone.
