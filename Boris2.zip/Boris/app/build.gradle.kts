import org.gradle.api.tasks.bundling.Zip

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.boris.assistant"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.boris.assistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}

// Packages the exact project source used to build this APK into the APK.
// Boris can then maintain a persistent private copy of that source at runtime.
// The generated asset is excluded from itself to avoid recursive growth.
val packageBorisSource by tasks.registering(Zip::class) {
    archiveFileName.set("boris_source.zip")
    destinationDirectory.set(layout.projectDirectory.dir("src/main/assets"))
    from(rootProject.projectDir) {
        exclude("**/build/**")
        exclude("**/.gradle/**")
        exclude("**/src/main/assets/boris_source.zip")
        exclude("local.properties")
        exclude("**/.idea/**")
    }
}

tasks.named("preBuild") {
    dependsOn(packageBorisSource)
}
