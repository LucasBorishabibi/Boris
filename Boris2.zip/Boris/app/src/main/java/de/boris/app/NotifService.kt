package de.boris.app

import android.app.Notification
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONObject

/**
 * Liest eingehende Benachrichtigungen mit, laesst Boris sie bewerten
 * und meldet sich bei wichtigen. Bei dringenden hakt er nach, solange sie unbeantwortet sind.
 */
class NotifService : NotificationListenerService() {
    private val h = Handler(Looper.getMainLooper())
    private val queue = ArrayList<Item>()
    private var scheduled = false

    private class Item(val key: String, val app: String, val title: String, val text: String)

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!Store.reactNotifs || Store.apiKey.isBlank() || sbn.packageName == packageName) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val relevant = sbn.packageName in PKGS || n.category in CATS
        if (!relevant) return
        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        val app = runCatching {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        }.getOrDefault(sbn.packageName)
        synchronized(queue) {
            if (queue.none { it.key == sbn.key && it.text == text }) queue.add(Item(sbn.key, app, title, text.take(300)))
        }
        if (!scheduled) {
            scheduled = true
            h.postDelayed({ scheduled = false; flush() }, 6_000)
        }
    }

    private fun flush() {
        val items = synchronized(queue) { val l = ArrayList(queue); queue.clear(); l.take(10) }
        if (items.isEmpty()) return
        Thread {
            runCatching {
                val prompt = items.mapIndexed { i, it ->
                    "id=$i | App: ${it.app} | Titel: ${it.title} | Text: ${it.text}"
                }.joinToString("\n")
                val res = Gemini.triage(prompt)
                for (j in 0 until res.length()) {
                    val r = res.getJSONObject(j)
                    val level = r.optInt("level", 0)
                    val say = r.optString("say", "")
                    val item = items.getOrNull(r.optInt("id", -1)) ?: continue
                    if (level >= 2 && say.isNotBlank()) h.post { announce(item, say, level) }
                }
            }
        }.start()
    }

    private fun announce(item: Item, say: String, level: Int) {
        Brain.addMessage(Msg("assistant", say))
        if (Brain.appOpen) Stimme.speak(say) else Notify.post(item.key.hashCode(), "Boris", say)
        if (level >= 3) h.postDelayed({ followUp(item, say, 1) }, FOLLOW_MS)
    }

    private fun followUp(item: Item, say: String, count: Int) {
        val stillThere = runCatching { activeNotifications?.any { it.key == item.key } == true }.getOrDefault(false)
        if (!stillThere) return
        val msg = if (count == 1) "Sir, das hier wartet noch auf Sie: $say"
        else "Letzte Erinnerung dazu: $say Soll ich Ihnen einen Timer stellen?"
        Brain.addMessage(Msg("assistant", msg))
        if (Brain.appOpen) Stimme.speak(msg) else Notify.post(item.key.hashCode() + count, "Boris hakt nach", msg)
        if (count < 2) h.postDelayed({ followUp(item, say, count + 1) }, FOLLOW_MS)
    }

    companion object {
        private const val FOLLOW_MS = 10 * 60_000L
        private val CATS = setOf(
            Notification.CATEGORY_MESSAGE, Notification.CATEGORY_EMAIL, Notification.CATEGORY_CALL,
            Notification.CATEGORY_MISSED_CALL, Notification.CATEGORY_EVENT, Notification.CATEGORY_REMINDER
        )
        private val PKGS = setOf(
            "com.whatsapp", "org.telegram.messenger", "org.thoughtcrime.securesms", "com.google.android.gm",
            "com.google.android.apps.messaging", "com.samsung.android.messaging", "com.google.android.calendar",
            "com.samsung.android.calendar", "com.microsoft.office.outlook", "com.instagram.android"
        )
    }
}
