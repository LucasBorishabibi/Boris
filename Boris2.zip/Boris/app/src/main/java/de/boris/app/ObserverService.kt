package de.boris.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/**
 * Beobachtet nur, WELCHE App im Vordergrund ist (nie deren Inhalt).
 * Bleibt der Nutzer laenger in einer Beobachtungs-App, stellt Boris eine Rueckfrage per Benachrichtigung.
 */
class ObserverService : Service() {
    private var running = false
    private var pkg: String? = null
    private var since = 0L
    private var lastAsk = 0L
    private var lastPoll = 0L

    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { pkg = null }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("svc", "Boris im Hintergrund", NotificationManager.IMPORTANCE_MIN))
        nm.createNotificationChannel(NotificationChannel("ask", "Boris Rueckfragen", NotificationManager.IMPORTANCE_DEFAULT))
        registerReceiver(screenOff, IntentFilter(Intent.ACTION_SCREEN_OFF))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n: Notification = NotificationCompat.Builder(this, "svc")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Boris ist wach")
            .setContentText("Sieht nur den App-Namen, nie Inhalte.")
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
        if (!running) {
            running = true
            Thread {
                while (running) {
                    try { poll() } catch (_: Exception) {}
                    try { Thread.sleep(15_000) } catch (_: InterruptedException) {}
                }
            }.start()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        runCatching { unregisterReceiver(screenOff) }
        super.onDestroy()
    }

    private fun poll() {
        val now = System.currentTimeMillis()
        val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
        val from = if (lastPoll == 0L) now - 20_000 else lastPoll
        lastPoll = now
        val ev = usm.queryEvents(from, now)
        val e = UsageEvents.Event()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED && e.packageName != pkg) {
                pkg = e.packageName
                since = e.timeStamp
            }
        }
        val p = pkg ?: return
        val name = WATCH[p] ?: return
        val mins = ((now - since) / 60_000).toInt()
        if (Store.proactive && Store.apiKey.isNotBlank() && mins >= Store.minutes && now - lastAsk > COOLDOWN) {
            lastAsk = now
            val q = Gemini.askAbout(name, mins)
            Brain.addMessage(Msg("assistant", q))
            val open = PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(this, "ask")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Boris")
                .setContentText(q)
                .setStyle(NotificationCompat.BigTextStyle().bigText(q))
                .setContentIntent(open).setAutoCancel(true).build()
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(2, n)
        }
    }

    companion object {
        private const val COOLDOWN = 45 * 60_000L
        val WATCH = mapOf(
            "com.zhiliaoapp.musically" to "TikTok",
            "com.ss.android.ugc.trill" to "TikTok",
            "com.google.android.youtube" to "YouTube",
            "com.instagram.android" to "Instagram",
            "com.facebook.katana" to "Facebook",
            "com.netflix.mediaclient" to "Netflix",
            "com.snapchat.android" to "Snapchat",
            "com.twitter.android" to "X",
            "com.reddit.frontpage" to "Reddit",
            "com.spotify.music" to "Spotify"
        )

        fun start(c: Context) = ContextCompat.startForegroundService(c, Intent(c, ObserverService::class.java))
        fun stop(c: Context) { c.stopService(Intent(c, ObserverService::class.java)) }
    }
}
