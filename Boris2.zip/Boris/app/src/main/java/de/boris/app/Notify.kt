package de.boris.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

/** Boris' eigene Benachrichtigungen. */
object Notify {
    fun init(c: Context) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("svc", "Boris im Hintergrund", NotificationManager.IMPORTANCE_MIN))
        nm.createNotificationChannel(NotificationChannel("ask", "Boris meldet sich", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel("agent", "Boris arbeitet", NotificationManager.IMPORTANCE_LOW))
    }

    fun agentOngoing(text: String) {
        val c = Store.ctx
        val stop = PendingIntent.getBroadcast(
            c, 1, Intent(c, StopReceiver::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(c, "agent")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Boris arbeitet").setContentText(text)
            .setOngoing(true).setOnlyAlertOnce(true)
            .addAction(0, "Stopp", stop).build()
        runCatching { (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(7, n) }
    }

    fun agentClear() {
        runCatching { (Store.ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(7) }
    }

    fun post(id: Int, title: String, text: String) {
        val c = Store.ctx
        val open = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(c, "ask")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title).setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open).setAutoCancel(true).build()
        runCatching { (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id, n) }
    }
}
