package de.boris.app

import android.content.Context

/** Einstellungen (SharedPreferences). */
object Store {
    private lateinit var app: Context
    fun init(c: Context) { app = c.applicationContext }
    val ctx: Context get() = app
    private val sp get() = app.getSharedPreferences("boris", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("key", "") ?: ""
        set(v) { sp.edit().putString("key", v.trim()).apply() }
    var model: String
        get() = sp.getString("model", "gemini-3.5-flash") ?: "gemini-3.5-flash"
        set(v) { sp.edit().putString("model", v.trim()).apply() }
    var autoSpeak: Boolean
        get() = sp.getBoolean("speak", true)
        set(v) { sp.edit().putBoolean("speak", v).apply() }
    var voice: String
        get() = sp.getString("voice", "") ?: ""
        set(v) { sp.edit().putString("voice", v).apply() }
    var pitch: Float
        get() = sp.getFloat("pitch", 0.8f)
        set(v) { sp.edit().putFloat("pitch", v).apply() }
    var proactive: Boolean
        get() = sp.getBoolean("proactive", false)
        set(v) { sp.edit().putBoolean("proactive", v).apply() }
    var minutes: Int
        get() = sp.getInt("minutes", 10)
        set(v) { sp.edit().putInt("minutes", v).apply() }
    var agentConfirm: Boolean
        get() = sp.getBoolean("agentConfirm", true)
        set(v) { sp.edit().putBoolean("agentConfirm", v).apply() }
    var reactNotifs: Boolean
        get() = sp.getBoolean("notifs", false)
        set(v) { sp.edit().putBoolean("notifs", v).apply() }
}
