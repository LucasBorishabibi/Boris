package de.boris.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Boris als 3D-Partikelschwarm. Im Ruhezustand driftet er langsam, beim Sprechen
 * pulsiert und zerstreut er sich im Rhythmus der Woerter. Per Wischen laesst er sich drehen.
 */
@Composable
fun Swarm(modifier: Modifier, speaking: Boolean, thinking: Boolean) {
    val n = 900
    val base = remember {
        FloatArray(n * 3).also { a ->
            val ga = PI * (3 - sqrt(5.0))
            for (i in 0 until n) {
                val y = 1f - 2f * (i + 0.5f) / n
                val r = sqrt(1f - y * y)
                val th = (ga * i).toFloat()
                a[i * 3] = cos(th) * r
                a[i * 3 + 1] = y
                a[i * 3 + 2] = sin(th) * r
            }
        }
    }
    val phase = remember { FloatArray(n) { Random.nextFloat() * 6.2832f } }

    var yaw by remember { mutableFloatStateOf(0f) }
    var pitch by remember { mutableFloatStateOf(0.3f) }
    var vYaw by remember { mutableFloatStateOf(0.25f) }
    var vPitch by remember { mutableFloatStateOf(0f) }
    var dragging by remember { mutableStateOf(false) }
    var time by remember { mutableFloatStateOf(0f) }
    var energy by remember { mutableFloatStateOf(0f) }
    val spk by rememberUpdatedState(speaking)
    val thk by rememberUpdatedState(thinking)

    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                val dt = if (last == 0L) 0.016f else ((now - last) / 1e9f).coerceAtMost(0.05f)
                last = now
                time += dt
                val target = max(
                    Stimme.pulse,
                    if (spk) 0.35f + 0.15f * sin(time * 9f) else if (thk) 0.18f else 0f
                )
                Stimme.pulse = Stimme.pulse * 0.9f
                energy += (target - energy) * min(1f, dt * 10f)
                if (!dragging) {
                    yaw += vYaw * dt
                    pitch = (pitch + vPitch * dt).coerceIn(-1.4f, 1.4f)
                    vYaw += (0.25f + energy * 0.5f - vYaw) * dt * 0.6f
                    vPitch *= 0.96f
                }
            }
        }
    }

    Canvas(
        modifier.pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { dragging = true },
                onDragEnd = { dragging = false },
                onDragCancel = { dragging = false }
            ) { _, d ->
                yaw += d.x * 0.008f
                pitch = (pitch - d.y * 0.008f).coerceIn(-1.4f, 1.4f)
                vYaw = (d.x * 0.5f).coerceIn(-4f, 4f)
                vPitch = (-d.y * 0.5f).coerceIn(-4f, 4f)
            }
        }
    ) {
        val t = time
        val e = energy.coerceIn(0f, 1f)
        val cx = size.width / 2f
        val cy = size.height / 2f
        val rad = min(size.width, size.height) * 0.36f
        val cY = cos(yaw); val sY = sin(yaw)
        val cP = cos(pitch); val sP = sin(pitch)
        val col = lerp(Color(0xFF29B6F6), Color(0xFFFFE082), e)
        val jit = 0.03f + e * 0.12f

        for (i in 0 until n) {
            val ph = phase[i]
            val bx = base[i * 3]; val by = base[i * 3 + 1]; val bz = base[i * 3 + 2]
            val wave = sin(t * 3.2f + by * 5f + ph * 0.3f)
            val disp = 1f + e * 0.45f * wave + 0.04f * sin(t * 0.8f + ph)
            val x = bx * disp + sin(t * 1.3f + ph) * jit
            val y = by * disp + cos(t * 1.1f + ph * 1.7f) * jit
            val z = bz * disp + sin(t * 0.9f + ph * 2.3f) * jit

            val x1 = x * cY + z * sY
            val z1 = -x * sY + z * cY
            val y2 = y * cP - z1 * sP
            val z2 = y * sP + z1 * cP

            val persp = 2.8f / (2.8f + z2)
            val px = cx + x1 * rad * persp
            val py = cy + y2 * rad * persp
            val depth = ((z2 + 1.6f) / 3.2f).coerceIn(0f, 1f)
            val alpha = (0.2f + 0.8f * (1f - depth)).coerceIn(0f, 1f)
            drawCircle(col.copy(alpha = alpha), 1.1f + 1.9f * persp + e * 1.4f, Offset(px, py))
        }
    }
}
