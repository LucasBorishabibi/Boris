package de.boris.app

import android.content.Intent
import android.provider.AlarmClock
import org.json.JSONObject

/** Werkzeuge, die Boris selbst aufrufen kann. */
object Actions {
    fun run(name: String, i: JSONObject): String = when (name) {
        "remember" -> { Brain.addMemory(i.getString("text")); "Gespeichert." }
        "forget" -> { Brain.deleteMemory(i.getLong("id")); "Vergessen." }
        "set_timer" -> {
            val it = Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, i.getInt("seconds"))
                .putExtra(AlarmClock.EXTRA_MESSAGE, i.optString("label", "Boris"))
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            Store.ctx.startActivity(it); "Timer gestellt."
        }
        "set_alarm" -> {
            val it = Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, i.getInt("hour"))
                .putExtra(AlarmClock.EXTRA_MINUTES, i.getInt("minute"))
                .putExtra(AlarmClock.EXTRA_MESSAGE, i.optString("label", "Boris"))
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            Store.ctx.startActivity(it); "Wecker gestellt."
        }
        "run_agent" -> Agent.start(i.getString("task"))
        else -> "Unbekanntes Werkzeug."
    }
}
