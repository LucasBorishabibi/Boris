package de.boris.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Boris' Augen und Haende: liest den Bildschirm und fuehrt Taps, Eingaben und Scrollen aus. */
class BorisAccess : AccessibilityService() {
    companion object {
        @Volatile var inst: BorisAccess? = null
        val enabled: Boolean get() = inst != null
    }

    private val nodes = ArrayList<AccessibilityNodeInfo>()

    override fun onServiceConnected() { inst = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { inst = null; return super.onUnbind(intent) }

    @Synchronized
    fun snapshot(): String {
        val root = rootInActiveWindow ?: return "(Bildschirminhalt nicht lesbar, evtl. gesperrt oder Ladebildschirm)"
        nodes.clear()
        val sb = StringBuilder("Aktive App: ${root.packageName}\n")
        walk(root, sb)
        return sb.toString()
    }

    private fun walk(n: AccessibilityNodeInfo?, sb: StringBuilder) {
        if (n == null || nodes.size >= 90) return
        if (n.isVisibleToUser) {
            val text = if (n.isPassword) "(Passwortfeld)" else n.text?.toString()?.take(80)
            val desc = n.contentDescription?.toString()?.take(80)
            val interesting = n.isClickable || n.isEditable || n.isScrollable || n.isCheckable ||
                !text.isNullOrBlank() || !desc.isNullOrBlank()
            if (interesting) {
                val id = nodes.size
                nodes.add(n)
                val cls = n.className?.toString()?.substringAfterLast('.') ?: "?"
                val flags = buildList {
                    if (n.isClickable) add("klickbar")
                    if (n.isEditable) add("editierbar")
                    if (n.isScrollable) add("scrollbar")
                    if (n.isCheckable) add(if (n.isChecked) "an" else "aus")
                }.joinToString(",")
                sb.append("[$id] $cls")
                if (!text.isNullOrBlank()) sb.append(" \"$text\"")
                if (!desc.isNullOrBlank() && desc != text) sb.append(" (Beschr.: $desc)")
                if (flags.isNotEmpty()) sb.append(" {$flags}")
                sb.append('\n')
            }
        }
        for (i in 0 until n.childCount) walk(n.getChild(i), sb)
    }

    private fun node(id: Int): AccessibilityNodeInfo? = nodes.getOrNull(id)?.also { it.refresh() }

    fun click(id: Int): String {
        val n = node(id) ?: return "Ungueltige id"
        var c: AccessibilityNodeInfo? = n
        while (c != null && !c.isClickable) c = c.parent
        if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "ok"
        val r = Rect(); n.getBoundsInScreen(r)
        return tapAt(r.centerX().toFloat(), r.centerY().toFloat())
    }

    private fun tapAt(x: Float, y: Float): String {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build()
        return if (dispatchGesture(g, null, null)) "ok (Geste)" else "Tippen fehlgeschlagen"
    }

    fun typeText(id: Int, text: String): String {
        val n = node(id) ?: return "Ungueltige id"
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return if (n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) "ok"
        else "Feld nicht beschreibbar. Tippe es zuerst an und versuche es erneut."
    }

    fun scroll(id: Int, forward: Boolean): String {
        val n = (if (id >= 0) node(id) else nodes.firstOrNull { it.isScrollable }) ?: return "Nichts scrollbar"
        val act = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return if (n.performAction(act)) "ok" else "Scrollen nicht moeglich (Ende erreicht?)"
    }

    fun press(key: String): String {
        val a = when (key.lowercase()) {
            "back", "zurueck" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "recents", "uebersicht" -> GLOBAL_ACTION_RECENTS
            else -> return "Unbekannte Taste (erlaubt: back, home, recents)"
        }
        return if (performGlobalAction(a)) "ok" else "fehlgeschlagen"
    }

    fun imeEnter(id: Int): String {
        val n = node(id) ?: return "Ungueltige id"
        return if (Build.VERSION.SDK_INT >= 30 &&
            n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        ) "ok" else "Enter nicht moeglich. Tippe stattdessen den Senden- oder Such-Button."
    }
}
