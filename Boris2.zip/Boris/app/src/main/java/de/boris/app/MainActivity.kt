package de.boris.app

import android.Manifest
import android.app.Activity
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process
import android.provider.Settings
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import android.os.Bundle
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

fun hasUsageAccess(c: Context): Boolean {
    val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    val mode = if (Build.VERSION.SDK_INT >= 29)
        ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
    else
        @Suppress("DEPRECATION")
        ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
    return mode == AppOpsManager.MODE_ALLOWED
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { BorisUi() }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (Store.proactive && hasUsageAccess(this)) ObserverService.start(this)
    }
}

@Composable
fun BorisUi() {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = tab) {
            listOf("Boris", "Gehirn", "Setup").forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) })
            }
        }
        when (tab) {
            0 -> ChatTab()
            1 -> BrainTab()
            else -> SettingsTab()
        }
    }
}

@Composable
fun Bubble(m: Msg) {
    val me = m.role == "user"
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (me) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (me) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.widthIn(max = 300.dp)
        ) { Text(m.text, Modifier.padding(12.dp)) }
    }
}

@Composable
fun ColumnScope.ChatTab() {
    val scope = rememberCoroutineScope()
    val list = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    fun send(t: String) {
        if (t.isBlank() || busy) return
        input = ""
        busy = true
        Brain.addMessage(Msg("user", t))
        scope.launch {
            val reply = withContext(Dispatchers.IO) {
                runCatching { Claude.chat(Brain.messages.toList()) }
                    .getOrElse { "Fehler: ${it.message}" }
            }
            Brain.addMessage(Msg("assistant", reply))
            busy = false
            if (Store.autoSpeak) Stimme.speak(reply)
        }
    }

    val mic = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == Activity.RESULT_OK && t != null) send(t)
    }

    LaunchedEffect(Brain.messages.size, busy) {
        if (Brain.messages.isNotEmpty()) list.animateScrollToItem(Brain.messages.lastIndex)
    }

    LazyColumn(
        Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp),
        state = list,
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        items(Brain.messages) { Bubble(it) }
        if (busy) item { Text("Boris denkt nach ...", Modifier.padding(8.dp)) }
    }

    Row(
        Modifier.fillMaxWidth().padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        OutlinedTextField(
            value = input, onValueChange = { input = it },
            modifier = Modifier.weight(1f), placeholder = { Text("Sag etwas ...") },
            maxLines = 4
        )
        Button(onClick = {
            Stimme.stop()
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE")
                .putExtra(RecognizerIntent.EXTRA_PROMPT, "Ja, bitte?")
            runCatching { mic.launch(i) }
        }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("Mic") }
        Button(onClick = { send(input) }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("Senden") }
    }
}

@Composable
fun BrainTab() {
    var neu by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text(
            "Das ist Boris' dauerhaftes Gedaechtnis. Er ergaenzt es selbst, wenn er etwas Wichtiges ueber dich lernt. " +
                "Du kannst Eintraege loeschen oder selbst welche hinzufuegen.",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(
                value = neu, onValueChange = { neu = it },
                modifier = Modifier.weight(1f), placeholder = { Text("z.B. Ich heisse Alex") }
            )
            Button(onClick = { if (neu.isNotBlank()) { Brain.addMemory(neu); neu = "" } }) { Text("Merken") }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(Brain.memories) { m ->
                Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                    Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(m.text, Modifier.weight(1f))
                        TextButton(onClick = { Brain.deleteMemory(m.id) }) { Text("Loeschen") }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsTab() {
    val ctx = LocalContext.current
    var key by remember { mutableStateOf(Store.apiKey) }
    var model by remember { mutableStateOf(Store.model) }
    var speak by remember { mutableStateOf(Store.autoSpeak) }
    var pitch by remember { mutableStateOf(Store.pitch) }
    var voice by remember { mutableStateOf(Stimme.currentName()) }
    var proactive by remember { mutableStateOf(Store.proactive) }
    var minutes by remember { mutableStateOf(Store.minutes.toFloat()) }
    var usage by remember { mutableStateOf(hasUsageAccess(ctx)) }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        OutlinedTextField(
            value = key, onValueChange = { key = it; Store.apiKey = it },
            label = { Text("Claude API-Key") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = model, onValueChange = { model = it; Store.model = it },
            label = { Text("Modell") }, singleLine = true, modifier = Modifier.fillMaxWidth()
        )

        HorizontalDivider()
        Text("Stimme", style = MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Antworten vorlesen", Modifier.weight(1f))
            Switch(checked = speak, onCheckedChange = { speak = it; Store.autoSpeak = it })
        }
        Text("Tiefe: ${"%.2f".format(pitch)} (niedriger = tiefer)")
        Slider(value = pitch, onValueChange = { pitch = it; Store.pitch = it }, valueRange = 0.5f..1.2f)
        Text("Aktive Stimme: $voice", style = MaterialTheme.typography.bodySmall)
        Button(onClick = {
            Stimme.next(); voice = Stimme.currentName()
            Stimme.speak("Guten Tag. Ich bin Boris, zu Ihren Diensten.")
        }) { Text("Naechste Stimme ausprobieren") }

        HorizontalDivider()
        Text("Rueckfragen", style = MaterialTheme.typography.titleMedium)
        Text(
            "Boris merkt, wenn du laenger in Apps wie TikTok oder YouTube bist, und stellt dir per Benachrichtigung " +
                "eine Frage. Er sieht nur den App-Namen, keine Inhalte. Der App-Name und die Dauer werden an die Claude-API gesendet.",
            style = MaterialTheme.typography.bodySmall
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Rueckfragen aktiv", Modifier.weight(1f))
            Switch(checked = proactive, onCheckedChange = { on ->
                proactive = on; Store.proactive = on
                if (on) {
                    if (Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS)
                    usage = hasUsageAccess(ctx)
                    if (usage) ObserverService.start(ctx)
                    else ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                } else ObserverService.stop(ctx)
            })
        }
        Text("Nach ${minutes.toInt()} Minuten in einer App fragen")
        Slider(
            value = minutes, onValueChange = { minutes = it },
            onValueChangeFinished = { Store.minutes = minutes.toInt() },
            valueRange = 1f..30f
        )
        Text(if (usage) "Nutzungszugriff: erteilt" else "Nutzungszugriff: fehlt", style = MaterialTheme.typography.bodySmall)
        OutlinedButton(onClick = {
            ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }) { Text("Nutzungszugriff oeffnen") }
        OutlinedButton(onClick = { usage = hasUsageAccess(ctx) }) { Text("Status neu pruefen") }

        HorizontalDivider()
        OutlinedButton(onClick = { Brain.clearChat() }) { Text("Chatverlauf loeschen (Gedaechtnis bleibt)") }
    }
}
