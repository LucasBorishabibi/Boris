package de.boris.app

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.mutableStateOf
import java.util.Locale

/** Boris' Stimme: tiefe, ruhige deutsche TTS-Stimme. Meldet Sprechstatus und Wort-Impulse an den Schwarm. */
object Stimme {
    private var tts: TextToSpeech? = null
    val speaking = mutableStateOf(false)
    @Volatile var pulse = 0f

    fun init(c: Context) {
        tts = TextToSpeech(c.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setLanguage(Locale.GERMANY)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) { speaking.value = true }
                    override fun onDone(id: String?) { speaking.value = false }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) { speaking.value = false }
                    override fun onStop(id: String?, interrupted: Boolean) { speaking.value = false }
                    override fun onRangeStart(id: String?, start: Int, end: Int, frame: Int) { pulse = 1f }
                })
                apply()
            }
        }
    }

    private fun list(): List<android.speech.tts.Voice> = runCatching {
        tts?.voices?.filter { it.locale.language == "de" && !it.features.contains("notInstalled") }
            ?.sortedBy { it.name } ?: emptyList()
    }.getOrDefault(emptyList())

    fun apply() {
        val t = tts ?: return
        val l = list()
        val v = l.firstOrNull { it.name == Store.voice }
            ?: l.firstOrNull { it.name.contains("-deb-") }
            ?: l.firstOrNull()
        if (v != null) t.setVoice(v)
        t.setPitch(Store.pitch)
        t.setSpeechRate(0.95f)
    }

    fun next() {
        val l = list()
        if (l.isEmpty()) return
        val i = l.indexOfFirst { it.name == currentName() }
        Store.voice = l[(i + 1) % l.size].name
        apply()
    }

    fun currentName(): String = tts?.voice?.name ?: "-"

    fun speak(text: String) {
        apply()
        tts?.speak(text.replace(Regex("[*_#`]"), ""), TextToSpeech.QUEUE_FLUSH, null, "boris")
    }

    fun stop() { tts?.stop(); speaking.value = false }
}
