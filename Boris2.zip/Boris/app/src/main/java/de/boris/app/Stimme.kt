package de.boris.app

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Boris' Stimme: tiefe, ruhige deutsche TTS-Stimme. */
object Stimme {
    private var tts: TextToSpeech? = null

    fun init(c: Context) {
        tts = TextToSpeech(c.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setLanguage(Locale.GERMANY)
                apply()
            }
        }
    }

    private fun list(): List<android.speech.tts.Voice> = runCatching {
        tts?.voices?.filter { it.locale.language == "de" && !it.features.contains("notInstalled") }
            ?.sortedBy { it.name } ?: emptyList()
    }.getOrDefault(emptyList())

    fun apply() {
        val t = tts ?: return
        val l = list()
        val v = l.firstOrNull { it.name == Store.voice }
            ?: l.firstOrNull { it.name.contains("-deb-") }
            ?: l.firstOrNull()
        if (v != null) t.setVoice(v)
        t.setPitch(Store.pitch)
        t.setSpeechRate(0.95f)
    }

    fun next() {
        val l = list()
        if (l.isEmpty()) return
        val i = l.indexOfFirst { it.name == currentName() }
        Store.voice = l[(i + 1) % l.size].name
        apply()
    }

    fun currentName(): String = tts?.voice?.name ?: "-"

    fun speak(text: String) {
        apply()
        tts?.speak(text.replace(Regex("[*_#`]"), ""), TextToSpeech.QUEUE_FLUSH, null, "boris")
    }

    fun stop() { tts?.stop() }
}
