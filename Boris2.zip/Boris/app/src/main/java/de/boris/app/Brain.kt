package de.boris.app

import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Memory(val id: Long, val text: String)
data class Msg(val role: String, val text: String)

/** Boris' dauerhaftes Gehirn: Erinnerungen + Chatverlauf, gespeichert als JSON im App-Speicher. */
object Brain {
    val memories = mutableStateListOf<Memory>()
    val messages = mutableStateListOf<Msg>()
    val thinking = androidx.compose.runtime.mutableStateOf(false)
    @Volatile var appOpen = false
    private val main = Handler(Looper.getMainLooper())
    private var lastId = 0L

    private fun file(n: String) = File(Store.ctx.filesDir, n)
    private fun onMain(b: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) b() else main.post(b)
    }

    fun load() = onMain {
        memories.clear(); messages.clear()
        runCatching {
            val a = JSONArray(file("memory.json").readText())
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                memories.add(Memory(o.getLong("id"), o.getString("text")))
            }
        }
        runCatching {
            val a = JSONArray(file("chat.json").readText())
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                messages.add(Msg(o.getString("role"), o.getString("text")))
            }
        }
    }

    private fun saveMem() {
        val a = JSONArray()
        memories.forEach { a.put(JSONObject().put("id", it.id).put("text", it.text)) }
        file("memory.json").writeText(a.toString())
    }

    private fun saveMsgs() {
        val a = JSONArray()
        messages.takeLast(300).forEach { a.put(JSONObject().put("role", it.role).put("text", it.text)) }
        file("chat.json").writeText(a.toString())
    }

    @Synchronized
    fun addMemory(text: String): Long {
        val id = maxOf(System.currentTimeMillis(), lastId + 1)
        lastId = id
        onMain { memories.add(Memory(id, text.trim())); saveMem() }
        return id
    }

    fun deleteMemory(id: Long) = onMain { memories.removeAll { it.id == id }; saveMem() }
    fun addMessage(m: Msg) = onMain { messages.add(m); saveMsgs() }
    fun clearChat() = onMain { messages.clear(); saveMsgs() }
}
