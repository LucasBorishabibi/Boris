package de.boris.app

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/** Anbindung an die Claude-API (blockierend: immer im Hintergrund-Thread aufrufen). */
object Claude {
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()
    private val JSON = "application/json".toMediaType()

    private fun system(): String {
        val now = SimpleDateFormat("EEEE, dd.MM.yyyy HH:mm", Locale.GERMAN).format(Date())
        val mem = Brain.memories.toList().let { l ->
            if (l.isEmpty()) "(noch nichts gespeichert)"
            else l.joinToString("\n") { "- [${it.id}] ${it.text}" }
        }
        return """
Du bist Boris, der persoenliche Assistent auf dem Handy deines Nutzers. Dein Stil ist wie Jarvis: souveraen, hoeflich, trocken-humorvoll, loyal.
Antworte auf Deutsch, kurz und praezise (1 bis 3 Saetze), ohne Markdown und ohne Emojis, weil deine Antworten vorgelesen werden.
Aktuelle Zeit: $now

DEIN GEDAECHTNIS (bleibt dauerhaft erhalten):
$mem

Regeln:
- Lernst du etwas Dauerhaftes ueber den Nutzer (Name, Vorlieben, Gewohnheiten, Ziele, Menschen in seinem Leben), rufe das Werkzeug remember auf, kurz und eigenstaendig formuliert. Speichere keine Kleinigkeiten und nichts doppelt.
- Bittet der Nutzer dich, etwas zu vergessen, nutze forget mit der id aus dem Gedaechtnis.
- Timer und Wecker stellst du mit set_timer und set_alarm.
- Stelle hoechstens EINE kurze Rueckfrage pro Antwort, und nur wenn sie dir hilft, den Nutzer besser zu verstehen oder besser zu helfen. Sei neugierig, aber nie aufdringlich.
""".trimIndent()
    }

    private fun tool(name: String, desc: String, props: JSONObject, req: List<String>) = JSONObject()
        .put("name", name).put("description", desc)
        .put("input_schema", JSONObject().put("type", "object").put("properties", props).put("required", JSONArray(req)))

    private fun str(d: String) = JSONObject().put("type", "string").put("description", d)
    private fun num(d: String) = JSONObject().put("type", "integer").put("description", d)

    private fun tools() = JSONArray()
        .put(tool("remember", "Speichert einen dauerhaften Fakt im Gedaechtnis.", JSONObject().put("text", str("Der Fakt")), listOf("text")))
        .put(tool("forget", "Loescht eine Erinnerung.", JSONObject().put("id", num("id der Erinnerung")), listOf("id")))
        .put(tool("set_timer", "Stellt einen Timer.", JSONObject().put("seconds", num("Dauer in Sekunden")).put("label", str("Bezeichnung")), listOf("seconds")))
        .put(tool("set_alarm", "Stellt einen Wecker.", JSONObject().put("hour", num("Stunde 0-23")).put("minute", num("Minute 0-59")).put("label", str("Bezeichnung")), listOf("hour", "minute")))

    fun chat(history: List<Msg>, withTools: Boolean = true): String {
        if (Store.apiKey.isBlank()) error("Kein API-Key. Bitte unter Setup eintragen.")
        val msgs = JSONArray()
        history.takeLast(30).dropWhile { it.role != "user" }
            .forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.text)) }

        for (round in 0 until 6) {
            val body = JSONObject().put("model", Store.model).put("max_tokens", 1024)
                .put("system", system()).put("messages", msgs)
            if (withTools) body.put("tools", tools())
            val req = Request.Builder().url("https://api.anthropic.com/v1/messages")
                .header("x-api-key", Store.apiKey)
                .header("anthropic-version", "2023-06-01")
                .post(body.toString().toRequestBody(JSON)).build()
            val resp = http.newCall(req).execute()
            val txt = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                val m = runCatching { JSONObject(txt).getJSONObject("error").getString("message") }.getOrDefault(txt.take(200))
                error("API ${resp.code}: $m")
            }
            val o = JSONObject(txt)
            val content = o.getJSONArray("content")
            if (o.optString("stop_reason") == "tool_use") {
                msgs.put(JSONObject().put("role", "assistant").put("content", content))
                val results = JSONArray()
                for (j in 0 until content.length()) {
                    val b = content.getJSONObject(j)
                    if (b.getString("type") == "tool_use") {
                        val out = runCatching { Actions.run(b.getString("name"), b.getJSONObject("input")) }
                            .getOrElse { "Fehler: ${it.message}" }
                        results.put(JSONObject().put("type", "tool_result").put("tool_use_id", b.getString("id")).put("content", out))
                    }
                }
                msgs.put(JSONObject().put("role", "user").put("content", results))
            } else {
                val sb = StringBuilder()
                for (j in 0 until content.length()) {
                    val b = content.getJSONObject(j)
                    if (b.getString("type") == "text") sb.append(b.getString("text"))
                }
                return sb.toString().trim().ifEmpty { "Erledigt." }
            }
        }
        return "Erledigt."
    }

    /** Proaktive Rueckfrage, ausgeloest durch die aktive App. */
    fun askAbout(app: String, minutes: Int): String = chat(
        listOf(
            Msg(
                "user",
                "[Systemhinweis, nicht vom Nutzer: Er ist seit etwa $minutes Minuten in $app. " +
                    "Stelle genau eine kurze, neugierige, freundliche Frage dazu (max. 20 Woerter), nicht belehrend. " +
                    "Beziehe dich wenn passend auf dein Gedaechtnis.]"
            )
        ),
        withTools = false
    )
}
