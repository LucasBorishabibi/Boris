package de.boris.app

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/** Anbindung an die Gemini-API (blockierend: immer im Hintergrund-Thread aufrufen). */
object Gemini {
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()
    private val JSON = "application/json".toMediaType()

    fun memoryText(): String = Brain.memories.toList().let { l ->
        if (l.isEmpty()) "(noch nichts gespeichert)"
        else l.joinToString("\n") { "- [${it.id}] ${it.text}" }
    }

    private fun now(): String = SimpleDateFormat("EEEE, dd.MM.yyyy HH:mm", Locale.GERMAN).format(Date())

    private fun system(): String = """
Du bist Boris, der persoenliche Assistent auf dem Handy deines Nutzers. Dein Stil ist wie Jarvis: souveraen, hoeflich, trocken-humorvoll, loyal.
Antworte auf Deutsch, kurz und praezise (1 bis 3 Saetze), ohne Markdown und ohne Emojis, weil deine Antworten vorgelesen werden.
Aktuelle Zeit: ${now()}

DEIN GEDAECHTNIS (bleibt dauerhaft erhalten):
${memoryText()}

Regeln:
- Lernst du etwas Dauerhaftes ueber den Nutzer (Name, Vorlieben, Gewohnheiten, Ziele, wichtige Menschen), rufe die Funktion remember auf, kurz und eigenstaendig formuliert. Speichere keine Kleinigkeiten und nichts doppelt.
- Bittet der Nutzer dich, etwas zu vergessen, nutze forget mit der id aus dem Gedaechtnis.
- Timer und Wecker stellst du mit set_timer und set_alarm.
- Alles, was in anderen Apps oder auf dem Handy getan werden muss (Nachricht in WhatsApp oder Discord schreiben, Website oeffnen, E-Mail schreiben und senden, Apps bedienen), erledigst du mit run_agent. Gib dort die komplette Aufgabe praezise an (an wen, was genau, in welcher App). Fehlt etwas Wesentliches, frage vorher nach. Danach sagst du nur kurz, dass du dich darum kuemmerst.
- Stelle hoechstens EINE kurze Rueckfrage pro Antwort, und nur wenn sie dir hilft, den Nutzer besser zu verstehen oder besser zu helfen.
- Nachrichten, in denen du den Nutzer auf eine Benachrichtigung hingewiesen hast, kennst du aus dem Verlauf. Beantwortet der Nutzer sie, hilf ihm konkret weiter.
""".trimIndent()

    fun prop(type: String, d: String) = JSONObject().put("type", type).put("description", d)

    fun decl(name: String, desc: String, props: JSONObject, req: List<String>) = JSONObject()
        .put("name", name).put("description", desc)
        .put("parameters", JSONObject().put("type", "object").put("properties", props).put("required", JSONArray(req)))

    private fun tools() = JSONArray().put(
        JSONObject().put(
            "functionDeclarations", JSONArray()
                .put(decl("remember", "Speichert einen dauerhaften Fakt im Gedaechtnis.", JSONObject().put("text", prop("string", "Der Fakt")), listOf("text")))
                .put(decl("forget", "Loescht eine Erinnerung.", JSONObject().put("id", prop("integer", "id der Erinnerung")), listOf("id")))
                .put(decl("set_timer", "Stellt einen Timer.", JSONObject().put("seconds", prop("integer", "Dauer in Sekunden")).put("label", prop("string", "Bezeichnung")), listOf("seconds")))
                .put(decl("run_agent", "Fuehrt eine Aufgabe auf dem Handy selbststaendig aus (Apps bedienen, Nachrichten schreiben, Websites oeffnen, E-Mails senden).", JSONObject().put("task", prop("string", "Praezise, vollstaendige Aufgabenbeschreibung")), listOf("task")))
                .put(decl("set_alarm", "Stellt einen Wecker.", JSONObject().put("hour", prop("integer", "Stunde 0-23")).put("minute", prop("integer", "Minute 0-59")).put("label", prop("string", "Bezeichnung")), listOf("hour", "minute")))
        )
    )

    fun agentTools() = JSONArray().put(
        JSONObject().put(
            "functionDeclarations", JSONArray()
                .put(decl("open_app", "Startet eine App anhand ihres Namens.", JSONObject().put("name", prop("string", "App-Name, z.B. WhatsApp")), listOf("name")))
                .put(decl("open_url", "Oeffnet eine Website im Browser.", JSONObject().put("url", prop("string", "Volle URL mit https://")), listOf("url")))
                .put(decl("compose_email", "Oeffnet einen E-Mail-Entwurf. Gesendet wird erst durch Tippen auf Senden.", JSONObject().put("to", prop("string", "Empfaenger")).put("subject", prop("string", "Betreff")).put("body", prop("string", "Text")), listOf("to")))
                .put(decl("tap", "Tippt ein Element an.", JSONObject().put("id", prop("integer", "id aus der Liste")), listOf("id")))
                .put(decl("type_text", "Schreibt Text in ein editierbares Feld (ersetzt den Inhalt).", JSONObject().put("id", prop("integer", "id des Felds")).put("text", prop("string", "Text")), listOf("id", "text")))
                .put(decl("scroll", "Scrollt eine Liste oder Seite.", JSONObject().put("id", prop("integer", "id des scrollbaren Elements, optional")).put("direction", prop("string", "down oder up")), listOf("direction")))
                .put(decl("press", "Drueckt eine Systemtaste.", JSONObject().put("key", prop("string", "back, home oder recents")), listOf("key")))
                .put(decl("ime_enter", "Sendet die Enter-/Such-Taste der Tastatur im Feld.", JSONObject().put("id", prop("integer", "id des Felds")), listOf("id")))
                .put(decl("wait", "Wartet, bis etwas geladen ist.", JSONObject().put("seconds", prop("integer", "1 bis 10")), listOf("seconds")))
                .put(decl("ask_user", "Fragt den Nutzer und wartet auf die Antwort (Rueckfrage oder Bestaetigung).", JSONObject().put("question", prop("string", "Kurze Frage")), listOf("question")))
                .put(decl("finish", "Beendet die Aufgabe mit einer kurzen Zusammenfassung.", JSONObject().put("summary", prop("string", "1-2 Saetze")), listOf("summary")))
        )
    )

    fun post(body: JSONObject): JSONObject {
        if (Store.apiKey.isBlank()) error("Kein API-Key. Bitte unter Setup eintragen.")
        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/${Store.model}:generateContent")
            .header("x-goog-api-key", Store.apiKey)
            .post(body.toString().toRequestBody(JSON)).build()
        val resp = http.newCall(req).execute()
        val txt = resp.body?.string().orEmpty()
        if (!resp.isSuccessful) {
            val m = runCatching { JSONObject(txt).getJSONObject("error").getString("message") }.getOrDefault(txt.take(200))
            error("API ${resp.code}: $m")
        }
        return JSONObject(txt)
    }

    fun sysInstr(t: String) = JSONObject().put("parts", JSONArray().put(JSONObject().put("text", t)))

    fun chat(history: List<Msg>, withTools: Boolean = true): String {
        val contents = JSONArray()
        history.takeLast(30).dropWhile { it.role != "user" }.forEach { m ->
            val role = if (m.role == "user") "user" else "model"
            val last = if (contents.length() > 0) contents.getJSONObject(contents.length() - 1) else null
            if (last != null && last.getString("role") == role) {
                last.getJSONArray("parts").put(JSONObject().put("text", m.text))
            } else {
                contents.put(JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", m.text))))
            }
        }

        for (round in 0 until 6) {
            val body = JSONObject().put("systemInstruction", sysInstr(system()))
                .put("contents", contents)
                .put("generationConfig", JSONObject().put("maxOutputTokens", 2048))
            if (withTools) body.put("tools", tools())
            val o = post(body)
            val cand = o.optJSONArray("candidates")?.optJSONObject(0)
            val content = cand?.optJSONObject("content") ?: return "Dazu kann ich leider nichts sagen."
            val parts = content.optJSONArray("parts") ?: return "Erledigt."

            val calls = ArrayList<JSONObject>()
            val sb = StringBuilder()
            for (j in 0 until parts.length()) {
                val p = parts.getJSONObject(j)
                if (p.has("functionCall")) calls.add(p.getJSONObject("functionCall"))
                else if (p.has("text") && !p.optBoolean("thought", false)) sb.append(p.getString("text"))
            }
            if (calls.isEmpty()) return sb.toString().trim().ifEmpty { "Erledigt." }

            // Modell-Antwort unveraendert anhaengen (inkl. Thought-Signaturen), dann Ergebnisse zurueckgeben.
            contents.put(content)
            val resp = JSONArray()
            for (c in calls) {
                val out = runCatching { Actions.run(c.getString("name"), c.optJSONObject("args") ?: JSONObject()) }
                    .getOrElse { "Fehler: ${it.message}" }
                resp.put(
                    JSONObject().put(
                        "functionResponse",
                        JSONObject().put("name", c.getString("name")).put("response", JSONObject().put("result", out))
                    )
                )
            }
            contents.put(JSONObject().put("role", "user").put("parts", resp))
        }
        return "Erledigt."
    }

    /** Proaktive Rueckfrage, ausgeloest durch die aktive App. */
    fun askAbout(app: String, minutes: Int): String = chat(
        listOf(
            Msg(
                "user",
                "[Systemhinweis, nicht vom Nutzer: Er ist seit etwa $minutes Minuten in $app. " +
                    "Stelle genau eine kurze, neugierige, freundliche Frage dazu (max. 20 Woerter), nicht belehrend. " +
                    "Beziehe dich wenn passend auf dein Gedaechtnis.]"
            )
        ),
        withTools = false
    )

    /** Bewertet neue Benachrichtigungen. Liefert ein Array [{id, level 0-3, say}]. */
    fun triage(items: String): JSONArray {
        val sys = """
Du bist Boris und bewertest eingehende Handy-Benachrichtigungen fuer deinen Nutzer. Heute ist ${now()}.
Was du ueber ihn weisst:
${memoryText()}

Vergib pro Benachrichtigung level:
0 = Spam, Werbung, Newsletter, belangloser Gruppenchat
1 = normal, kann warten
2 = wichtig (persoenliche Nachricht von nahestehender Person, Termin, Frage an den Nutzer)
3 = dringend und zeitkritisch (Notfall, Person wartet auf Antwort, baldiger Termin, verpasster wichtiger Anruf)
Bei level 2 oder 3 schreibst du in say einen kurzen deutschen Satz (max. 25 Woerter, ohne Emojis), den Boris dem Nutzer sagt, im Jarvis-Stil und mit dem Namen der Person oder App. Sonst ist say leer.
Antworte NUR mit einem JSON-Array in der Form [{"id":0,"level":2,"say":"..."}].
""".trimIndent()
        val body = JSONObject().put("systemInstruction", sysInstr(sys))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", items)))))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("maxOutputTokens", 2048))
        val o = post(body)
        val t = o.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        return JSONArray(t.trim())
    }
}
