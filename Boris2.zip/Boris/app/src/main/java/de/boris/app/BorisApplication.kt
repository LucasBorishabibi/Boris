package de.boris.app

import android.app.Application

class BorisApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        Brain.load()
        Stimme.init(this)
    }
}
