package com.boris.assistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import kotlin.math.max

/** Ein Anhang für das nächste Gespräch: Bild, PDF oder Text/Code. */
class Attachment(val name: String, val kind: String, val part: JSONObject)

/** Liest Dateien, die der Nutzer ausdrücklich auswählt (Android-Dateiauswahl, keine Speicher-Berechtigung nötig). */
object Attach {
    private const val MAX_BYTES = 10 * 1024 * 1024
    private const val MAX_TEXT = 60_000
    private const val MAX_EDGE = 1600

    fun load(ctx: Context, uri: Uri): Attachment {
        val cr = ctx.contentResolver
        val name = displayName(ctx, uri)
        val mime = cr.getType(uri)
            ?: android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase()) ?: ""
        return when {
            mime.startsWith("image/") -> Attachment(name, "image", inline("image/jpeg", jpeg(ctx, uri)))
            mime == "application/pdf" || name.lowercase().endsWith(".pdf") -> {
                val b = cr.openInputStream(uri)?.use { it.readBytes() } ?: throw RuntimeException("Datei konnte nicht gelesen werden.")
                if (b.size > MAX_BYTES) throw RuntimeException("Die PDF ist zu groß (maximal 10 MB).")
                Attachment(name, "pdf", inline("application/pdf", b))
            }
            else -> {
                val buf = CharArray(MAX_TEXT + 1)
                val n = cr.openInputStream(uri)?.bufferedReader()?.use { it.read(buf) } ?: throw RuntimeException("Datei konnte nicht gelesen werden.")
                if (n <= 0) throw RuntimeException("Die Datei ist leer.")
                val s = String(buf, 0, minOf(n, MAX_TEXT))
                if (s.count { it == '\u0000' } > 4) throw RuntimeException("Dieser Dateityp wird nicht unterstützt. Ich kann Bilder, PDF, Text und Code lesen.")
                val cut = if (n > MAX_TEXT) "\n[… gekürzt]" else ""
                Attachment(name, "text", JSONObject().put("text", "Anhang \"$name\":\n$s$cut"))
            }
        }
    }

    private fun inline(mime: String, bytes: ByteArray): JSONObject =
        JSONObject().put("inlineData", JSONObject().put("mimeType", mime).put("data", Base64.encodeToString(bytes, Base64.NO_WRAP)))

    /** Bild verkleinern und drehen, damit es schnell hochgeladen ist und wenig Kontingent braucht. */
    private fun jpeg(ctx: Context, uri: Uri): ByteArray {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > MAX_EDGE * 2) sample *= 2
        var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) }
            ?: throw RuntimeException("Das Bild konnte nicht gelesen werden.")
        val rot = try {
            cr.openInputStream(uri)?.use {
                when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (e: Exception) { 0f }
        val scale = MAX_EDGE.toFloat() / max(bmp.width, bmp.height)
        val m = Matrix()
        if (scale < 1f) m.postScale(scale, scale)
        if (rot != 0f) m.postRotate(rot)
        if (!m.isIdentity) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
        return out.toByteArray()
    }

    private fun displayName(ctx: Context, uri: Uri): String {
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) { val n = it.getString(0); if (!n.isNullOrBlank()) return n.take(60) }
            }
        } catch (e: Exception) {}
        return uri.lastPathSegment?.take(60) ?: "Datei"
    }
}
