package com.boris.assistant

import android.app.Notification
import android.app.NotificationManager
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.os.PowerManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONObject

/** Liest eingehende Benachrichtigungen, filtert per KI nach Wichtigkeit und meldet Wichtiges per Stimme. */
class NotifService : NotificationListenerService() {
    companion object {
        @Volatile var instance: NotifService? = null
        private val MESSENGERS = setOf(
            "com.whatsapp", "org.telegram.messenger", "org.thoughtcrime.securesms", "com.discord",
            "com.instagram.android", "com.google.android.apps.messaging", "com.samsung.android.messaging",
            "com.google.android.gm", "com.microsoft.office.outlook", "com.facebook.orca"
        )
        private val CATS = setOf(
            Notification.CATEGORY_MESSAGE, Notification.CATEGORY_CALL, Notification.CATEGORY_EMAIL,
            Notification.CATEGORY_EVENT, Notification.CATEGORY_REMINDER, Notification.CATEGORY_ALARM
        )
    }

    private val seen = HashMap<String, Long>()
    private val spoken = ArrayList<Long>()

    override fun onListenerConnected() { instance = this; Brain.load(this) }
    override fun onListenerDisconnected() { instance = null }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        Thread { try { triage(sbn) } catch (e: Exception) {} }.start()
    }

    private fun triage(sbn: StatusBarNotification) {
        val prefs = getSharedPreferences("boris", 0)
        if (!prefs.getBoolean("notif_ai", true)) return
        val n = sbn.notification
        val pkg = sbn.packageName
        if (pkg == packageName || sbn.isOngoing || n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (pkg !in MESSENGERS && n.category !in CATS) return
        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = (ex.getCharSequence(Notification.EXTRA_TEXT) ?: ex.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString() ?: ""
        if (title.isBlank() && text.isBlank()) return
        Scheduler.matchWatch(this, title)?.let { w ->
            Core.announce(this, w.optString("text").ifBlank { "$title hat dir geschrieben" } + ": " + text.take(80), false)
            return
        }
        if (AutoSendService.instance?.curPkg == pkg) return                      // Nutzer sieht es ohnehin
        if ((getSystemService(NotificationManager::class.java)).currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL) return
        if (!(getSystemService(POWER_SERVICE) as PowerManager).isInteractive) return
        val j = Hub.jarvis(this)
        if (PhoneAgent.running || j.speaking) return
        val now = System.currentTimeMillis()
        synchronized(this) {
            val k = "$pkg|$title"
            if (now - (seen[k] ?: 0L) < 90_000) return
            seen[k] = now
            spoken.removeAll { now - it > 3_600_000 }
            if (spoken.size >= 12) return
        }
        val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }
        val sys = "Du filterst Handy-Benachrichtigungen für den Nutzer und entscheidest streng, ob sie jetzt wichtig genug sind, ihn per Stimme zu unterbrechen. " +
            "Wichtig: persönliche Nachrichten von Menschen, Anrufe, Termine in Kürze, Sicherheits- oder Bankwarnungen, angekommene Lieferungen, dringende Arbeit. " +
            "Unwichtig: Werbung, Newsletter, Likes, Spiele, Updates, Smalltalk in großen Gruppen. " +
            "Bekannte Fakten über den Nutzer (z.B. wichtige Personen):\n${Brain.prompt()}\n" +
            "Antworte NUR mit JSON: {\"important\":true|false,\"say\":\"ein kurzer gesprochener deutscher Satz (max. 22 Wörter) mit Absender und Kern\",\"offer_reply\":true|false}"
        val out = Notify.ask(this, sys, "App: $label\nTitel: $title\nText: $text") ?: return
        val js = try { JSONObject(out.substring(out.indexOf('{'), out.lastIndexOf('}') + 1)) } catch (e: Exception) { return }
        if (!js.optBoolean("important")) return
        var say = js.optString("say").ifBlank { return }
        if (js.optBoolean("offer_reply")) say += " Soll ich antworten?"
        synchronized(this) { spoken.add(now) }
        Notify.deliver(this, say)
    }

    /** Antwortet direkt über die Antwort-Funktion einer offenen Benachrichtigung (WhatsApp, Telegram, SMS …). */
    fun reply(match: String, text: String): String? {
        val list = try { activeNotifications } catch (e: Exception) { return null }
        for (sbn in list) {
            val ex = sbn.notification.extras
            val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            val conv = ex.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString() ?: ""
            if (!title.contains(match, true) && !conv.contains(match, true)) continue
            val act = sbn.notification.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true } ?: continue
            val ri = act.remoteInputs
            val i = Intent()
            val b = Bundle(); b.putCharSequence(ri[0].resultKey, text)
            RemoteInput.addResultsToIntent(ri, i, b)
            act.actionIntent.send(this, 0, i)
            return "Antwort an ${title.ifBlank { conv }} gesendet."
        }
        return null
    }

    fun summary(): String {
        val list = try { activeNotifications } catch (e: Exception) { return "Benachrichtigungszugriff nicht verfügbar." }
        val lines = list.filter { !it.isOngoing && it.packageName != packageName }.take(15).map {
            val ex = it.notification.extras
            val app = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(it.packageName, 0)).toString() } catch (e: Exception) { it.packageName }
            "$app: ${ex.getCharSequence(Notification.EXTRA_TITLE) ?: ""} – ${ex.getCharSequence(Notification.EXTRA_TEXT) ?: ""}"
        }
        return if (lines.isEmpty()) "INFO: Keine offenen Benachrichtigungen." else "INFO: Offene Benachrichtigungen:\n" + lines.joinToString("\n")
    }
}
