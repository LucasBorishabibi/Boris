package com.boris.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** Hört dauerhaft zu (solange Boris offen ist). Auf "Boris …" hin wird der Befehl übernommen. mode: 0 aus, 1 wartet auf "Boris", 2 hört Befehl. */
class WakeListener(
    private val act: Context,
    private val onCommand: (String) -> Unit,
    private val onMode: (Int) -> Unit
) {
    private val h = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var running = false
    private var paused = false
    private var awaiting = false
    private val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE")
        .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, act.packageName)

    fun start() { if (running) return; running = true; schedule(0) }

    fun stop() {
        running = false; h.removeCallbacksAndMessages(null)
        try { rec?.destroy() } catch (e: Exception) {}
        rec = null; onMode(0)
    }

    fun pause(p: Boolean) {
        paused = p
        if (p) { try { rec?.cancel() } catch (e: Exception) {}; onMode(0) }
        else if (running) schedule(400)
    }

    /** Nächste Äußerung ist direkt ein Befehl (ohne "Boris"). */
    fun awaitCommand() {
        awaiting = true; onMode(2)
        try { ToneGenerator(AudioManager.STREAM_MUSIC, 70).startTone(ToneGenerator.TONE_PROP_ACK, 120) } catch (e: Exception) {}
        h.postDelayed({ if (awaiting) { awaiting = false; if (!paused) onMode(1) } }, 10000)
        if (running && !paused) { try { rec?.cancel() } catch (e: Exception) {}; schedule(250) }
    }

    private fun schedule(delay: Long) { h.postDelayed({ listen() }, delay) }

    private fun listen() {
        if (!running || paused) return
        if (act.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { schedule(2000); return }
        if (rec == null) { rec = SpeechRecognizer.createSpeechRecognizer(act); rec?.setRecognitionListener(listener) }
        onMode(if (awaiting) 2 else 1)
        try { rec?.startListening(intent) } catch (e: Exception) { try { rec?.destroy() } catch (x: Exception) {}; rec = null; schedule(1000) }
    }

    private fun handle(b: Bundle?) {
        if (paused) return
        val text = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
        if (awaiting) { awaiting = false; onCommand(text); return }
        val idx = text.lowercase().indexOf("boris")
        if (idx < 0) return
        val cmd = text.substring(idx + 5).trim().trimStart(',', '.', '!', ':', ' ').trim()
        if (cmd.length >= 3) onCommand(cmd) else awaitCommand()
    }

    private val listener = object : RecognitionListener {
        override fun onResults(results: Bundle?) { handle(results); if (running && !paused) schedule(250) }
        override fun onError(error: Int) {
            if (!running || paused) return
            if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || error == SpeechRecognizer.ERROR_CLIENT) {
                try { rec?.destroy() } catch (e: Exception) {}; rec = null; schedule(700)
            } else schedule(300)
        }
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(r: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(p: Bundle?) {}
        override fun onEvent(t: Int, p: Bundle?) {}
    }
}
