package com.boris.assistant

import android.app.Application
import android.util.Log

class BorisApp : Application() {
    override fun onCreate() {
        super.onCreate()
        instance = this
        Brain.load(this)
        Learner.init(this)
        SelfCoder.init(this)
        LiveRuntime.load(this)
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { getSharedPreferences("boris", 0).edit().putString("crash", Log.getStackTraceString(e).take(1600)).apply() } catch (x: Exception) {}
            old?.uncaughtException(t, e)
        }
    }

    companion object {
        @Volatile private var instance: BorisApp? = null
        fun appCtx(): android.content.Context =
            instance ?: throw IllegalStateException("BorisApp nicht initialisiert")
    }
}
