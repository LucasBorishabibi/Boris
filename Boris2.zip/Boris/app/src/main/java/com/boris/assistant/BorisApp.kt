package com.boris.assistant

import android.app.Application
import android.util.Log

class BorisApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Brain.load(this)
        Skills.load(this)
        Learning.init(this)
        Learning.start()
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { getSharedPreferences("boris", 0).edit().putString("crash", Log.getStackTraceString(e).take(1600)).apply() } catch (x: Exception) {}
            old?.uncaughtException(t, e)
        }
    }
}
