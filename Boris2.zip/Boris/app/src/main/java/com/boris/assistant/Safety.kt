package com.boris.assistant

import android.content.Context
import org.json.JSONObject

/** Sicherheitsabfragen: vor Geld-Themen, langen Texten und ersten Nachrichten an neue Kontakte fragt Boris nach. */
object Safety {
    private val money = listOf("überweis", "bezahl", "kauf", "paypal", "euro", "€", "iban", "konto", "kredit", "bitcoin", "krypto", "bank")
    private val sends = setOf("send_sms", "send_whatsapp", "reply_notification")

    fun enabled(ctx: Context) = ctx.getSharedPreferences("boris", 0).getBoolean("safety", true)
    private fun trusted(ctx: Context): Set<String> = ctx.getSharedPreferences("boris", 0).getStringSet("trusted", emptySet()) ?: emptySet()

    fun needsConfirm(ctx: Context, name: String, args: JSONObject): String? {
        if (!enabled(ctx)) return null
        val sensitive = money.any { args.toString().lowercase().contains(it) }
        if (name in sends) {
            val c = args.optString("contact"); val text = args.optString("text")
            if (sensitive) return "Das betrifft Geld oder Konten. Soll ich „${text.take(80)}“ wirklich an $c senden?"
            if (text.length > 200) return "Die Nachricht ist ziemlich lang. Soll ich sie wirklich an $c senden?"
            if (trusted(ctx).none { it.equals(c, true) }) return "Erste Nachricht an $c. Soll ich „${text.take(80)}“ senden?"
        }
        if (name == "phone_task" && sensitive) return "Der Auftrag betrifft Geld oder Konten: ${args.optString("task").take(100)}. Soll ich das wirklich tun?"
        return null
    }

    fun afterSuccess(ctx: Context, name: String, args: JSONObject, result: String) {
        if (name !in sends || result.startsWith("Fehler") || result.startsWith("INFO") || result.startsWith("Keine")) return
        val c = args.optString("contact").ifBlank { return }
        val p = ctx.getSharedPreferences("boris", 0)
        p.edit().putStringSet("trusted", trusted(ctx) + c).apply()
    }
}
