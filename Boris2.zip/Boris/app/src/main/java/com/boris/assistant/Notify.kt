package com.boris.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

/** Gemeinsame Objekte für Activity und Dienste. */
object Hub {
    /** Gesetzt, solange Boris sichtbar ist: Dienste stellen Rückfragen dann direkt in der App. */
    @Volatile var activityAsk: ((String) -> Unit)? = null
    @Volatile private var j: Jarvis? = null
    fun jarvis(ctx: Context): Jarvis = j ?: synchronized(this) { j ?: Jarvis(ctx.applicationContext).also { j = it } }
}

object Notify {
    private const val CH = "boris_ask"
    private var nid = 100

    fun post(ctx: Context, title: String, text: String) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Boris", NotificationManager.IMPORTANCE_DEFAULT))
        val pi = PendingIntent.getActivity(
            ctx, nid,
            Intent(ctx, MainActivity::class.java).putExtra("q", text)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(ctx, CH)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title).setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(pi).setAutoCancel(true).build()
        nm.notify(nid++, n)
    }

    /** Spricht den Satz (oder stellt ihn in der offenen App) und legt eine Benachrichtigung zum Antworten ab. */
    fun deliver(ctx: Context, text: String) {
        val ask = Hub.activityAsk
        if (ask != null) { android.os.Handler(android.os.Looper.getMainLooper()).post { ask(text) }; return }
        val key = ctx.getSharedPreferences("boris", 0).getString("key", "") ?: ""
        Hub.jarvis(ctx).speak(key, text)
        post(ctx, "Boris", text)
    }

    /** Einfacher KI-Aufruf ohne Werkzeuge. */
    fun ask(ctx: Context, system: String, prompt: String): String? = try {
        val key = ctx.getSharedPreferences("boris", 0).getString("key", "") ?: ""
        val h = org.json.JSONArray().put(org.json.JSONObject().put("role", "user")
            .put("parts", org.json.JSONArray().put(org.json.JSONObject().put("text", prompt))))
        val res = GeminiClient.generate(key, system, org.json.JSONArray(), h,
            listOf("gemini-3.5-flash-lite", "gemini-flash-lite-latest", "gemini-flash-latest"))
        val parts = res.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
        (0 until parts.length()).joinToString("") { parts.getJSONObject(it).optString("text") }.trim()
    } catch (e: Exception) { null }
}
