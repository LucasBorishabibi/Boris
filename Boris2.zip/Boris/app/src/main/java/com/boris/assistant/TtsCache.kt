package com.boris.assistant

import android.content.Context
import java.io.File
import java.security.MessageDigest

/** Bereitet Text für die Sprachausgabe auf: ohne Markdown, Links und Emojis, an Satzgrenzen gekürzt. */
object SpeechText {
    private val codeBlock = Regex("```[\\s\\S]*?```")
    private val inlineCode = Regex("`([^`]*)`")
    private val mdLink = Regex("\\[([^\\]]+)\\]\\((https?://[^)]+)\\)")
    private val url = Regex("https?://\\S+")
    private val heading = Regex("(?m)^\\s{0,3}#{1,6}\\s*")
    private val bullet = Regex("(?m)^\\s*[-*•]\\s+")
    private val emphasis = Regex("\\*{1,3}([^*\\n]+)\\*{1,3}")
    private val symbols = Regex("[\\p{So}\\u200d\\uFE0F]")
    private val spaces = Regex("\\s+")
    private val sentenceEnd = Regex("[.!?…](?=\\s|$)")

    fun clean(raw: String): String {
        var s = raw
        s = codeBlock.replace(s, " ")
        s = inlineCode.replace(s, "$1")
        s = mdLink.replace(s, "$1")
        s = url.replace(s, " ")
        s = heading.replace(s, "")
        s = bullet.replace(s, "")
        s = emphasis.replace(s, "$1")
        s = symbols.replace(s, "")
        return spaces.replace(s, " ").trim()
    }

    /** Kürzt auf höchstens max Zeichen, bevorzugt am letzten Satzende, sonst an Komma oder Wortgrenze. */
    fun cap(s: String, max: Int): String {
        if (s.length <= max) return s
        val window = s.substring(0, max)
        val m = sentenceEnd.findAll(window).lastOrNull()
        if (m != null && m.range.last >= max * 0.4) return window.substring(0, m.range.last + 1)
        val c = window.lastIndexOfAny(charArrayOf(',', ';', ':', '–', '—'))
        if (c >= max * 0.5) return window.substring(0, c).trimEnd() + "."
        val sp = window.lastIndexOf(' ')
        val cut = if (sp > max * 0.5) window.substring(0, sp) else window
        return cut.trimEnd(',', ';', ':', ' ') + "."
    }
}

/** Lokaler Speicher für fertige Sprachausgaben (PCM 24 kHz). Gleicher Text + gleiche Stimme kostet nie zweimal. */
object TtsCache {
    private const val MAX_BYTES = 48L * 1024 * 1024
    private const val MIN_BYTES = 2400L   // alles unter ~50 ms ist kaputt

    private fun dir(ctx: Context): File = File(ctx.filesDir, "tts_cache").also { it.mkdirs() }

    fun key(vararg parts: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        val bytes = md.digest(parts.joinToString("\u0001").toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }.take(40)
    }

    fun get(ctx: Context, key: String): ByteArray? {
        val f = File(dir(ctx), "$key.pcm")
        if (!f.isFile || f.length() < MIN_BYTES) return null
        return try {
            val b = f.readBytes()
            f.setLastModified(System.currentTimeMillis())
            if ((b.size and 1) == 0) b else b.copyOf(b.size and 1.inv())
        } catch (e: Exception) { null }
    }

    fun partFile(ctx: Context, key: String): File = File(dir(ctx), "$key.part")

    /** Erst wenn der Stream vollständig war, wird aus der .part-Datei ein gültiger Cache-Eintrag. */
    @Synchronized
    fun commit(ctx: Context, key: String, part: File) {
        try {
            val target = File(dir(ctx), "$key.pcm")
            if (part.length() < MIN_BYTES) { part.delete(); return }
            if (target.exists()) target.delete()
            if (!part.renameTo(target)) part.delete()
            trim(ctx)
        } catch (e: Exception) { part.delete() }
    }

    @Synchronized
    private fun trim(ctx: Context) {
        val files = dir(ctx).listFiles() ?: return
        val now = System.currentTimeMillis()
        files.filter { it.name.endsWith(".part") && now - it.lastModified() > 3_600_000 }.forEach { it.delete() }
        val pcm = files.filter { it.name.endsWith(".pcm") }.sortedBy { it.lastModified() }
        var total = pcm.sumOf { it.length() }
        if (total <= MAX_BYTES) return
        for (f in pcm) {
            if (total <= MAX_BYTES * 9 / 10) break
            total -= f.length(); f.delete()
        }
    }


    /** Statistiken für den sichtbaren Cache-Fortschritt und die geschätzten gesparten Credits. */
    fun recordHit(ctx: Context, chars: Int) {
        val p = ctx.getSharedPreferences("boris", 0)
        p.edit()
            .putLong("tts_cache_hits", p.getLong("tts_cache_hits", 0L) + 1L)
            .putFloat("tts_credits_saved", p.getFloat("tts_credits_saved", 0f) + chars.coerceAtLeast(0) * 0.5f)
            .apply()
    }

    fun stats(ctx: Context): CacheStats {
        val files = dir(ctx).listFiles()?.filter { it.isFile && it.name.endsWith(".pcm") } ?: emptyList()
        val p = ctx.getSharedPreferences("boris", 0)
        return CacheStats(
            entries = files.size,
            hits = p.getLong("tts_cache_hits", 0L),
            savedCredits = p.getFloat("tts_credits_saved", 0f),
            bytes = files.sumOf { it.length() }
        )
    }

    data class CacheStats(val entries: Int, val hits: Long, val savedCredits: Float, val bytes: Long)

    /** Alte ElevenLabs-Einträge aus der früheren Version (unsicherer Schlüssel, evtl. abgeschnittene Audios) einmalig löschen. */
    fun purgeLegacy(ctx: Context) {
        val p = ctx.getSharedPreferences("boris", 0)
        if (p.getBoolean("tts_legacy_purged", false)) return
        try { ctx.cacheDir.listFiles { x -> x.name.startsWith("el_") && x.name.endsWith(".pcm") }?.forEach { it.delete() } } catch (e: Exception) {}
        p.edit().putBoolean("tts_legacy_purged", true).apply()
    }
}
