package com.boris.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Kurzbefehle: erfolgreiche Agenten-Abläufe werden als Rezept gespeichert und später ohne KI-Runden abgespielt. */
object Recipes {
    private const val PREF = "boris_recipes"
    private val allowed = setOf("click_text", "type", "submit", "scroll", "back", "home", "open_app")

    @Synchronized private fun load(ctx: Context): JSONArray = JSONArray(ctx.getSharedPreferences(PREF, 0).getString("r", "[]") ?: "[]")
    @Synchronized private fun save(ctx: Context, a: JSONArray) { ctx.getSharedPreferences(PREF, 0).edit().putString("r", a.toString()).apply() }

    fun count(ctx: Context) = load(ctx).length()

    private fun json(out: String?): JSONObject? = try {
        if (out == null) null else JSONObject(out.substring(out.indexOf('{'), out.lastIndexOf('}') + 1))
    } catch (e: Exception) { null }

    fun learn(ctx: Context, task: String, app: String?, actions: JSONArray) {
        val sys = "Du erzeugst wiederverwendbare Kurzbefehl-Rezepte für einen Handy-Agenten. Antworte NUR mit JSON."
        val p = "Aufgabe: $task\nApp: ${app ?: "unbekannt"}\nErfolgreich ausgeführte Schritte: $actions\n\n" +
            "Erzeuge ein Rezept {\"name\":\"kurzer_snake_case_name\",\"description\":\"was es tut, ohne konkrete Namen\",\"params\":[\"kontakt\",\"text\"],\"steps\":[...]}. " +
            "Ersetze aufgabenspezifische Werte (Namen, Nachrichtentexte, Suchbegriffe) in den Texten durch {param}-Platzhalter. Entferne überflüssige oder doppelte Schritte. " +
            "Erlaubte Schritte: {\"a\":\"click_text\",\"text\":..}, {\"a\":\"type\",\"text\":..}, {\"a\":\"submit\"}, {\"a\":\"scroll\",\"dir\":\"down\"}, {\"a\":\"back\"}, {\"a\":\"home\"}, {\"a\":\"open_app\",\"app\":..}."
        val js = json(Notify.ask(ctx, sys, p)) ?: return
        val steps = js.optJSONArray("steps") ?: return
        if (steps.length() < 2 || steps.length() > 20) return
        for (i in 0 until steps.length()) if (steps.getJSONObject(i).optString("a") !in allowed) return
        val name = js.optString("name").ifBlank { return }
        val all = load(ctx); val keep = JSONArray()
        for (i in 0 until all.length()) if (all.getJSONObject(i).optString("name") != name) keep.put(all.getJSONObject(i))
        js.put("fails", 0); keep.put(js)
        while (keep.length() > 30) keep.remove(0)
        save(ctx, keep)
        Dbg.d("Kurzbefehl gelernt: $name")
    }

    fun match(ctx: Context, task: String): Pair<JSONObject, Map<String, String>>? {
        val all = load(ctx)
        if (all.length() == 0) return null
        val list = (0 until all.length()).joinToString("\n") {
            val r = all.getJSONObject(it); "${r.optString("name")}: ${r.optString("description")} (params: ${r.optJSONArray("params")})"
        }
        val js = json(Notify.ask(ctx,
            "Wähle für die Aufgabe ein passendes Kurzbefehl-Rezept oder null. Es muss die Aufgabe exakt abdecken. " +
                "Antworte NUR mit JSON {\"recipe\":\"name\" oder null,\"params\":{\"param\":\"wert\"}}.",
            "Aufgabe: $task\nRezepte:\n$list")) ?: return null
        val n = js.optString("recipe")
        if (n.isBlank() || n == "null") return null
        for (i in 0 until all.length()) {
            val r = all.getJSONObject(i)
            if (r.optString("name") == n) {
                val pm = HashMap<String, String>()
                js.optJSONObject("params")?.let { o -> o.keys().forEach { k -> pm[k] = o.optString(k) } }
                return r to pm
            }
        }
        return null
    }

    fun fail(ctx: Context, name: String) {
        val all = load(ctx); val keep = JSONArray()
        for (i in 0 until all.length()) {
            val r = all.getJSONObject(i)
            if (r.optString("name") == name) { r.put("fails", r.optInt("fails") + 1); if (r.optInt("fails") >= 2) continue }
            keep.put(r)
        }
        save(ctx, keep)
    }
}
