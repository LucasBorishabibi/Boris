package com.boris.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Borris dauerhaftes Gehirn: Fakten bleiben gespeichert, wachsen mit und werden bei Überfüllung automatisch verdichtet. */
object Brain {
    private const val PREF = "boris_brain"
    private var ctx: Context? = null
    private val facts = ArrayList<JSONObject>()

    @Synchronized fun load(c: Context) {
        if (ctx != null) return
        ctx = c.applicationContext
        val arr = JSONArray(ctx!!.getSharedPreferences(PREF, 0).getString("facts", "[]") ?: "[]")
        for (i in 0 until arr.length()) facts.add(arr.getJSONObject(i))
    }

    private fun save() {
        val a = JSONArray(); facts.forEach { a.put(it) }
        ctx?.getSharedPreferences(PREF, 0)?.edit()?.putString("facts", a.toString())?.apply()
    }

    @Synchronized fun add(fact: String, cat: String = "allgemein"): String {
        val f = fact.trim()
        if (f.isBlank()) return "Nichts zu merken."
        if (facts.any { it.getString("t").equals(f, true) }) return "Das wusste ich schon."
        facts.add(JSONObject().put("t", f).put("c", cat).put("ts", System.currentTimeMillis()))
        save()
        if (facts.size > 140) compactAsync()
        return "Gemerkt."
    }

    @Synchronized fun remove(keyword: String): Int {
        val before = facts.size
        facts.removeAll { it.getString("t").contains(keyword, true) }
        save()
        return before - facts.size
    }

    @Synchronized fun all(): List<Pair<String, String>> = facts.map { it.getString("c") to it.getString("t") }

    @Synchronized fun exportJson(): org.json.JSONArray { val a = org.json.JSONArray(); facts.forEach { a.put(it) }; return a }

    /** Ersetzt das Gehirn durch eine Sicherung; leere oder kaputte Einträge werden übersprungen. */
    @Synchronized fun importJson(a: org.json.JSONArray): Int {
        val n = ArrayList<JSONObject>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val t = o.optString("t").trim()
            if (t.isNotBlank()) n.add(JSONObject().put("t", t).put("c", o.optString("c", "allgemein")).put("ts", o.optLong("ts", System.currentTimeMillis())))
        }
        facts.clear(); facts.addAll(n); save()
        return n.size
    }

    @Synchronized fun setAt(i: Int, text: String) {
        val f = text.trim()
        if (i in facts.indices && f.isNotBlank()) { facts[i].put("t", f); save() }
    }

    @Synchronized fun removeAt(i: Int) { if (i in facts.indices) { facts.removeAt(i); save() } }

    @Synchronized fun prompt(): String {
        if (facts.isEmpty()) return "(noch leer)"
        return facts.takeLast(120).joinToString("\n") { "- [${it.getString("c")}] ${it.getString("t")}" }
    }

    /** Verdichtet die ältesten Einträge per KI zu wenigen prägnanten Fakten. */
    private fun compactAsync() {
        val key = ctx?.getSharedPreferences("boris", 0)?.getString("key", "") ?: ""
        if (key.isBlank()) return
        val old = facts.take(70).map { it.getString("t") }
        Thread {
            try {
                val h = JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text",
                    "Fasse diese Notizen über einen Nutzer zu höchstens 20 prägnanten Fakten zusammen (eine pro Zeile, ohne Aufzählungszeichen, nichts erfinden, Wichtiges behalten):\n" + old.joinToString("\n")))))
                val res = GeminiClient.generate(key, "Du verdichtest Notizen.", JSONArray(), h,
                    listOf("gemini-3.5-flash-lite", "gemini-flash-lite-latest"))
                val parts = res.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
                val text = (0 until parts.length()).joinToString("") { parts.getJSONObject(it).optString("text") }
                val lines = text.lines().map { it.trim().trimStart('-', '•', ' ') }.filter { it.length > 3 }
                if (lines.size in 3..30) synchronized(this) {
                    facts.removeAll { f -> old.contains(f.getString("t")) }
                    lines.forEachIndexed { i, l -> facts.add(i, JSONObject().put("t", l).put("c", "verdichtet").put("ts", System.currentTimeMillis())) }
                    save()
                }
            } catch (e: Exception) {}
        }.start()
    }
}
