package com.boris.assistant

import android.animation.ObjectAnimator
import android.content.Context
import android.content.Intent
import android.graphics.Color as AColor
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

/** FaceTime-artiges, verschiebbares Boris-Fenster. Android verlangt dafür eine einmalige Nutzerfreigabe. */
object FloatBorisOverlay {
    @Volatile private var root: LinearLayout? = null
    @Volatile private var manager: WindowManager? = null
    @Volatile private var params: WindowManager.LayoutParams? = null
    @Volatile private var messageView: TextView? = null
    @Volatile private var pulse: ObjectAnimator? = null

    fun hasPermission(ctx: Context) = Settings.canDrawOverlays(ctx)

    fun requestPermission(ctx: Context) {
        if (hasPermission(ctx)) return
        try {
            val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } catch (_: Exception) {
            Toast.makeText(ctx, "Bitte Boris unter 'Über anderen Apps anzeigen' erlauben.", Toast.LENGTH_LONG).show()
        }
    }

    @Synchronized fun show(ctx0: Context, text: String) {
        val ctx = ctx0.applicationContext
        if (!hasPermission(ctx)) return
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        try {
            if (root != null) {
                messageView?.text = text
                root?.visibility = View.VISIBLE
                return
            }
            val panel = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(ctx, 14), dp(ctx, 12), dp(ctx, 14), dp(ctx, 12))
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    intArrayOf(AColor.rgb(10, 22, 43), AColor.rgb(13, 35, 57))).apply {
                    cornerRadius = dp(ctx, 22).toFloat()
                    setStroke(dp(ctx, 1), AColor.rgb(36, 174, 235))
                    setColor(AColor.rgb(10, 24, 42))
                }
                elevation = dp(ctx, 14).toFloat()
            }
            val top = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val avatar = TextView(ctx).apply {
                text = "🤖"; textSize = 27f; gravity = Gravity.CENTER
                setTextColor(AColor.rgb(75, 210, 255)); typeface = Typeface.DEFAULT_BOLD
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(AColor.rgb(14, 55, 85)); setStroke(dp(ctx, 2), AColor.rgb(36, 174, 235)) }
            }
            top.addView(avatar, LinearLayout.LayoutParams(dp(ctx, 48), dp(ctx, 48)))
            val nameBlock = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(ctx, 10), 0, 0, 0) }
            nameBlock.addView(TextView(ctx).apply { text = "Boris"; textSize = 16f; setTextColor(AColor.WHITE); typeface = Typeface.DEFAULT_BOLD })
            nameBlock.addView(TextView(ctx).apply { text = "●  spricht mit dir"; textSize = 11f; setTextColor(AColor.rgb(65, 224, 178)) })
            top.addView(nameBlock, LinearLayout.LayoutParams(0, -2, 1f))
            val close = TextView(ctx).apply { text = "×"; textSize = 27f; gravity = Gravity.CENTER; setTextColor(AColor.LTGRAY) }
            top.addView(close, LinearLayout.LayoutParams(dp(ctx, 32), dp(ctx, 40)))
            panel.addView(top)
            val speech = TextView(ctx).apply {
                text = text; textSize = 14f; setTextColor(AColor.WHITE); setPadding(dp(ctx, 2), dp(ctx, 10), dp(ctx, 2), dp(ctx, 6))
            }
            messageView = speech
            panel.addView(speech)
            val wave = TextView(ctx).apply {
                text = "▂ ▄ ▆ ▇ ▅ ▃ ▆ ▄ ▂"; textSize = 17f; gravity = Gravity.CENTER
                setTextColor(AColor.rgb(43, 195, 255)); setPadding(0, dp(ctx, 2), 0, 0)
            }
            panel.addView(wave)
            val lp = WindowManager.LayoutParams(
                dp(ctx, 300), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                android.graphics.PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.END; x = dp(ctx, 12); y = dp(ctx, 100) }
            close.setOnClickListener { dismiss() }
            var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
            top.setOnTouchListener { _, ev ->
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> { downX = ev.rawX; downY = ev.rawY; startX = lp.x; startY = lp.y; true }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = (startX - (ev.rawX - downX).toInt()).coerceAtLeast(0)
                        lp.y = (startY + (ev.rawY - downY).toInt()).coerceAtLeast(0)
                        try { wm.updateViewLayout(panel, lp) } catch (_: Exception) {}
                        true
                    }
                    MotionEvent.ACTION_UP -> true
                    else -> true
                }
            }
            wm.addView(panel, lp)
            manager = wm; params = lp; root = panel
            panel.alpha = 0f; panel.translationY = -dp(ctx, 18).toFloat()
            panel.animate().alpha(1f).translationY(0f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
            pulse = ObjectAnimator.ofFloat(avatar, View.ALPHA, 1f, 0.62f, 1f).apply { duration = 1050; repeatCount = ObjectAnimator.INFINITE; start() }
        } catch (_: Exception) { dismiss() }
    }

    @Synchronized fun dismiss() {
        try { pulse?.cancel(); pulse = null; root?.let { manager?.removeView(it) } } catch (_: Exception) {}
        root = null; manager = null; params = null; messageView = null
    }

    private fun dp(ctx: Context, n: Int) = (n * ctx.resources.displayMetrics.density).toInt()
}
