package com.boris.assistant

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

data class Msg(val kind: Int, val text: String) // 0 = du, 1 = Boris, 2 = Aktion, 3 = Fehler

/** Kleines Protokoll für die Fehlersuche (sichtbar im SYSTEM-Reiter). */
object Dbg {
    val lines = mutableStateListOf<String>()
    fun d(s: String) {
        val t = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.GERMAN).format(java.util.Date())
        Handler(Looper.getMainLooper()).post { lines.add("$t $s"); while (lines.size > 40) lines.removeAt(0) }
    }
}

/** Das Zentrum: verarbeitet Befehle egal ob aus der App, vom Dauer-Zuhörer, von Erinnerungen oder Routinen. */
object Core {
    val messages = mutableStateListOf<Msg>()
    val history = JSONArray()
    var status by mutableStateOf("BEREIT")
    var busy by mutableStateOf(false)
    var voiceMode by mutableIntStateOf(0)
    @Volatile var listener: WakeListener? = null
    @Volatile var activityVisible = false
    @Volatile private var pending: Pair<String, JSONObject>? = null
    private val ui = Handler(Looper.getMainLooper())

    fun onUi(b: () -> Unit) { ui.post(b) }
    fun key(ctx: Context): String = ctx.getSharedPreferences("boris", 0).getString("key", "") ?: ""

    private fun isStop(l: String) = l in setOf("stopp", "stop", "abbrechen", "halt", "boris stopp", "boris stop", "hör auf")
    private fun isYes(l: String) = l.trim('.', '!', ' ') in setOf("ja", "jo", "yes", "klar", "mach", "mach das", "okay", "ok", "gern", "los",
        "sende", "senden", "bestätigt", "passt", "ja bitte", "ja klar", "ja mach", "sicher", "gerne")
    private fun isNo(l: String) = l.trim('.', '!', ' ') in setOf("nein", "nö", "nee", "lass", "lass es", "nicht", "bloß nicht", "nein danke")

    /** Spricht, ohne sich selbst zuzuhören. Endet der Satz mit "?", hört Boris danach direkt auf die Antwort. */
    fun say(ctx: Context, text: String, listenAfter: Boolean, then: (() -> Unit)? = null) {
        val l = listener
        l?.pause(true)
        Hub.jarvis(ctx).speak(key(ctx), text, onDone = { l?.pause(false); if (listenAfter) l?.awaitCommand(); then?.invoke() })
    }

    /** Boris meldet sich von sich aus (Erinnerung, Beobachtung). */
    fun announce(ctx0: Context, text: String, question: Boolean) {
        val ctx = ctx0.applicationContext
        onUi { messages.add(Msg(1, text)) }
        if (question) {
            synchronized(history) {
                if (history.length() == 0) history.put(JSONObject().put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", "(Boris meldet sich von sich aus)"))))
                history.put(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", text))))
            }
        }
        say(ctx, text, question)
        if (!activityVisible) Notify.post(ctx, "Boris", text)
    }

    fun ask(ctx: Context, q: String) = announce(ctx, q, true)

    fun handle(ctx0: Context, text: String) {
        val ctx = ctx0.applicationContext
        val t = text.trim()
        if (t.isBlank()) return
        val low = t.lowercase()
        if (isStop(low) && (busy || PhoneAgent.running || Hub.jarvis(ctx).speaking)) {
            PhoneAgent.abort(); Hub.jarvis(ctx).stop(); Dbg.d("Stopp per Sprache"); return
        }
        if (busy) return
        val p = pending
        if (p != null) {
            pending = null
            if (isYes(low)) {
                onUi { messages.add(Msg(0, t)); busy = true; status = statusFor(p.first, p.second).uppercase() }
                Thread {
                    val r = try { runTool(ctx, p.first, p.second) } catch (e: Exception) { "Fehler: ${e.message}" }
                    Safety.afterSuccess(ctx, p.first, p.second, r)
                    val out = r.removePrefix("INFO:").trim()
                    onUi { messages.add(Msg(2, out.take(120))); busy = false; status = "BEREIT" }
                    say(ctx, out, false)
                }.start()
                return
            }
            if (isNo(low)) {
                onUi { messages.add(Msg(0, t)); messages.add(Msg(1, "Verstanden, abgebrochen.")) }
                say(ctx, "Verstanden, abgebrochen.", false)
                return
            }
        }
        val key = key(ctx)
        Hub.jarvis(ctx).stop()
        onUi { messages.add(Msg(0, t)); busy = true; status = "ANALYSIERE …" }
        synchronized(history) {
            history.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", t))))
        }
        agentApiKey = key
        statusSink = { s -> onUi { status = s.uppercase() } }
        Thread {
            var ok = true
            var reply = ""
            try {
                reply = GeminiClient.chat(key, history, { s -> onUi { status = s.uppercase() } }) { n, a -> guarded(ctx, n, a) }
            } catch (e: Exception) { ok = false; reply = e.message ?: "Unbekannter Fehler"; Dbg.d("Fehler: ${e.message}") }
            onUi { messages.add(Msg(if (ok) 1 else 3, reply)); busy = false; status = "BEREIT" }
            if (ok) say(ctx, reply, reply.trim().endsWith("?"))
        }.start()
    }

    private fun guarded(ctx: Context, name: String, args: JSONObject): String {
        val q = Safety.needsConfirm(ctx, name, args)
        if (q != null) { pending = name to args; return "ASK:$q" }
        onUi { status = statusFor(name, args).uppercase() }
        val r = try { runTool(ctx, name, args) } catch (e: Exception) { "Fehler: ${e.message}" }
        if (r.startsWith("Fehler")) Dbg.d("$name: $r")
        onUi { messages.add(Msg(2, r.removePrefix("INFO:").trim().take(120))) }
        Safety.afterSuccess(ctx, name, args, r)
        return r
    }
}
