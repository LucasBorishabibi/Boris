package com.boris.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object GeminiClient {
    private val MODELS = listOf("gemini-3.5-flash-lite", "gemini-flash-lite-latest", "gemini-flash-latest")

    class ApiException(val code: Int, msg: String) : RuntimeException(msg)

    private val tools = JSONArray(
        """[{"function_declarations":[
        {"name":"set_timer","description":"Stellt einen Countdown-Timer.",
         "parameters":{"type":"object","properties":{"seconds":{"type":"integer"},"label":{"type":"string"}},"required":["seconds"]}},
        {"name":"set_alarm","description":"Stellt einen Wecker (24h).",
         "parameters":{"type":"object","properties":{"hour":{"type":"integer"},"minute":{"type":"integer"},"label":{"type":"string"}},"required":["hour","minute"]}},
        {"name":"spotify_play","description":"Spielt in Spotify Song, Künstler, Album oder Playlist per Suchbegriff.",
         "parameters":{"type":"object","properties":{"query":{"type":"string"}},"required":["query"]}},
        {"name":"spotify_liked","description":"Spielt in Spotify die Lieblingssongs."},
        {"name":"open_app","description":"Öffnet eine App.",
         "parameters":{"type":"object","properties":{"app":{"type":"string"}},"required":["app"]}},
        {"name":"send_sms","description":"Sendet eine SMS direkt ab.",
         "parameters":{"type":"object","properties":{"contact":{"type":"string"},"text":{"type":"string"},"phone":{"type":"string"}},"required":["contact","text"]}},
        {"name":"send_whatsapp","description":"Sendet blitzschnell eine WhatsApp-Nachricht an einen Kontakt.",
         "parameters":{"type":"object","properties":{"contact":{"type":"string"},"text":{"type":"string"}},"required":["contact","text"]}},
        {"name":"reply_notification","description":"Antwortet direkt auf eine gerade offene Benachrichtigung (WhatsApp, Telegram, SMS …). Der schnellste Weg, wenn der Nutzer auf eine eingegangene Nachricht antworten will.",
         "parameters":{"type":"object","properties":{"contact":{"type":"string","description":"Absender laut Benachrichtigung"},"text":{"type":"string"}},"required":["contact","text"]}},
        {"name":"read_notifications","description":"Liest die aktuell offenen Benachrichtigungen vor bzw. fasst sie zusammen."},
        {"name":"phone_task","description":"Führt eine beliebige Aufgabe selbständig in Apps aus, in mehreren Schritten (öffnen, suchen, tippen, senden). Für Discord, Instagram, Telegram und alles ohne eigenes Werkzeug.",
         "parameters":{"type":"object","properties":{"task":{"type":"string","description":"Vollständige Aufgabe mit allen Details"},"app":{"type":"string","description":"App, die zuerst geöffnet werden soll"}},"required":["task"]}},
        {"name":"call_contact","description":"Ruft einen Kontakt an.",
         "parameters":{"type":"object","properties":{"contact":{"type":"string"}},"required":["contact"]}},
        {"name":"navigate","description":"Startet die Navigation zu einem Ziel.",
         "parameters":{"type":"object","properties":{"destination":{"type":"string"}},"required":["destination"]}},
        {"name":"search_web","description":"Öffnet eine Google-Suche im Browser.",
         "parameters":{"type":"object","properties":{"query":{"type":"string"}},"required":["query"]}},
        {"name":"torch","description":"Schaltet die Taschenlampe an oder aus.",
         "parameters":{"type":"object","properties":{"on":{"type":"boolean"}},"required":["on"]}},
        {"name":"set_volume","description":"Stellt die Medienlautstärke in Prozent.",
         "parameters":{"type":"object","properties":{"percent":{"type":"integer"}},"required":["percent"]}},
        {"name":"remember","description":"Speichert einen dauerhaften Fakt im Gehirn (Vorlieben, Kontakte/Spitznamen, Gewohnheiten, Wichtiges).",
         "parameters":{"type":"object","properties":{"fact":{"type":"string"},"category":{"type":"string","description":"person, vorliebe, gewohnheit, wichtig, app oder allgemein"}},"required":["fact"]}},
        {"name":"forget","description":"Löscht Fakten aus dem Gehirn, die das Stichwort enthalten.",
         "parameters":{"type":"object","properties":{"keyword":{"type":"string"}},"required":["keyword"]}}
        ]}]"""
    )

    private fun system(): String {
        val now = SimpleDateFormat("EEEE, dd.MM.yyyy HH:mm", Locale.GERMAN).format(Date())
        return "Du bist Boris, ein souveräner, trocken-humorvoller KI-Assistent im Stil von J.A.R.V.I.S., auf dem Android-Handy des Nutzers. " +
            "Du sprichst Deutsch, knapp (höchstens 2 Sätze) und gut vorlesbar. " +
            "Handle sofort mit den Werkzeugen. Nimm den schnellsten passenden Weg: eigene Werkzeuge vor phone_task. " +
            "Auf eingehende Nachrichten antwortest du mit reply_notification. Für Fragen zu Benachrichtigungen nutze read_notifications. " +
            "Rückfragen: Ist ein Auftrag mehrdeutig oder fehlt etwas Wichtiges (Empfänger, Uhrzeit, Inhalt), stelle genau EINE kurze Rückfrage, statt zu raten. " +
            "Gehirn: Du hast ein dauerhaftes Gedächtnis. Sagt der Nutzer etwas Bleibendes über sich, seine Vorlieben, Kontakte (Spitznamen) oder Gewohnheiten, rufe remember auf. " +
            "Nutze dein Wissen aktiv und unaufdringlich. Handle nur, wenn der Nutzer es verlangt. " +
            "Das weißt du bisher über den Nutzer:\n${Brain.prompt()}\n" +
            "Aktuelle Zeit: $now."
    }

    fun chat(apiKey: String, history: JSONArray, onStatus: (String) -> Unit, runTool: (String, JSONObject) -> String): String {
        repeat(6) {
            onStatus("Denke nach …")
            val res = generate(apiKey, system(), tools, history, MODELS)
            val content = res.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                ?: return "Dazu habe ich keine Antwort bekommen."
            val parts = content.optJSONArray("parts") ?: JSONArray()
            history.put(JSONObject(content.toString()).put("role", "model"))

            val calls = (0 until parts.length()).map { parts.getJSONObject(it) }.filter { it.has("functionCall") }
            if (calls.isEmpty()) {
                val sb = StringBuilder()
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    if (p.has("text") && !p.optBoolean("thought")) sb.append(p.getString("text"))
                }
                return sb.toString().ifBlank { "Erledigt." }
            }
            val responses = JSONArray()
            val outs = ArrayList<String>()
            for (p in calls) {
                val fc = p.getJSONObject("functionCall")
                val name = fc.getString("name")
                val out = runTool(name, fc.optJSONObject("args") ?: JSONObject())
                outs.add(out)
                responses.put(JSONObject().put("functionResponse",
                    JSONObject().put("name", name).put("response", JSONObject().put("result", out))))
            }
            history.put(JSONObject().put("role", "user").put("parts", responses))
            // "INFO:"-Ergebnisse soll die KI noch in Worte fassen oder weiterverarbeiten
            if (outs.any { it.startsWith("INFO:") }) return@repeat
            val summary = outs.joinToString(" ")
            history.put(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", summary))))
            return summary
        }
        return "Das war mir zu viele Schritte auf einmal."
    }

    fun generate(apiKey: String, system: String, tools: JSONArray, history: JSONArray, models: List<String>): JSONObject {
        for (model in models) {
            for (attempt in 0..1) {
                try {
                    return call(apiKey, model, system, tools, history)
                } catch (e: ApiException) {
                    if (e.code == 404) break
                    if (e.code != 503 && e.code != 429 && e.code != 500) throw e
                    if (attempt == 0) Thread.sleep(700)
                }
            }
        }
        throw RuntimeException("Gemini ist gerade überlastet. Versuch es in ein paar Minuten nochmal.")
    }

    private fun call(apiKey: String, model: String, system: String, tools: JSONArray, history: JSONArray): JSONObject {
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", history)
            .put("generationConfig", JSONObject().put("maxOutputTokens", 700))
        if (tools.length() > 0) body.put("tools", tools)
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 10000
        conn.readTimeout = 40000
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-goog-api-key", apiKey)
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val ok = conn.responseCode in 200..299
        val text = (if (ok) conn.inputStream else conn.errorStream).bufferedReader().readText()
        if (!ok) throw ApiException(conn.responseCode, "API ${conn.responseCode}: $text")
        return JSONObject(text)
    }
}
