package com.boris.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object GeminiClient {
    private val MODELS = listOf("gemini-3.5-flash-lite", "gemini-flash-lite-latest", "gemini-flash-latest")

    class ApiException(val code: Int, msg: String) : RuntimeException(msg)

    private val tools = JSONArray(
        """[{"function_declarations":[
        {"name":"set_timer","description":"Stellt einen Countdown-Timer.",
         "parameters":{"type":"object","properties":{"seconds":{"type":"integer"},"label":{"type":"string"}},"required":["seconds"]}},
        {"name":"set_alarm","description":"Stellt einen Wecker (24h).",
         "parameters":{"type":"object","properties":{"hour":{"type":"integer"},"minute":{"type":"integer"},"label":{"type":"string"}},"required":["hour","minute"]}},
        {"name":"spotify_play","description":"Spielt in Spotify Song, Künstler, Album oder Playlist per Suchbegriff.",
         "parameters":{"type":"object","properties":{"query":{"type":"string"}},"required":["query"]}},
        {"name":"spotify_liked","description":"Spielt in Spotify die Lieblingssongs."},
        {"name":"open_app","description":"Öffnet eine App.",
         "parameters":{"type":"object","properties":{"app":{"type":"string"}},"required":["app"]}},
        {"name":"send_sms","description":"Sendet eine SMS direkt ab.",
         "parameters":{"type":"object","properties":{"contact":{"type":"string"},"text":{"type":"string"},"phone":{"type":"string"}},"required":["contact","text"]}},
        {"name":"send_whatsapp","description":"Sendet blitzschnell eine WhatsApp-Nachricht an einen Kontakt.",
         "parameters":{"type":"object","properties":{"contact":{"type":"string"},"text":{"type":"string"}},"required":["contact","text"]}},
        {"name":"reply_notification","description":"Antwortet direkt auf eine gerade offene Benachrichtigung (WhatsApp, Telegram, SMS …). Der schnellste Weg, wenn der Nutzer auf eine eingegangene Nachricht antworten will.",
         "parameters":{"type":"object","properties":{"contact":{"type":"string","description":"Absender laut Benachrichtigung"},"text":{"type":"string"}},"required":["contact","text"]}},
        {"name":"read_notifications","description":"Liest die aktuell offenen Benachrichtigungen vor bzw. fasst sie zusammen."},
        {"name":"phone_task","description":"Führt eine beliebige Aufgabe selbständig in Apps aus, in mehreren Schritten (öffnen, suchen, tippen, senden). Für Discord, Instagram, Telegram und alles ohne eigenes Werkzeug.",
         "parameters":{"type":"object","properties":{"task":{"type":"string","description":"Vollständige Aufgabe mit allen Details"},"app":{"type":"string","description":"App, die zuerst geöffnet werden soll"}},"required":["task"]}},
        {"name":"call_contact","description":"Ruft einen Kontakt an.",
         "parameters":{"type":"object","properties":{"contact":{"type":"string"}},"required":["contact"]}},
        {"name":"navigate","description":"Startet die Navigation zu einem Ziel.",
         "parameters":{"type":"object","properties":{"destination":{"type":"string"}},"required":["destination"]}},
        {"name":"web_answer","description":"Recherchiert aktuelle Informationen mit echter Google-Suche und gibt eine kurze Antwort: Wetter, Nachrichten, Sportergebnisse, Preise, Öffnungszeiten, aktuelle Fakten. Immer nutzen, wenn die Antwort von heute oder neu sein könnte.",
         "parameters":{"type":"object","properties":{"question":{"type":"string","description":"Die vollständige Frage"}},"required":["question"]}},
        {"name":"search_web","description":"Öffnet eine Google-Suche im Browser.",
         "parameters":{"type":"object","properties":{"query":{"type":"string"}},"required":["query"]}},
        {"name":"torch","description":"Schaltet die Taschenlampe an oder aus.",
         "parameters":{"type":"object","properties":{"on":{"type":"boolean"}},"required":["on"]}},
        {"name":"set_volume","description":"Stellt die Medienlautstärke in Prozent.",
         "parameters":{"type":"object","properties":{"percent":{"type":"integer"}},"required":["percent"]}},
        {"name":"set_reminder","description":"Erinnert den Nutzer später per Stimme. Entweder in_minutes oder at (HH:MM, 24h).",
         "parameters":{"type":"object","properties":{"text":{"type":"string"},"in_minutes":{"type":"integer"},"at":{"type":"string"}},"required":["text"]}},
        {"name":"watch_message","description":"Sagt Bescheid, sobald eine bestimmte Person schreibt (z.B. Erinner mich, wenn Mama zurückschreibt).",
         "parameters":{"type":"object","properties":{"contact":{"type":"string"},"say":{"type":"string","description":"Optionaler Satz, den Boris sagen soll"}},"required":["contact"]}},
        {"name":"set_routine","description":"Legt eine Routine an: trigger ist 'daily HH:MM' (täglich) oder 'charging' (wenn das Handy geladen wird). action ist der Auftrag, den Boris dann ausführt (z.B. ein Morgenbriefing mit Datum, Terminen und offenen Benachrichtigungen).",
         "parameters":{"type":"object","properties":{"trigger":{"type":"string"},"action":{"type":"string"}},"required":["trigger","action"]}},
        {"name":"list_tasks","description":"Listet geplante Erinnerungen, Beobachtungen und Routinen."},
        {"name":"cancel_task","description":"Löscht geplante Aufgaben, die das Stichwort enthalten.",
         "parameters":{"type":"object","properties":{"keyword":{"type":"string"}},"required":["keyword"]}},
        {"name":"read_calendar","description":"Liest die Kalendertermine der nächsten Tage.",
         "parameters":{"type":"object","properties":{"days":{"type":"integer"}}}},
        {"name":"mute_notifications","description":"Boris liest Benachrichtigungen automatisch vor. Dieses Werkzeug schaltet eine Quelle stumm. target leer = die zuletzt vorgelesene Quelle (Absender, sonst App); 'alle' = alles. minutes optional (0 = dauerhaft).",
         "parameters":{"type":"object","properties":{"target":{"type":"string"},"minutes":{"type":"integer"}}}},
        {"name":"unmute_notifications","description":"Hebt das Stummschalten wieder auf. target 'alle' hebt alles auf.",
         "parameters":{"type":"object","properties":{"target":{"type":"string"}},"required":["target"]}},
        {"name":"remember","description":"Speichert einen dauerhaften Fakt im Gehirn (Vorlieben, Kontakte/Spitznamen, Gewohnheiten, Wichtiges).",
         "parameters":{"type":"object","properties":{"fact":{"type":"string"},"category":{"type":"string","description":"person, vorliebe, gewohnheit, wichtig, app oder allgemein"}},"required":["fact"]}},
        {"name":"forget","description":"Löscht Fakten aus dem Gehirn, die das Stichwort enthalten.",
         "parameters":{"type":"object","properties":{"keyword":{"type":"string"}},"required":["keyword"]}},
        {"name":"learning_report","description":"Berichtet, was Boris in seinen Ruhephasen selbstständig gelernt hat und woran er gerade lernt. Nutzen bei Fragen wie 'was hast du gelernt?'."},
        {"name":"learn_topic","description":"Merkt ein Thema vor, das Boris in seiner nächsten Ruhephase gründlich recherchieren und lernen soll (z. B. 'lern mehr über Photovoltaik').",
         "parameters":{"type":"object","properties":{"topic":{"type":"string"}},"required":["topic"]}}
        ]}]"""
    )

    private fun system(query: String = ""): String {
        val now = SimpleDateFormat("EEEE, dd.MM.yyyy HH:mm", Locale.GERMAN).format(Date())
        return "Du bist Boris, ein souveräner, trocken-humorvoller KI-Assistent im Stil von J.A.R.V.I.S., auf dem Android-Handy des Nutzers. " +
            "Du sprichst Deutsch, knapp (höchstens 2 Sätze) und gut vorlesbar. " +
            "Handle sofort mit den Werkzeugen. Nimm den schnellsten passenden Weg: eigene Werkzeuge vor phone_task. " +
            "Auf eingehende Nachrichten antwortest du mit reply_notification. Für Fragen zu Benachrichtigungen nutze read_notifications. " +
            "Zeit: Erinnerungen mit set_reminder, ‚sag Bescheid, wenn X schreibt‘ mit watch_message, Routinen und Morgenbriefing mit set_routine, Termine mit read_calendar. " +
            "Für aktuelle Fakten nutze web_answer statt zu raten; search_web nur, wenn der Nutzer die Suche im Browser sehen will. " +
            "Benachrichtigungen liest du automatisch jedem vor, ohne zu antworten. Sagt der Nutzer so etwas wie lass das, sei still oder ignoriere den Absender, nutze mute_notifications. " +
            "Rückfragen: Ist ein Auftrag mehrdeutig oder fehlt etwas Wichtiges (Empfänger, Uhrzeit, Inhalt), stelle genau EINE kurze Rückfrage, statt zu raten. " +
            "Gehirn: Du hast ein dauerhaftes Gedächtnis. Sagt der Nutzer etwas Bleibendes über sich, seine Vorlieben, Kontakte (Spitznamen) oder Gewohnheiten, rufe remember auf. " +
            "Nutze dein Wissen aktiv und unaufdringlich. Handle nur, wenn der Nutzer es verlangt. " +
            "Das weißt du bisher über den Nutzer:\n${Brain.prompt()}\n" +
            Learner.prompt(query) +
            "Aktuelle Zeit: $now."
    }

    private fun lastUserText(h: JSONArray): String {
        for (i in h.length() - 1 downTo 0) {
            val o = h.optJSONObject(i) ?: continue
            if (o.optString("role") != "user") continue
            val p = o.optJSONArray("parts") ?: continue
            for (j in 0 until p.length()) { val t = p.optJSONObject(j)?.optString("text", "") ?: ""; if (t.isNotBlank()) return t }
        }
        return ""
    }

    fun chat(apiKey: String, history: JSONArray, onStatus: (String) -> Unit, runTool: (String, JSONObject) -> String): String {
        repeat(6) {
            onStatus("Denke nach …")
            val res = generate(apiKey, system(lastUserText(history)), tools, history, MODELS)
            val content = res.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                ?: return "Dazu habe ich keine Antwort bekommen."
            val parts = content.optJSONArray("parts") ?: JSONArray()
            history.put(JSONObject(content.toString()).put("role", "model"))

            val calls = (0 until parts.length()).map { parts.getJSONObject(it) }.filter { it.has("functionCall") }
            if (calls.isEmpty()) {
                val sb = StringBuilder()
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    if (p.has("text") && !p.optBoolean("thought")) sb.append(p.getString("text"))
                }
                return sb.toString().ifBlank { "Erledigt." }
            }
            val responses = JSONArray()
            val outs = ArrayList<String>()
            for (p in calls) {
                val fc = p.getJSONObject("functionCall")
                val name = fc.getString("name")
                val out = runTool(name, fc.optJSONObject("args") ?: JSONObject())
                outs.add(out)
                responses.put(JSONObject().put("functionResponse",
                    JSONObject().put("name", name).put("response", JSONObject().put("result", out))))
            }
            history.put(JSONObject().put("role", "user").put("parts", responses))
            outs.firstOrNull { it.startsWith("ASK:") }?.let { q ->
                val ask = q.removePrefix("ASK:").trim()
                history.put(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", ask))))
                return ask
            }
            // "INFO:"-Ergebnisse soll die KI noch in Worte fassen oder weiterverarbeiten
            if (outs.any { it.startsWith("INFO:") }) return@repeat
            val summary = outs.joinToString(" ")
            history.put(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", summary))))
            return summary
        }
        return "Das war mir zu viele Schritte auf einmal."
    }

    class Cancelled : RuntimeException("abgebrochen")

    fun generate(apiKey: String, system: String, tools: JSONArray, history: JSONArray, models: List<String>,
                 onConn: ((HttpURLConnection) -> Unit)? = null, cancelled: () -> Boolean = { false }): JSONObject {
        for (model in models) {
            for (attempt in 0..1) {
                if (cancelled()) throw Cancelled()
                try {
                    return call(apiKey, model, system, tools, history, onConn)
                } catch (e: Cancelled) { throw e
                } catch (e: java.io.IOException) {
                    if (cancelled()) throw Cancelled() else throw e
                } catch (e: ApiException) {
                    if (e.code == 404) break
                    if (e.code != 503 && e.code != 429 && e.code != 500) throw e
                    if (attempt == 0) Thread.sleep(700)
                }
            }
        }
        throw RuntimeException("Gemini ist gerade überlastet. Versuch es in ein paar Minuten nochmal.")
    }

    private fun call(apiKey: String, model: String, system: String, tools: JSONArray, history: JSONArray,
                     onConn: ((HttpURLConnection) -> Unit)? = null): JSONObject {
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", history)
            .put("generationConfig", JSONObject().put("maxOutputTokens", 700))
        if (tools.length() > 0) body.put("tools", tools)
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 10000
        conn.readTimeout = 40000
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-goog-api-key", apiKey)
        conn.doOutput = true
        onConn?.invoke(conn)
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val ok = conn.responseCode in 200..299
        val text = (if (ok) conn.inputStream else conn.errorStream).bufferedReader().readText()
        if (!ok) throw ApiException(conn.responseCode, "API ${conn.responseCode}: $text")
        return JSONObject(text)
    }
}
