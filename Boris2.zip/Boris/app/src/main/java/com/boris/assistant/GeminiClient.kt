package com.boris.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object GeminiClient {
    // Schnellste zuerst; die anderen sind Ausweichmodelle bei Überlastung.
    private val MODELS = listOf("gemini-3.5-flash-lite", "gemini-flash-lite-latest", "gemini-flash-latest")

    class ApiException(val code: Int, msg: String) : RuntimeException(msg)

    private val tools = JSONArray(
        """[{"function_declarations":[
        {"name":"set_timer","description":"Stellt einen Countdown-Timer.",
         "parameters":{"type":"object","properties":{
           "seconds":{"type":"integer","description":"Dauer in Sekunden"},
           "label":{"type":"string"}},"required":["seconds"]}},
        {"name":"set_alarm","description":"Stellt einen Wecker zu einer Uhrzeit (24h).",
         "parameters":{"type":"object","properties":{
           "hour":{"type":"integer"},"minute":{"type":"integer"},
           "label":{"type":"string"}},"required":["hour","minute"]}},
        {"name":"spotify_play","description":"Spielt in Spotify einen Song, Künstler, Album oder eine Playlist anhand eines Suchbegriffs.",
         "parameters":{"type":"object","properties":{
           "query":{"type":"string","description":"z.B. Songname, Künstler oder Playlist-Name"}},"required":["query"]}},
        {"name":"spotify_liked","description":"Öffnet in Spotify die Lieblingssongs (Liked Songs) und startet die Wiedergabe."},
        {"name":"open_app","description":"Öffnet eine App auf dem Handy.",
         "parameters":{"type":"object","properties":{
           "app":{"type":"string","description":"spotify, discord, whatsapp, telegram, instagram, youtube, maps, chrome, kamera, einstellungen"}},"required":["app"]}},
        {"name":"send_message","description":"Bereitet eine Nachricht in einer Messenger-App vor (discord, whatsapp, telegram, instagram, signal, sms). Der Nutzer wählt den Empfänger selbst und tippt auf Senden, außer bei sms mit Telefonnummer.",
         "parameters":{"type":"object","properties":{
           "app":{"type":"string"},
           "text":{"type":"string","description":"Nachrichtentext"},
           "phone":{"type":"string","description":"Nur für sms: Telefonnummer, falls bekannt"}},"required":["app","text"]}}
        ]}]"""
    )

    private fun system(): String {
        val now = SimpleDateFormat("EEEE, dd.MM.yyyy HH:mm", Locale.GERMAN).format(Date())
        return "Du bist Boris, der persönliche Sprachassistent auf dem Android-Handy des Nutzers. " +
            "Antworte sehr kurz (1-2 Sätze) und auf Deutsch, gut vorlesbar. " +
            "Handle sofort mit den Tools, statt nachzufragen: Timer, Wecker, Spotify, Apps öffnen, Nachrichten vorbereiten. " +
            "Wichtig: Nachrichten werden nur vorbereitet; der Nutzer wählt den Empfänger und tippt selbst auf Senden. " +
            "Sage das kurz dazu. Aktuelle Zeit: $now."
    }

    fun chat(apiKey: String, history: JSONArray, runTool: (String, JSONObject) -> String): String {
        repeat(6) {
            val res = post(apiKey, history)
            val content = res.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                ?: return "Dazu habe ich keine Antwort bekommen."
            val parts = content.optJSONArray("parts") ?: JSONArray()
            history.put(JSONObject(content.toString()).put("role", "model"))

            val calls = (0 until parts.length()).map { parts.getJSONObject(it) }.filter { it.has("functionCall") }
            if (calls.isEmpty()) {
                val sb = StringBuilder()
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    if (p.has("text") && !p.optBoolean("thought")) sb.append(p.getString("text"))
                }
                return sb.toString().ifBlank { "Erledigt." }
            }
            val responses = JSONArray()
            for (p in calls) {
                val fc = p.getJSONObject("functionCall")
                val name = fc.getString("name")
                val out = runTool(name, fc.optJSONObject("args") ?: JSONObject())
                responses.put(JSONObject().put("functionResponse",
                    JSONObject().put("name", name).put("response", JSONObject().put("result", out))))
            }
            history.put(JSONObject().put("role", "user").put("parts", responses))
        }
        return "Das war mir zu viele Schritte auf einmal."
    }

    private fun post(apiKey: String, history: JSONArray): JSONObject {
        for (model in MODELS) {
            for (attempt in 0..1) {
                try {
                    return call(apiKey, model, history)
                } catch (e: ApiException) {
                    if (e.code == 404) break // Modell nicht verfügbar -> nächstes Modell
                    if (e.code != 503 && e.code != 429 && e.code != 500) throw e
                    if (attempt == 0) Thread.sleep(700)
                }
            }
        }
        throw RuntimeException("Gemini ist gerade überlastet. Versuch es in ein paar Minuten nochmal.")
    }

    private fun call(apiKey: String, model: String, history: JSONArray): JSONObject {
        val gen = JSONObject().put("maxOutputTokens", 400)
        if (model == "gemini-2.5-flash") gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system()))))
            .put("contents", history)
            .put("tools", tools)
            .put("generationConfig", gen)
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 10000
        conn.readTimeout = 30000
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-goog-api-key", apiKey)
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val ok = conn.responseCode in 200..299
        val text = (if (ok) conn.inputStream else conn.errorStream).bufferedReader().readText()
        if (!ok) throw ApiException(conn.responseCode, "API ${conn.responseCode}: $text")
        return JSONObject(text)
    }
}
