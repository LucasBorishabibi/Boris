package com.boris.assistant

import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/** Ringpuffer der zuletzt abgespielten PCM-Samples (16 Bit, mono, little endian), absolut indiziert. */
class PcmRing(capacity: Int) {
    private val cap = max(1, capacity)
    private val buf = ShortArray(cap)
    @Volatile var written = 0L
        private set

    @Synchronized
    fun push(b: ByteArray, off: Int, len: Int) {
        var i = off
        val end = off + (len and 1.inv())
        var w = written
        while (i < end) {
            buf[(w % cap).toInt()] = ((b[i].toInt() and 0xFF) or (b[i + 1].toInt() shl 8)).toShort()
            w++; i += 2
        }
        written = w
    }

    /** Füllt out mit den Samples direkt vor endFrame. Fehlende Samples bleiben 0. Gibt false zurück, wenn gar nichts da war. */
    @Synchronized
    fun window(endFrame: Long, out: FloatArray): Boolean {
        val end = min(endFrame, written)
        val n = out.size
        var any = false
        for (k in 0 until n) {
            val idx = end - n + k
            if (idx < 0 || idx < written - cap) out[k] = 0f
            else { out[k] = buf[(idx % cap).toInt()] / 32768f; any = true }
        }
        return any
    }
}

/**
 * Liest aus dem, was Boris gerade wirklich sagt (an der Abspielposition, nicht am Download),
 * Merkmale für das Gesicht. Alle Werte sind weich und liegen in 0..1 (pitch in -1..1).
 * Wird von genau einem Mess-Thread befüllt, das UI liest nur.
 */
class VoiceAnalyzer {
    @Volatile var level = 0f          // schneller Pegel (Silbenebene)
    @Volatile var body = 0f           // langsame Hüllkurve (Satzebene)
    @Volatile var bright = 0f         // hell/zischend (s, sch, f) gegen dunkel/vokalisch
    @Volatile var pitch = 0f          // Tonhöhe relativ zur eigenen Stimmlage, -1 tiefer .. +1 höher
    @Volatile var voiced = 0f         // stimmhaft
    @Volatile var tempo = 0f          // 0 langsam .. 1 schnell (Silben pro Sekunde)
    @Volatile var silence = 0f        // Sekunden seit der letzten hörbaren Stelle
    @Volatile var onsetSeq = 0        // zählt jede neue Silbe hoch
    @Volatile var onsetStrength = 0f  // Stärke dieser Silbe

    private val win = FloatArray(1024)             // ~43 ms bei 24 kHz
    private val dec = FloatArray(1024 / 3)         // auf 8 kHz heruntergerechnet für die Tonhöhe
    private val nr = FloatArray(MAX_LAG + 2)
    private var peak = 0.15f
    private var pitchMean = 0f
    private var prevLv = 0f
    private var valley = 0f
    private var sinceOnset = 1f
    private var clock = 0f
    private var quiet = 0f
    private val onsetTimes = FloatArray(16) { -10f }
    private var onsetIdx = 0
    // Ersatz-Sprachmuster für die Handy-Stimme (liefert keine Samples)
    private var synTarget = 0f
    private var synTimer = 0f
    private var synWords = 3
    private val rnd = java.util.Random()

    private companion object {
        const val LEAD = 480       // ~20 ms vorausschauen, damit das Gesicht nicht hinterherhinkt
        const val MIN_LAG = 27     // ~300 Hz bei 8 kHz
        const val MAX_LAG = 114    // ~70 Hz
        const val GATE = 0.005f
    }

    /** Vor jeder neuen Wiedergabe: Lernwerte zurücksetzen. */
    fun reset() {
        peak = 0.15f; pitchMean = 0f; prevLv = 0f; valley = 0f; sinceOnset = 1f; clock = 0f; quiet = 0f
        onsetTimes.fill(-10f); synTarget = 0f; synTimer = 0f; synWords = 3
        idle()
    }

    /** Alles auf Ruhe (Ende der Wiedergabe). */
    fun idle() {
        level = 0f; body = 0f; bright = 0f; pitch = 0f; voiced = 0f; tempo = 0f; silence = 0f; onsetStrength = 0f
    }

    /** Eine Messung an der aktuellen Abspielposition. ring == null heißt: gerade Stille / Wiedergabe steht. */
    fun update(ring: PcmRing?, headFrame: Long, dt: Float) {
        var rms = 0f
        var zcr = 0f
        var hz = 0f
        if (ring != null && ring.window(headFrame + LEAD, win)) {
            var sum = 0f
            var zc = 0
            for (i in win.indices) sum += win[i] * win[i]
            for (i in 1 until win.size) if ((win[i - 1] < 0f) != (win[i] < 0f)) zc++
            rms = sqrt(sum / win.size)
            zcr = zc.toFloat() / win.size
            if (rms > GATE) hz = estimatePitch()
        }
        val gated = rms > GATE
        var lv = if (gated) (rms / peak).coerceIn(0f, 1f) else 0f
        if (gated) peak = max(0.05f, max(peak * exp(-dt / 8f), rms)) else peak = max(0.05f, peak * exp(-dt / 8f))
        lv = lv.pow(0.75f)
        val brightT = if (gated) ((zcr - 0.05f) / 0.25f).coerceIn(0f, 1f) else 0f
        var rel: Float? = null
        if (hz > 0f) {
            pitchMean = if (pitchMean == 0f) hz else pitchMean + (hz - pitchMean) * 0.03f
            rel = ((hz - pitchMean) / pitchMean * 2.2f).coerceIn(-1f, 1f)
        }
        publish(lv, brightT, rel, dt)
    }

    /** Autokorrelation auf 8 kHz: liefert die Grundfrequenz oder 0, wenn stimmlos. */
    private fun estimatePitch(): Float {
        val n = dec.size
        for (i in 0 until n) dec[i] = (win[3 * i] + win[3 * i + 1] + win[3 * i + 2]) / 3f
        var r0 = 0f
        for (i in 0 until n) r0 += dec[i] * dec[i]
        if (r0 < 1e-6f) return 0f
        var gm = 0f
        for (lag in MIN_LAG..MAX_LAG) {
            var r = 0f
            for (i in 0 until n - lag) r += dec[i] * dec[i + lag]
            val v = r / (r0 * (n - lag) / n)
            nr[lag] = v
            if (v > gm) gm = v
        }
        if (gm < 0.5f) return 0f
        // kleinste Periode, die fast so gut ist wie die beste (vermeidet Oktavsprünge nach unten)
        for (lag in MIN_LAG + 1 until MAX_LAG) {
            if (nr[lag] >= gm * 0.85f && nr[lag] >= nr[lag - 1] && nr[lag] >= nr[lag + 1]) return 8000f / lag
        }
        return 0f
    }

    private fun publish(lv: Float, brightT: Float, pitchRel: Float?, dt: Float) {
        clock += dt; sinceOnset += dt
        level += (lv - level) * (1f - exp(-dt * (if (lv > level) 45f else 14f)))
        body += (lv - body) * (1f - exp(-dt * (if (lv > body) 10f else 3.5f)))
        bright += (brightT - bright) * (1f - exp(-dt * (if (brightT > bright) 14f else 6f)))
        if (pitchRel != null) {
            pitch += (pitchRel - pitch) * (1f - exp(-dt * 10f))
            voiced += (1f - voiced) * (1f - exp(-dt * 12f))
        } else {
            pitch *= exp(-dt * 1.5f)
            voiced += (0f - voiced) * (1f - exp(-dt * 12f))
        }
        // Silben-Einsatz = deutlicher Anstieg nach einer Senke
        valley = min(valley, lv)
        if (lv - valley > 0.28f && lv > prevLv && sinceOnset > 0.11f) {
            onsetStrength = ((lv - valley) * 1.2f).coerceIn(0.25f, 1f)
            onsetSeq++
            onsetTimes[onsetIdx % onsetTimes.size] = clock
            onsetIdx++
            sinceOnset = 0f
            valley = lv
        }
        prevLv = lv
        var n = 0
        for (t in onsetTimes) if (clock - t < 1.6f) n++
        val tempoT = ((n / 1.6f - 1.5f) / 4.5f).coerceIn(0f, 1f)
        tempo += (tempoT - tempo) * (1f - exp(-dt * 2f))
        if (level > 0.14f) quiet = 0f else quiet += dt
        silence = quiet
    }

    /** Plausibles Sprechmuster, wenn nur die Handy-Stimme spricht und keine Samples vorliegen. */
    fun synth(dt: Float) {
        synTimer -= dt
        if (synTimer <= 0f) {
            if (synWords-- <= 0) {
                synTimer = 0.28f + rnd.nextFloat() * 0.3f; synWords = 3 + rnd.nextInt(5); synTarget = 0f
            } else {
                synTimer = 0.14f + rnd.nextFloat() * 0.12f; synTarget = 0.45f + rnd.nextFloat() * 0.55f
            }
        }
        val lv = synTarget
        synTarget *= exp(-dt * 7f)
        val rel = if (lv > 0.1f) (rnd.nextFloat() - 0.5f) * 1.2f else null
        publish(lv, if (lv > 0.1f) rnd.nextFloat() * 0.6f else 0f, rel, dt)
    }
}
