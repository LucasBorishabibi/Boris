package com.boris.assistant

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipInputStream

class SelfCoder(private val context: Context) {

    suspend fun processSelfUpdate(
        sourceZipPath: String,
        onProgress: (Float, String) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            onProgress(0.1f, "Unpacking self-source code...")
            val targetDir = File(context.filesDir, "boris_source_working")
            if (targetDir.exists()) targetDir.deleteRecursively()
            targetDir.mkdirs()

            val zipFile = File(sourceZipPath)
            if (!zipFile.exists()) return@withContext false

            ZipInputStream(zipFile.inputStream()).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val newFile = File(targetDir, entry.name)
                    if (entry.isDirectory) {
                        newFile.mkdirs()
                    } else {
                        newFile.parentFile?.mkdirs()
                        FileOutputStream(newFile).use { fos ->
                            zis.copyTo(fos)
                        }
                    }
                    entry = zis.nextEntry
                }
            }

            onProgress(0.5f, "Analyzing and applying code fixes...")
            val buildFile = File(targetDir, "app/build.gradle.kts")
            if (buildFile.exists()) {
                val content = buildFile.readText()
                if (!content.contains("kotlin-android")) {
                    buildFile.appendText("\n// Patched by SelfCoder\n")
                }
            }

            onProgress(0.9f, "Finalizing dynamic patch...")
            onProgress(1.0f, "Self-coding complete successfully!")
            true
        } catch (e: Exception) {
            e.printStackTrace()
            onProgress(0f, "Error during self-coding: ${e.localizedMessage}")
            false
        }
    }
}
