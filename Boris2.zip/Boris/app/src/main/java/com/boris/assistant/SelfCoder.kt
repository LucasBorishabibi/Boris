package com.boris.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Boris' eigener Entwicklungsarbeitsplatz.
 *
 * Wichtig: Der Workspace ist eine verwaltete Kopie des Quellprojekts. Eine laufende
 * Android-APK ersetzt ihren eigenen Code nicht. Änderungen werden daher atomar in
 * diesem Workspace committed und als "build pending" markiert. Vor jedem Commit
 * existiert ein vollständiger Snapshot, der bei Validierungsfehlern wiederhergestellt
 * werden kann.
 */
object SelfCoder {
    private const val PREF = "boris_self_code"
    private const val VERSION = 1
    private const val MAX_AUTONOMOUS_PER_DAY = 3
    private const val AUTONOMOUS_GAP = 30 * 60 * 1000L

    private val allowedRoots = listOf(
        "app/src/main/java/",
        "app/src/main/res/",
        "app/src/main/AndroidManifest.xml",
        "app/build.gradle.kts",
        "build.gradle.kts",
        "settings.gradle.kts",
        "gradle.properties"
    )

    @Volatile private var running = false
    @Volatile private var cancelFlag = false

    private fun prefs(c: Context) = c.getSharedPreferences(PREF, 0)
    private fun root(c: Context) = File(c.filesDir, "boris-self-code")
    private fun source(c: Context) = File(root(c), "workspace")
    private fun versions(c: Context) = File(root(c), "versions")
    private fun journal(c: Context) = File(root(c), "journal.json")
    private fun now() = System.currentTimeMillis()

    fun init(c0: Context) {
        val c = c0.applicationContext
        try {
            root(c).mkdirs(); versions(c).mkdirs()
            if (!source(c).isDirectory || File(root(c), "workspace.meta").readTextOrNull() != "v$VERSION") {
                seed(c)
            }
            if (!journal(c).exists()) journal(c).writeText("[]")
        } catch (e: Exception) {
            Dbg.d("SelfCoding init: ${e.message?.take(100)}")
        }
    }

    private fun seed(c: Context) {
        val target = source(c)
        val tmp = File(root(c), "seed-tmp")
        target.deleteRecursively(); tmp.deleteRecursively()
        target.mkdirs()
        tmp.mkdirs()
        try {
            c.assets.open("boris_source.zip").use { input ->
                unzip(input, tmp)
            }
            // The build task packages the Boris project root itself.
            val actual = if (File(tmp, "Boris").isDirectory) File(tmp, "Boris") else tmp
            copyTree(actual, target)
            File(root(c), "workspace.meta").writeText("v$VERSION")
            Dbg.d("SelfCoding: Source-Workspace initialisiert.")
        } catch (e: Exception) {
            target.deleteRecursively()
            Dbg.d("SelfCoding: kein Source-Snapshot im APK: ${e.message?.take(120)}")
        } finally {
            tmp.deleteRecursively()
        }
    }

    private fun unzip(input: java.io.InputStream, target: File) {
        ZipInputStream(input.buffered()).use { zis ->
            var e = zis.nextEntry
            while (e != null) {
                val out = File(target, e.name)
                if (!isSafeZipPath(target, out)) throw SecurityException("Unsicherer Zip-Pfad")
                if (e.isDirectory) out.mkdirs() else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { zis.copyTo(it) }
                }
                e = zis.nextEntry
            }
        }
    }

    private fun isSafeZipPath(base: File, f: File): Boolean {
        val b = base.canonicalPath + File.separator
        return f.canonicalPath.startsWith(b)
    }

    private fun copyTree(from: File, to: File) {
        if (from.isDirectory) {
            to.mkdirs()
            from.listFiles()?.forEach { copyTree(it, File(to, it.name)) }
        } else {
            to.parentFile?.mkdirs()
            from.copyTo(to, true)
        }
    }

    private fun rel(f: File, c: Context): String =
        f.relativeTo(source(c)).path.replace(File.separatorChar, '/')

    private fun validPath(path: String): Boolean {
        if (path.isBlank() || path.startsWith("/") || path.contains("..") || path.contains("\\") ||
            path.contains("\u0000") || path.startsWith(".git/")) return false
        return allowedRoots.any { path == it.removeSuffix("/") || path.startsWith(it) }
    }

    private fun read(c: Context, path: String): String? {
        if (!validPath(path)) return null
        val f = File(source(c), path)
        return if (f.isFile) f.readText(Charsets.UTF_8) else null
    }

    private fun snapshot(c: Context, label: String): File {
        val out = File(versions(c), "${now()}-${label.replace(Regex("[^A-Za-z0-9_-]"), "_")}.zip")
        zipTree(source(c), out)
        return out
    }

    private fun zipTree(dir: File, out: File) {
        ZipOutputStream(FileOutputStream(out).buffered()).use { zos ->
            if (!dir.exists()) return
            dir.walkTopDown().filter { it.isFile }.forEach { f ->
                val entry = ZipEntry(f.relativeTo(dir).path.replace(File.separatorChar, '/'))
                zos.putNextEntry(entry)
                FileInputStream(f).use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
    }

    private fun restore(c: Context, zip: File) {
        val tmp = File(root(c), "rollback-tmp")
        tmp.deleteRecursively(); tmp.mkdirs()
        zip.inputStream().use { unzip(it, tmp) }
        source(c).deleteRecursively()
        source(c).mkdirs()
        copyTree(tmp, source(c))
        tmp.deleteRecursively()
    }

    private fun appendJournal(c: Context, item: JSONObject) {
        val a = try { JSONArray(journal(c).readText()) } catch (_: Exception) { JSONArray() }
        a.put(item)
        // Behalte die letzten 100 Einträge (nicht nur einen löschen und abbrechen)
        if (a.length() > 100) {
            val keep = JSONArray()
            for (i in a.length() - 100 until a.length()) keep.put(a.getJSONObject(i))
            journal(c).writeText(keep.toString())
        } else {
            journal(c).writeText(a.toString())
        }
    }

    private fun setPending(c: Context, pending: Boolean, summary: String = "") {
        prefs(c).edit()
            .putBoolean("build_pending", pending)
            .putString("last_summary", summary.take(500))
            .putLong("last_change", now())
            .apply()
    }

    fun buildPending(c: Context): Boolean = prefs(c).getBoolean("build_pending", false)

    fun interrupt() {
        cancelFlag = true
    }

    fun status(c0: Context): String {
        val c = c0.applicationContext
        init(c)
        val count = source(c).walkTopDown().count { it.isFile }
        val last = prefs(c).getLong("last_change", 0L)
        val pending = if (buildPending(c)) "Build ausstehend" else "kein Build ausstehend"
        return "Self-Coding: $count Quelldateien, $pending" +
            if (last > 0) ", letzte Änderung vor ${(now() - last) / 60000} Min." else ""
    }

    fun history(c0: Context): String {
        val c = c0.applicationContext
        init(c)
        val a = try { JSONArray(journal(c).readText()) } catch (_: Exception) { JSONArray() }
        if (a.length() == 0) return "Noch keine Self-Coding-Änderungen."
        val sb = StringBuilder()
        for (i in (a.length() - 1).downTo(maxOf(0, a.length() - 8))) {
            val o = a.getJSONObject(i)
            sb.append(o.optString("time")).append(" — ")
                .append(o.optString("summary")).append(" [")
                .append(o.optString("result")).append("]\n")
        }
        return sb.toString().trim()
    }

    fun exportWorkspace(c0: Context): String {
        val c = c0.applicationContext
        init(c)
        val dir = c.getExternalFilesDir("BorisSelfCode") ?: return "Fehler: Kein externer App-Speicher verfügbar."
        dir.mkdirs()
        val out = File(dir, "boris-source-pending.zip")
        return try {
            zipTree(source(c), out)
            "Source-Workspace exportiert: ${out.absolutePath}"
        } catch (e: Exception) {
            "Fehler: Export fehlgeschlagen: ${e.message}"
        }
    }

    fun rollbackLast(c0: Context): String {
        val c = c0.applicationContext
        init(c)
        val files = versions(c).listFiles()?.filter { it.isFile && it.extension == "zip" }?.sortedByDescending { it.name }
            ?: emptyList()
        val backup = files.firstOrNull() ?: return "Kein Rollback-Snapshot vorhanden."
        return try {
            restore(c, backup)
            setPending(c, true, "Rollback auf ${backup.name}")
            appendJournal(c, JSONObject()
                .put("time", now()).put("summary", "Rollback auf ${backup.name}")
                .put("result", "rollback").put("snapshot", backup.name))
            "Rollback ausgeführt. Die wiederhergestellte Version ist für den nächsten Build vorgemerkt."
        } catch (e: Exception) {
            "Fehler: Rollback fehlgeschlagen: ${e.message}"
        }
    }

    fun applyInstruction(c0: Context, instruction: String, autonomous: Boolean = false): String {
        val c = c0.applicationContext
        init(c)
        if (running) return "INFO: Self-Coding läuft bereits."
        val geminiKey = Core.key(c).trim()
        val freeKey = c.getSharedPreferences("boris", 0).getString("openrouter_key", "")?.trim().orEmpty()
        if (geminiKey.isBlank() && freeKey.isBlank()) return "Fehler: Für Self-Coding fehlt Gemini- oder OpenRouter-Key."
        if (source(c).walkTopDown().none { it.isFile }) return "Fehler: Kein eigener Source-Workspace vorhanden."
        if (instruction.isBlank()) return "Fehler: Keine Änderungsanweisung angegeben."

        running = true
        cancelFlag = false
        var before: File? = null
        return try {
            val plan = askPlan(c, instruction)
                ?: return "Fehler: Boris konnte keinen Änderungsplan erstellen (Modell-Antwort ungültig oder abgebrochen)."
            val paths = plan.optJSONArray("files") ?: JSONArray()
            if (paths.length() == 0) return "INFO: Keine betroffenen Dateien gefunden."
            val selected = LinkedHashMap<String, String>()
            for (i in 0 until paths.length()) {
                val p = paths.optString(i).trim().replace('\\', '/')
                if (!validPath(p)) return "Fehler: Ungültiger Dateipfad im Änderungsplan: $p"
                val content = read(c, p)
                if (content != null) selected[p] = content
            }
            if (selected.isEmpty()) return "Fehler: Die geplanten Dateien sind im Workspace nicht vorhanden."
            if (cancelFlag) return "INFO: Self-Coding wurde unterbrochen."

            val patch = askPatch(c, instruction, plan, selected)
                ?: return "Fehler: Kein gültiger Änderungsentwurf erhalten (Modell-Antwort ungültig oder zu kurz)."
            if (cancelFlag) return "INFO: Self-Coding wurde unterbrochen."
            val changes = patch.optJSONArray("changes") ?: JSONArray()
            if (changes.length() == 0) return "INFO: Der Änderungsentwurf enthält keine Änderungen."

            before = snapshot(c, if (autonomous) "auto-before" else "before")
            if (cancelFlag) return "INFO: Self-Coding wurde vor dem Commit unterbrochen."
            val changed = ArrayList<String>()
            for (i in 0 until changes.length()) {
                val ch = changes.getJSONObject(i)
                val path = ch.optString("path").trim().replace('\\', '/')
                val op = ch.optString("op", "replace").lowercase()
                if (!validPath(path)) throw SecurityException("Nicht erlaubter Pfad: $path")
                when (op) {
                    "replace", "add" -> {
                        val content = ch.optString("content", "")
                        if (content.length > 500_000) throw IllegalArgumentException("Datei zu groß")
                        File(source(c), path).apply { parentFile?.mkdirs(); writeText(content, Charsets.UTF_8) }
                        changed.add("$op:$path")
                    }
                    "replace_text" -> {
                        val f = File(source(c), path)
                        if (!f.isFile) throw IllegalArgumentException("Datei für replace_text nicht vorhanden: $path")
                        val oldText = ch.optString("find", "")
                        val newText = ch.optString("replace", "")
                        if (oldText.isBlank()) throw IllegalArgumentException("replace_text ohne find für $path")
                        val current = f.readText(Charsets.UTF_8)
                        // Zuerst exakter Treffer; falls Whitespace-Unterschiede, normalisierter Fallback
                        val exact = countOccurrences(current, oldText)
                        when {
                            exact == 1 -> f.writeText(current.replaceFirst(oldText, newText), Charsets.UTF_8)
                            exact > 1 -> throw IllegalArgumentException(
                                "replace_text in $path: find kommt $exact-mal vor (muss eindeutig sein). Wähle einen längeren Kontext.")
                            else -> {
                                // Sanfter Fallback: nur wenn find nach Trim-Normalisierung genau einmal passt
                                val soft = softReplaceOnce(current, oldText, newText)
                                    ?: throw IllegalArgumentException(
                                        "replace_text in $path: find-Ausschnitt nicht gefunden. Modell muss exakten Code liefern.")
                                f.writeText(soft, Charsets.UTF_8)
                            }
                        }
                        changed.add("replace_text:$path")
                    }
                    "delete" -> {
                        val f = File(source(c), path)
                        if (f.exists()) f.delete()
                        changed.add("delete:$path")
                    }
                    else -> throw IllegalArgumentException("Unbekannte Operation: $op")
                }
            }

            val validation = validate(c, changed)
            if (!validation.first) {
                restore(c, before)
                appendJournal(c, JSONObject().put("time", now()).put("summary", instruction.take(300))
                    .put("result", "rejected").put("reason", validation.second).put("files", changed.joinToString()))
                return "Änderung verworfen: ${validation.second}"
            }

            val summary = patch.optString("summary").ifBlank { plan.optString("plan").take(300) }
            setPending(c, true, summary)
            exportWorkspace(c)
            appendJournal(c, JSONObject().put("time", now()).put("summary", summary)
                .put("instruction", instruction.take(500)).put("result", "committed")
                .put("files", changed.joinToString()).put("snapshot", before?.name.orEmpty())
                .put("autonomous", autonomous))
            "Änderung übernommen: $summary. Dateien: ${changed.joinToString()}. Für die laufende APK ist noch kein Selbst-Rebuild erfolgt; die validierte Version liegt im Entwicklungs-Workspace für den nächsten Build."
        } catch (e: Exception) {
            try { if (before?.isFile == true) restore(c, before!!) } catch (rollback: Exception) {
                Dbg.d("SelfCoding Rollback: ${rollback.message?.take(120)}")
            }
            Dbg.d("SelfCoding: ${e.message?.take(160)}")
            "Fehler: Self-Coding fehlgeschlagen; letzte Version wurde soweit möglich wiederhergestellt: ${e.message}"
        } finally {
            running = false
            cancelFlag = false
        }
    }

    private fun countOccurrences(hay: String, needle: String): Int {
        if (needle.isEmpty()) return 0
        var count = 0
        var idx = 0
        while (true) {
            val found = hay.indexOf(needle, idx)
            if (found < 0) return count
            count++
            idx = found + needle.length
        }
    }

    /** Wenn der exakte Ausschnitt fehlt: einmal ersetzen, falls nur Whitespace/Zeilenenden abweichen. */
    private fun softReplaceOnce(current: String, find: String, replace: String): String? {
        val norm = { s: String -> s.replace("\r\n", "\n").replace('\r', '\n') }
        val cur = norm(current)
        val f = norm(find)
        if (f.isBlank()) return null
        // 1) normalisierte Zeilenenden
        val i1 = cur.indexOf(f)
        if (i1 >= 0 && cur.indexOf(f, i1 + f.length) < 0) {
            return cur.substring(0, i1) + norm(replace) + cur.substring(i1 + f.length)
        }
        // 2) trailing whitespace pro Zeile ignorieren
        fun stripTrail(s: String) = s.lines().joinToString("\n") { it.trimEnd() }
        val cur2 = stripTrail(cur)
        val f2 = stripTrail(f)
        val i2 = cur2.indexOf(f2)
        if (i2 >= 0 && cur2.indexOf(f2, i2 + f2.length) < 0) {
            return cur2.substring(0, i2) + stripTrail(norm(replace)) + cur2.substring(i2 + f2.length)
        }
        return null
    }

    private fun askPlan(c: Context, instruction: String): JSONObject? {
        val listing = source(c).walkTopDown().filter { it.isFile && validPath(rel(it, c)) }
            .map { rel(it, c) }.sorted().take(400).joinToString("\n")
        val prompt = """
            Analysiere den bestehenden Android/Kotlin-Code von Boris für diese Änderungsanweisung:
            "$instruction"

            Projektdateien:
            $listing

            Antworte NUR als JSON:
            {"plan":"kurzer konkreter Plan","files":["relative/datei.kt"],"risk":"low|medium|high"}
            Wähle nur Dateien, die für die Änderung wirklich relevant sind. Keine Fantasiepfade.
        """.trimIndent()
        return askJson(c, "Du bist Boris' Software-Architekt. Analysiere nur den vorhandenen Code und plane minimal-invasive Änderungen. Keine erfundenen APIs.", prompt)
    }

    private fun askPatch(c: Context, instruction: String, plan: JSONObject, files: Map<String, String>): JSONObject? {
        val material = files.entries.joinToString("\n\n") { (p, v) ->
            "===== FILE: $p =====\n$v\n===== END FILE ====="
        }
        val prompt = """
            Setze diese Anweisung im vorhandenen Boris-Projekt um:
            "$instruction"

            Änderungsplan:
            ${plan.optString("plan")}
            Risiko: ${plan.optString("risk")}

            Bestehende relevante Dateien:
            $material

            Regeln:
            - Minimal-invasive Änderung; bestehende KI, Wake-Word, Listening, TTS und Face nicht entfernen.
            - Behalte APIs und Architektur, sofern die Aufgabe keinen Umbau verlangt.
            - Für Änderungen an bestehenden Dateien IMMER "replace_text" verwenden. Gib dabei einen kurzen, exakt vorhandenen Ausschnitt in "find" und die neue Version in "replace" an.
            - "find" muss exakt einmal in der übergebenen Datei vorkommen. Verändere möglichst nur wenige Zeilen.
            - "replace" und "add" nur für neue Dateien oder wenn eine vollständige Datei wirklich unvermeidbar ist.
            - Keine absoluten Pfade, keine Secrets, keine Netzwerk- oder Shell-Ausführung.
            - Keine Änderung außerhalb der übergebenen relevanten Dateien außer einer wirklich nötigen neuen Datei.
            - Nichts erfinden: nutze nur APIs, die zum Projekt passen.

            Antworte NUR als JSON:
            {"summary":"was geändert wurde","changes":[
              {"path":"relative/datei.kt","op":"replace_text","find":"exakt vorhandener kurzer Codeausschnitt","replace":"neuer Codeausschnitt"}
            ]}
        """.trimIndent()
        return askJson(c, "Du bist Boris' vorsichtiger Self-Coding-Engineer. Liefere kompilierbaren Kotlin/Android-Code und halte Änderungen klein.", prompt)
    }

    private fun askJson(c: Context, system: String, prompt: String): JSONObject? {
        val h = JSONArray().put(JSONObject().put("role", "user").put("parts",
            JSONArray().put(JSONObject().put("text", prompt))))
        val geminiKey = Core.key(c).trim()
        // Coding braucht deutlich mehr Tokens als Chat (Patches + JSON)
        val codingModels = listOf(
            "gemini-3.5-flash-lite", "gemini-2.5-flash", "gemini-flash-lite-latest", "gemini-flash-latest"
        )
        if (geminiKey.isNotBlank()) {
            try {
                val res = GeminiClient.generate(
                    geminiKey, system, JSONArray(), h, codingModels,
                    null, { cancelFlag },
                    maxOutputTokens = 8192,
                    jsonMode = true
                )
                val parts = res.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                val text = parts?.let { arr ->
                    (0 until arr.length()).joinToString("") { i ->
                        val p = arr.optJSONObject(i) ?: return@joinToString ""
                        // Thought-Parts von Thinking-Modellen überspringen
                        if (p.optBoolean("thought", false)) "" else p.optString("text")
                    }
                }
                val parsed = text?.let { parseJson(it) }
                if (parsed != null) return parsed
                Dbg.d("SelfCoding: Gemini lieferte kein gültiges JSON (${text?.take(80)}); prüfe OpenRouter-Fallback")
            } catch (e: Exception) {
                Dbg.d("SelfCoding Gemini: ${e.message?.take(120)}; prüfe OpenRouter-Fallback")
            }
        }
        val freeKey = c.getSharedPreferences("boris", 0).getString("openrouter_key", "")?.trim().orEmpty()
        if (freeKey.isBlank() || cancelFlag) return null
        return try {
            val text = FreeLearningClient.generate(
                freeKey,
                system + " Antworte ausschließlich mit einem einzigen gültigen JSON-Objekt. Keine Markdown-Codeblöcke.",
                prompt,
                { },
                { cancelFlag },
                8000
            )
            parseJson(text)
        } catch (e: Exception) {
            Dbg.d("SelfCoding OpenRouter: ${e.message?.take(120)}")
            null
        }
    }

    private fun parseJson(text: String): JSONObject? {
        var clean = text.trim()
        // Markdown-Fences und BOM entfernen
        clean = clean.removePrefix("\uFEFF")
            .replace(Regex("^```(?:json)?\\s*", RegexOption.IGNORE_CASE), "")
            .replace(Regex("\\s*```\\s*$"), "")
            .trim()
        val a = clean.indexOf('{')
        val b = clean.lastIndexOf('}')
        if (a < 0 || b <= a) return null
        val slice = clean.substring(a, b + 1)
        return try {
            JSONObject(slice)
        } catch (_: Exception) {
            // Häufig: trailing commas oder abgeschnittene Strings — einmal reparieren versuchen
            try {
                val fixed = slice
                    .replace(Regex(",\\s*([}\\]])"), "$1")
                JSONObject(fixed)
            } catch (_: Exception) {
                null
            }
        }
    }

    private fun validate(c: Context, changed: List<String>): Pair<Boolean, String> {
        for (path in changed.map { it.substringAfter(':') }) {
            val f = File(source(c), path)
            if (!f.exists()) continue
            if (f.length() > 500_000) return false to "$path ist ungewöhnlich groß."
            val text = try { f.readText() } catch (e: Exception) { return false to "Lesefehler $path" }
            if (text.contains("\u0000")) return false to "$path enthält ungültige Zeichen."
            if (path.endsWith(".kt") || path.endsWith(".kts") || path.endsWith(".xml")) {
                if (balanced(text, '(', ')').not()) return false to "$path: Klammern () sind unausgeglichen."
                if (balanced(text, '{', '}').not()) return false to "$path: Klammern {} sind unausgeglichen."
                if (balanced(text, '[', ']').not()) return false to "$path: Klammern [] sind unausgeglichen."
            }
            if (text.contains("Runtime.getRuntime().exec(") || text.contains("ProcessBuilder("))
                return false to "$path versucht einen Shell-Prozess zu starten."
        }
        return true to "statische Validierung erfolgreich"
    }

    private fun balanced(s: String, open: Char, close: Char): Boolean {
        var n = 0
        var quote: Char? = null
        var escaped = false
        for (ch in s) {
            if (quote != null) {
                if (escaped) escaped = false
                else if (ch == '\\') escaped = true
                else if (ch == quote) quote = null
                continue
            }
            if (ch == '"' || ch == '\'') quote = ch
            else if (ch == open) n++
            else if (ch == close) { n--; if (n < 0) return false }
        }
        return n == 0 && quote == null
    }

    /** Wird aus Learner in einer Ruhephase aufgerufen. */
    fun autonomousPass(c0: Context): String {
        val c = c0.applicationContext
        if (running || !enabled(c)) return "Self-Coding nicht aktiv."
        val p = prefs(c)
        val day = java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(java.util.Date())
        if (p.getString("auto_day", "") != day) p.edit().putString("auto_day", day).putInt("auto_count", 0).apply()
        if (p.getInt("auto_count", 0) >= MAX_AUTONOMOUS_PER_DAY) return "Tageslimit für autonome Codeverbesserungen erreicht."
        if (now() - p.getLong("auto_last", 0) < AUTONOMOUS_GAP) return "Autonome Codeverbesserung wartet noch."
        val instruction = """
            Führe genau EINE kleine, risikoarme Self-Development-Aufgabe am bestehenden Boris-Projekt aus.
            Suche nach einem konkreten Bug, einer klaren Robustheitsverbesserung, kleinen Performance-/UI-Verbesserung
            oder einer nützlichen internen Fähigkeit. Keine großflächigen Refactorings, keine Änderung von Berechtigungen,
            keine Änderungen an Wake-Word, Listening, TTS oder sicherheitskritischen Aktionen ohne zwingenden Grund.
            Wenn du keine klar begründete und sicher testbare Verbesserung findest, ändere nichts und melde das.
        """.trimIndent()
        val result = applyInstruction(c, instruction, true)
        if (result.startsWith("Änderung übernommen")) {
            p.edit().putLong("auto_last", now()).putInt("auto_count", p.getInt("auto_count", 0) + 1).apply()
        }
        return result
    }

    private fun enabled(c: Context): Boolean =
        c.getSharedPreferences("boris", 0).getBoolean("self_learn", true)

    private fun File.readTextOrNull(): String? = try { if (exists()) readText() else null } catch (_: Exception) { null }
}
