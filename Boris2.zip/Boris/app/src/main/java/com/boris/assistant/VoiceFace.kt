package com.boris.assistant

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

enum class FaceMode { IDLE, LISTEN, THINK, SPEAK, LEARN }
enum class FaceMood { NEUTRAL, HAPPY, CONCERNED, CURIOUS }

/** Alles, was das Gesicht von außen wissen muss. Wird jedes Bild neu befüllt. */
class FaceInput {
    var mode = FaceMode.IDLE
    var mood = FaceMood.NEUTRAL
    var speaking = false
    var touching = false
    var tdx = 0f; var tdy = 0f      // Fingerposition relativ zur Gesichtsmitte
    var drowsy = 0f                 // 0 wach .. 1 sehr müde (lange Ruhe)
    var learnSeq = 0                // zählt hoch, wenn Boris etwas Neues gelernt hat
}

private const val EYE_STEPS = 56
private const val NP = 30
private val GLYPHS = listOf("0", "1", "01", "10", "{ }", "</>", "π", "Σ", "∞", "?", "!", "A", "Ω", "x²", "√", "=", "+", "#", "λ", "ß", "∫", "§", "%", "&", "fn", "AI")
private val TAU = (2.0 * PI).toFloat()

private fun smooth01(x: Float): Float { val c = x.coerceIn(0f, 1f); return c * c * (3f - 2f * c) }
private fun approach(cur: Float, tgt: Float, rate: Float, dt: Float) = cur + (tgt - cur) * (1f - exp(-rate * dt))
private fun hash(x: Int): Int {
    var h = x * -1640531535
    h = h xor (h ushr 15); h *= 0x2c1b3c6d; h = h xor (h ushr 12)
    return h
}
private fun sgnPow(v: Float, e: Float): Float {
    val a = abs(v).toDouble().pow(e.toDouble()).toFloat()
    return if (v < 0f) -a else a
}

/**
 * Boris' Gesicht: zwei leuchtende Augen, Brauen und ein Mund auf dunklem Grund.
 * Blick, Blinzeln, Kopfhaltung und Ausdruck folgen dem Zustand (Zuhören, Denken, Sprechen, Lernen) und der Situation;
 * der Mund formt Laute passend zur tatsächlich gesprochenen Stimme (Pegel, Helligkeit, Silben-Einsätze).
 */
class VoiceFace {
    private var cx = 0f; private var cy = 0f; private var u = 1f
    private var t = 0f
    private val rnd = java.util.Random(7)

    // Zustandsgewichte
    private var wIdle = 1f; private var wListen = 0f; private var wThink = 0f; private var wSpeak = 0f; private var wLearn = 0f
    private var lastMode = FaceMode.IDLE

    // Stimme (geglättet)
    private var lvl = 0f; private var bright = 0f; private var pitch = 0f
    private var lastSeq = 0

    // Stimmungen
    private var mHappy = 0f; private var mConc = 0f; private var mCur = 0f

    // Ausdruck
    private var xOpen = 1f; private var xLid = 0f; private var xCheek = 0f; private var xTilt = 0f
    private var xBrow = 0f; private var xAsym = 0f; private var xEyeW = 1f; private var xEyeH = 1f
    private var xSmile = 0.1f; private var xMShift = 0f; private var xMW = 1f; private var xMBase = 0f

    // Blick
    private var gx = 0f; private var gy = 0f; private var gtx = 0f; private var gty = 0f
    private var gazeT = 1f; private var scanDir = 1f

    // Blinzeln
    private var blink = 0f; private var blinkT = -1f; private var nextBlink = 2.5f; private var pendingDouble = false

    // Kopf
    private var roll = 0f; private var hx = 0f; private var hy = 0f

    // Mund
    private var mOpen = 0f; private var mWd = 1f; private var mRound = 0f
    private var visOpen = 0f; private var visW = 1f; private var visRound = 0f

    // Impulse
    private var flick = 0f; private var startle = 0f; private var aha = 0f
    private var lastLearn = 0

    // Ring und Partikel
    private var ringAng = 0f
    private var spawnAcc = 0f
    private val pAng = FloatArray(NP); private val pR = FloatArray(NP); private val pV = FloatArray(NP)
    private val pAge = FloatArray(NP) { 1f }; private val pLife = FloatArray(NP) { 1f }; private val pSize = FloatArray(NP)
    private val pGlyph = IntArray(NP); private val pSpin = FloatArray(NP)
    private var absorb = 0f          // jedes ankommende Zeichen lässt Augen und Kopf kurz aufleuchten
    private var lastAng = 0f         // Richtung des zuletzt gestarteten Zeichens: dorthin schauen die Augen
    private val glyphPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        typeface = android.graphics.Typeface.MONOSPACE; textAlign = android.graphics.Paint.Align.CENTER
    }

    private val path = Path()
    private val brow = Path()

    // ------------------------------------------------------------------ Simulation
    fun update(dt0: Float, va: VoiceAnalyzer, inp: FaceInput, cx: Float, cy: Float, rr: Float) {
        this.cx = cx; this.cy = cy; this.u = rr
        val dt = dt0.coerceIn(0.001f, 0.05f)
        t += dt
        val speaking = inp.speaking

        // Zustand überblenden
        val kw = 1f - exp(-dt * 3.4f)
        wIdle += ((if (inp.mode == FaceMode.IDLE) 1f else 0f) - wIdle) * kw
        wListen += ((if (inp.mode == FaceMode.LISTEN) 1f else 0f) - wListen) * kw
        wThink += ((if (inp.mode == FaceMode.THINK) 1f else 0f) - wThink) * kw
        wSpeak += ((if (inp.mode == FaceMode.SPEAK) 1f else 0f) - wSpeak) * kw
        wLearn += ((if (inp.mode == FaceMode.LEARN) 1f else 0f) - wLearn) * kw
        if (inp.mode != lastMode) {
            if (inp.mode == FaceMode.LISTEN) startle = 1f     // Aufmerken, wenn er angesprochen wird
            nextBlink = min(nextBlink, 0.06f)
            lastMode = inp.mode
        }

        // Stimme
        val rawL = if (speaking) va.level else 0f
        lvl = approach(lvl, rawL, if (rawL > lvl) 26f else 10f, dt)
        bright = approach(bright, if (speaking) va.bright else 0f, 8f, dt)
        pitch = approach(pitch, if (speaking) va.pitch else 0f, 7f, dt)
        val sp = wSpeak

        // Stimmungen nur, solange er spricht
        val on = if (speaking) 1f else 0f
        mHappy = approach(mHappy, if (inp.mood == FaceMood.HAPPY) on else 0f, 2.6f, dt)
        mConc = approach(mConc, if (inp.mood == FaceMood.CONCERNED) on else 0f, 2.6f, dt)
        mCur = approach(mCur, if (inp.mood == FaceMood.CURIOUS) on else 0f, 2.6f, dt)

        // Neue Silbe: Laut (Mundform) wählen, Brauen zucken lassen
        val seq = va.onsetSeq
        if (speaking && seq != lastSeq) {
            val h = hash(seq)
            val r = ((h ushr 4) and 255) / 255f
            if (bright > 0.5f) {
                if (r < 0.5f) { visOpen = 0.45f; visW = 1.15f; visRound = 0f } else { visOpen = 0.25f; visW = 1.22f; visRound = 0f }
            } else {
                if (r < 0.45f) { visOpen = 0.95f; visW = 1.0f; visRound = 0.1f }
                else if (r < 0.8f) { visOpen = 0.7f; visW = 0.62f; visRound = 1f }
                else { visOpen = 0.5f; visW = 0.55f; visRound = 1f }
            }
            flick += va.onsetStrength * 0.8f
            if (r > 0.93f) nextBlink = 0f
        }
        lastSeq = seq
        if (!speaking) { visOpen = 0f; visW = 1f; visRound = 0f }
        flick *= exp(-dt * 9f); startle *= exp(-dt * 3f); aha *= exp(-dt * 1.6f)

        if (inp.learnSeq != lastLearn) { lastLearn = inp.learnSeq; aha = 1f; for (i in 0 until 12) spawn(true) }

        // Mund: folgt dem Pegel schnell; unter der Hörschwelle bleiben die Lippen zu
        val tOpen = if (rawL < 0.07f) 0f else visOpen * (0.2f + 0.8f * rawL.coerceIn(0f, 1f))
        mOpen = approach(mOpen, tOpen, if (tOpen > mOpen) 34f else 18f, dt)
        mWd = approach(mWd, visW, 14f, dt)
        mRound = approach(mRound, visRound, 14f, dt)

        // Ausdruck: Mischung aus Zustand, Stimmung und Impulsen
        val happy = mHappy; val conc = mConc; val cur = mCur
        val dr = inp.drowsy
        val tEyeOpen = wIdle + 1.08f * wListen + 0.94f * wThink + wSpeak + 0.9f * wLearn + startle * 0.28f + aha * 0.22f
        val tLid = wIdle * dr * 0.5f + wThink * 0.16f + wLearn * 0.22f
        val tCheek = wIdle * 0.04f + wLearn * 0.12f + happy * 0.5f + aha * 0.55f
        val tTilt = wThink * 0.30f + wLearn * 0.04f - conc * 0.6f
        val tBrow = wListen * 0.35f + wThink * 0.05f + wLearn * 0.12f +
            sp * (0.10f + 0.55f * max(pitch, 0f) - 0.25f * max(-pitch, 0f)) + flick * 0.5f + startle * 0.8f + aha * 0.7f + conc * 0.35f + cur * 0.45f
        val tAsym = wThink * 0.7f + cur * 0.6f + wListen * 0.12f * sin(t * 0.6f)
        val tEyeW = 1f + wListen * 0.08f + startle * 0.14f + aha * 0.10f
        val tEyeH = 1f + wListen * 0.12f + startle * 0.2f + aha * 0.18f + absorb * 0.05f - flick * 0.06f * sp
        val tSmile = 0.08f + wIdle * 0.04f + wListen * 0.10f - wThink * 0.04f + wLearn * 0.16f + happy * 0.55f - conc * 0.30f + aha * 0.6f + cur * 0.05f
        xOpen = approach(xOpen, tEyeOpen, 6f, dt)
        xLid = approach(xLid, tLid, 4f, dt)
        xCheek = approach(xCheek, tCheek, 5f, dt)
        xTilt = approach(xTilt, tTilt, 4f, dt)
        xBrow = approach(xBrow, tBrow, 7f, dt)
        xAsym = approach(xAsym, tAsym, 4f, dt)
        xEyeW = approach(xEyeW, tEyeW, 6f, dt)
        xEyeH = approach(xEyeH, tEyeH * min(1.4f, max(0.6f, xOpen)), 6f, dt)
        xSmile = approach(xSmile, tSmile, 5f, dt)
        xMShift = approach(xMShift, wThink * 0.9f, 3f, dt)
        xMW = approach(xMW, 1f - wThink * 0.35f - startle * 0.2f, 4f, dt)
        xMBase = approach(xMBase, startle * 0.25f + aha * 0.15f, 6f, dt)

        // Blick
        gazeT -= dt
        if (inp.touching) {
            gtx = (inp.tdx / (u * 1.5f)).coerceIn(-1f, 1f); gty = (inp.tdy / (u * 1.5f)).coerceIn(-1f, 1f); gazeT = 0.2f
        } else if (gazeT <= 0f) {
            val r1 = rnd.nextFloat(); val r2 = rnd.nextFloat()
            when (inp.mode) {
                FaceMode.THINK -> { scanDir = -scanDir; gtx = 0.55f * scanDir + (r1 - 0.5f) * 0.15f; gty = -0.55f + (r2 - 0.5f) * 0.12f; gazeT = 1.4f + r1 }
                FaceMode.LEARN -> {   // die Augen verfolgen die einfliegenden Zeichen
                    gtx = cos(lastAng) * 0.55f; gty = sin(lastAng) * 0.45f
                    gazeT = 0.45f + r1 * 0.4f
                }
                FaceMode.LISTEN -> { gtx = (r1 - 0.5f) * 0.12f; gty = (r2 - 0.5f) * 0.1f + 0.02f; gazeT = 1.2f + r1 * 1.8f }
                FaceMode.SPEAK -> { gtx = (r1 - 0.5f) * 0.35f; gty = (r2 - 0.5f) * 0.25f; gazeT = 0.8f + r2 * 1.8f }
                FaceMode.IDLE -> {
                    if (r1 < 0.25f) { gtx = 0f; gty = 0f } else { gtx = (r1 - 0.5f) * 0.9f; gty = (r2 - 0.5f) * 0.5f }
                    gazeT = (1.2f + r2 * 3.5f) * (1f + dr)
                }
            }
        }
        gx = approach(gx, gtx, 16f, dt); gy = approach(gy, gty, 16f, dt)

        // Blinzeln
        nextBlink -= dt
        if (blinkT < 0f && nextBlink <= 0f) {
            blinkT = 0f
            val (a, b) = when (inp.mode) {
                FaceMode.THINK -> 3f to 4f
                FaceMode.LEARN -> 3.5f to 4.5f
                FaceMode.SPEAK -> 2f to 2.5f
                FaceMode.LISTEN -> 2.5f to 2.5f
                FaceMode.IDLE -> 2.2f to 3.3f
            }
            nextBlink = (a + rnd.nextFloat() * b) * (1f + dr)
            if (rnd.nextFloat() < 0.18f) pendingDouble = true
        }
        if (blinkT >= 0f) {
            blinkT += dt / (0.17f + 0.25f * dr)
            if (blinkT >= 1f) {
                blinkT = -1f; blink = 0f
                if (pendingDouble) { pendingDouble = false; nextBlink = 0.08f }
            } else {
                blink = smooth01(if (blinkT < 0.4f) blinkT / 0.4f else 1f - (blinkT - 0.4f) / 0.6f)
            }
        }

        // Kopf: atmet, neigt sich beim Zuhören, wiegt sich beim Sprechen
        val tRoll = wIdle * sin(t * 0.37f) + wListen * (3.5f + 1.2f * sin(t * 0.9f)) + wThink * (-3f + sin(t * 0.6f)) +
            wLearn * 1.2f * sin(t * 0.5f) + sp * (pitch * 2.5f + 1.2f * sin(t * 1.1f)) + cur * sp * 3f
        roll = approach(roll, tRoll, 3f, dt)
        val tx = u * 0.012f * sin(t * 0.5f) + (if (inp.touching) inp.tdx * 0.04f else 0f)
        val ty = u * (0.012f * cos(t * 0.43f) + 0.02f * lvl * sp + wListen * 0.012f * sin(t * 2.2f) + 0.015f * absorb)
        hx = approach(hx, tx, 5f, dt); hy = approach(hy, ty, 5f, dt)

        // Ringe und Partikel
        ringAng += dt * (1.4f * wLearn + 0.4f * wListen)
        if (wLearn > 0.3f) {
            spawnAcc += dt * 7f * wLearn
            while (spawnAcc >= 1f) { spawnAcc -= 1f; spawn(false) }
        }
        for (i in 0 until NP) if (pAge[i] < 1f) {
            val before = pAge[i]
            pAge[i] = min(1f, before + dt / pLife[i])
            if (before < 0.88f && pAge[i] >= 0.88f) absorb = min(1f, absorb + 0.3f)
        }
        absorb *= exp(-dt * 5f)
    }

    private fun spawn(burst: Boolean) {
        var slot = -1
        for (i in 0 until NP) if (pAge[i] >= 1f) { slot = i; break }
        if (slot < 0) return
        pAng[slot] = rnd.nextFloat() * TAU
        pR[slot] = (if (burst) 1.3f else 1.8f) + rnd.nextFloat() * 0.9f
        pLife[slot] = if (burst) 1.1f else 1.5f + rnd.nextFloat()
        pSize[slot] = rnd.nextFloat()
        pGlyph[slot] = rnd.nextInt(GLYPHS.size)
        pSpin[slot] = (rnd.nextFloat() - 0.5f) * 1.6f
        pAge[slot] = 0f
        lastAng = pAng[slot]
    }

    // ------------------------------------------------------------------ Zeichnen
    fun draw(sc: DrawScope, tint: Color, dens: Float, light: Boolean = false) {
        val hi = if (light) lerp(tint, Color(0xFF0B1220), 0.35f) else lerp(tint, Color.White, 0.6f)
        val energy = wIdle * 0.2f + wListen * 0.45f + wThink * 0.5f + wSpeak * (0.5f + 0.5f * lvl) + wLearn * 0.5f
        with(sc) {
            // Weicher Schein hinter dem Gesicht
            val glowC = Offset(cx, cy + u * 0.1f)
            val glowR = u * 2.1f
            drawCircle(Brush.radialGradient(listOf(tint.copy(alpha = (0.07f + 0.16f * energy).coerceIn(0f, 1f)), Color.Transparent), center = glowC, radius = glowR),
                radius = glowR, center = glowC)

            // Zuhören: ruhige Halo-Ringe
            if (wListen > 0.02f) {
                val a = wListen
                drawCircle(hi.copy(alpha = (a * (0.10f + 0.05f * sin(t * 2f))).coerceIn(0f, 1f)), u * (1.42f + 0.02f * sin(t * 2f)), Offset(cx, cy + u * 0.1f),
                    style = Stroke(1.2f * dens))
                drawCircle(hi.copy(alpha = (a * (0.06f + 0.04f * sin(t * 2f + 2.1f))).coerceIn(0f, 1f)), u * (1.58f + 0.03f * sin(t * 2f + 2.1f)), Offset(cx, cy + u * 0.1f),
                    style = Stroke(1.0f * dens))
            }

            // Lernen: gepunkteter Ring mit wandernder Welle und aufsteigende Datenpunkte
            if (wLearn > 0.02f) {
                val n = 44
                val rr0 = u * 1.5f
                for (i in 0 until n) {
                    val ang = i * TAU / n
                    val d = max(0f, cos(ang - ringAng)).pow(6f)
                    val a = wLearn * (0.12f + 0.7f * d)
                    drawCircle(hi.copy(alpha = a.coerceIn(0f, 1f)), (1.3f + 1.7f * d) * dens, Offset(cx + cos(ang) * rr0, cy + u * 0.1f + sin(ang) * rr0 * 0.92f))
                }
            }
            // Lernen: Zeichen fliegen von außen in den Kopf, werden kleiner und verschwinden dort
            if (absorb > 0.02f) {
                val gc = Offset(cx, cy - u * 0.05f)
                drawCircle(Brush.radialGradient(listOf(hi.copy(alpha = (0.28f * absorb).coerceIn(0f, 1f)), Color.Transparent), center = gc, radius = u * 1.1f),
                    radius = u * 1.1f, center = gc)
            }
            val cv = drawContext.canvas.nativeCanvas
            for (i in 0 until NP) {
                val age = pAge[i]
                if (age >= 1f) continue
                val prog = age.pow(1.5f)
                val r = (pR[i] * (1f - prog) + 0.30f * prog) * u
                val ang = pAng[i] + age * pSpin[i]
                val px = cx + cos(ang) * r
                val py = cy + u * 0.05f + sin(ang) * r * 0.9f
                val al = smooth01(age / 0.12f) * (1f - smooth01((age - 0.72f) / 0.2f)) * 0.9f
                if (al < 0.02f) continue
                drawLine(hi.copy(alpha = (al * 0.35f).coerceIn(0f, 1f)), Offset(px, py),
                    Offset(px + cos(ang) * u * 0.16f * (1f - prog), py + sin(ang) * u * 0.14f * (1f - prog)), strokeWidth = 1.2f * dens)
                glyphPaint.color = hi.copy(alpha = al.coerceIn(0f, 1f)).toArgb()
                glyphPaint.textSize = (12f + 8f * pSize[i]) * dens * (1f - 0.45f * prog)
                cv.drawText(GLYPHS[pGlyph[i]], px, py + glyphPaint.textSize * 0.35f, glyphPaint)
            }

            // Gesicht (mit Kopfbewegung)
            withTransform({ translate(hx, hy); rotate(roll, Offset(cx, cy)) }) {
                drawFace(this, tint, hi, dens, energy, light)
            }
        }
    }

    private fun drawFace(sc: DrawScope, tint: Color, hi: Color, dens: Float, energy: Float, light: Boolean) {
        val eyeSep = u * 0.58f
        val ew = u * 0.40f * xEyeW
        val eh = u * 0.52f * xEyeH
        val ey0 = cy - u * 0.18f
        val close = 1f - (1f - xLid) * (1f - blink)
        val a = (0.80f + 0.2f * energy + 0.25f * absorb).coerceIn(0f, 1f)
        val gxm = gx + 0.015f * sin(t * 1.3f)
        val gym = gy + 0.012f * cos(t * 1.1f)

        for (s in floatArrayOf(-1f, 1f)) {
            val persp = 1f + 0.05f * s * gxm
            val w = ew * persp; val h = eh * persp
            val ex = cx + s * eyeSep + gxm * u * 0.07f
            val ey = ey0 + gym * u * 0.05f
            eyePath(path, ex, ey, w, h, s, close)
            // Schein, Körper, Kontur
            sc.drawPath(path, tint.copy(alpha = 0.10f * a), style = Stroke(14f * dens, join = StrokeJoin.Round))
            sc.drawPath(path, tint.copy(alpha = 0.16f * a), style = Stroke(6f * dens, join = StrokeJoin.Round))
            sc.drawPath(path, Brush.radialGradient(
                if (light) listOf(lerp(tint, Color.White, 0.25f).copy(alpha = 0.95f * a), tint.copy(alpha = 0.95f * a), hi.copy(alpha = 0.9f * a))
                else listOf(Color.White.copy(alpha = 0.95f * a), hi.copy(alpha = 0.92f * a), tint.copy(alpha = 0.78f * a)),
                center = Offset(ex + gxm * w * 0.15f, ey + gym * h * 0.12f - h * 0.05f), radius = max(w, h) * 0.7f))
            sc.drawPath(path, hi.copy(alpha = (0.9f * a).coerceIn(0f, 1f)), style = Stroke((if (close > 0.85f) 2.4f else 1.2f) * dens, cap = StrokeCap.Round, join = StrokeJoin.Round))
            // Lichtpunkt wandert mit dem Blick
            val vis = (1f - close).coerceIn(0f, 1f)
            sc.drawCircle(Color.White.copy(alpha = (0.85f * vis * a).coerceIn(0f, 1f)), w * 0.075f,
                Offset(ex - w * 0.18f + gxm * w * 0.12f, ey - h * 0.22f + gym * h * 0.10f))

            // Braue
            val raise = xBrow * u * 0.12f + (if (s < 0f) xAsym else -xAsym * 0.2f) * u * 0.06f
            val by = ey - h / 2f - u * 0.15f - raise
            val xi = ex - s * w * 0.45f; val xo = ex + s * w * 0.5f
            val yi = by + xTilt * u * 0.10f; val yo = by - xTilt * u * 0.04f
            brow.rewind()
            brow.moveTo(xi, yi)
            brow.quadraticBezierTo(ex, by - u * 0.04f - xBrow * u * 0.02f, xo, yo)
            sc.drawPath(brow, hi.copy(alpha = (0.55f + 0.25f * energy).coerceIn(0f, 1f)), style = Stroke(u * 0.032f, cap = StrokeCap.Round))
        }

        drawMouth(sc, tint, hi, dens, energy)

        // Denken: drei Punkte, die nacheinander aufleuchten
        if (wThink > 0.02f) {
            for (i in 0..2) {
                val s = max(0f, sin(t * 3.2f - i * 0.9f))
                sc.drawCircle(hi.copy(alpha = (wThink * (0.25f + 0.75f * s)).coerceIn(0f, 1f)), u * 0.028f * (0.7f + 0.5f * s),
                    Offset(cx + u * (0.98f + i * 0.13f), cy - u * 0.78f))
            }
        }
    }

    /** Augenform: Superellipse, oben vom Lid (Neigung) und unten von der Wange (Lächeln) beschnitten. */
    private fun eyePath(p: Path, ex: Float, ey: Float, w: Float, h: Float, side: Float, close: Float) {
        p.rewind()
        val e = 2f / 3f
        for (i in 0..EYE_STEPS) {
            val th = i * TAU / EYE_STEPS
            val x = sgnPow(cos(th), e) * w / 2f
            var y = sgnPow(sin(th), e) * h / 2f
            val tt = x * (-side) / (w / 2f)
            val xr = x / (w / 2f)
            var top = -h / 2f + close * h * 0.72f + xTilt * h * 0.45f * tt
            var bot = h / 2f - close * h * 0.28f - xCheek * h * 0.55f * (1f - xr * xr)
            if (top > bot) { val m = (top + bot) / 2f; top = m; bot = m }
            y = min(max(y, top), bot)
            if (i == 0) p.moveTo(ex + x, ey + y) else p.lineTo(ex + x, ey + y)
        }
        p.close()
    }

    private fun drawMouth(sc: DrawScope, tint: Color, hi: Color, dens: Float, energy: Float) {
        val w = u * 0.60f * xMW * mWd
        val mx = cx + xMShift * u * 0.10f
        val my = cy + u * 0.66f
        val cornerY = my - xSmile * u * 0.11f
        val open = (mOpen + xMBase).coerceIn(0f, 1f)
        val xl = mx - w / 2f; val xr = mx + w / 2f
        val ctrl = w * (0.20f + 0.28f * mRound)
        val sag = xSmile * u * 0.07f
        val upMid = my + sag - open * u * 0.10f
        val loMid = my + sag + open * u * (0.30f + 0.12f * mRound)
        val upC = (upMid - 0.25f * cornerY) / 0.75f
        val loC = (loMid - 0.25f * cornerY) / 0.75f
        path.rewind()
        path.moveTo(xl, cornerY)
        path.cubicTo(mx - ctrl, upC, mx + ctrl, upC, xr, cornerY)
        path.cubicTo(mx + ctrl, loC, mx - ctrl, loC, xl, cornerY)
        path.close()
        val glow = 0.10f + 0.12f * lvl
        sc.drawPath(path, tint.copy(alpha = glow), style = Stroke(10f * dens, join = StrokeJoin.Round))
        if (open > 0.04f) {
            sc.drawPath(path, tint.copy(alpha = (0.16f + 0.2f * open).coerceIn(0f, 1f)))
        }
        sc.drawPath(path, hi.copy(alpha = (0.75f + 0.2f * energy).coerceIn(0f, 1f)),
            style = Stroke((if (open > 0.04f) 2.0f else 2.8f) * dens, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}
