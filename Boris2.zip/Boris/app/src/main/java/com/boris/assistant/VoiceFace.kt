package com.boris.assistant

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

enum class FaceMode { IDLE, LISTEN, THINK, SPEAK }

private const val FK = 8            // Formmoden 2..FK (Index 1 und 0 bleiben ungenutzt)
private const val STEPS = 128
private const val MAX_RIPPLES = 7
private val TAU = (2.0 * PI).toFloat()

private fun smooth01(x: Float): Float { val c = x.coerceIn(0f, 1f); return c * c * (3f - 2f * c) }
private fun mix(a: Float, b: Float, t: Float) = a + (b - a) * t
private fun hash(x: Int): Int {
    var h = x * -1640531535
    h = h xor (h ushr 15); h *= 0x2c1b3c6d; h = h xor (h ushr 12)
    return h
}

/**
 * Boris' Gesicht: eine einzige organische Form, deren Kontur aus Schwingungsmoden besteht.
 * Tiefe Moden folgen der Satzmelodie, hohe Moden den Zischlauten, jede Silbe stößt eine andere Mode an
 * und schickt eine Welle mit ihrer eigenen Form nach außen. Zuhören, Denken und Sprechen sind weich überblendete Zustände.
 */
class VoiceFace {
    private var cx = 0f; private var cy = 0f; private var rr = 1f
    private var t = 0f

    // Zustandsgewichte (überblenden weich ineinander)
    private var wIdle = 1f; private var wListen = 0f; private var wThink = 0f; private var wSpeak = 0f

    // Stimme, im 60-fps-Takt geglättet
    private var lvl = 0f; private var body = 0f; private var bright = 0f; private var pitch = 0f
    private var tempo = 0f; private var calm = 0f; private var pop = 0f; private var egg = 0f

    // Formmoden als gedämpfte Federn
    private val amp = FloatArray(FK + 1); private val vel = FloatArray(FK + 1); private val ph = FloatArray(FK + 1)
    private val dirs = FloatArray(FK + 1) { if (it % 2 == 0) 1f else -1f }
    private var lastSeq = 0

    // Körper hängt leicht nach, federt zurück
    private var jx = 0f; private var jy = 0f; private var jvx = 0f; private var jvy = 0f
    private var touchPull = 0f; private var touchAng = 0f

    private var arcAng = 0f
    private var listenTimer = 0f
    private var sinceRipple = 1f

    private class Ripple {
        var age = 1f; var life = 1f; var strength = 0f; var inward = false
        val a = FloatArray(FK + 1); val p = FloatArray(FK + 1)
    }
    private val ripples = Array(MAX_RIPPLES) { Ripple() }
    private val path = Path(); private val layer = Path(); private val rp = Path()

    // ------------------------------------------------------------------ Simulation
    fun update(dt0: Float, mode: FaceMode, va: VoiceAnalyzer, speaking: Boolean, touching: Boolean,
               tdx: Float, tdy: Float, cx: Float, cy: Float, rr: Float) {
        this.cx = cx; this.cy = cy; this.rr = rr
        val dt = dt0.coerceIn(0.001f, 0.05f)
        val n = if (dt > 0.02f) 2 else 1
        repeat(n) { step(dt / n, mode, va, speaking, touching, tdx, tdy) }
    }

    private fun step(dt: Float, mode: FaceMode, va: VoiceAnalyzer, speaking: Boolean, touching: Boolean, tdx: Float, tdy: Float) {
        t += dt
        val kw = 1f - exp(-dt * 3.2f)
        wIdle += ((if (mode == FaceMode.IDLE) 1f else 0f) - wIdle) * kw
        wListen += ((if (mode == FaceMode.LISTEN) 1f else 0f) - wListen) * kw
        wThink += ((if (mode == FaceMode.THINK) 1f else 0f) - wThink) * kw
        wSpeak += ((if (mode == FaceMode.SPEAK) 1f else 0f) - wSpeak) * kw

        // Stimme: schnell hinein, langsam wieder heraus
        val tl = if (speaking) va.level else 0f
        val tb = if (speaking) va.body else 0f
        val tbr = if (speaking) va.bright else 0f
        val tp = if (speaking) va.pitch else 0f
        val tt = if (speaking) va.tempo else 0f
        lvl += (tl - lvl) * (1f - exp(-dt * (if (tl > lvl) 26f else 9f)))
        body += (tb - body) * (1f - exp(-dt * (if (tb > body) 8f else 3f)))
        bright += (tbr - bright) * (1f - exp(-dt * 7f))
        pitch += (tp - pitch) * (1f - exp(-dt * 7f))
        tempo += (tt - tempo) * (1f - exp(-dt * 2.2f))
        val calmT = if (speaking) smooth01((va.silence - 0.18f) / 0.6f) else 0f
        calm += (calmT - calm) * (1f - exp(-dt * 2.5f))
        pop *= exp(-dt * 8f)
        egg += (pitch * 0.05f * wSpeak - egg) * (1f - exp(-dt * 6f))

        // Modenziele je Zustand, dann Feder
        val act = (1f - 0.75f * calm) * (1f - 0.2f * tempo)
        val big = 1f + 0.35f * (1f - tempo)      // langsame Rede: weite, ruhige Formen
        val shim = 1f + 0.6f * tempo             // schnelle Rede: feineres Flirren
        val spd = (0.55f * wIdle + 0.8f * wListen + 1.4f * wThink + wSpeak * (0.7f + 2.4f * tempo + lvl)) * (1f - 0.6f * calm)
        for (k in 2..FK) {
            val idle = 0.022f * (0.55f + 0.45f * sin(t * (0.35f + 0.11f * k) + k * 1.7f)) / sqrt(k.toFloat())
            val listen = when (k) { 2 -> 0.030f + 0.012f * sin(t * 1.6f); 3 -> 0.020f; else -> 0.008f }
            val think = when (k) { 3 -> 0.050f; 2 -> 0.012f; else -> 0.006f }
            val speak = when (k) {
                2, 3 -> (0.020f + 0.085f * body + 0.05f * lvl) * big
                4, 5 -> 0.012f + 0.050f * lvl * (0.5f + 0.5f * body)
                else -> (0.006f + 0.060f * bright * lvl) * shim
            } * act
            val tg = wIdle * idle + wListen * listen + wThink * think + wSpeak * speak
            val w = 7f + 2.6f * k
            vel[k] += ((tg - amp[k]) * w * w - vel[k] * 2f * 0.55f * w) * dt
            amp[k] += vel[k] * dt
            ph[k] += dirs[k] * dt * spd * (0.5f + 0.16f * k)
        }

        // Neue Silbe: stößt eine Mode an (tief oder hoch je nach Klang) und schickt eine Welle los
        val seq = va.onsetSeq
        if (speaking && seq != lastSeq) {
            val s = va.onsetStrength
            val h = hash(seq)
            val base = if (bright > 0.45f) 5 else 2
            val kk = base + ((h and 0x7fffffff) % 4)
            val sgn = if (((h shr 7) and 1) == 0) 1f else -1f
            vel[kk] += sgn * s * 0.055f * (7f + 2.6f * kk)
            ph[kk] += ((h shr 9) and 255) / 255f * 1.5f
            val k2 = 2 + (((h shr 3) and 0x7fffffff) % 7)
            vel[k2] -= sgn * s * 0.025f * (7f + 2.6f * k2)
            pop += s * 0.04f
            spawn(s, false)
        }
        lastSeq = seq
        sinceRipple += dt

        // Zuhören: sanfte Wellen, die nach innen laufen
        listenTimer += dt * wListen
        if (listenTimer > 1.9f) { listenTimer = 0f; spawn(0.5f, true) }
        val aging = dt
        for (r in ripples) if (r.age < 1f) r.age = min(1f, r.age + aging / r.life)

        arcAng += dt * (1.9f + 0.9f * sin(t * 0.8f)) * wThink

        // Körper: sanftes Treiben im Ruhezustand, Hinterherhängen, Fingerzug
        val tgx = (if (touching) tdx * 0.10f else 0f) + rr * 0.012f * sin(t * 0.5f) * wIdle
        val tgy = (if (touching) tdy * 0.10f else 0f) + rr * 0.015f * cos(t * 0.43f) * wIdle
        jvx += ((tgx - jx) * 60f - jvx * 7f) * dt
        jvy += ((tgy - jy) * 60f - jvy * 7f) * dt
        jx += jvx * dt; jy += jvy * dt
        val dist = sqrt(tdx * tdx + tdy * tdy)
        touchPull += ((if (touching) min(1f, dist / rr) else 0f) - touchPull) * (1f - exp(-dt * 10f))
        if (touching) touchAng = atan2(tdy - jy, tdx - jx)
    }

    private fun spawn(strength: Float, inward: Boolean) {
        if (!inward && sinceRipple < 0.11f) return
        var pick = ripples[0]
        for (r in ripples) { if (r.age >= 1f) { pick = r; break }; if (r.age > pick.age) pick = r }
        pick.age = 0f; pick.strength = strength; pick.inward = inward
        pick.life = if (inward) 1.9f else 1.5f - 0.5f * tempo
        for (k in 2..FK) { pick.a[k] = amp[k]; pick.p[k] = ph[k] }
        sinceRipple = 0f
    }

    // ------------------------------------------------------------------ Zeichnen
    private fun blob(p: Path, gx: Float, gy: Float, r: Float, a: FloatArray, phs: FloatArray, ampMul: Float, phOff: Float, main: Boolean) {
        p.rewind()
        for (i in 0..STEPS) {
            val th = i * TAU / STEPS
            var w = 0f
            for (k in 2..FK) w += a[k] * sin(k * th + phs[k] + phOff * k)
            w *= ampMul
            if (main) {
                w -= egg * sin(th)
                var d = th - touchAng
                while (d > PI.toFloat()) d -= TAU
                while (d < -PI.toFloat()) d += TAU
                w += 0.10f * exp(-d * d * 2.2f) * touchPull
            }
            val rad = r * (1f + w)
            val x = gx + cos(th) * rad; val y = gy + sin(th) * rad
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
    }

    fun draw(sc: DrawScope, tint: Color, dens: Float) {
        with(sc) {
            val energy = wIdle * 0.25f + wListen * 0.5f + wThink * 0.55f + wSpeak * (0.55f + 0.45f * lvl)
            val scale = 1f + wIdle * 0.014f * sin(t * 0.9f) + wListen * (0.02f + 0.014f * sin(t * 1.9f)) +
                wThink * (-0.05f + 0.012f * sin(t * 2.6f)) + wSpeak * (0.10f * lvl + 0.045f * body) + pop
            val r0 = rr * 0.92f
            val r = r0 * scale
            val gx = cx + jx
            val gy = cy + jy - egg * rr * 0.5f
            val hi = lerp(tint, Color.White, 0.55f)
            val g = Offset(gx, gy)

            // Weicher Schein
            val glowR = r0 * (2.0f + 0.25f * lvl)
            drawCircle(Brush.radialGradient(listOf(tint.copy(alpha = (0.10f + 0.20f * energy).coerceIn(0f, 1f)), Color.Transparent), center = g, radius = glowR),
                radius = glowR, center = g)

            // Wellen der einzelnen Silben (hinter dem Körper)
            for (rip in ripples) {
                if (rip.age >= 1f) continue
                val e = 1f - (1f - rip.age) * (1f - rip.age)
                val sc2 = if (rip.inward) 1.5f - 0.5f * e else 1f + 0.5f * e
                val al = if (rip.inward) sin(rip.age * PI.toFloat()) * 0.30f * wListen
                         else rip.strength * Math.pow((1f - rip.age).toDouble(), 1.6).toFloat() * 0.55f
                if (al <= 0.005f) continue
                blob(rp, gx, gy, r * sc2, rip.a, rip.p, 1f - 0.5f * rip.age, 0f, false)
                drawPath(rp, hi.copy(alpha = al.coerceIn(0f, 1f)), style = Stroke(1.3f * dens, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }

            // Körper
            blob(path, gx, gy, r, amp, ph, 1f, 0f, true)
            val fillA = (0.40f + 0.18f * energy).coerceIn(0f, 0.6f)
            drawPath(path, Brush.radialGradient(
                listOf(lerp(tint, Color.White, 0.35f).copy(alpha = fillA), tint.copy(alpha = fillA * 0.55f), tint.copy(alpha = fillA * 0.16f)),
                center = Offset(gx - r * 0.18f, gy - r * 0.22f), radius = r * 1.35f))
            drawPath(path, tint.copy(alpha = 0.12f), style = Stroke(7f * dens, join = StrokeJoin.Round))
            drawPath(path, hi.copy(alpha = (0.50f + 0.20f * energy).coerceIn(0f, 1f)), style = Stroke(1.6f * dens, join = StrokeJoin.Round))

            // Innere Konturen: zwei versetzte Schichten geben Tiefe
            blob(layer, gx, gy, r * 0.80f, amp, ph, 1.25f, 0.9f, false)
            drawPath(layer, hi.copy(alpha = 0.26f), style = Stroke(1.1f * dens, join = StrokeJoin.Round))
            blob(layer, gx, gy, r * 0.62f, amp, ph, 1.6f, -1.3f, false)
            drawPath(layer, hi.copy(alpha = 0.16f), style = Stroke(1.0f * dens, join = StrokeJoin.Round))

            // Kern: leuchtet mit der Stimme
            val coreR = r * (0.45f + 0.25f * lvl)
            val coreC = Offset(gx - r * 0.1f, gy - r * 0.12f)
            drawCircle(Brush.radialGradient(
                listOf(Color.White.copy(alpha = (0.14f + 0.08f * wListen + 0.08f * wThink + 0.35f * lvl * wSpeak).coerceIn(0f, 1f)), Color.Transparent),
                center = coreC, radius = coreR), radius = coreR, center = coreC)

            // Denken: ein Lichtbogen mit Schweif umkreist die Form
            if (wThink > 0.02f) {
                val ra = r * 1.2f
                val segs = 14
                val deg = arcAng * 180f / PI.toFloat()
                for (i in 0 until segs) {
                    val f = (i + 1) / segs.toFloat()
                    drawArc(hi.copy(alpha = (f * f * 0.8f * wThink).coerceIn(0f, 1f)),
                        startAngle = deg - (segs - i) * 9f, sweepAngle = 9.6f, useCenter = false,
                        topLeft = Offset(gx - ra, gy - ra), size = Size(2f * ra, 2f * ra),
                        style = Stroke((1.5f + 1.5f * f) * dens, cap = StrokeCap.Round))
                }
                val hx = gx + cos(arcAng) * ra; val hy = gy + sin(arcAng) * ra
                drawCircle(Color.White.copy(alpha = (0.9f * wThink).coerceIn(0f, 1f)), 2.6f * dens, Offset(hx, hy))
            }
        }
    }
}
