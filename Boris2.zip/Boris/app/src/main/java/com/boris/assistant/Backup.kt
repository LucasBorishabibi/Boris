package com.boris.assistant

import android.content.Context
import android.net.Uri
import org.json.JSONObject

/** Sicherung als einzelne Datei an einem Ort deiner Wahl. API-Schlüssel gehören bewusst nie dazu. */
object Backup {
    private val BOOL = listOf("proactive", "safety", "notif_ai", "hq_voice", "self_learn")
    private val INT = listOf("theme", "persona")
    private val STR = listOf("gvoice", "el_voice")

    fun write(ctx: Context, uri: Uri): String {
        return try {
            val s = JSONObject()
            for ((k, v) in ctx.getSharedPreferences("boris", 0).all) {
                if (k in BOOL && v is Boolean) s.put(k, v)
                else if (k in INT && v is Int) s.put(k, v)
                else if (k in STR && v is String) s.put(k, v)
            }
            val j = JSONObject().put("app", "Boris").put("version", 1).put("ts", System.currentTimeMillis())
                .put("brain", Brain.exportJson()).put("knowledge", Knowledge.exportJson()).put("settings", s)
            val out = ctx.contentResolver.openOutputStream(uri, "wt") ?: throw RuntimeException("kein Ziel")
            out.use { it.write(j.toString(2).toByteArray(Charsets.UTF_8)) }
            "Sicherung gespeichert (ohne API-Schlüssel)."
        } catch (e: Exception) { Dbg.d("Sicherung: " + e.message?.take(60)); "Die Sicherung hat nicht geklappt." }
    }

    fun read(ctx: Context, uri: Uri): String {
        return try {
            val txt = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: throw RuntimeException("leer")
            val j = JSONObject(txt)
            if (j.optString("app") != "Boris") return "Das ist keine Boris-Sicherung."
            val facts = j.optJSONArray("brain")?.let { Brain.importJson(it) } ?: 0
            val learned = j.optJSONObject("knowledge")?.let { Knowledge.importJson(it) } ?: 0
            val e = ctx.getSharedPreferences("boris", 0).edit()
            j.optJSONObject("settings")?.let { s ->
                for (k in BOOL) if (s.has(k)) e.putBoolean(k, s.optBoolean(k))
                for (k in INT) if (s.has(k)) e.putInt(k, s.optInt(k))
                for (k in STR) if (s.has(k)) e.putString(k, s.optString(k))
            }
            e.apply()
            Persona.load(ctx)
            Learning.refresh()
            "Sicherung geladen: $facts Erinnerungen, $learned gelernte Einträge."
        } catch (e: Exception) { Dbg.d("Sicherung laden: " + e.message?.take(60)); "Die Datei konnte ich nicht lesen." }
    }
}
