package com.boris.assistant

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import android.view.animation.DecelerateInterpolator

/** Der sichtbare Cursor des Agenten: fliegt zum Ziel, zeigt die Aktion und "klickt" mit Welle. */
class CursorView(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private var cx = -1f
    private var cy = -1f
    private var label = ""
    private val trail = ArrayList<FloatArray>()
    private var spin = 0f
    private var ripple = -1f
    private var anim: ValueAnimator? = null
    private val cyan = Color.parseColor("#00E5FF")
    private val gold = Color.parseColor("#FFB400")
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 12 * d; typeface = Typeface.MONOSPACE; color = Color.WHITE
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        if (cx < 0) { cx = w / 2f; cy = h * 0.6f }
    }

    fun setLabel(l: String) { label = l; invalidate() }

    fun moveTo(x: Float, y: Float, l: String) {
        label = l
        val sx = cx; val sy = cy
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 300
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                val f = it.animatedValue as Float
                cx = sx + (x - sx) * f
                cy = sy + (y - sy) * f
                trail.add(floatArrayOf(cx, cy))
                if (trail.size > 14) trail.removeAt(0)
                invalidate()
            }
            start()
        }
    }

    fun tapFlash() {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 380
            addUpdateListener { ripple = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) { ripple = -1f; invalidate() }
            })
            start()
        }
    }

    override fun onDraw(c: Canvas) {
        if (cx < 0) return
        spin += 5f
        p.style = Paint.Style.FILL
        for ((i, t) in trail.withIndex()) {
            p.color = cyan
            p.alpha = (i * 90 / trail.size.coerceAtLeast(1)).coerceIn(0, 255)
            c.drawCircle(t[0], t[1], (2 + i * 0.35f) * d, p)
        }
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2 * d; p.color = cyan; p.alpha = 255
        c.drawCircle(cx, cy, 18 * d, p)
        p.strokeWidth = 3 * d; p.color = gold
        val r = RectF(cx - 26 * d, cy - 26 * d, cx + 26 * d, cy + 26 * d)
        for (k in 0 until 3) c.drawArc(r, spin + k * 120f, 40f, false, p)
        p.strokeWidth = 1.5f * d; p.color = cyan
        c.drawLine(cx - 36 * d, cy, cx - 22 * d, cy, p); c.drawLine(cx + 22 * d, cy, cx + 36 * d, cy, p)
        c.drawLine(cx, cy - 36 * d, cx, cy - 22 * d, p); c.drawLine(cx, cy + 22 * d, cx, cy + 36 * d, p)
        p.style = Paint.Style.FILL; p.color = Color.WHITE
        c.drawCircle(cx, cy, 3 * d, p)
        if (ripple >= 0f) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 3 * d; p.color = gold
            p.alpha = ((1f - ripple) * 255).toInt().coerceIn(0, 255)
            c.drawCircle(cx, cy, (18 + 44 * ripple) * d, p)
            p.alpha = 255
        }
        if (label.isNotEmpty()) {
            val w = tp.measureText(label) + 16 * d
            val x = (cx + 30 * d).coerceAtMost(width - w - 8 * d).coerceAtLeast(8 * d)
            val y = (cy - 40 * d).coerceAtLeast(70 * d)
            val box = RectF(x, y - 16 * d, x + w, y + 8 * d)
            p.style = Paint.Style.FILL; p.color = Color.parseColor("#E6020B14")
            c.drawRoundRect(box, 6 * d, 6 * d, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = d; p.color = cyan
            c.drawRoundRect(box, 6 * d, 6 * d, p)
            c.drawText(label, x + 8 * d, y, tp)
        }
        postInvalidateOnAnimation()
    }
}
