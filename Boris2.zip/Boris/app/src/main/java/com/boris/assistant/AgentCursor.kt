package com.boris.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

class AgentCursor(context: Context) : View(context) {

    private var currentX = 0f
    private var currentY = 0f
    private var targetX = 0f
    private var targetY = 0f

    private val cursorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF00E5FF")
        style = Paint.Style.FILL
    }

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#6600E5FF")
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }

    fun moveTo(x: Float, y: Float) {
        targetX = x
        targetY = y
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val dx = targetX - currentX
        val dy = targetY - currentY

        if (Math.abs(dx) > 0.5f || Math.abs(dy) > 0.5f) {
            currentX += dx * 0.15f
            currentY += dy * 0.15f
            postInvalidateOnAnimation()
        } else {
            currentX = targetX
            currentY = targetY
        }

        canvas.drawCircle(currentX, currentY, 16f, cursorPaint)
        canvas.drawCircle(currentX, currentY, 28f, ringPaint)
    }
}
