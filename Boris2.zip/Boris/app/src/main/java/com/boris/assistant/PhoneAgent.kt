package com.boris.assistant

import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject

/**
 * Mehrstufiger Agent mit Cursor. Reihenfolge: 1) gelernter Kurzbefehl (ohne KI-Runden), 2) Aktionsketten mit Bildschirmliste,
 * 3) Screenshot nur wenn wirklich nötig (leere Liste, Festhängen oder ausdrücklich per "look"), 4) starkes Modell bei Problemen.
 */
object PhoneAgent {
    @Volatile var running = false
    @Volatile private var aborted = false
    fun abort() { aborted = true }

    private val FAST = listOf("gemini-3.5-flash-lite", "gemini-flash-lite-latest", "gemini-flash-latest")
    private val SMART = listOf("gemini-flash-latest", "gemini-3.5-flash-lite", "gemini-flash-lite-latest")
    private const val MAX_SHOTS = 3

    private val tools = JSONArray(
        """[{"function_declarations":[
        {"name":"click_text","description":"Tippt auf das sichtbare Element mit diesem Text oder dieser Beschreibung. Bleibt nach Bildschirmwechseln gültig, ideal für Ketten.",
         "parameters":{"type":"object","properties":{"text":{"type":"string"}},"required":["text"]}},
        {"name":"type","description":"Gibt Text in das fokussierte (sonst erste sichtbare) Eingabefeld ein.",
         "parameters":{"type":"object","properties":{"text":{"type":"string"}},"required":["text"]}},
        {"name":"submit","description":"Drückt Enter/Suchen auf der Tastatur."},
        {"name":"click","description":"Tippt per Nummer. Nummern gelten nur für den aktuellen Bildschirm, also nur als letzte Aktion einer Runde.",
         "parameters":{"type":"object","properties":{"id":{"type":"integer"}},"required":["id"]}},
        {"name":"type_text","description":"Text in das Eingabefeld mit dieser Nummer (nur als letzte Aktion einer Runde).",
         "parameters":{"type":"object","properties":{"id":{"type":"integer"},"text":{"type":"string"}},"required":["id","text"]}},
        {"name":"scroll","description":"Scrollt die Seite.",
         "parameters":{"type":"object","properties":{"direction":{"type":"string","description":"down oder up"}},"required":["direction"]}},
        {"name":"back","description":"Zurück-Taste."},
        {"name":"home","description":"Startbildschirm."},
        {"name":"open_app","description":"Öffnet eine App per Namen.",
         "parameters":{"type":"object","properties":{"app":{"type":"string"}},"required":["app"]}},
        {"name":"look","description":"LETZTES MITTEL: Macht einen Screenshot, den du im nächsten Schritt siehst. Nur wenn die Liste nicht reicht (Bilder, unbeschriftete Symbole, Spiele, Captchas)."},
        {"name":"tap_xy","description":"Tippt auf eine Bildposition (x,y von 0 bis 1000, links oben = 0,0). Nur nach einem Screenshot.",
         "parameters":{"type":"object","properties":{"x":{"type":"integer"},"y":{"type":"integer"}},"required":["x","y"]}},
        {"name":"done","description":"Aufgabe erledigt. Bei Informationsfragen steht die Antwort in summary. learned: optionaler kurzer Tipp, der in dieser App funktioniert hat.",
         "parameters":{"type":"object","properties":{"summary":{"type":"string"},"learned":{"type":"string"}},"required":["summary"]}},
        {"name":"fail","description":"Aufgabe ist nicht machbar, oder es fehlt eine Angabe (dann als Rückfrage formulieren).",
         "parameters":{"type":"object","properties":{"reason":{"type":"string"}},"required":["reason"]}}
        ]}]"""
    )

    private fun system() = "Du steuerst ein Android-Handy über die Bedienungshilfe, um eine Aufgabe des Nutzers schnell und selbständig zu erledigen. " +
        "Du bekommst den Bildschirm als nummerierte Liste. TEMPO: Gib pro Runde MEHRERE Aktionen hintereinander aus, wenn du sicher weißt, wie es weitergeht. " +
        "Beispiel Nachricht senden: click_text(Suche) → type(Name) → click_text(Name) → click(Nachrichtenfeld) → type(Text) → click_text(Senden). " +
        "Nutze für Ketten click_text und type (bleiben gültig); Nummern nur als letzte Aktion einer Runde. " +
        "Scheitert eine Aktion, bricht der Rest der Runde ab und du bekommst den neuen Bildschirm. " +
        "Schließe Popups/Hinweise weg (Zulassen, Später, X), wenn sie stören. Ist der Bildschirm unverändert, wähle einen anderen Weg (Suche, scrollen, zurück). " +
        "SCREENSHOTS: Normalerweise reicht die Liste. Rufe look nur, wenn sie für die Aufgabe nicht reicht (Bilder, unbeschriftete Symbole, Spiele, Captchas). " +
        "Du bekommst ein Bild von selbst, wenn die Liste fast leer ist. Mit einem Bild tippst du per tap_xy (x,y 0 bis 1000). " +
        "Rufe done erst auf, wenn es wirklich erledigt ist (z.B. gesendete Nachricht im Chat sichtbar, Eingabefeld leer). " +
        "Bei Informationsfragen liest du die Antwort vom Bildschirm und gibst sie in done.summary zurück. " +
        "Fehlt dir etwas Wichtiges oder ist etwas mehrdeutig (z.B. zwei Kontakte mit dem Namen), rufe fail mit einer Rückfrage als reason auf. " +
        "Tätige niemals Käufe oder Zahlungen, gib keine Passwörter ein und lösche nichts, außer es wurde ausdrücklich verlangt.\n" +
        "Wissen über Nutzer und Apps (nutze es!):\n${Brain.prompt()}"

    fun bringBack(svc: AutoSendService) {
        try {
            svc.startActivity(Intent(svc, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
        } catch (e: Exception) {}
    }

    fun run(ctx: Context, apiKey: String, task: String, onStatus: (String) -> Unit, app: String? = null): String {
        val svc = AutoSendService.instance
            ?: return "Agent-Zugriff nicht aktiv. Der Nutzer muss „Boris Auto-Senden“ in den Bedienungshilfen einschalten."
        aborted = false
        running = true
        svc.cursorShow()
        val result = try { loop(svc, apiKey, task, onStatus, app) } catch (e: Exception) { Dbg.d("Agent: ${e.message}"); "Agent-Fehler: ${e.message}" }
        running = false
        svc.cursorHide()
        bringBack(svc)
        return result
    }

    private fun loop(svc: AutoSendService, apiKey: String, task: String, onStatus: (String) -> Unit, app: String?): String {
        var opened = ""
        if (!app.isNullOrBlank()) { onStatus("Agent: öffne $app …"); opened = openApp(svc, app) }

        // 1) Gelernter Kurzbefehl
        var replayed = false
        val m = try { Recipes.match(svc, task) } catch (e: Exception) { null }
        if (m != null && (!app.isNullOrBlank() || m.first.getJSONArray("steps").getJSONObject(0).optString("a") == "open_app")) {
            val name = m.first.optString("name")
            onStatus("Kurzbefehl „$name“ …")
            replayed = true
            if (replay(svc, m.first, m.second, onStatus)) {
                val v = Notify.ask(svc, "Antworte nur mit JA oder NEIN.",
                    "Aufgabe: $task\nAktueller Bildschirm:\n${svc.dump()}\nIst die Aufgabe nach diesem Bildschirm erledigt?")
                if (v?.trim()?.uppercase()?.startsWith("JA") == true) return "Erledigt."
            }
            Recipes.fail(svc, name)
            Dbg.d("Kurzbefehl $name schlug fehl, normaler Agent übernimmt")
        }
        if (aborted) return "Abgebrochen."

        // 2) Normaler Agent
        val history = JSONArray()
        val first = if (!app.isNullOrBlank() || replayed)
            "Aufgabe: $task\n\nAktueller Bildschirm${if (opened.isNotBlank()) " (App „$app“ geöffnet)" else ""}:\n${svc.dump()}"
        else "Aufgabe: $task\n\nAktueller Bildschirm: Boris-App (starte mit open_app)."
        history.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", first))))
        var failures = 0
        var lastScreen = ""
        var shots = 0
        val rec = JSONArray()
        var replayable = true

        for (step in 1..20) {
            if (aborted) return "Abgebrochen."
            val smart = failures >= 2 || step >= 6
            onStatus("Agent · Runde $step: plane${if (smart) " (starkes Modell)" else ""} …")
            val res = GeminiClient.generate(apiKey, system(), tools, history, if (smart) SMART else FAST)
            val content = res.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                ?: return "Der Agent hat nicht geantwortet."
            val parts = content.optJSONArray("parts") ?: JSONArray()
            history.put(JSONObject(content.toString()).put("role", "model"))
            val calls = (0 until parts.length()).map { parts.getJSONObject(it) }
                .filter { it.has("functionCall") }.map { it.getJSONObject("functionCall") }
            if (calls.isEmpty()) {
                val sb = StringBuilder()
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    if (p.has("text") && !p.optBoolean("thought")) sb.append(p.getString("text"))
                }
                return sb.toString().ifBlank { "Agent ohne Ergebnis beendet." }
            }
            val results = ArrayList<Pair<String, String>>()
            var broken = false
            var wantShot = false
            for (fc in calls) {
                val name = fc.getString("name")
                val args = fc.optJSONObject("args") ?: JSONObject()
                if (name == "done") {
                    val learned = args.optString("learned", "")
                    if (learned.length > 8) Brain.add(learned, "app")
                    if (!replayed && replayable && rec.length() >= 2) {
                        val copy = JSONArray(rec.toString())
                        Thread { try { Recipes.learn(svc, task, app, copy) } catch (e: Exception) {} }.start()
                    }
                    return args.optString("summary", "Erledigt.")
                }
                if (name == "fail") return "Nicht möglich: ${args.optString("reason")}"
                if (aborted) return "Abgebrochen."
                if (broken) { results.add(name to "übersprungen (vorherige Aktion fehlgeschlagen)"); continue }
                if (name == "look") { wantShot = true; results.add(name to "Screenshot folgt im nächsten Schritt."); continue }
                onStatus("Agent · Runde $step: ${describe(svc, name, args)}")
                val label = if (name == "click") svc.labelRaw(args.optInt("id")) else null
                val r = try { act(svc, name, args) } catch (e: Exception) { "Fehler: ${e.message}" }
                results.add(name to r)
                if (r.startsWith("Fehler")) { broken = true; failures++ } else {
                    svc.waitStable(700)
                    // Ablauf für spätere Kurzbefehle mitschreiben (nur textbasierte, wiederholbare Schritte)
                    when (name) {
                        "click_text" -> rec.put(JSONObject().put("a", "click_text").put("text", args.getString("text")))
                        "type" -> rec.put(JSONObject().put("a", "type").put("text", args.getString("text")))
                        "type_text" -> rec.put(JSONObject().put("a", "type").put("text", args.getString("text")))
                        "click" -> if (label != null) rec.put(JSONObject().put("a", "click_text").put("text", label)) else replayable = false
                        "submit", "back", "home" -> rec.put(JSONObject().put("a", name))
                        "scroll" -> rec.put(JSONObject().put("a", "scroll").put("dir", args.optString("direction", "down")))
                        "open_app" -> rec.put(JSONObject().put("a", "open_app").put("app", args.getString("app")))
                        "tap_xy" -> replayable = false
                    }
                }
            }
            svc.waitStable(1500)
            val screen = svc.dump()
            val hint = if (screen == lastScreen) { failures++; "Der Bildschirm hat sich nicht verändert. Wähle einen anderen Weg." } else null
            lastScreen = screen
            // Screenshot nur bei echtem Bedarf: ausdrücklich gewünscht, Liste fast leer oder mehrfach festgefahren
            val sparse = screen.lines().count { it.startsWith("[") } < 4
            val auto = shots < MAX_SHOTS && (sparse || (failures >= 3 && hint != null))
            val shot = if ((wantShot || auto) && shots < MAX_SHOTS) { shots++; svc.screenshotB64() } else null

            val responses = JSONArray()
            for ((i, pr) in results.withIndex()) {
                val resp = JSONObject().put("result", pr.second)
                if (i == results.size - 1) {
                    resp.put("screen", screen)
                    if (hint != null) resp.put("hinweis", hint)
                    if (shot != null) resp.put("screenshot", "Bild angehängt. Koordinaten für tap_xy: x,y von 0 bis 1000.")
                    else if (wantShot || auto) resp.put("screenshot", "Screenshot nicht möglich (geschützter Inhalt oder Limit).")
                }
                responses.put(JSONObject().put("functionResponse", JSONObject().put("name", pr.first).put("response", resp)))
            }
            if (shot != null) responses.put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", shot)))
            history.put(JSONObject().put("role", "user").put("parts", responses))
            trim(history)
        }
        return "Abgebrochen: die Aufgabe hat zu viele Runden gebraucht."
    }

    /** Spielt ein gelerntes Rezept ohne KI-Runden ab. */
    private fun replay(svc: AutoSendService, r: JSONObject, params: Map<String, String>, onStatus: (String) -> Unit): Boolean {
        val steps = r.getJSONArray("steps")
        fun sub(t: String): String { var x = t; for ((k, v) in params) x = x.replace("{$k}", v); return x }
        for (i in 0 until steps.length()) {
            if (aborted) return false
            val s = steps.getJSONObject(i)
            val a = s.getString("a")
            val args = JSONObject()
            s.optString("text").takeIf { it.isNotEmpty() }?.let { args.put("text", sub(it)) }
            s.optString("app").takeIf { it.isNotEmpty() }?.let { args.put("app", sub(it)) }
            if (s.has("dir")) args.put("direction", s.getString("dir"))
            onStatus("Kurzbefehl · ${i + 1}/${steps.length()}: ${describe(svc, a, args)}")
            val res = try { act(svc, a, args) } catch (e: Exception) { "Fehler: ${e.message}" }
            if (res.startsWith("Fehler")) { Dbg.d("Rezept Schritt ${i + 1}: $res"); return false }
            svc.waitStable(700)
        }
        return true
    }

    private fun trim(history: JSONArray) {
        for (i in 0 until history.length() - 3) {
            val parts = history.getJSONObject(i).optJSONArray("parts") ?: continue
            val keep = JSONArray()
            for (j in 0 until parts.length()) {
                val p = parts.getJSONObject(j)
                if (p.has("inlineData")) continue            // alte Bilder entfernen
                p.optJSONObject("functionResponse")?.optJSONObject("response")?.let { if (it.has("screen")) it.put("screen", "(alter Bildschirm entfernt)") }
                keep.put(p)
            }
            if (keep.length() != parts.length()) history.getJSONObject(i).put("parts", keep)
        }
    }

    private fun describe(svc: AutoSendService, name: String, a: JSONObject): String = when (name) {
        "click_text" -> "tippe „${a.optString("text").take(25)}“"
        "click" -> "tippe „${svc.label(a.optInt("id"))}“"
        "type", "type_text" -> "tippe ein: „${a.optString("text").take(25)}“"
        "submit" -> "Enter"
        "scroll" -> "scrolle"
        "back" -> "zurück"
        "home" -> "Startbildschirm"
        "open_app" -> "öffne ${a.optString("app")}"
        "tap_xy" -> "tippe auf Bildposition"
        else -> name
    }

    private fun act(svc: AutoSendService, name: String, args: JSONObject): String = when (name) {
        "click_text" -> svc.clickText(args.getString("text"))
        "type" -> svc.typeAuto(args.getString("text"))
        "submit" -> svc.submit()
        "click" -> svc.click(args.getInt("id"))
        "type_text" -> svc.typeText(args.getInt("id"), args.getString("text"))
        "scroll" -> svc.scroll(args.optString("direction", "down") == "down")
        "back" -> svc.back()
        "home" -> svc.home()
        "open_app" -> openApp(svc, args.getString("app"))
        "tap_xy" -> svc.tapNorm(args.getInt("x"), args.getInt("y"))
        else -> "Fehler: unbekannte Aktion"
    }

    fun openApp(svc: AutoSendService, app: String): String {
        val pm = svc.packageManager
        var pkg = PKG[app.lowercase()]
        if (pkg == null) {
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pkg = pm.queryIntentActivities(q, 0)
                .firstOrNull { it.loadLabel(pm).toString().contains(app, true) }?.activityInfo?.packageName
        }
        val i = pkg?.let { pm.getLaunchIntentForPackage(it) } ?: return "Fehler: App nicht gefunden: $app"
        svc.cursorLabel("ÖFFNE ${app.uppercase()}")
        svc.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        Thread.sleep(300)
        svc.waitStable(2500)
        return "App geöffnet"
    }
}
