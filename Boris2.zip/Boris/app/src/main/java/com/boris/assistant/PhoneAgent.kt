package com.boris.assistant

import android.accessibilityservice.AccessibilityService
import android.app.Activity
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject

/** Mehrstufiger Agent mit Cursor: sieht den Bildschirm, führt Aktionsketten aus, lernt aus Erfolgen und eskaliert bei Problemen auf ein stärkeres Modell. */
object PhoneAgent {
    @Volatile var running = false
    private val FAST = listOf("gemini-3.5-flash-lite", "gemini-flash-lite-latest", "gemini-flash-latest")
    private val SMART = listOf("gemini-flash-latest", "gemini-3.5-flash-lite", "gemini-flash-lite-latest")

    private val tools = JSONArray(
        """[{"function_declarations":[
        {"name":"click_text","description":"Tippt auf das sichtbare Element mit diesem Text oder dieser Beschreibung. Bleibt nach Bildschirmwechseln gültig, ideal für Ketten.",
         "parameters":{"type":"object","properties":{"text":{"type":"string"}},"required":["text"]}},
        {"name":"type","description":"Gibt Text in das fokussierte (sonst erste sichtbare) Eingabefeld ein.",
         "parameters":{"type":"object","properties":{"text":{"type":"string"}},"required":["text"]}},
        {"name":"submit","description":"Drückt Enter/Suchen auf der Tastatur."},
        {"name":"click","description":"Tippt per Nummer. Nummern gelten nur für den aktuellen Bildschirm, also nur als letzte Aktion einer Runde.",
         "parameters":{"type":"object","properties":{"id":{"type":"integer"}},"required":["id"]}},
        {"name":"type_text","description":"Text in das Eingabefeld mit dieser Nummer (nur als letzte Aktion einer Runde).",
         "parameters":{"type":"object","properties":{"id":{"type":"integer"},"text":{"type":"string"}},"required":["id","text"]}},
        {"name":"scroll","description":"Scrollt die Seite.",
         "parameters":{"type":"object","properties":{"direction":{"type":"string","description":"down oder up"}},"required":["direction"]}},
        {"name":"back","description":"Zurück-Taste."},
        {"name":"home","description":"Startbildschirm."},
        {"name":"open_app","description":"Öffnet eine App per Namen.",
         "parameters":{"type":"object","properties":{"app":{"type":"string"}},"required":["app"]}},
        {"name":"done","description":"Aufgabe erledigt. Bei Informationsfragen steht die Antwort in summary. learned: optionaler kurzer Tipp, der in dieser App funktioniert hat (wird gespeichert).",
         "parameters":{"type":"object","properties":{"summary":{"type":"string"},"learned":{"type":"string"}},"required":["summary"]}},
        {"name":"fail","description":"Aufgabe ist nicht machbar.",
         "parameters":{"type":"object","properties":{"reason":{"type":"string"}},"required":["reason"]}}
        ]}]"""
    )

    private fun system() = "Du steuerst ein Android-Handy über die Bedienungshilfe, um eine Aufgabe des Nutzers schnell und selbständig zu erledigen. " +
        "Du bekommst den Bildschirm als nummerierte Liste. TEMPO: Gib pro Runde MEHRERE Aktionen hintereinander aus, wenn du sicher weißt, wie es weitergeht. " +
        "Beispiel Nachricht senden: click_text(Suche) → type(Name) → click_text(Name) → click(Nachrichtenfeld) → type(Text) → click_text(Senden). " +
        "Nutze für Ketten click_text und type (bleiben gültig); Nummern nur als letzte Aktion einer Runde. " +
        "Scheitert eine Aktion, bricht der Rest der Runde ab und du bekommst den neuen Bildschirm. " +
        "Schließe Popups/Hinweise weg (Zulassen, Später, X), wenn sie stören. Ist der Bildschirm unverändert, wähle einen anderen Weg (Suche, scrollen, zurück). " +
        "Rufe done erst auf, wenn es wirklich erledigt ist (z.B. gesendete Nachricht im Chat sichtbar, Eingabefeld leer). " +
        "Bei Informationsfragen liest du die Antwort vom Bildschirm und gibst sie in done.summary zurück. " +
        "Fehlt dir etwas Wichtiges oder ist etwas mehrdeutig (z.B. zwei Kontakte mit dem Namen), rufe fail mit einer Rückfrage im reason-Text auf. " +
        "Tätige niemals Käufe oder Zahlungen, gib keine Passwörter ein und lösche nichts, außer es wurde ausdrücklich verlangt.\n" +
        "Wissen über Nutzer und Apps (nutze es!):\n${Brain.prompt()}"

    fun bringBack(svc: AutoSendService) {
        try {
            svc.startActivity(Intent(svc, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
        } catch (e: Exception) {}
    }

    fun run(activity: Activity, apiKey: String, task: String, onStatus: (String) -> Unit, app: String? = null): String {
        val svc = AutoSendService.instance
            ?: return "Agent-Zugriff nicht aktiv. Der Nutzer muss „Boris Auto-Senden“ in den Bedienungshilfen einschalten."
        running = true
        svc.cursorShow()
        val result = try { loop(svc, apiKey, task, onStatus, app) } catch (e: Exception) { "Agent-Fehler: ${e.message}" }
        running = false
        svc.cursorHide()
        bringBack(svc)
        return result
    }

    private fun loop(svc: AutoSendService, apiKey: String, task: String, onStatus: (String) -> Unit, app: String?): String {
        val history = JSONArray()
        var first = "Aufgabe: $task\n\nAktueller Bildschirm: Boris-App (starte mit open_app)."
        if (!app.isNullOrBlank()) {
            onStatus("Agent: öffne $app …")
            val r = openApp(svc, app)
            first = "Aufgabe: $task\n\nDie App „$app“ wurde bereits geöffnet ($r). Aktueller Bildschirm:\n${svc.dump()}"
        }
        history.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", first))))
        var failures = 0
        var lastScreen = ""

        for (step in 1..20) {
            val smart = failures >= 2 || step >= 6
            onStatus("Agent · Runde $step: plane${if (smart) " (starkes Modell)" else ""} …")
            val res = GeminiClient.generate(apiKey, system(), tools, history, if (smart) SMART else FAST)
            val content = res.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                ?: return "Der Agent hat nicht geantwortet."
            val parts = content.optJSONArray("parts") ?: JSONArray()
            history.put(JSONObject(content.toString()).put("role", "model"))
            val calls = (0 until parts.length()).map { parts.getJSONObject(it) }
                .filter { it.has("functionCall") }.map { it.getJSONObject("functionCall") }
            if (calls.isEmpty()) {
                val sb = StringBuilder()
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    if (p.has("text") && !p.optBoolean("thought")) sb.append(p.getString("text"))
                }
                return sb.toString().ifBlank { "Agent ohne Ergebnis beendet." }
            }
            val results = ArrayList<Pair<String, String>>()
            var broken = false
            for (fc in calls) {
                val name = fc.getString("name")
                val args = fc.optJSONObject("args") ?: JSONObject()
                if (name == "done") {
                    val learned = args.optString("learned", "")
                    if (learned.length > 8) Brain.add(learned, "app")
                    return args.optString("summary", "Erledigt.")
                }
                if (name == "fail") return "Nicht möglich: ${args.optString("reason")}"
                if (broken) { results.add(name to "übersprungen (vorherige Aktion fehlgeschlagen)"); continue }
                onStatus("Agent · Runde $step: ${describe(svc, name, args)}")
                val r = try { act(svc, name, args) } catch (e: Exception) { "Fehler: ${e.message}" }
                results.add(name to r)
                if (r.startsWith("Fehler")) { broken = true; failures++ } else svc.waitStable(700)
            }
            svc.waitStable(1500)
            val screen = svc.dump()
            val hint = if (screen == lastScreen) { failures++; "Der Bildschirm hat sich nicht verändert. Wähle einen anderen Weg." } else null
            lastScreen = screen
            val responses = JSONArray()
            for ((i, pr) in results.withIndex()) {
                val resp = JSONObject().put("result", pr.second)
                if (i == results.size - 1) { resp.put("screen", screen); if (hint != null) resp.put("hinweis", hint) }
                responses.put(JSONObject().put("functionResponse", JSONObject().put("name", pr.first).put("response", resp)))
            }
            history.put(JSONObject().put("role", "user").put("parts", responses))
            trim(history)
        }
        return "Abgebrochen: die Aufgabe hat zu viele Runden gebraucht."
    }

    private fun trim(history: JSONArray) {
        for (i in 0 until history.length() - 3) {
            val parts = history.getJSONObject(i).optJSONArray("parts") ?: continue
            for (j in 0 until parts.length()) {
                val fr = parts.getJSONObject(j).optJSONObject("functionResponse") ?: continue
                fr.optJSONObject("response")?.let { if (it.has("screen")) it.put("screen", "(alter Bildschirm entfernt)") }
            }
        }
    }

    private fun describe(svc: AutoSendService, name: String, a: JSONObject): String = when (name) {
        "click_text" -> "tippe „${a.optString("text").take(25)}“"
        "click" -> "tippe „${svc.label(a.optInt("id"))}“"
        "type", "type_text" -> "tippe ein: „${a.optString("text").take(25)}“"
        "submit" -> "Enter"
        "scroll" -> "scrolle"
        "back" -> "zurück"
        "home" -> "Startbildschirm"
        "open_app" -> "öffne ${a.optString("app")}"
        else -> name
    }

    private fun act(svc: AutoSendService, name: String, args: JSONObject): String = when (name) {
        "click_text" -> svc.clickText(args.getString("text"))
        "type" -> svc.typeAuto(args.getString("text"))
        "submit" -> svc.submit()
        "click" -> svc.click(args.getInt("id"))
        "type_text" -> svc.typeText(args.getInt("id"), args.getString("text"))
        "scroll" -> svc.scroll(args.optString("direction", "down") == "down")
        "back" -> svc.back()
        "home" -> svc.home()
        "open_app" -> openApp(svc, args.getString("app"))
        else -> "Fehler: unbekannte Aktion"
    }

    fun openApp(svc: AutoSendService, app: String): String {
        val pm = svc.packageManager
        var pkg = PKG[app.lowercase()]
        if (pkg == null) {
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pkg = pm.queryIntentActivities(q, 0)
                .firstOrNull { it.loadLabel(pm).toString().contains(app, true) }?.activityInfo?.packageName
        }
        val i = pkg?.let { pm.getLaunchIntentForPackage(it) } ?: return "Fehler: App nicht gefunden: $app"
        svc.cursorLabel("ÖFFNE ${app.uppercase()}")
        svc.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        Thread.sleep(300)
        svc.waitStable(2500)
        return "App geöffnet"
    }
}
