package com.boris.assistant

import android.accessibilityservice.AccessibilityService
import android.app.Activity
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject

/** Mehrstufiger Agent: sieht den Bildschirm, wählt eine Aktion, führt sie aus, wiederholt – bis die Aufgabe erledigt ist. */
object PhoneAgent {
    private val MODELS = listOf("gemini-flash-latest", "gemini-3.5-flash-lite", "gemini-flash-lite-latest")

    private val tools = JSONArray(
        """[{"function_declarations":[
        {"name":"click","description":"Tippt auf ein Element des Bildschirms.",
         "parameters":{"type":"object","properties":{"id":{"type":"integer","description":"Nummer in eckigen Klammern"}},"required":["id"]}},
        {"name":"type_text","description":"Gibt Text in ein Eingabefeld ein (ersetzt den Inhalt).",
         "parameters":{"type":"object","properties":{"id":{"type":"integer"},"text":{"type":"string"}},"required":["id","text"]}},
        {"name":"scroll","description":"Scrollt die Seite.",
         "parameters":{"type":"object","properties":{"direction":{"type":"string","description":"down oder up"}},"required":["direction"]}},
        {"name":"back","description":"Zurück-Taste des Handys."},
        {"name":"open_app","description":"Öffnet eine App anhand ihres Namens.",
         "parameters":{"type":"object","properties":{"app":{"type":"string","description":"z.B. WhatsApp, Discord, Spotify, Instagram, YouTube, Chrome, Einstellungen"}},"required":["app"]}},
        {"name":"wait","description":"Wartet kurz, bis der Bildschirm geladen ist."},
        {"name":"done","description":"Aufgabe ist vollständig erledigt.",
         "parameters":{"type":"object","properties":{"summary":{"type":"string"}},"required":["summary"]}},
        {"name":"fail","description":"Aufgabe ist nicht machbar.",
         "parameters":{"type":"object","properties":{"reason":{"type":"string"}},"required":["reason"]}}
        ]}]"""
    )

    private fun system() = "Du steuerst ein Android-Handy über die Bedienungshilfe, um eine Aufgabe des Nutzers selbständig zu erledigen. " +
        "Du bekommst in jeder Runde den Bildschirm als nummerierte Liste. Rufe pro Runde genau eine Funktion auf. " +
        "Zu Beginn ist Boris selbst offen: starte mit open_app. " +
        "Beispiel Nachricht senden: App öffnen, Suche oder Chatliste nutzen, Chat der Person öffnen (Namen in der Liste suchen, ggf. scrollen oder Suchfeld benutzen), " +
        "Nachrichtenfeld antippen, Text mit type_text eingeben, dann den Senden-Button (oft desc „Senden“/„Send“) klicken. " +
        "Rufe done erst auf, wenn du sicher bist, dass es erledigt ist (z.B. die gesendete Nachricht ist im Chat sichtbar und das Eingabefeld leer). " +
        "Wenn ein Weg nicht klappt, probiere einen anderen (Suche, scrollen, zurück). Rufe fail nur auf, wenn es wirklich nicht geht. " +
        "Tätige niemals Käufe oder Zahlungen, gib keine Passwörter ein und lösche nichts, außer es wurde ausdrücklich verlangt."

    fun run(activity: Activity, apiKey: String, task: String, onStatus: (String) -> Unit): String {
        val svc = AutoSendService.instance
            ?: return "Agent-Zugriff nicht aktiv. Der Nutzer muss „Boris Auto-Senden“ in den Bedienungshilfen einschalten (Boris oben rechts antippen)."
        val result = try { loop(svc, apiKey, task, onStatus) } catch (e: Exception) { "Agent-Fehler: ${e.message}" }
        try {
            svc.startActivity(Intent(svc, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
        } catch (e: Exception) {}
        return result
    }

    private fun loop(svc: AutoSendService, apiKey: String, task: String, onStatus: (String) -> Unit): String {
        val history = JSONArray()
        history.put(JSONObject().put("role", "user").put("parts", JSONArray().put(
            JSONObject().put("text", "Aufgabe: $task\n\nAktueller Bildschirm: Boris-App (starte mit open_app)."))))
        for (step in 1..30) {
            onStatus("Agent · Schritt $step: überlege …")
            val res = GeminiClient.generate(apiKey, system(), tools, history, MODELS)
            val content = res.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                ?: return "Der Agent hat nicht geantwortet."
            val parts = content.optJSONArray("parts") ?: JSONArray()
            history.put(JSONObject(content.toString()).put("role", "model"))
            val calls = (0 until parts.length()).map { parts.getJSONObject(it) }
                .filter { it.has("functionCall") }.map { it.getJSONObject("functionCall") }
            if (calls.isEmpty()) {
                val sb = StringBuilder()
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    if (p.has("text") && !p.optBoolean("thought")) sb.append(p.getString("text"))
                }
                return sb.toString().ifBlank { "Agent ohne Ergebnis beendet." }
            }
            val results = ArrayList<Pair<String, String>>()
            for ((i, fc) in calls.withIndex()) {
                val name = fc.getString("name")
                val args = fc.optJSONObject("args") ?: JSONObject()
                if (name == "done") return args.optString("summary", "Erledigt.")
                if (name == "fail") return "Nicht möglich: ${args.optString("reason")}"
                val r = if (i > 0) "übersprungen: bitte nur eine Aktion pro Schritt"
                else {
                    onStatus("Agent · Schritt $step: ${describe(svc, name, args)}")
                    try { act(svc, name, args) } catch (e: Exception) { "Fehler: ${e.message}" }
                }
                results.add(name to r)
            }
            Thread.sleep(1200)
            val screen = svc.dump()
            val responses = JSONArray()
            for ((i, pr) in results.withIndex()) {
                val resp = JSONObject().put("result", pr.second)
                if (i == 0) resp.put("screen", screen)
                responses.put(JSONObject().put("functionResponse", JSONObject().put("name", pr.first).put("response", resp)))
            }
            history.put(JSONObject().put("role", "user").put("parts", responses))
            trim(history)
        }
        return "Abgebrochen: die Aufgabe hat zu viele Schritte gebraucht."
    }

    /** Alte Bildschirm-Dumps entfernen, damit der Verlauf klein und schnell bleibt. */
    private fun trim(history: JSONArray) {
        for (i in 0 until history.length() - 5) {
            val parts = history.getJSONObject(i).optJSONArray("parts") ?: continue
            for (j in 0 until parts.length()) {
                val fr = parts.getJSONObject(j).optJSONObject("functionResponse") ?: continue
                fr.optJSONObject("response")?.let { if (it.has("screen")) it.put("screen", "(alter Bildschirm entfernt)") }
            }
        }
    }

    private fun describe(svc: AutoSendService, name: String, a: JSONObject): String = when (name) {
        "click" -> "tippe auf „${svc.label(a.optInt("id"))}“"
        "type_text" -> "tippe ein: „${a.optString("text").take(30)}“"
        "scroll" -> "scrolle"
        "back" -> "zurück"
        "open_app" -> "öffne ${a.optString("app")}"
        else -> "warte"
    }

    private fun act(svc: AutoSendService, name: String, args: JSONObject): String = when (name) {
        "click" -> svc.click(args.getInt("id"))
        "type_text" -> svc.typeText(args.getInt("id"), args.getString("text"))
        "scroll" -> svc.scroll(args.optString("direction", "down") == "down")
        "back" -> { svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK); "zurück" }
        "wait" -> { Thread.sleep(1500); "gewartet" }
        "open_app" -> openApp(svc, args.getString("app"))
        else -> "unbekannte Aktion"
    }

    private fun openApp(svc: AutoSendService, app: String): String {
        val pm = svc.packageManager
        var pkg = PKG[app.lowercase()]
        if (pkg == null) {
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pkg = pm.queryIntentActivities(q, 0)
                .firstOrNull { it.loadLabel(pm).toString().contains(app, true) }?.activityInfo?.packageName
        }
        val i = pkg?.let { pm.getLaunchIntentForPackage(it) } ?: return "App nicht gefunden: $app"
        svc.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        Thread.sleep(1800)
        return "App geöffnet"
    }
}
