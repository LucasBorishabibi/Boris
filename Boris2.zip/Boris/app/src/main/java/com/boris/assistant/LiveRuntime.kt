package com.boris.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Sofort wirksame Selbstverbesserungen – ohne APK-Rebuild.
 *
 * Android kann den kompilierten Bytecode einer laufenden APK nicht ersetzen.
 * Deshalb schreibt Self-Coding hierher, was die laufende App sofort nutzen kann:
 * Persönlichkeit, Stil, Face-Parameter, Feature-Flags, Antwort-Hinweise.
 *
 * Jede Änderung wird atomar in JSON persistiert und beim nächsten Lesen aktiv.
 */
object LiveRuntime {
    private const val PREF = "boris_live"
    private const val FILE = "live_runtime.json"

    @Volatile private var cache: JSONObject? = null
    @Volatile private var faceSeq = 0

    /** Erhöht sich bei Face-Parameter-Änderungen (Face kann neu einlesen). */
    fun faceRevision(): Int = faceSeq

    private fun file(c: Context) = File(c.filesDir, FILE)

    @Synchronized fun load(c0: Context): JSONObject {
        cache?.let { return it }
        val c = c0.applicationContext
        val fromFile = try {
            val f = file(c)
            if (f.isFile) JSONObject(f.readText()) else null
        } catch (_: Exception) { null }
        val fromPref = try {
            JSONObject(c.getSharedPreferences(PREF, 0).getString("data", "{}") ?: "{}")
        } catch (_: Exception) { JSONObject() }
        val merged = fromFile ?: fromPref
        cache = merged
        faceSeq = merged.optInt("face_rev", 0)
        return merged
    }

    @Synchronized fun save(c0: Context, data: JSONObject) {
        val c = c0.applicationContext
        cache = data
        try {
            file(c).writeText(data.toString())
        } catch (_: Exception) {}
        c.getSharedPreferences(PREF, 0).edit().putString("data", data.toString()).apply()
    }

    /** Text-Zusatz für den System-Prompt (Persönlichkeit, Stil, gelernte Verhaltensregeln). */
    fun promptAddon(c: Context): String {
        val d = load(c)
        val sb = StringBuilder()
        d.optString("personality").takeIf { it.isNotBlank() }?.let {
            sb.append("Selbst-Verbesserung (Persönlichkeit): ").append(it.take(600)).append('\n')
        }
        d.optString("style").takeIf { it.isNotBlank() }?.let {
            sb.append("Selbst-Verbesserung (Stil): ").append(it.take(400)).append('\n')
        }
        d.optJSONArray("rules")?.let { rules ->
            if (rules.length() > 0) {
                sb.append("Selbst auferlegte Regeln:\n")
                for (i in 0 until minOf(rules.length(), 12)) {
                    val r = rules.optString(i).trim()
                    if (r.isNotBlank()) sb.append("- ").append(r.take(200)).append('\n')
                }
            }
        }
        d.optString("tool_hints").takeIf { it.isNotBlank() }?.let {
            sb.append("Werkzeug-Hinweise: ").append(it.take(400)).append('\n')
        }
        return sb.toString()
    }

    /** Face-Parameter als relative Multiplikatoren / Offsets (0 = unverändert). */
    fun faceParams(c: Context): JSONObject = load(c).optJSONObject("face") ?: JSONObject()

    fun featureFlags(c: Context): JSONObject = load(c).optJSONObject("flags") ?: JSONObject()

    fun flag(c: Context, key: String, default: Boolean = false): Boolean =
        featureFlags(c).optBoolean(key, default)

    /**
     * Wendet ein Live-Patch-JSON sofort an.
     * Erwartetes Schema (alle Felder optional):
     * {
     *   "personality":"...",
     *   "style":"...",
     *   "rules":["..."],
     *   "tool_hints":"...",
     *   "face":{"damp":0.9,"modeBlend":2.4,"blinkDur":0.22,...},
     *   "flags":{"verbose_status":true},
     *   "summary":"was live aktiv ist"
     * }
     */
    @Synchronized fun applyPatch(c0: Context, patch: JSONObject): String {
        val c = c0.applicationContext
        val d = load(c)
        val applied = ArrayList<String>()

        patch.optString("personality").takeIf { it.isNotBlank() }?.let {
            d.put("personality", it.take(1200)); applied.add("personality")
        }
        patch.optString("style").takeIf { it.isNotBlank() }?.let {
            d.put("style", it.take(800)); applied.add("style")
        }
        patch.optString("tool_hints").takeIf { it.isNotBlank() }?.let {
            d.put("tool_hints", it.take(800)); applied.add("tool_hints")
        }
        patch.optJSONArray("rules")?.let { incoming ->
            val existing = d.optJSONArray("rules") ?: JSONArray()
            val keep = JSONArray()
            val seen = HashSet<String>()
            for (i in 0 until existing.length()) {
                val r = existing.optString(i).trim()
                if (r.isNotBlank() && seen.add(r.lowercase())) keep.put(r)
            }
            for (i in 0 until incoming.length()) {
                val r = incoming.optString(i).trim()
                if (r.isNotBlank() && seen.add(r.lowercase())) keep.put(r)
            }
            while (keep.length() > 20) keep.remove(0)
            d.put("rules", keep)
            applied.add("rules(${incoming.length()})")
        }
        patch.optJSONObject("face")?.let { face ->
            val cur = d.optJSONObject("face") ?: JSONObject()
            val keys = face.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                cur.put(k, face.get(k))
            }
            d.put("face", cur)
            faceSeq = faceSeq + 1
            d.put("face_rev", faceSeq)
            applied.add("face")
        }
        patch.optJSONObject("flags")?.let { flags ->
            val cur = d.optJSONObject("flags") ?: JSONObject()
            val keys = flags.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                cur.put(k, flags.get(k))
            }
            d.put("flags", cur)
            applied.add("flags")
        }

        if (applied.isEmpty()) return "Keine live-anwendbaren Felder im Patch."

        d.put("last_apply", System.currentTimeMillis())
        d.put("last_summary", patch.optString("summary").ifBlank { applied.joinToString() }.take(300))
        save(c, d)
        return "Live aktiv: ${applied.joinToString()} — ${d.optString("last_summary")}"
    }

    fun status(c: Context): String {
        val d = load(c)
        val parts = ArrayList<String>()
        if (d.optString("personality").isNotBlank()) parts.add("Persönlichkeit")
        if (d.optString("style").isNotBlank()) parts.add("Stil")
        if ((d.optJSONArray("rules")?.length() ?: 0) > 0) parts.add("${d.optJSONArray("rules")!!.length()} Regeln")
        if (d.optJSONObject("face") != null && d.optJSONObject("face")!!.length() > 0) parts.add("Face")
        if (d.optJSONObject("flags") != null && d.optJSONObject("flags")!!.length() > 0) parts.add("Flags")
        val last = d.optLong("last_apply", 0L)
        return if (parts.isEmpty()) "Keine Live-Selbstverbesserungen aktiv."
        else "Live aktiv: ${parts.joinToString()}" +
            if (last > 0) " · zuletzt vor ${(System.currentTimeMillis() - last) / 60000} Min." else ""
    }

    @Synchronized fun clear(c0: Context) {
        val c = c0.applicationContext
        cache = JSONObject()
        faceSeq = 0
        try { file(c).delete() } catch (_: Exception) {}
        c.getSharedPreferences(PREF, 0).edit().clear().apply()
    }
}
