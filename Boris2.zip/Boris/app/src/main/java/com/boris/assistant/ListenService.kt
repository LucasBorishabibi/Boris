package com.boris.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/** Hält das Zuhören ("Boris …") auch bei geschlossener App oder gesperrtem Handy am Leben. */
class ListenService : Service() {
    private var wl: WakeListener? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("boris_listen", "Boris hört zu", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "boris_listen").setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Boris hört zu").setContentText("Sag „Boris“ …").setContentIntent(pi).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(7, n)
        Brain.load(this)
        wl = WakeListener(this, { t -> Core.handle(this, t) }, { m -> Core.voiceMode = m })
        Core.listener = wl
        wl?.start()
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onDestroy() {
        wl?.stop()
        if (Core.listener === wl) Core.listener = null
        super.onDestroy()
    }
}
