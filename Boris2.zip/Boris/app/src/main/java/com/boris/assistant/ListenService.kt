package com.boris.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import java.util.Locale

/** Dauerhaftes Wake-Word-Hören. Start erfolgt sichtbar durch den Nutzer in Boris. */
class ListenService : Service() {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())
    private var restarting = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification = NotificationCompat.Builder(this, "boris_listen")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Boris hört zu")
            .setContentText("Sag „Hey Boris“ oder „Boris“")
            .setOngoing(true).setCategory(Notification.CATEGORY_SERVICE).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(42, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(42, notification)
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale.GERMAN }
        startListening()
    }

    private fun startListening() {
        if (restarting) return
        restarting = true
        handler.postDelayed({
            restarting = false
            if (!SpeechRecognizer.isRecognitionAvailable(this)) return@postDelayed
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onResults(results: android.os.Bundle?) {
                        val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                        handle(text)
                        startListening()
                    }
                    override fun onError(error: Int) { startListening() }
                    override fun onReadyForSpeech(p: android.os.Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(r: Float) {}
                    override fun onBufferReceived(b: ByteArray?) {}
                    override fun onEndOfSpeech() { startListening() }
                    override fun onPartialResults(p: android.os.Bundle?) {}
                    override fun onEvent(t: Int, p: android.os.Bundle?) {}
                })
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE")
                    .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                startListening(i)
            }
        }, 250)
    }

    private fun handle(raw: String) {
        val lower = raw.lowercase(Locale.GERMAN).trim()
        val idx = listOf("hey boris", "boris").map { lower.indexOf(it) }.filter { it >= 0 }.minOrNull() ?: return
        val wake = if (lower.substring(idx).startsWith("hey boris")) "hey boris" else "boris"
        val command = raw.substring(idx + wake.length).trim().trim(',', '.', '!', '?', ':')
        if (command.isBlank()) {
            speak("Ja?")
            return
        }
        if (MainActivity.isForeground) sendBroadcast(Intent(ACTION_COMMAND).setPackage(packageName).putExtra("command", command)) else respondInBackground(command)
    }

    private fun respondInBackground(command: String) {
        Thread {
            try {
                val prefs = getSharedPreferences("boris", 0)
                val key = prefs.getString("key", "").orEmpty()
                if (key.isBlank()) { speak("Öffne Boris einmal und hinterlege deinen API-Key."); return@Thread }
                val memory = MemoryStore(this)
                val history = memory.loadHistory()
                history.put(org.json.JSONObject().put("role", "user").put("parts", org.json.JSONArray().put(org.json.JSONObject().put("text", command))))
                val reply = GeminiClient.chat(key, history, memory.memoryText(), memory.recentApps(), {}, { _, _ -> "Diese Aktion kann ich gerade nur aus der geöffneten Boris-Oberfläche ausführen." })
                history.put(org.json.JSONObject().put("role", "model").put("parts", org.json.JSONArray().put(org.json.JSONObject().put("text", reply))))
                memory.addMemory("Nutzer: $command"); memory.addMemory("Boris: $reply"); memory.saveHistory(history)
                handler.post { speak(reply) }
            } catch (e: Exception) { handler.post { speak("Da ist etwas schiefgelaufen.") } }
        }.start()
    }

    private fun speak(text: String) {
        tts?.setPitch(0.68f); tts?.setSpeechRate(0.90f)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "boris")
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel("boris_listen", "Boris Sprachassistent", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onDestroy() { recognizer?.destroy(); tts?.shutdown(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
    companion object { const val ACTION_COMMAND = "com.boris.assistant.BORIS_COMMAND" }
}
