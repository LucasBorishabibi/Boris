package com.boris.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.*
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import java.util.Locale

/** Visible foreground microphone loop. Wake: Boris / Hey Boris. Session ends: Boris Ende. */
class ListenService : Service() {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var session = false
    @Volatile private var speaking = false
    @Volatile private var processing = false
    private var restarting = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification = NotificationCompat.Builder(this, "boris_listen")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Boris hört zu")
            .setContentText("„Boris“ / „Hey Boris“ · „Boris Ende“ beendet die Sitzung")
            .setOngoing(true).setCategory(Notification.CATEGORY_SERVICE).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(42, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(42, notification)
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) { tts?.language=Locale.GERMAN; tts?.setPitch(.63f); tts?.setSpeechRate(.94f) } }
        val rf=android.content.IntentFilter(ACTION_RESPONSE)
        if(Build.VERSION.SDK_INT>=33) registerReceiver(responseReceiver,rf,android.content.Context.RECEIVER_NOT_EXPORTED) else registerReceiver(responseReceiver,rf)
        startListening(80)
    }

    private fun startListening(delay: Long = 80) {
        if (speaking || processing || restarting) return
        restarting = true
        handler.postDelayed({
            restarting = false
            if (speaking || processing || !SpeechRecognizer.isRecognitionAvailable(this)) return@postDelayed
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object: RecognitionListener {
                    override fun onResults(results: Bundle?) { handle(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()); startListening(40) }
                    override fun onError(error: Int) { startListening(if(error==SpeechRecognizer.ERROR_NO_MATCH) 20 else 120) }
                    override fun onEndOfSpeech() { startListening(30) }
                    override fun onReadyForSpeech(p: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(r: Float) {}
                    override fun onBufferReceived(b: ByteArray?) {}
                    override fun onPartialResults(p: Bundle?) {}
                    override fun onEvent(t: Int,p: Bundle?) {}
                })
                val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE,"de-DE")
                    .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false)
                    .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,1)
                    .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS,650)
                    .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS,250)
                startListening(i)
            }
        },delay)
    }

    private fun handle(raw:String) {
        val lower=raw.lowercase(Locale.GERMAN).trim()
        if (lower.contains("boris ende") || lower.contains("hey boris ende")) {
            session=false
            speak("Alles klar.")
            return
        }
        if (session) {
            if (lower.isNotBlank()) dispatch(raw)
            return
        }
        val hey=lower.indexOf("hey boris")
        val boris=lower.indexOf("boris")
        val idx=listOf(hey,boris).filter{it>=0}.minOrNull() ?: return
        val wake=if(hey>=0 && hey==idx) "hey boris" else "boris"
        session=true
        val command=raw.substring((idx+wake.length).coerceAtMost(raw.length)).trim().trim(',', '.', '!', '?', ':')
        if(command.isBlank()) speak("Ja?") else dispatch(command)
    }

    private fun dispatch(command:String) {
        processing = true
        stopRecognition()
        if (!MainActivity.isForeground) {
            try { startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("boris_external_command", command)) } catch (_: Exception) {}
        }
        sendBroadcast(Intent(ACTION_COMMAND).setPackage(packageName).putExtra("command",command).putExtra("service",true))
    }

    private fun stopRecognition(){ try{recognizer?.cancel()}catch(_:Exception){} }

    private val responseReceiver=object: android.content.BroadcastReceiver(){
        override fun onReceive(context: android.content.Context,intent:Intent){
            if(intent.action!=ACTION_RESPONSE)return
            val text=intent.getStringExtra("text").orEmpty()
            if(text.isNotBlank()) speak(text)
        }
    }

    private fun speak(text:String){
        processing=false
        speaking=true; stopRecognition()
        tts?.setPitch(.63f); tts?.setSpeechRate(.94f)
        tts?.speak(text,TextToSpeech.QUEUE_FLUSH,"", "boris")
        val ms=(text.length*48L).coerceIn(900,6500)
        handler.postDelayed({ speaking=false; startListening(70) },ms)
    }

    private fun createChannel(){ if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("boris_listen","Boris Sprachassistent",NotificationManager.IMPORTANCE_LOW)) }
    override fun onDestroy(){ try{unregisterReceiver(responseReceiver)}catch(_:Exception){}; recognizer?.destroy();tts?.shutdown();super.onDestroy() }
    override fun onBind(intent:Intent?):IBinder?=null
    companion object { const val ACTION_COMMAND="com.boris.assistant.BORIS_COMMAND"; const val ACTION_RESPONSE="com.boris.assistant.BORIS_RESPONSE" }
}
