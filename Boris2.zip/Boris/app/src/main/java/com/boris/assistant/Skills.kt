package com.boris.assistant

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Selbstgeschriebene Fähigkeiten ("Skills"): kleine JavaScript-Programme, die Boris selbst programmiert, testet und speichert.
 * Sie laufen in einer abgeschotteten Umgebung ohne Netz und dürfen nur eine feste Liste harmloser Werkzeuge benutzen.
 */
object Skills {
    private var file: File? = null
    private val list = ArrayList<JSONObject>()

    @Synchronized fun load(c: Context) {
        if (file != null) return
        val f = File(c.applicationContext.filesDir, "skills.json")
        file = f
        try {
            if (f.exists()) { val a = JSONArray(f.readText()); for (i in 0 until a.length()) list.add(a.getJSONObject(i)) }
        } catch (e: Exception) { Dbg.d("Skills laden: " + e.message?.take(60)) }
    }

    @Synchronized private fun save() {
        val f = file ?: return
        try {
            val a = JSONArray(); list.forEach { a.put(it) }
            val tmp = File(f.parentFile, "skills.json.tmp")
            tmp.writeText(a.toString())
            if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f) }
        } catch (e: Exception) { Dbg.d("Skills speichern: " + e.message?.take(60)) }
    }

    @Synchronized fun all(): List<JSONObject> = ArrayList(list)
    @Synchronized fun get(name: String): JSONObject? = list.firstOrNull { it.optString("name").equals(name.trim(), true) }
    @Synchronized fun put(o: JSONObject) {
        list.removeAll { it.optString("name") == o.optString("name") }
        list.add(o)
        while (list.size > 40) list.removeAt(0)
        save()
    }
    @Synchronized fun remove(name: String): Boolean { val r = list.removeAll { it.optString("name").equals(name.trim(), true) }; if (r) save(); return r }

    @Synchronized fun recordUse(name: String, ok: Boolean, err: String) {
        val o = list.firstOrNull { it.optString("name") == name } ?: return
        o.put("uses", o.optInt("uses") + 1)
        if (ok) o.put("streakFails", 0)
        else { o.put("fails", o.optInt("fails") + 1); o.put("streakFails", o.optInt("streakFails") + 1); o.put("lastErr", err.take(200)) }
        save()
    }

    /** Ein Skill, der zweimal hintereinander scheiterte, wird im Leerlauf repariert. */
    @Synchronized fun broken(): JSONObject? = list.firstOrNull { it.optInt("streakFails") >= 2 }

    @Synchronized fun digest(): String {
        if (list.isEmpty()) return "(noch keine)"
        return list.takeLast(12).joinToString("\n") {
            val ps = it.optJSONObject("params")?.keys()?.asSequence()?.joinToString(",") ?: ""
            "- ${it.optString("name")}($ps): ${it.optString("desc")}"
        }
    }

    @Synchronized fun recentReport(): String {
        val recent = list.filter { System.currentTimeMillis() - it.optLong("ts") < 3 * 86_400_000L }
        if (recent.isEmpty()) return ""
        return "\nSelbst programmiert: " + recent.joinToString("; ") { "${it.optString("name")} (${it.optString("desc").take(60)})" }
    }

    fun run(c: Context, name: String, argsJson: String): String {
        val s = get(name) ?: return "Fehler: Skill „$name“ gibt es nicht."
        val args = try { if (argsJson.isBlank()) JSONObject() else JSONObject(argsJson) } catch (e: Exception) { JSONObject() }
        val r = Sandbox.run(c, s.getString("code"), args, false)
        recordUse(s.getString("name"), r.ok, r.error)
        return if (r.ok) "INFO: " + r.result.ifBlank { "Fertig." } else "Fehler: Skill ${s.getString("name")}: ${r.error}"
    }
}

object SkillCheck {
    private val FORBIDDEN = Regex(
        "\\b(eval|Function|XMLHttpRequest|fetch|WebSocket|importScripts|import|require|document|window|localStorage|sessionStorage|indexedDB|" +
            "navigator|location|postMessage|setTimeout|setInterval|requestAnimationFrame|Worker|globalThis|constructor|__proto__|prototype|__B|" +
            "Reflect|Proxy|WebAssembly|async|await|Promise)\\b")

    /** null = in Ordnung, sonst die Fehlermeldung (wird dem Modell zur Korrektur zurückgegeben). */
    fun validate(code: String): String? {
        if (code.length > 6000) return "Der Code ist zu lang (höchstens 6000 Zeichen)."
        if (!Regex("function\\s+run\\s*\\(").containsMatchIn(code)) return "Es fehlt die Funktion function run(args)."
        val m = FORBIDDEN.find(code)
        if (m != null) return "Verbotenes Element im Code: ${m.value}"
        return null
    }
}

/** Die Brücke, über die ein Skill (und nur er) Werkzeuge aufrufen darf. */
object SandboxBridge {
    @JavascriptInterface fun tool(id: Int, name: String, argsJson: String): String {
        val r = Sandbox.runs[id] ?: return "Fehler: Lauf ist schon beendet"
        if (name !in Sandbox.ALLOWED) return "Fehler: Das Werkzeug $name ist für Skills nicht erlaubt"
        if (++r.calls > 12) return "Fehler: zu viele Werkzeugaufrufe"
        if (r.dry) return "(Testlauf) $name ok"
        return try { runTool(r.ctx, name, JSONObject(argsJson)).removePrefix("INFO:").trim() } catch (e: Exception) { "Fehler: " + e.message }
    }

    @JavascriptInterface fun done(id: Int, json: String) {
        val r = Sandbox.runs[id] ?: return
        r.out = json
        r.latch.countDown()
    }
}

object Sandbox {
    class Result(val ok: Boolean, val result: String, val error: String)
    class Run(val ctx: Context, val dry: Boolean) {
        val latch = CountDownLatch(1)
        @Volatile var out: String? = null
        @Volatile var calls = 0
    }

    val runs = ConcurrentHashMap<Int, Run>()
    /** Nur harmlose Werkzeuge: kein Senden von Nachrichten, keine Anrufe, kein Agent. */
    val ALLOWED = setOf("set_timer", "set_alarm", "set_reminder", "spotify_play", "spotify_liked", "open_app", "navigate", "search_web",
        "web_answer", "torch", "set_volume", "read_calendar", "read_notifications", "remember", "list_tasks")
    @Volatile private var counter = 0
    private val ui = Handler(Looper.getMainLooper())

    private const val PAGE = "<!doctype html><html><head><meta http-equiv=\"Content-Security-Policy\" " +
        "content=\"default-src 'none'; script-src 'unsafe-inline' 'unsafe-eval'\"></head><body></body></html>"

    private fun wrapper(id: Int, code: String, args: JSONObject): String =
        "(function(){var __id=$id;" +
            "var Boris={tool:function(n,a){return __B.tool(__id,String(n),JSON.stringify(a||{}));}," +
            "web:function(q){return __B.tool(__id,'web_answer',JSON.stringify({question:String(q)}));}," +
            "remember:function(f){return __B.tool(__id,'remember',JSON.stringify({fact:String(f)}));}};" +
            "try{var f=new Function('Boris','args'," + JSONObject.quote(code + "\n;return typeof run==='function'?run(args):undefined;") + ");" +
            "var r=f(Boris," + args.toString() + ");" +
            "__B.done(__id,JSON.stringify({ok:true,result:(r===undefined||r===null)?'':String(r)}));" +
            "}catch(e){__B.done(__id,JSON.stringify({ok:false,error:String((e&&e.message)||e)}));}})();"

    /** Führt Skill-Code aus. dry = Testlauf: Werkzeuge tun nichts, der Code wird aber vollständig durchlaufen. */
    @SuppressLint("SetJavaScriptEnabled")
    fun run(c: Context, code: String, args: JSONObject, dry: Boolean, timeoutMs: Long = 12000): Result {
        val id = ++counter
        val r = Run(c.applicationContext, dry)
        runs[id] = r
        val holder = arrayOfNulls<WebView>(1)
        ui.post {
            try {
                val w = WebView(c.applicationContext)
                holder[0] = w
                w.settings.javaScriptEnabled = true
                w.settings.allowFileAccess = false
                w.settings.allowContentAccess = false
                w.settings.blockNetworkLoads = true
                w.addJavascriptInterface(SandboxBridge, "__B")
                var started = false
                w.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String?) {
                        if (started) return
                        started = true
                        view.evaluateJavascript(wrapper(id, code, args), null)
                    }
                }
                w.loadDataWithBaseURL("https://boris.invalid/", PAGE, "text/html", "utf-8", null)
            } catch (e: Exception) {
                r.out = JSONObject().put("ok", false).put("error", "WebView: " + e.message).toString()
                r.latch.countDown()
            }
        }
        val finished = r.latch.await(timeoutMs, TimeUnit.MILLISECONDS)
        runs.remove(id)
        ui.post { try { holder[0]?.let { it.stopLoading(); it.removeJavascriptInterface("__B"); it.destroy() } } catch (e: Exception) {} }
        if (!finished) return Result(false, "", "Zeitüberschreitung (der Code lief zu lange)")
        return try {
            val j = JSONObject(r.out ?: "{}")
            if (j.optBoolean("ok")) Result(true, j.optString("result"), "") else Result(false, "", j.optString("error", "unbekannter Fehler"))
        } catch (e: Exception) { Result(false, "", "Ergebnis nicht lesbar") }
    }
}

/** Boris programmiert sich selbst neue Fähigkeiten: Modell schreibt Code, Boris prüft, testet und repariert ihn, bevor er ihn speichert. */
object SelfCoder {
    fun enabled(c: Context) = c.getSharedPreferences("boris", 0).getBoolean("selfcode", true)

    private const val SPEC = "Du schreibst kleine JavaScript-Skills für Boris, einen Android-Sprachassistenten. " +
        "REGELN: Genau eine Funktion function run(args), vollständig synchron (kein async, await, Promise, setTimeout). " +
        "Sie gibt einen kurzen deutschen Antworttext als String zurück, gut vorlesbar. " +
        "Erlaubt ist reines JavaScript (Math, Date, JSON, String, Array, RegExp, Number, parseFloat). " +
        "VERBOTEN: fetch, XMLHttpRequest, eval, Function, import, require, document, window, localStorage, constructor, prototype. " +
        "Zugriff auf das Handy nur über diese Funktionen: Boris.tool(name, objekt) gibt einen Text zurück; erlaubte Werkzeuge: " +
        "set_timer{seconds,label}, set_alarm{hour,minute,label}, set_reminder{text,in_minutes oder at}, spotify_play{query}, open_app{app}, " +
        "navigate{destination}, search_web{query}, web_answer{question}, torch{on}, set_volume{percent}, read_calendar{days}, " +
        "read_notifications{}, remember{fact}. Zusätzlich Boris.web(frage) für aktuelle Informationen. Höchstens 12 Aufrufe. " +
        "Prüfe Eingaben defensiv (args kann Felder auslassen), und liefere bei fehlenden Angaben eine kurze Rückfrage als Text. " +
        "ANTWORTFORMAT, genau so, ohne weiteren Text:\n" +
        "### NAME\nkurzer_name_in_snake_case\n" +
        "### BESCHREIBUNG\nein Satz: wann soll Boris den Skill benutzen\n" +
        "### PARAMETER\n{\"feld\":\"Bedeutung\"} (leeres Objekt {}, wenn keine)\n" +
        "### CODE\nfunction run(args) { ... }\n" +
        "### TESTS\n[{\"args\":{...},\"contains\":\"Teilstring der erwarteten Antwort\"}] (1 bis 3 Fälle)"

    private class Draft(val name: String, val desc: String, val params: JSONObject, val code: String, val tests: JSONArray)

    private fun section(text: String, name: String): String? =
        Regex("###\\s*$name\\s*\\n([\\s\\S]*?)(?=\\n###\\s|\\z)").find(text)?.groupValues?.get(1)?.trim()

    private fun parse(text: String): Draft? {
        val name = section(text, "NAME")?.lines()?.firstOrNull()?.trim()?.lowercase()?.replace(Regex("[^a-z0-9_]"), "_")?.trim('_') ?: return null
        if (name.length !in 3..32) return null
        val desc = section(text, "BESCHREIBUNG")?.take(160) ?: return null
        val code = (section(text, "CODE") ?: return null).replace(Regex("^```[a-z]*\\s*"), "").replace(Regex("```\\s*$"), "").trim()
        val params = try { JSONObject(section(text, "PARAMETER") ?: "{}") } catch (e: Exception) { JSONObject() }
        val tests = try { JSONArray((section(text, "TESTS") ?: "[]").replace("```json", "").replace("```", "").trim()) } catch (e: Exception) { JSONArray() }
        return Draft(name, desc, params, code, tests)
    }

    /** Erst OpenRouter (Coder-Modelle), sonst Gemini. Auto-Läufe im Leerlauf nutzen nie Gemini. */
    private fun write(c: Context, prompt: String, auto: Boolean): String? {
        if (OpenRouter.usable(c)) OpenRouter.chat(c, SPEC, prompt, true, 2500)?.let { return it }
        if (auto) return null
        val key = Core.key(c)
        if (key.isBlank() || !RateGuard.ok("gem")) return null
        return try {
            val h = JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt))))
            val res = GeminiClient.generate(key, SPEC, JSONArray(), h, listOf("gemini-flash-latest", "gemini-3.5-flash-lite"), 3000)
            val parts = res.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
            (0 until parts.length()).joinToString("") { if (parts.getJSONObject(it).optBoolean("thought")) "" else parts.getJSONObject(it).optString("text") }
        } catch (e: Exception) { Dbg.d("Selfcoding: " + e.message?.take(70)); null }
    }

    /** null = alle Tests bestanden. Skills ohne Werkzeuge laufen echt, Skills mit Werkzeugen im Testlauf. */
    private fun test(c: Context, d: Draft, strict: Boolean): String? {
        val usesBoris = d.code.contains("Boris.")
        val cases = ArrayList<JSONObject>()
        for (i in 0 until d.tests.length()) d.tests.optJSONObject(i)?.let { cases.add(it) }
        if (cases.isEmpty()) cases.add(JSONObject().put("args", JSONObject()))
        for (t in cases.take(3)) {
            val args = t.optJSONObject("args") ?: JSONObject()
            val r = Sandbox.run(c, d.code, args, usesBoris)
            if (!r.ok) return "Der Testlauf mit $args schlug fehl: ${r.error}"
            if (!usesBoris) {
                if (r.result.isBlank()) return "Der Testlauf mit $args lieferte keinen Text."
                val exp = t.optString("contains")
                if (strict && exp.isNotBlank() && !r.result.contains(exp, true))
                    return "Der Testlauf mit $args lieferte „${r.result.take(80)}“, erwartet war etwas mit „$exp“. Korrigiere Code oder Test."
            }
        }
        return null
    }

    private fun uniqueName(n: String): String {
        if (Skills.get(n) == null) return n
        var i = 2
        while (Skills.get("${n}_$i") != null) i++
        return "${n}_$i"
    }

    /** Programmiert, prüft und speichert einen Skill (bis zu 3 Versuche mit Fehlerrückmeldung). existing = Reparatur. */
    fun create(c: Context, goal: String, auto: Boolean, existing: JSONObject? = null, onStatus: (String) -> Unit = {}): String {
        if (!enabled(c)) return "Fehler: Selfcoding ist ausgeschaltet."
        var feedback = ""
        for (attempt in 1..3) {
            onStatus("Programmiere Skill ($attempt/3) …")
            val p = StringBuilder("Aufgabe für den Skill: $goal\n")
            if (existing != null) p.append("\nBestehender Skill, der repariert werden soll (Namen beibehalten):\nNAME: ${existing.optString("name")}\n" +
                "CODE:\n${existing.optString("code")}\nLetzter Fehler: ${existing.optString("lastErr")}\n")
            p.append("\nBereits vorhandene Skills (nicht doppelt bauen):\n${Skills.digest()}\n")
            if (feedback.isNotBlank()) p.append("\nDein letzter Versuch ist gescheitert: $feedback\nKorrigiere das und antworte erneut im vollständigen Format.\n")
            val out = write(c, p.toString(), auto)
                ?: return "Fehler: Gerade ist kein Programmier-Modell erreichbar (Limit erreicht, kein Key oder keine Verbindung)."
            val d = parse(out)
            if (d == null) { feedback = "Das Antwortformat stimmte nicht (### NAME, ### BESCHREIBUNG, ### PARAMETER, ### CODE, ### TESTS)."; continue }
            val bad = SkillCheck.validate(d.code)
            if (bad != null) { feedback = bad; continue }
            val err = test(c, d, attempt < 3)
            if (err != null) { feedback = err; Dbg.d("Selfcoding Versuch $attempt: " + err.take(80)); continue }
            val name = existing?.optString("name") ?: uniqueName(d.name)
            Skills.put(JSONObject().put("name", name).put("desc", d.desc).put("params", d.params).put("code", d.code).put("tests", d.tests)
                .put("ver", (existing?.optInt("ver") ?: 0) + 1).put("auto", auto).put("ts", System.currentTimeMillis())
                .put("uses", existing?.optInt("uses") ?: 0).put("fails", 0).put("streakFails", 0))
            Learning.noteSkill()
            return "Neuer Skill „$name“ ist fertig und getestet: ${d.desc}"
        }
        return "Fehler: Der Skill hat nach drei Versuchen die Tests nicht bestanden ($feedback)"
    }

    /** Im Leerlauf: erst kaputte Skills reparieren, sonst höchstens einen neuen aus der Idee der Lernsitzung bauen. */
    fun idle(c: Context, idea: String, alive: () -> Boolean, topic: (String) -> Unit) {
        if (!enabled(c) || !alive() || !OpenRouter.usable(c) || Budget.left(c, "skill_auto") <= 0) return
        val broken = Skills.broken()
        if (broken != null) {
            Budget.inc(c, "skill_auto")
            topic("Repariere Skill: " + broken.optString("name"))
            Dbg.d("Selfcoding: " + create(c, broken.optString("desc"), true, broken).take(100))
            return
        }
        if (idea.length < 12 || !Knowledge.acceptable(idea, 12)) return
        Budget.inc(c, "skill_auto")
        topic("Programmiere neuen Skill")
        Dbg.d("Selfcoding: " + create(c, idea, true).take(100))
    }
}
