package com.boris.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder

/**
 * Das Sprachmodell fürs Selbstlernen. Läuft über OpenRouter und nimmt ausschließlich kostenlose Modelle (":free").
 * Kostenlos heißt dort: 20 Anfragen pro Minute und 50 pro Tag, solange man nie Guthaben gekauft hat.
 */
object OpenRouter {
    class Failure(val code: Int, msg: String) : RuntimeException(msg)

    private const val ENDPOINT = "https://openrouter.ai/api/v1/chat/completions"
    private const val MODELS_URL = "https://openrouter.ai/api/v1/models"
    private val prefer = listOf("llama-3.3-70b", "gpt-oss-120b", "qwen3", "qwen-2.5-72b", "deepseek", "gemma-3-27b",
        "mistral-small", "glm", "nemotron", "gpt-oss-20b", "llama")
    private val thinkRx = Regex("<think>[\\s\\S]*?</think>")

    @Volatile private var cached: List<String> = emptyList()
    @Volatile private var cachedAt = 0L

    fun key(c: Context): String = c.getSharedPreferences("boris", 0).getString("or_key", "")?.trim().orEmpty()

    /** Die aktuell kostenlosen Textmodelle, beste zuerst. Die Liste ändert sich bei OpenRouter laufend, deshalb wird sie abgefragt. */
    @Synchronized fun freeModels(): List<String> {
        val now = System.currentTimeMillis()
        if (cached.isNotEmpty() && now - cachedAt < 12 * 3_600_000L) return cached
        val out = ArrayList<String>()
        try {
            val c = URL(MODELS_URL).openConnection() as HttpURLConnection
            c.connectTimeout = 8000; c.readTimeout = 12000
            val data = JSONObject(c.inputStream.bufferedReader().use { it.readText() }).getJSONArray("data")
            val free = ArrayList<Triple<String, Int, Int>>()
            var router = false
            for (i in 0 until data.length()) {
                val o = data.optJSONObject(i) ?: continue
                val id = o.optString("id")
                if (id == "openrouter/free") router = true
                if (!id.endsWith(":free")) continue
                val outMods = o.optJSONObject("architecture")?.optJSONArray("output_modalities")
                var textOnly = true
                if (outMods != null) for (k in 0 until outMods.length()) if (outMods.optString(k) != "text") textOnly = false
                if (!textOnly || o.optInt("context_length") < 16000) continue
                val rank = prefer.indexOfFirst { id.contains(it) }.let { if (it < 0) 99 else it }
                free.add(Triple(id, rank, o.optInt("context_length")))
            }
            free.sortedWith(compareBy<Triple<String, Int, Int>>({ it.second }, { -it.third })).take(2).forEach { out.add(it.first) }
            if (router) out.add("openrouter/free")
        } catch (e: Exception) { Dbg.d("OpenRouter Modelle: " + e.message?.take(60)) }
        if (out.isEmpty()) out.add("openrouter/free")
        cached = out; cachedAt = now
        return out
    }

    /** Eine Anfrage. Die Modellliste dient als Ausweichkette, falls eines gerade ausgelastet ist. */
    fun complete(key: String, system: String, user: String, maxTokens: Int): String {
        val body = JSONObject()
            .put("models", JSONArray(freeModels().take(3)))
            .put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", system))
                .put(JSONObject().put("role", "user").put("content", user)))
            .put("max_tokens", maxTokens)
            .put("temperature", 0.2)
        val c = URL(ENDPOINT).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 10000; c.readTimeout = 60000; c.doOutput = true
        c.setRequestProperty("Authorization", "Bearer $key")
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("X-Title", "Boris")
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw Failure(code, txt.take(200))
        val j = JSONObject(txt)
        j.optJSONObject("error")?.let { throw Failure(it.optInt("code", 500), it.optString("message").take(200)) }
        val content = j.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content").orEmpty()
        val clean = thinkRx.replace(content, "").trim()
        if (clean.isBlank()) throw Failure(0, "leere Antwort")
        return clean
    }
}

/** Kostenlose Websuche ohne Schlüssel: Wikipedia (Fakten samt Text) und DuckDuckGo (Breite). */
object Web {
    class Hit(val title: String, val url: String, val snippet: String, val text: String) {
        val domain: String get() = try { URL(url).host.removePrefix("www.") } catch (e: Exception) { "" }
    }

    private const val UA = "Mozilla/5.0 (Linux; Android 14; SM-A245F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"
    private val tagRx = Regex("<[^>]+>")
    private val scriptRx = Regex("<(script|style|noscript|nav|footer|header|svg)[\\s\\S]*?</\\1>", RegexOption.IGNORE_CASE)
    private val commentRx = Regex("<!--[\\s\\S]*?-->")
    private val spaceRx = Regex("\\s+")
    private val ddgTitle = Regex("<a[^>]*class=\"result__a\"[^>]*href=\"([^\"]+)\"[^>]*>([\\s\\S]*?)</a>")
    private val ddgSnip = Regex("<a[^>]*class=\"result__snippet\"[^>]*>([\\s\\S]*?)</a>")

    fun search(question: String, topic: String): List<Hit> {
        val out = ArrayList<Hit>()
        try { out.addAll(wiki(topic, "de")) } catch (e: Exception) { Dbg.d("Wikipedia: " + e.message?.take(50)) }
        try { out.addAll(ddg(question)) } catch (e: Exception) { Dbg.d("Suche: " + e.message?.take(50)) }
        val seen = HashSet<String>()
        return out.filter { seen.add(it.url) }.take(10)
    }

    private fun get(url: String, max: Int): String? {
        if (!publicHost(url)) return null
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 10000; c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", UA); c.setRequestProperty("Accept-Language", "de,en;q=0.7")
        if (c.responseCode !in 200..299) return null
        val type = c.contentType.orEmpty().lowercase()
        if (!(type.contains("text/html") || type.contains("text/plain") || type.contains("json") || type.contains("xml"))) return null
        val out = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        c.inputStream.use { ins ->
            while (out.size() < max) { val n = ins.read(buf); if (n < 0) break; out.write(buf, 0, n) }
        }
        return out.toString("UTF-8")
    }

    private fun wiki(topic: String, lang: String): List<Hit> {
        val u = "https://$lang.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=" + URLEncoder.encode(topic, "UTF-8") +
            "&gsrlimit=3&prop=extracts%7Cinfo&inprop=url&exintro=1&explaintext=1&exchars=1500&format=json&utf8=1"
        val txt = get(u, 400_000) ?: return emptyList()
        val pages = JSONObject(txt).optJSONObject("query")?.optJSONObject("pages") ?: return emptyList()
        val out = ArrayList<Hit>()
        val keys = pages.keys()
        while (keys.hasNext()) {
            val p = pages.optJSONObject(keys.next()) ?: continue
            val ex = p.optString("extract").trim()
            val url = p.optString("fullurl")
            if (ex.length > 80 && url.startsWith("http")) out.add(Hit(p.optString("title"), url, ex.take(160), ex))
        }
        return out
    }

    private fun ddg(q: String): List<Hit> {
        val html = get("https://html.duckduckgo.com/html/?q=" + URLEncoder.encode(q, "UTF-8"), 300_000) ?: return emptyList()
        val titles = ddgTitle.findAll(html).toList()
        val snips = ddgSnip.findAll(html).toList()
        val out = ArrayList<Hit>()
        for (i in 0 until minOf(titles.size, 6)) {
            var href = titles[i].groupValues[1]
            val m = Regex("uddg=([^&]+)").find(href)
            if (m != null) href = URLDecoder.decode(m.groupValues[1], "UTF-8")
            if (href.startsWith("//")) href = "https:$href"
            if (!href.startsWith("http")) continue
            val snip = if (i < snips.size) plain(snips[i].groupValues[1]) else ""
            out.add(Hit(plain(titles[i].groupValues[2]), href, snip, ""))
        }
        return out
    }

    /** Lesbarer Text einer Seite (ohne Menüs und Skripte), auf max Zeichen gekürzt. */
    fun fetchText(url: String, max: Int): String? {
        return try {
            val html = get(url, 300_000) ?: return null
            plain(scriptRx.replace(commentRx.replace(html, " "), " ")).take(max)
        } catch (e: Exception) { null }
    }

    private fun plain(s: String): String = spaceRx.replace(
        tagRx.replace(s, " ").replace("&nbsp;", " ").replace("&amp;", "&").replace("&quot;", "\"")
            .replace("&#39;", "'").replace("&lt;", "<").replace("&gt;", ">"), " ").trim()

    /** Nur öffentliche Webadressen, nie das Heimnetz oder das Gerät selbst. */
    private fun publicHost(url: String): Boolean = try {
        val u = URL(url)
        (u.protocol == "http" || u.protocol == "https") &&
            InetAddress.getAllByName(u.host).none { it.isAnyLocalAddress || it.isLoopbackAddress || it.isLinkLocalAddress || it.isSiteLocalAddress }
    } catch (e: Exception) { false }
}
