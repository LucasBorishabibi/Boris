package com.boris.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Free-tier OpenRouter fallback used only by the idle-learning pipeline. */
object FreeLearningClient {
    class Cancelled : RuntimeException("abgebrochen")

    fun generate(
        apiKey: String,
        system: String,
        prompt: String,
        onConn: ((HttpURLConnection) -> Unit)? = null,
        cancelled: () -> Boolean = { false }
    ): String {
        if (apiKey.isBlank()) throw IllegalArgumentException("OpenRouter-Key fehlt")
        if (cancelled()) throw Cancelled()
        val messages = JSONArray()
            .put(JSONObject().put("role", "system").put("content", system + "\n\nWenn du keine belastbaren Informationen hast, gib leere JSON-Listen statt zu raten."))
            .put(JSONObject().put("role", "user").put("content", prompt))
        val body = JSONObject()
            .put("model", "openrouter/free")
            .put("messages", messages)
            .put("temperature", 0.2)
            .put("max_tokens", 1200)
        val conn = URL("https://openrouter.ai/api/v1/chat/completions").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 10000
        conn.readTimeout = 60000
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("Authorization", "Bearer $apiKey")
        conn.setRequestProperty("X-OpenRouter-Title", "Boris Learning")
        conn.doOutput = true
        onConn?.invoke(conn)
        try {
            if (cancelled()) throw Cancelled()
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            if (cancelled()) throw Cancelled()
            val code = conn.responseCode
            val response = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val detail = try { JSONObject(response).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
                throw IllegalStateException("OpenRouter API $code${if (!detail.isNullOrBlank()) ": ${detail.take(140)}" else ""}")
            }
            val root = JSONObject(response)
            val content = root.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content").orEmpty()
            if (content.isBlank()) throw IllegalStateException("OpenRouter lieferte keine Antwort")
            return content
        } finally {
            try { conn.disconnect() } catch (_: Exception) {}
        }
    }
}
