package com.boris.assistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager

/** Prüft alles, was Boris braucht, und zeigt, was fehlt. */
object SelfTest {
    fun run(ctx: Context): List<Pair<Boolean, String>> {
        val out = ArrayList<Pair<Boolean, String>>()
        fun perm(p: String, label: String) { out.add((ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED) to "Berechtigung: $label") }
        perm(Manifest.permission.RECORD_AUDIO, "Mikrofon")
        perm(Manifest.permission.READ_CONTACTS, "Kontakte")
        perm(Manifest.permission.SEND_SMS, "SMS")
        perm(Manifest.permission.CALL_PHONE, "Anrufe")
        perm(Manifest.permission.READ_CALENDAR, "Kalender")
        perm("android.permission.POST_NOTIFICATIONS", "Benachrichtigungen")
        val svc = AutoSendService.instance
        out.add((svc != null) to "Agent-Zugriff verbunden")
        out.add((NotifService.instance != null) to "Benachrichtigungszugriff verbunden")
        out.add((Core.listener != null) to "Zuhören aktiv (Mikrofon-Schleife)")
        val shot = try { svc?.screenshotB64() != null } catch (e: Exception) { false }
        out.add(shot to "Screenshot-Fähigkeit (nur bei Bedarf genutzt)")
        val t0 = System.currentTimeMillis()
        val r = Notify.ask(ctx, "Antworte mit genau einem Wort.", "Sag OK.")
        out.add((r != null) to "Gemini-Verbindung (${System.currentTimeMillis() - t0} ms)")
        val hq = Hub.jarvis(ctx).hqAvailable(Core.key(ctx))
        out.add(hq to "HQ-Stimme (sonst Handy-Stimme)")
        out.add((Brain.all().isNotEmpty()) to "Gehirn enthält ${Brain.all().size} Einträge")
        out.add(true to "Kurzbefehle gelernt: ${Recipes.count(ctx)} · Geplante Aufgaben: ${Scheduler.all(ctx).size}")
        return out
    }
}
