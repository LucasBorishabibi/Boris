package com.boris.assistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager

/** Prüft alles, was Boris braucht, und zeigt, was fehlt. */
object SelfTest {
    fun run(ctx: Context): List<Pair<Boolean, String>> {
        val out = ArrayList<Pair<Boolean, String>>()
        fun perm(p: String, label: String) { out.add((ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED) to "Berechtigung: $label") }
        perm(Manifest.permission.RECORD_AUDIO, "Mikrofon")
        perm(Manifest.permission.READ_CONTACTS, "Kontakte")
        perm(Manifest.permission.SEND_SMS, "SMS")
        perm(Manifest.permission.CALL_PHONE, "Anrufe")
        perm(Manifest.permission.READ_CALENDAR, "Kalender")
        perm("android.permission.POST_NOTIFICATIONS", "Benachrichtigungen")
        val svc = AutoSendService.instance
        out.add((svc != null) to "Agent-Zugriff verbunden")
        out.add((NotifService.instance != null) to "Benachrichtigungszugriff verbunden")
        out.add((Core.listener != null) to "Zuhören aktiv (Mikrofon-Schleife)")
        val shot = try { svc?.screenshotB64() != null } catch (e: Exception) { false }
        out.add(shot to "Screenshot-Fähigkeit (nur bei Bedarf genutzt)")
        val t0 = System.currentTimeMillis()
        val r = Notify.ask(ctx, "Antworte mit genau einem Wort.", "Sag OK.")
        out.add((r != null) to "Gemini-Verbindung (${System.currentTimeMillis() - t0} ms)")
        val hq = Hub.jarvis(ctx).hqAvailable(Core.key(ctx))
        val el = ctx.getSharedPreferences("boris", 0).getString("el_key", "") ?: ""
        if (el.isNotBlank()) out.add(Hub.jarvis(ctx).elOk(el) to "ElevenLabs-Key gültig")
        if (el.isNotBlank()) out.add((ElBudget.remaining(ctx) > 40f) to "ElevenLabs: ${ElBudget.summary(ctx)}")
        out.add(hq to "Gemini-Stimme als Ausweichlösung")
        out.add((Brain.all().isNotEmpty()) to "Gehirn enthält ${Brain.all().size} Einträge")
        if (OpenRouter.hasKey(ctx)) out.add(OpenRouter.check(ctx).startsWith("OK") to "OpenRouter-Key (${Providers.status(ctx)})")
        else out.add(false to "OpenRouter-Key fehlt (Selbstlernen belastet dann Gemini)")
        val sb = try { Sandbox.run(ctx, "function run(args){ return String(6*7); }", org.json.JSONObject(), false, 8000) } catch (e: Exception) { null }
        out.add((sb != null && sb.ok && sb.result == "42") to "Skill-Sandbox (Selfcoding) läuft${if (sb != null && !sb.ok) ": " + sb.error else ""}")
        out.add(true to "Kurzbefehle gelernt: ${Recipes.count(ctx)} · Geplante Aufgaben: ${Scheduler.all(ctx).size}")
        return out
    }
}
