package com.boris.assistant

import android.content.Context

/** Tonlage, in der Boris antwortet. Die Stimme selbst bleibt unverändert. */
object Persona {
    val names = listOf("Standard", "Locker", "Sachlich", "Motivierend", "Erklärbär")
    private val prompts = listOf(
        "",
        "Sprich locker und freundlich mit leichtem Humor, wie ein guter Kumpel.",
        "Antworte sachlich, präzise und so knapp wie möglich.",
        "Sei motivierend und ermutigend, aber ehrlich.",
        "Erkläre geduldig und Schritt für Schritt mit einfachen Beispielen."
    )
    @Volatile var index = 0

    fun load(c: Context) { index = c.getSharedPreferences("boris", 0).getInt("persona", 0).coerceIn(0, names.size - 1) }

    fun set(c: Context, i: Int) {
        index = i.coerceIn(0, names.size - 1)
        c.getSharedPreferences("boris", 0).edit().putInt("persona", index).apply()
    }

    fun prompt(): String = prompts[index]
}
