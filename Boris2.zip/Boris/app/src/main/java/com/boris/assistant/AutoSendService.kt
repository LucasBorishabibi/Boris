package com.boris.assistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.CountDownLatch

object AutoSend {
    @Volatile var active = false
    @Volatile var contact: String? = null
    @Volatile var contactClicked = false
    @Volatile var latch: CountDownLatch = CountDownLatch(1)
    fun begin(c: String?) { contact = c; contactClicked = false; latch = CountDownLatch(1); active = true }
    fun done() { active = false; latch.countDown() }
}

/** Tippt in Messenger-Apps auf Empfänger und "Senden", wenn Boris eine Nachricht verschickt. */
class AutoSendService : AccessibilityService() {
    private val words = listOf("Senden", "Send", "Absenden")

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (!AutoSend.active) return
        val root = rootInActiveWindow ?: return
        val c = AutoSend.contact
        if (c != null && !AutoSend.contactClicked) {
            val n = root.findAccessibilityNodeInfosByText(c).firstOrNull() ?: return
            // Zeile mit eigenem Senden-Button (z.B. Discord)
            var p: AccessibilityNodeInfo? = n
            var depth = 0
            while (p != null && depth < 4) {
                val sends = findSend(p)
                if (sends.size == 1 && click(sends[0])) { AutoSend.done(); return }
                p = p.parent; depth++
            }
            // sonst Empfänger antippen (z.B. WhatsApp) und danach Senden-Dialog suchen
            if (click(n)) AutoSend.contactClicked = true
            return
        }
        val sends = findSend(root)
        if (sends.isNotEmpty() && click(sends.last())) AutoSend.done()
    }

    private fun findSend(node: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        for (w in words) {
            for (n in node.findAccessibilityNodeInfosByText(w)) {
                val t = n.text?.toString(); val d = n.contentDescription?.toString()
                if (t.equals(w, true) || d.equals(w, true)) out.add(n)
            }
        }
        return out
    }

    private fun click(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        while (n != null && !n.isClickable) n = n.parent
        return n?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
    }
}
