package com.boris.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Augen und Hände des Agenten: liest den Bildschirm, führt Aktionen aus und zeigt dabei einen Cursor. */
class AutoSendService : AccessibilityService() {
    companion object { @Volatile var instance: AutoSendService? = null }

    @Volatile var nodes: List<AccessibilityNodeInfo> = emptyList()
    private val main = Handler(Looper.getMainLooper())
    private var cursor: CursorView? = null

    @Volatile var curPkg: String? = null
    private var curSince = System.currentTimeMillis()
    private var lastPrompt = 0L
    private val media = setOf(
        "com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.google.android.youtube", "com.instagram.android",
        "com.netflix.mediaclient", "tv.twitch.android.app", "com.reddit.frontpage", "com.twitter.android",
        "com.snapchat.android", "com.facebook.katana", "com.disney.disneyplus", "com.amazon.avod.thirdpartyclient"
    )
    private val ticker = object : Runnable {
        override fun run() { try { proactiveCheck() } catch (e: Exception) {}; main.postDelayed(this, 60_000) }
    }

    override fun onServiceConnected() { instance = this; Brain.load(this); main.postDelayed(ticker, 60_000) }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; cursorHide(); main.removeCallbacks(ticker); return super.onUnbind(intent) }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val p = e.packageName?.toString() ?: return
        if (p == packageName || p.startsWith("com.android.systemui") || p.contains("launcher") ||
            p.contains("inputmethod") || p.contains("keyboard")) return
        if (p != curPkg) { curPkg = p; curSince = System.currentTimeMillis() }
    }

    /** Boris bemerkt, was du tust, und stellt von sich aus eine passende Rückfrage. */
    private fun proactiveCheck() {
        val prefs = getSharedPreferences("boris", 0)
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isInteractive) { curSince = System.currentTimeMillis(); return }
        if (!prefs.getBoolean("proactive", true)) return
        val pkg = curPkg ?: return
        val now = System.currentTimeMillis()
        val minutes = (now - curSince) / 60000
        if (minutes < (if (pkg in media) 12 else 45) || now - lastPrompt < 40 * 60000L) return
        if (PhoneAgent.running || Hub.jarvis(this).speaking) return
        lastPrompt = now
        val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }
        Thread {
            val q = Notify.ask(this,
                "Du bist Boris, ein souveräner, trocken-humorvoller KI-Assistent im Stil von J.A.R.V.I.S. Das Gedächtnis über den Nutzer:\n${Brain.prompt()}",
                "Der Nutzer ist seit $minutes Minuten in der App „$label“. Stelle EINE kurze, lockere, persönliche Rückfrage auf Deutsch (max. 20 Wörter), " +
                    "die dazu passt (z.B. was er sich anschaut, ob du etwas für ihn tun oder ihn später erinnern sollst). Nur die Frage, nichts anderes.")
            if (!q.isNullOrBlank()) Notify.deliver(this, q.trim().trim('"'))
        }.start()
    }
    override fun onInterrupt() {}

    // ---------- Cursor-Overlay
    fun cursorShow() {
        main.post {
            if (cursor != null) return@post
            try {
                val v = CursorView(this)
                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT)
                (getSystemService(WINDOW_SERVICE) as WindowManager).addView(v, lp)
                cursor = v
            } catch (e: Exception) {}
        }
    }

    fun cursorHide() {
        main.post {
            cursor?.let { try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (e: Exception) {} }
            cursor = null
        }
    }

    fun cursorLabel(text: String) { main.post { cursor?.setLabel(text) } }

    private fun cursorMove(r: Rect, label: String, tap: Boolean) {
        val c = cursor ?: return
        main.post { c.moveTo(r.centerX().toFloat(), r.centerY().toFloat(), label) }
        Thread.sleep(330)
        if (tap) { main.post { c.tapFlash() }; Thread.sleep(120) }
    }

    // ---------- Bildschirm lesen
    fun dump(): String {
        val root = rootInActiveWindow ?: return "(Bildschirm gerade nicht lesbar)"
        val list = ArrayList<AccessibilityNodeInfo>()
        val sb = StringBuilder("App: ${root.packageName}\n")
        fun walk(n: AccessibilityNodeInfo) {
            if (list.size >= 90) return
            val t = n.text?.toString()?.take(45)
            val d = n.contentDescription?.toString()?.take(45)
            val interesting = !t.isNullOrBlank() || !d.isNullOrBlank() || n.isClickable || n.isEditable || n.isScrollable
            if (interesting && n.isVisibleToUser) {
                val id = list.size
                list.add(n)
                sb.append("[$id] ${n.className?.toString()?.substringAfterLast('.')}")
                if (!t.isNullOrBlank()) sb.append(" \"$t\"")
                if (!d.isNullOrBlank() && d != t) sb.append(" desc=\"$d\"")
                if (n.isClickable) sb.append(" klickbar")
                if (n.isEditable) sb.append(" eingabe")
                if (n.isScrollable) sb.append(" scrollbar")
                sb.append('\n')
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
        }
        walk(root)
        nodes = list
        return sb.toString()
    }

    private fun signature(): Int {
        val root = rootInActiveWindow ?: return 0
        var h = 17
        var count = 0
        fun w(n: AccessibilityNodeInfo) {
            if (count++ > 250) return
            h = h * 31 + (n.text?.hashCode() ?: 0) + n.childCount
            for (i in 0 until n.childCount) n.getChild(i)?.let { w(it) }
        }
        w(root)
        return h
    }

    /** Wartet nur, bis sich der Bildschirm nicht mehr ändert. */
    fun waitStable(maxMs: Long = 1800) {
        val end = System.currentTimeMillis() + maxMs
        var last = Int.MIN_VALUE
        var stable = 0
        while (System.currentTimeMillis() < end) {
            val h = signature()
            if (h == last) { if (++stable >= 2) return } else { stable = 0; last = h }
            Thread.sleep(100)
        }
    }

    fun label(id: Int): String {
        val n = nodes.getOrNull(id) ?: return "?"
        return (n.text ?: n.contentDescription ?: n.className ?: "?").toString().take(40)
    }

    // ---------- Aktionen
    private fun tap(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 50)).build()
        return dispatchGesture(g, null, null)
    }

    private fun clickNode(n: AccessibilityNodeInfo, what: String = ""): Boolean {
        val r = Rect(); n.getBoundsInScreen(r)
        val l = (what.ifBlank { (n.text ?: n.contentDescription ?: "").toString() }).take(28)
        cursorMove(r, if (l.isBlank()) "TIPPE" else "TIPPE · $l", true)
        var c: AccessibilityNodeInfo? = n
        while (c != null && !c.isClickable) c = c.parent
        if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        return tap(r.centerX().toFloat(), r.centerY().toFloat())
    }

    fun click(id: Int): String {
        val n = nodes.getOrNull(id) ?: return "Fehler: unbekannte id $id (Bildschirm hat sich geändert)"
        return if (clickNode(n)) "geklickt" else "Fehler: Klick fehlgeschlagen"
    }

    fun clickText(text: String): String {
        val root = rootInActiveWindow ?: return "Fehler: Bildschirm nicht lesbar"
        val found = root.findAccessibilityNodeInfosByText(text).filter { it.isVisibleToUser && !it.isEditable }
        val n = found.firstOrNull { it.text?.toString().equals(text, true) || it.contentDescription?.toString().equals(text, true) }
            ?: found.firstOrNull() ?: return "Fehler: „$text“ nicht gefunden"
        return if (clickNode(n, text)) "„$text“ geklickt" else "Fehler: Klick auf „$text“ fehlgeschlagen"
    }

    fun clickLabel(vararg labels: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (l in labels) {
            val n = root.findAccessibilityNodeInfosByText(l).firstOrNull {
                it.isVisibleToUser && (it.text?.toString().equals(l, true) || it.contentDescription?.toString().equals(l, true))
            }
            if (n != null && clickNode(n, l)) return true
        }
        return false
    }

    private fun setText(n: AccessibilityNodeInfo, text: String): Boolean {
        val r = Rect(); n.getBoundsInScreen(r)
        cursorMove(r, "SCHREIBE · ${text.take(22)}", false)
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    fun typeText(id: Int, text: String): String {
        val n = nodes.getOrNull(id) ?: return "Fehler: unbekannte id $id"
        if (setText(n, text)) return "Text eingegeben"
        clickNode(n); Thread.sleep(300)
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        return if (f != null && setText(f, text)) "Text eingegeben" else "Fehler: Eingabe fehlgeschlagen"
    }

    fun typeAuto(text: String): String {
        val root = rootInActiveWindow ?: return "Fehler: Bildschirm nicht lesbar"
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable } ?: firstEditable(root)
            ?: return "Fehler: kein Eingabefeld gefunden"
        return if (setText(f, text)) "Text eingegeben" else "Fehler: Eingabe fehlgeschlagen"
    }

    private fun firstEditable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isEditable && n.isVisibleToUser) return n
        for (i in 0 until n.childCount) n.getChild(i)?.let { c -> firstEditable(c)?.let { return it } }
        return null
    }

    fun submit(): String {
        if (Build.VERSION.SDK_INT >= 30) {
            val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (f != null) {
                val r = Rect(); f.getBoundsInScreen(r); cursorMove(r, "ENTER", true)
                if (f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)) return "Enter gesendet"
            }
        }
        return "Fehler: Enter nicht möglich"
    }

    fun scroll(down: Boolean): String {
        val n = nodes.firstOrNull { it.isScrollable } ?: return "Fehler: nichts zum Scrollen gefunden"
        val r = Rect(); n.getBoundsInScreen(r)
        cursorMove(r, if (down) "SCROLLE ↓" else "SCROLLE ↑", false)
        val a = if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return if (n.performAction(a)) "gescrollt" else "Fehler: Scrollen fehlgeschlagen"
    }

    fun home(): String { cursorLabel("STARTBILDSCHIRM"); performGlobalAction(GLOBAL_ACTION_HOME); return "Startbildschirm" }
    fun back(): String { cursorLabel("ZURÜCK"); performGlobalAction(GLOBAL_ACTION_BACK); return "zurück" }
}
