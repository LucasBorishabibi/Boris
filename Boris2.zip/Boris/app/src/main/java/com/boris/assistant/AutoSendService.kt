package com.boris.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Augen und Hände des Agenten: liest den Bildschirm als Liste und führt Tipp-/Tipp-Aktionen aus. */
class AutoSendService : AccessibilityService() {
    companion object { @Volatile var instance: AutoSendService? = null }

    @Volatile var nodes: List<AccessibilityNodeInfo> = emptyList()

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun dump(): String {
        val root = rootInActiveWindow ?: return "(Bildschirm gerade nicht lesbar, bitte wait aufrufen)"
        val list = ArrayList<AccessibilityNodeInfo>()
        val sb = StringBuilder("App: ${root.packageName}\n")
        fun walk(n: AccessibilityNodeInfo) {
            if (list.size >= 150) return
            val t = n.text?.toString()?.take(60)
            val d = n.contentDescription?.toString()?.take(60)
            val interesting = !t.isNullOrBlank() || !d.isNullOrBlank() || n.isClickable || n.isEditable || n.isScrollable
            if (interesting && n.isVisibleToUser) {
                val id = list.size
                list.add(n)
                sb.append("[$id] ${n.className?.toString()?.substringAfterLast('.')}")
                if (!t.isNullOrBlank()) sb.append(" \"$t\"")
                if (!d.isNullOrBlank() && d != t) sb.append(" desc=\"$d\"")
                if (n.isClickable) sb.append(" klickbar")
                if (n.isEditable) sb.append(" eingabe")
                if (n.isScrollable) sb.append(" scrollbar")
                sb.append('\n')
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
        }
        walk(root)
        nodes = list
        return sb.toString()
    }

    fun label(id: Int): String {
        val n = nodes.getOrNull(id) ?: return "?"
        return (n.text ?: n.contentDescription ?: n.className ?: "?").toString().take(40)
    }

    private fun tap(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build()
        return dispatchGesture(g, null, null)
    }

    fun click(id: Int): String {
        val n = nodes.getOrNull(id) ?: return "Fehler: unbekannte id $id (Bildschirm hat sich geändert?)"
        var c: AccessibilityNodeInfo? = n
        while (c != null && !c.isClickable) c = c.parent
        if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "geklickt"
        val r = Rect(); n.getBoundsInScreen(r)
        return if (tap(r.centerX().toFloat(), r.centerY().toFloat())) "getippt (Geste)" else "Klick fehlgeschlagen"
    }

    fun typeText(id: Int, text: String): String {
        val n = nodes.getOrNull(id) ?: return "Fehler: unbekannte id $id"
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        if (n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) return "Text eingegeben"
        click(id)
        Thread.sleep(500)
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        return if (f != null && f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) "Text eingegeben" else "Eingabe fehlgeschlagen"
    }

    fun scroll(down: Boolean): String {
        val n = nodes.firstOrNull { it.isScrollable } ?: return "Nichts zum Scrollen gefunden"
        val a = if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return if (n.performAction(a)) "gescrollt" else "Scrollen fehlgeschlagen"
    }
}
