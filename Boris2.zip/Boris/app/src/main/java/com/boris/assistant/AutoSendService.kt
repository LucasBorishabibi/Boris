package com.boris.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Augen und Hände des Agenten: liest den Bildschirm und führt Aktionen aus. */
class AutoSendService : AccessibilityService() {
    companion object { @Volatile var instance: AutoSendService? = null }

    @Volatile var nodes: List<AccessibilityNodeInfo> = emptyList()

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun dump(): String {
        val root = rootInActiveWindow ?: return "(Bildschirm gerade nicht lesbar)"
        val list = ArrayList<AccessibilityNodeInfo>()
        val sb = StringBuilder("App: ${root.packageName}\n")
        fun walk(n: AccessibilityNodeInfo) {
            if (list.size >= 90) return
            val t = n.text?.toString()?.take(45)
            val d = n.contentDescription?.toString()?.take(45)
            val interesting = !t.isNullOrBlank() || !d.isNullOrBlank() || n.isClickable || n.isEditable || n.isScrollable
            if (interesting && n.isVisibleToUser) {
                val id = list.size
                list.add(n)
                sb.append("[$id] ${n.className?.toString()?.substringAfterLast('.')}")
                if (!t.isNullOrBlank()) sb.append(" \"$t\"")
                if (!d.isNullOrBlank() && d != t) sb.append(" desc=\"$d\"")
                if (n.isClickable) sb.append(" klickbar")
                if (n.isEditable) sb.append(" eingabe")
                if (n.isScrollable) sb.append(" scrollbar")
                sb.append('\n')
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
        }
        walk(root)
        nodes = list
        return sb.toString()
    }

    private fun signature(): Int {
        val root = rootInActiveWindow ?: return 0
        var h = 17
        var count = 0
        fun w(n: AccessibilityNodeInfo) {
            if (count++ > 250) return
            h = h * 31 + (n.text?.hashCode() ?: 0) + n.childCount
            for (i in 0 until n.childCount) n.getChild(i)?.let { w(it) }
        }
        w(root)
        return h
    }

    /** Wartet nur so lange, bis sich der Bildschirm nicht mehr ändert (statt feste Pausen). */
    fun waitStable(maxMs: Long = 1800) {
        val end = System.currentTimeMillis() + maxMs
        var last = Int.MIN_VALUE
        var stable = 0
        while (System.currentTimeMillis() < end) {
            val h = signature()
            if (h == last) { if (++stable >= 2) return } else { stable = 0; last = h }
            Thread.sleep(100)
        }
    }

    fun label(id: Int): String {
        val n = nodes.getOrNull(id) ?: return "?"
        return (n.text ?: n.contentDescription ?: n.className ?: "?").toString().take(40)
    }

    private fun tap(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 50)).build()
        return dispatchGesture(g, null, null)
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        while (c != null && !c.isClickable) c = c.parent
        if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        val r = Rect(); n.getBoundsInScreen(r)
        return tap(r.centerX().toFloat(), r.centerY().toFloat())
    }

    fun click(id: Int): String {
        val n = nodes.getOrNull(id) ?: return "Fehler: unbekannte id $id (Bildschirm hat sich geändert)"
        return if (clickNode(n)) "geklickt" else "Fehler: Klick fehlgeschlagen"
    }

    /** Klickt das sichtbare Element mit diesem Text bzw. dieser Beschreibung (exakter Treffer bevorzugt). */
    fun clickText(text: String): String {
        val root = rootInActiveWindow ?: return "Fehler: Bildschirm nicht lesbar"
        val found = root.findAccessibilityNodeInfosByText(text).filter { it.isVisibleToUser && !it.isEditable }
        val n = found.firstOrNull { it.text?.toString().equals(text, true) || it.contentDescription?.toString().equals(text, true) }
            ?: found.firstOrNull() ?: return "Fehler: „$text“ nicht gefunden"
        return if (clickNode(n)) "„$text“ geklickt" else "Fehler: Klick auf „$text“ fehlgeschlagen"
    }

    fun clickLabel(vararg labels: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (l in labels) {
            val n = root.findAccessibilityNodeInfosByText(l).firstOrNull {
                it.isVisibleToUser && (it.text?.toString().equals(l, true) || it.contentDescription?.toString().equals(l, true))
            }
            if (n != null && clickNode(n)) return true
        }
        return false
    }

    private fun setText(n: AccessibilityNodeInfo, text: String): Boolean {
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    fun typeText(id: Int, text: String): String {
        val n = nodes.getOrNull(id) ?: return "Fehler: unbekannte id $id"
        if (setText(n, text)) return "Text eingegeben"
        clickNode(n); Thread.sleep(300)
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        return if (f != null && setText(f, text)) "Text eingegeben" else "Fehler: Eingabe fehlgeschlagen"
    }

    /** Tippt in das fokussierte Eingabefeld, sonst ins erste sichtbare. */
    fun typeAuto(text: String): String {
        val root = rootInActiveWindow ?: return "Fehler: Bildschirm nicht lesbar"
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable } ?: firstEditable(root)
            ?: return "Fehler: kein Eingabefeld gefunden"
        return if (setText(f, text)) "Text eingegeben" else "Fehler: Eingabe fehlgeschlagen"
    }

    private fun firstEditable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isEditable && n.isVisibleToUser) return n
        for (i in 0 until n.childCount) n.getChild(i)?.let { c -> firstEditable(c)?.let { return it } }
        return null
    }

    fun scroll(down: Boolean): String {
        val n = nodes.firstOrNull { it.isScrollable } ?: return "Fehler: nichts zum Scrollen gefunden"
        val a = if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return if (n.performAction(a)) "gescrollt" else "Fehler: Scrollen fehlgeschlagen"
    }
}
