package com.boris.assistant

import android.Manifest
import android.app.Activity
import android.app.SearchManager
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telephony.SmsManager
import android.view.KeyEvent
import org.json.JSONObject

val PKG = mapOf(
    "spotify" to "com.spotify.music", "discord" to "com.discord", "whatsapp" to "com.whatsapp",
    "telegram" to "org.telegram.messenger", "instagram" to "com.instagram.android",
    "signal" to "org.thoughtcrime.securesms", "youtube" to "com.google.android.youtube",
    "maps" to "com.google.android.apps.maps", "chrome" to "com.android.chrome",
    "kamera" to "com.sec.android.app.camera", "einstellungen" to "com.android.settings"
)

@Volatile var statusSink: (String) -> Unit = {}
@Volatile var agentApiKey: String = ""

fun isAutoSendEnabled(a: Activity): Boolean {
    val s = Settings.Secure.getString(a.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
    return s.contains("${a.packageName}/${AutoSendService::class.java.name}")
}

fun statusFor(name: String, args: JSONObject): String = when (name) {
    "set_timer" -> "Stelle Timer …"
    "set_alarm" -> "Stelle Wecker …"
    "spotify_play" -> "Spotify: suche „${args.optString("query")}“ …"
    "spotify_liked" -> "Spotify: Lieblingssongs …"
    "open_app" -> "Öffne ${args.optString("app")} …"
    "send_sms" -> "Sende SMS an ${args.optString("contact")} …"
    "send_whatsapp" -> "WhatsApp: sende an ${args.optString("contact")} …"
    "phone_task" -> "Agent startet: ${args.optString("task").take(60)}"
    else -> "Arbeite …"
}

private fun pressPlay(a: Activity, delayMs: Long) {
    Handler(Looper.getMainLooper()).postDelayed({
        val am = a.getSystemService(Activity.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY))
    }, delayMs)
}

private fun lookupNumber(a: Activity, name: String): String? {
    if (a.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
    a.contentResolver.query(
        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
        arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
        "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
        arrayOf("%$name%"), null
    )?.use { c -> if (c.moveToFirst()) return c.getString(0) }
    return null
}

private fun sendSms(a: Activity, args: JSONObject): String {
    val text = args.getString("text")
    val contact = args.optString("contact", "").ifBlank { null }
    if (a.checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED)
        return "Keine SMS-Berechtigung erteilt."
    var nr = args.optString("phone", "")
    if (nr.isBlank() && contact != null) nr = lookupNumber(a, contact) ?: ""
    if (nr.isBlank()) return "Keine Telefonnummer für ${contact ?: "den Empfänger"} gefunden."
    val sm = a.getSystemService(SmsManager::class.java)
    sm.sendMultipartTextMessage(nr, null, sm.divideMessage(text), null, null)
    return "SMS an ${contact ?: nr} gesendet."
}

fun runTool(a: Activity, name: String, args: JSONObject): String = try {
    when (name) {
        "set_timer" -> {
            a.startActivity(Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, args.getInt("seconds"))
                .putExtra(AlarmClock.EXTRA_MESSAGE, args.optString("label", "Boris"))
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            "Timer gestellt."
        }
        "set_alarm" -> {
            a.startActivity(Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, args.getInt("hour"))
                .putExtra(AlarmClock.EXTRA_MINUTES, args.getInt("minute"))
                .putExtra(AlarmClock.EXTRA_MESSAGE, args.optString("label", "Boris"))
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            "Wecker gestellt."
        }
        "spotify_play" -> {
            val q = args.getString("query")
            a.startActivity(Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                .setPackage("com.spotify.music")
                .putExtra(SearchManager.QUERY, q)
                .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*"))
            "Spotify gestartet mit: $q."
        }
        "spotify_liked" -> {
            a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("spotify:collection:tracks"))
                .setPackage("com.spotify.music"))
            pressPlay(a, 2500)
            "Lieblingssongs geöffnet, Wiedergabe startet."
        }
        "open_app" -> {
            val pkg = PKG[args.getString("app").lowercase()]
            val i = pkg?.let { a.packageManager.getLaunchIntentForPackage(it) }
            if (i == null) "App nicht gefunden oder nicht installiert." else { a.startActivity(i); "App geöffnet." }
        }
        "send_sms" -> sendSms(a, args)
        "send_whatsapp" -> sendWhatsApp(a, args)
        "phone_task" -> PhoneAgent.run(a, agentApiKey, args.getString("task"), statusSink, args.optString("app", "").ifBlank { null })
        else -> "Unbekanntes Tool."
    }
} catch (e: Exception) { "Fehler: ${e.message}" }

private fun waNumber(nr: String): String {
    val d = nr.filter { it.isDigit() || it == '+' }
    return when {
        d.startsWith("+") -> d.drop(1)
        d.startsWith("00") -> d.drop(2)
        d.startsWith("0") -> "49" + d.drop(1)
        else -> d
    }
}

/** Schnellweg: Chat per Nummer direkt öffnen und Senden tippen, ohne KI-Runden. Sonst Agent als Ausweichlösung. */
private fun sendWhatsApp(a: Activity, args: JSONObject): String {
    val contact = args.getString("contact")
    val text = args.getString("text")
    val svc = AutoSendService.instance
    val nr = lookupNumber(a, contact)
    val fallbackTask = "Öffne WhatsApp, finde den Chat mit „$contact“ (Suche nutzen), tippe die Nachricht „$text“ ins Nachrichtenfeld und sende sie ab."
    if (svc == null || nr == null)
        return PhoneAgent.run(a, agentApiKey, fallbackTask, statusSink, "whatsapp")
    svc.startActivity(Intent(Intent.ACTION_VIEW,
        Uri.parse("https://wa.me/${waNumber(nr)}?text=${Uri.encode(text)}"))
        .setPackage("com.whatsapp").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    val end = System.currentTimeMillis() + 7000
    while (System.currentTimeMillis() < end) {
        Thread.sleep(200)
        if (svc.clickLabel("Senden", "Send")) {
            Thread.sleep(400)
            PhoneAgent.bringBack(svc)
            return "WhatsApp-Nachricht an $contact gesendet."
        }
    }
    return PhoneAgent.run(a, agentApiKey, fallbackTask, statusSink, "whatsapp")
}
