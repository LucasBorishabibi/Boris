package com.boris.assistant

import android.Manifest
import android.app.Activity
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.content.ContentUris
import android.provider.AlarmClock
import android.provider.CalendarContract
import java.util.Calendar
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telephony.SmsManager
import android.view.KeyEvent
import org.json.JSONObject

val PKG = mapOf(
    "spotify" to "com.spotify.music", "discord" to "com.discord", "whatsapp" to "com.whatsapp",
    "telegram" to "org.telegram.messenger", "instagram" to "com.instagram.android",
    "signal" to "org.thoughtcrime.securesms", "youtube" to "com.google.android.youtube",
    "maps" to "com.google.android.apps.maps", "chrome" to "com.android.chrome",
    "kamera" to "com.sec.android.app.camera", "einstellungen" to "com.android.settings",
    "tiktok" to "com.zhiliaoapp.musically"
)

/** Startet eine Aktivität auch aus dem Hintergrund (über den Agent-Dienst, falls aktiv). */
private fun Context.go(i: Intent) {
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    (AutoSendService.instance ?: this).startActivity(i)
}

@Volatile var statusSink: (String) -> Unit = {}
@Volatile var agentApiKey: String = ""

fun isServiceEnabled(a: Context, cls: Class<*>): Boolean {
    val s = Settings.Secure.getString(a.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
    return s.contains("${a.packageName}/${cls.name}")
}
fun isAutoSendEnabled(a: Context): Boolean = isServiceEnabled(a, AutoSendService::class.java)
fun isNotifAccessEnabled(a: Context): Boolean =
    (Settings.Secure.getString(a.contentResolver, "enabled_notification_listeners") ?: "").contains(a.packageName)

fun statusFor(name: String, args: JSONObject): String = when (name) {
    "set_timer" -> "Stelle Timer …"
    "set_alarm" -> "Stelle Wecker …"
    "spotify_play" -> "Spotify: suche „${args.optString("query")}“ …"
    "spotify_liked" -> "Spotify: Lieblingssongs …"
    "open_app" -> "Öffne ${args.optString("app")} …"
    "send_sms" -> "Sende SMS an ${args.optString("contact")} …"
    "send_whatsapp" -> "WhatsApp: sende an ${args.optString("contact")} …"
    "reply_notification" -> "Antworte ${args.optString("contact")} …"
    "read_notifications" -> "Lese Benachrichtigungen …"
    "phone_task" -> "Agent startet: ${args.optString("task").take(60)}"
    "call_contact" -> "Rufe ${args.optString("contact")} an …"
    "navigate" -> "Navigation: ${args.optString("destination")} …"
    "search_web" -> "Suche im Web …"
    "remember" -> "Speichere im Gehirn …"
    "set_reminder" -> "Plane Erinnerung …"
    "watch_message" -> "Beobachte Nachrichten …"
    "set_routine" -> "Speichere Routine …"
    "read_calendar" -> "Lese Kalender …"
    "mute_notifications" -> "Stelle stumm …"
    else -> "Arbeite …"
}

private fun pressPlay(a: Context, delayMs: Long) {
    Handler(Looper.getMainLooper()).postDelayed({
        val am = a.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY))
    }, delayMs)
}

private fun lookupNumber(a: Context, name: String): String? {
    if (a.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
    a.contentResolver.query(
        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
        arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
        "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
        arrayOf("%$name%"), null
    )?.use { c -> if (c.moveToFirst()) return c.getString(0) }
    return null
}

private fun sendSms(a: Context, args: JSONObject): String {
    val text = args.getString("text")
    val contact = args.optString("contact", "").ifBlank { null }
    if (a.checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED)
        return "Keine SMS-Berechtigung erteilt."
    var nr = args.optString("phone", "")
    if (nr.isBlank() && contact != null) nr = lookupNumber(a, contact) ?: ""
    if (nr.isBlank()) return "Keine Telefonnummer für ${contact ?: "den Empfänger"} gefunden."
    val sm = a.getSystemService(SmsManager::class.java)
    sm.sendMultipartTextMessage(nr, null, sm.divideMessage(text), null, null)
    return "SMS an ${contact ?: nr} gesendet."
}

private fun waNumber(nr: String): String {
    val d = nr.filter { it.isDigit() || it == '+' }
    return when {
        d.startsWith("+") -> d.drop(1)
        d.startsWith("00") -> d.drop(2)
        d.startsWith("0") -> "49" + d.drop(1)
        else -> d
    }
}

/** Schnellweg: Chat per Nummer öffnen und Senden tippen. Sonst Agent als Ausweichlösung. */
private fun sendWhatsApp(a: Context, args: JSONObject): String {
    val contact = args.getString("contact")
    val text = args.getString("text")
    val svc = AutoSendService.instance
    val nr = lookupNumber(a, contact)
    val fallbackTask = "Finde in WhatsApp den Chat mit „$contact“ (Suche nutzen), tippe die Nachricht „$text“ ins Nachrichtenfeld und sende sie ab."
    if (svc == null || nr == null) return PhoneAgent.run(a, agentApiKey, fallbackTask, statusSink, "whatsapp")
    svc.cursorShow()
    svc.startActivity(Intent(Intent.ACTION_VIEW,
        Uri.parse("https://wa.me/${waNumber(nr)}?text=${Uri.encode(text)}"))
        .setPackage("com.whatsapp").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    val end = System.currentTimeMillis() + 7000
    while (System.currentTimeMillis() < end) {
        Thread.sleep(200)
        if (svc.clickLabel("Senden", "Send")) {
            Thread.sleep(400)
            svc.cursorHide()
            PhoneAgent.bringBack(svc)
            return "WhatsApp-Nachricht an $contact gesendet."
        }
    }
    svc.cursorHide()
    return PhoneAgent.run(a, agentApiKey, fallbackTask, statusSink, "whatsapp")
}

fun runTool(a: Context, name: String, args: JSONObject): String = try {
    when (name) {
        "set_timer" -> {
            a.go(Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, args.getInt("seconds"))
                .putExtra(AlarmClock.EXTRA_MESSAGE, args.optString("label", "Boris"))
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            "Timer gestellt."
        }
        "set_alarm" -> {
            a.go(Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, args.getInt("hour"))
                .putExtra(AlarmClock.EXTRA_MINUTES, args.getInt("minute"))
                .putExtra(AlarmClock.EXTRA_MESSAGE, args.optString("label", "Boris"))
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            "Wecker gestellt."
        }
        "spotify_play" -> {
            val q = args.getString("query")
            a.go(Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                .setPackage("com.spotify.music")
                .putExtra(SearchManager.QUERY, q)
                .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*"))
            "Spotify gestartet mit: $q."
        }
        "spotify_liked" -> {
            a.go(Intent(Intent.ACTION_VIEW, Uri.parse("spotify:collection:tracks"))
                .setPackage("com.spotify.music"))
            pressPlay(a, 2500)
            "Lieblingssongs geöffnet, Wiedergabe startet."
        }
        "open_app" -> {
            val pkg = PKG[args.getString("app").lowercase()]
            val i = pkg?.let { a.packageManager.getLaunchIntentForPackage(it) }
            if (i == null) "App nicht gefunden oder nicht installiert." else { a.go(i); "App geöffnet." }
        }
        "send_sms" -> sendSms(a, args)
        "send_whatsapp" -> sendWhatsApp(a, args)
        "reply_notification" -> {
            val n = NotifService.instance
            if (n == null) "INFO: Benachrichtigungszugriff ist nicht aktiviert. Nutze send_whatsapp oder phone_task."
            else n.reply(args.getString("contact"), args.getString("text"))
                ?: "INFO: Keine offene Benachrichtigung von ${args.getString("contact")} mit Antwortfunktion. Nutze send_whatsapp oder phone_task."
        }
        "read_notifications" -> NotifService.instance?.summary() ?: "INFO: Benachrichtigungszugriff ist nicht aktiviert."
        "phone_task" -> PhoneAgent.run(a, agentApiKey, args.getString("task"), statusSink, args.optString("app", "").ifBlank { null })
        "call_contact" -> {
            val c = args.getString("contact")
            val nr = lookupNumber(a, c)
            if (nr == null) "Keine Nummer für $c gefunden."
            else {
                val act = if (a.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED)
                    Intent.ACTION_CALL else Intent.ACTION_DIAL
                a.go(Intent(act, Uri.parse("tel:$nr")))
                "Rufe $c an."
            }
        }
        "navigate" -> {
            a.go(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(args.getString("destination"))))
                .setPackage("com.google.android.apps.maps"))
            "Navigation gestartet."
        }
        "search_web" -> {
            a.go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(args.getString("query")))))
            "Suche geöffnet."
        }
        "torch" -> {
            val cm = a.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (id == null) "Keine Taschenlampe gefunden." else { cm.setTorchMode(id, args.getBoolean("on")); if (args.getBoolean("on")) "Licht an." else "Licht aus." }
        }
        "set_volume" -> {
            val am = a.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, (max * args.getInt("percent").coerceIn(0, 100) / 100f).toInt(), 0)
            "Lautstärke gesetzt."
        }
        "remember" -> Brain.add(args.getString("fact"), args.optString("category", "allgemein"))
        "forget" -> { val n = Brain.remove(args.getString("keyword")); if (n > 0) "$n Einträge vergessen." else "Dazu hatte ich nichts gespeichert." }
        "set_reminder" -> {
            val m = args.optInt("in_minutes", -1)
            val now = System.currentTimeMillis()
            val at = if (m >= 0) now + m * 60_000L else {
                val p = args.optString("at", "").split(":", ".")
                if (p.size < 2) -1L else {
                    val c = Calendar.getInstance()
                    c.set(Calendar.HOUR_OF_DAY, p[0].trim().toInt()); c.set(Calendar.MINUTE, p[1].trim().toInt()); c.set(Calendar.SECOND, 0)
                    if (c.timeInMillis <= now) c.add(Calendar.DAY_OF_YEAR, 1)
                    c.timeInMillis
                }
            }
            if (at < 0) "Fehler: Zeitangabe fehlt." else {
                Scheduler.addReminder(a, args.getString("text"), at)
                "Erinnerung gesetzt für ${java.text.SimpleDateFormat("dd.MM. HH:mm", java.util.Locale.GERMAN).format(java.util.Date(at))}."
            }
        }
        "watch_message" -> {
            Scheduler.addWatch(a, args.getString("contact"), args.optString("say", ""))
            "Ich sage Bescheid, sobald ${args.getString("contact")} schreibt."
        }
        "mute_notifications" -> {
            var t = args.optString("target", "").trim()
            if (t.isBlank()) t = NotifService.lastSender.ifBlank { NotifService.lastApp }
            if (t.isBlank()) "Fehler: Ich weiß nicht, was ich stumm schalten soll." else Mute.add(a, t, args.optInt("minutes", 0))
        }
        "unmute_notifications" -> {
            val n = Mute.remove(a, args.getString("target"))
            if (n > 0) "Ich lese ${args.getString("target")} wieder vor." else "Das war nicht stumm geschaltet."
        }
        "set_routine" -> Scheduler.addRoutine(a, args.getString("trigger"), args.getString("action"))
        "list_tasks" -> "INFO: " + Scheduler.describe(a)
        "cancel_task" -> { val n = Scheduler.cancel(a, args.getString("keyword")); if (n > 0) "$n Aufgabe(n) gelöscht." else "Nichts Passendes gefunden." }
        "read_calendar" -> {
            if (a.checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) "INFO: Kalenderzugriff fehlt."
            else {
                val now = System.currentTimeMillis()
                val end = now + args.optInt("days", 1).coerceIn(1, 14) * 86_400_000L
                val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
                ContentUris.appendId(b, now); ContentUris.appendId(b, end)
                val sb = StringBuilder("INFO: Termine:\n")
                a.contentResolver.query(b.build(), arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN,
                    CalendarContract.Instances.EVENT_LOCATION), null, null, "begin ASC")?.use { c ->
                    val f = java.text.SimpleDateFormat("dd.MM. HH:mm", java.util.Locale.GERMAN)
                    while (c.moveToNext() && sb.length < 1500)
                        sb.append(f.format(java.util.Date(c.getLong(1)))).append(' ').append(c.getString(0) ?: "")
                            .append(c.getString(2)?.let { " ($it)" } ?: "").append('\n')
                }
                if (sb.endsWith(":\n")) "INFO: Keine Termine im Zeitraum." else sb.toString()
            }
        }
        else -> "Unbekanntes Tool."
    }
} catch (e: Exception) { "Fehler: ${e.message}" }
