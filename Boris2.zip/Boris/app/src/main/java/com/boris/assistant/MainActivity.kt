package com.boris.assistant

import android.Manifest
import android.app.Activity
import android.content.*
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

private val Void = Color(0xFF03060B)
private val Blue = Color(0xFF55D9FF)
private val Cyan = Color(0xFF9CF1FF)
private val White = Color(0xFFF2FBFF)
private val Dim = Color(0xFF7894A4)
private val Glass = Color(0xB90A1119)
private val Mono = FontFamily.Monospace

data class Msg(val kind: Int, val text: String)

data class SwarmTouch(val pos: Offset, val velocity: Offset, val active: Boolean)

class MainActivity : ComponentActivity() {
    companion object { @Volatile var isForeground = false }
    private var tts: TextToSpeech? = null
    private var pendingCommand: String? = null
    private var commandTick = 0
    private val commandReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                ListenService.ACTION_COMMAND -> {
                    pendingCommand = intent.getStringExtra("command")
                    serviceCommand = intent.getBooleanExtra("service", true)
                    commandTick++
                }
            }
        }
    }
    private var serviceCommand = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(SystemBarStyle.dark(android.graphics.Color.TRANSPARENT), SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        tts = TextToSpeech(this) {
            if (it == TextToSpeech.SUCCESS) {
                tts?.language = Locale.GERMAN
                tts?.setPitch(0.63f)
                tts?.setSpeechRate(0.94f)
            }
        }
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 701)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = Void, surface = Glass, primary = Blue)) { BorisScreen() }
        }
    }

    private fun startListenService() {
        val i = Intent(this, ListenService::class.java)
        try { if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i) } catch (_: Exception) {}
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 702 && grantResults.firstOrNull() == android.content.pm.PackageManager.PERMISSION_GRANTED) startListenService()
    }

    override fun onStart() {
        super.onStart()
        isForeground = true
        val f = IntentFilter(ListenService.ACTION_COMMAND)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(commandReceiver, f, RECEIVER_NOT_EXPORTED) else registerReceiver(commandReceiver, f)
    }
    override fun onStop() { isForeground = false; try { unregisterReceiver(commandReceiver) } catch (_: Exception) {}; super.onStop() }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }

    @Composable private fun BorisScreen() {
        val activity = this@MainActivity
        val memory = remember { MemoryStore(activity) }
        val prefs = remember { activity.getSharedPreferences("boris", 0) }
        var apiKey by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
        var keyInput by remember { mutableStateOf(apiKey) }
        var showSettings by remember { mutableStateOf(false) }
        var showChat by remember { mutableStateOf(false) }
        var listening by remember { mutableStateOf(prefs.getBoolean("listening", false)) }
        var busy by remember { mutableStateOf(false) }
        var status by remember { mutableStateOf(if (listening) "LISTENING" else "READY") }
        val messages = remember { mutableStateListOf<Msg>() }
        val history = remember { memory.loadHistory() }
        val scope = rememberCoroutineScope()

        fun execute(text: String, fromService: Boolean) {
            sendCommand(text, activity, memory, history, messages, apiKey, scope,
                { busy = it }, { status = it }, { answer ->
                    if (fromService) {
                        sendBroadcast(Intent(ListenService.ACTION_RESPONSE).setPackage(packageName).putExtra("text", answer))
                    } else speak(answer)
                })
        }

        LaunchedEffect(Unit) {
            intent.getStringExtra("boris_external_command")?.let { execute(it, true); intent.removeExtra("boris_external_command") }
        }

        LaunchedEffect(commandTick) {
            pendingCommand?.let { cmd -> pendingCommand = null; execute(cmd, serviceCommand) }
        }

        val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (r.resultCode == Activity.RESULT_OK && !t.isNullOrBlank()) execute(t, false)
        }

        fun toggleListening() {
            listening = !listening
            prefs.edit().putBoolean("listening", listening).apply()
            if (listening) {
                if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 702); return
                }
                startListenService(); status = "LISTENING"
            } else {
                stopService(Intent(activity, ListenService::class.java)); status = "READY"
            }
        }

        Box(Modifier.fillMaxSize().background(Void)) {
            ParticleSwarm(
                busy = busy,
                listening = listening,
                modifier = Modifier.fillMaxSize(),
                onOpenChat = { showChat = true },
                onState = { status = it }
            )

            // Premium HUD, deliberately tiny so the swarm remains the UI.
            Row(Modifier.align(Alignment.TopStart).padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(6.dp).clip(CircleShape).background(if (listening) Blue else Dim))
                Spacer(Modifier.width(8.dp))
                Text("BORIS  /  ${status.uppercase()}", color = Dim, fontFamily = Mono, fontSize = 9.sp, letterSpacing = 1.sp)
            }

            Box(Modifier.align(Alignment.TopEnd).padding(16.dp).size(42.dp).clip(CircleShape)
                .background(Color(0x44131D27)).border(1.dp, Blue.copy(alpha = .18f), CircleShape)
                .pointerInput(Unit) { detectTapGestures(onTap = { showSettings = true }) }, contentAlignment = Alignment.Center) {
                Text("⌁", color = White, fontSize = 21.sp)
            }

            if (showChat) ChatOverlay(Modifier.align(Alignment.BottomStart), messages, { showChat = false }, { text -> execute(text, false) })

            if (showSettings) SettingsOverlay(
                Modifier.align(Alignment.Center), apiKey, keyInput, listening, memory.recentApps(),
                onKey = { keyInput = it },
                onSave = { apiKey = keyInput.trim(); prefs.edit().putString("key", apiKey).apply(); showSettings = false },
                onListen = { toggleListening() },
                onAccessibility = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                onClose = { showSettings = false }
            )
        }
    }

    private fun speak(text: String) {
        tts?.setPitch(.63f); tts?.setSpeechRate(.94f)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "boris")
    }

    private fun sendCommand(text: String, activity: Activity, memory: MemoryStore, history: JSONArray, messages: MutableList<Msg>, apiKey: String,
                            scope: kotlinx.coroutines.CoroutineScope, setBusy: (Boolean)->Unit, setStatus: (String)->Unit, speak: (String)->Unit) {
        if (text.isBlank()) return
        if (apiKey.isBlank()) { val e="Kein Gemini API-Key hinterlegt."; messages.add(Msg(3,e)); setStatus("NO KEY"); speak(e); return }
        messages.add(Msg(0, text))
        history.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text))))
        memory.addMemory("Nutzer: $text"); memory.saveHistory(history); setBusy(true); setStatus("THINKING")
        agentApiKey = apiKey; statusSink = { setStatus(it.uppercase()) }
        // Keep the live prompt small for speed; long-term memory remains separate and persistent.
        while (history.length() > 16) history.remove(0)
        scope.launch {
            val result = try {
                withContext(Dispatchers.IO) {
                    GeminiClient.chat(apiKey, history, memory.memoryText(), memory.recentApps(), { setStatus(it.uppercase()) }) { n, a ->
                        setStatus(statusFor(n, a).uppercase()); runTool(activity, n, a).also { messages.add(Msg(2, it)) }
                    }
                }
            } catch (e: Exception) { "Fehler: ${e.message ?: "unbekannter Fehler"}" }
            val ok = !result.startsWith("Fehler:")
            messages.add(Msg(if (ok) 1 else 3, result))
            history.put(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", result))))
            memory.addMemory("Boris: $result"); memory.saveHistory(history); setBusy(false); setStatus("READY"); speak(result)
        }
    }
}

@Composable
private fun ParticleSwarm(busy: Boolean, listening: Boolean, modifier: Modifier, onOpenChat: () -> Unit, onState: (String) -> Unit) {
    val transition = rememberInfiniteTransition(label = "swarm")
    val time by transition.animateFloat(0f, 100f, infiniteRepeatable(tween(if (busy) 14000 else 28000, easing = LinearEasing)), label = "time")
    var center by remember { mutableStateOf(Offset.Unspecified) }
    var scale by remember { mutableFloatStateOf(1f) }
    var dragVelocity by remember { mutableStateOf(Offset.Zero) }
    var touch by remember { mutableStateOf(Offset.Unspecified) }
    var pulse by remember { mutableFloatStateOf(0f) }
    val state = if (busy) 1.65f else if (listening) 1.0f else .62f

    LaunchedEffect(busy, listening) { onState(if (busy) "THINKING" else if (listening) "LISTENING" else "READY") }
    LaunchedEffect(pulse) { if (pulse > 0f) { while (pulse > .01f) { kotlinx.coroutines.delay(16); pulse *= .93f } pulse = 0f } }

    Canvas(
        modifier
            .pointerInput(Unit) {
                detectTransformGestures { centroid, pan, zoom, rotation ->
                    if (!center.isSpecified) center = centroid
                    center += pan
                    scale = (scale * zoom).coerceIn(.55f, 2.4f)
                    dragVelocity = pan * 1.8f
                    touch = centroid
                    pulse = 1f
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { touch = it; pulse = 1f },
                    onDoubleTap = { touch = it; pulse = 1.5f; onOpenChat() }
                )
            }
    ) {
        val visualCenter = if (center.isSpecified) center else Offset(size.width / 2f, size.height / 2f)
        val cx = visualCenter.x.coerceIn(size.width*.15f, size.width*.85f)
        val cy = visualCenter.y.coerceIn(size.height*.15f, size.height*.85f)
        val minS = minOf(size.width, size.height)
        val pulseValue = pulse
        val count = 240
        val points = ArrayList<Offset>(count)
        val r0 = minS * .055f * scale
        for (i in 0 until count) {
            val a = i * 2.399963f + time * (.0025f + (i % 11) * .00035f) + dragVelocity.x*.0007f
            val ring = (i % 24) / 23f
            val base = r0 + minS * (.012f + ring*.285f) * scale
            val wave = sin(time*.55f + i*.37f) * minS * (.006f + ring*.012f) * state
            val breath = 1f + sin(time*.8f + i*.21f) * (.035f * state) + pulseValue*.025f
            var x = cx + cos(a)*base*breath + sin(time*.31f+i)*minS*.018f*state + dragVelocity.x*.035f
            var y = cy + sin(a)*base*breath + cos(time*.27f+i*.7f)*minS*.018f*state + dragVelocity.y*.035f
            if (touch.isSpecified) {
                val dx=x-touch.x; val dy=y-touch.y; val d=sqrt(dx*dx+dy*dy).coerceAtLeast(1f); val radius=minS*.22f
                if (d < radius) { val f=(1f-d/radius); x += dx/d*f*minS*.13f; y += dy/d*f*minS*.13f }
            }
            val p=Offset(x,y); points.add(p)
            val rr=(.65f+(i%5)*.35f)*(1f+.18f*sin(time*1.7f+i))
            drawCircle(Brush.radialGradient(listOf(Cyan.copy(alpha=.60f),Blue.copy(alpha=.10f),Color.Transparent)), rr*8.5f, p)
            drawCircle(White.copy(alpha=.70f+.2f*state), rr, p)
        }
        for (i in 0 until points.size step 2) {
            val j=(i+7)%points.size
            drawLine(Blue.copy(alpha=.035f+.025f*state), points[i], points[j], strokeWidth=.7f)
        }
        drawCircle(Brush.radialGradient(listOf(Cyan.copy(alpha=.22f),Blue.copy(alpha=.07f),Color.Transparent)), minS*.23f*scale, Offset(cx,cy))
        drawCircle(White.copy(alpha=.9f), minS*.0045f, Offset(cx,cy))
    }
}

@Composable private fun ChatOverlay(modifier: Modifier, messages: List<Msg>, close: () -> Unit, send: (String)->Unit) {
    var input by remember { mutableStateOf("") }
    Surface(modifier.fillMaxWidth(.68f).fillMaxHeight(.46f).padding(start=14.dp,bottom=18.dp), shape=RoundedCornerShape(24.dp), color=Color(0xE30A1119), border=androidx.compose.foundation.BorderStroke(1.dp, Blue.copy(alpha=.13f))) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically){Text("BORIS",color=Blue,fontFamily=Mono,fontSize=10.sp,letterSpacing=2.sp);Spacer(Modifier.weight(1f));Text("×",color=Dim,modifier=Modifier.clickable(close).padding(4.dp))}
            LazyColumn(Modifier.weight(1f).padding(vertical=8.dp)){items(messages.takeLast(16)){m->Text(if(m.kind==1) "Boris  ${m.text}" else if(m.kind==0) "Du  ${m.text}" else m.text,color=if(m.kind==1)White else Dim,fontFamily=Mono,fontSize=10.sp,modifier=Modifier.padding(vertical=3.dp))}}
            Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.clip(RoundedCornerShape(16.dp)).background(Color(0x5517222C))){
                TextField(input,{input=it},Modifier.weight(1f),placeholder={Text("Mit Boris sprechen …",color=Dim,fontSize=11.sp)},singleLine=true,colors=TextFieldDefaults.colors(focusedContainerColor=Color.Transparent,unfocusedContainerColor=Color.Transparent,focusedIndicatorColor=Color.Transparent,unfocusedIndicatorColor=Color.Transparent))
                Text("→",color=Blue,fontSize=20.sp,modifier=Modifier.padding(horizontal=12.dp).clickable{val t=input.trim();if(t.isNotBlank()){send(t);input=""}})
            }
        }
    }
}

@Composable private fun SettingsOverlay(modifier: Modifier, apiKey:String,keyInput:String,listening:Boolean,recent:String,onKey:(String)->Unit,onSave:()->Unit,onListen:()->Unit,onAccessibility:()->Unit,onClose:()->Unit) {
    Surface(modifier.fillMaxWidth(.88f).fillMaxHeight(.78f).padding(18.dp),shape=RoundedCornerShape(28.dp),color=Color(0xF20A1119),border=androidx.compose.foundation.BorderStroke(1.dp,Blue.copy(alpha=.14f))) {
        Column(Modifier.padding(22.dp)){
            Row(verticalAlignment=Alignment.CenterVertically){Text("BORIS  /  CONTROL",color=Blue,fontFamily=Mono,fontSize=11.sp,letterSpacing=1.5.sp);Spacer(Modifier.weight(1f));Text("×",color=Dim,modifier=Modifier.clickable(onClose).padding(6.dp))}
            Spacer(Modifier.height(22.dp));Text("VOICE LOOP",color=White,fontFamily=Mono,fontSize=11.sp);Text("Boris / Hey Boris → sprechen → Antwort → weiter zuhören. Sag „Boris Ende“, um die Sitzung zu beenden.",color=Dim,fontSize=11.sp)
            Spacer(Modifier.height(12.dp));Button(onClick=onListen,shape=RoundedCornerShape(14.dp),modifier=Modifier.fillMaxWidth()){Text(if(listening)"Always Listening  ·  ON" else "Always Listening  ·  OFF")}
            Spacer(Modifier.height(18.dp));Text("GEMINI API",color=White,fontFamily=Mono,fontSize=11.sp);TextField(keyInput,onKey,singleLine=true,modifier=Modifier.fillMaxWidth(),placeholder={Text("Gemini API Key")});Spacer(Modifier.height(7.dp));Button(onClick=onSave,shape=RoundedCornerShape(14.dp),modifier=Modifier.fillMaxWidth()){Text("API-Key speichern")}
            Spacer(Modifier.height(16.dp));Button(onClick=onAccessibility,shape=RoundedCornerShape(14.dp),modifier=Modifier.fillMaxWidth()){Text("Autonomen Agenten aktivieren")}
            Spacer(Modifier.height(16.dp));Text("AKTIVITÄT",color=White,fontFamily=Mono,fontSize=11.sp);Text(recent.ifBlank{"Noch keine App-Aktivität"},color=Dim,fontSize=10.sp);Spacer(Modifier.height(10.dp));Text("Gedächtnis und App-Kontext bleiben lokal auf dem Gerät.",color=Dim,fontSize=10.sp)
        }
    }
}
