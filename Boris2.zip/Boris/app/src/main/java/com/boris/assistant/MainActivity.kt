package com.boris.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

data class Msg(val kind: Int, val text: String) // 0 = du, 1 = Boris, 2 = Aktion, 3 = Fehler

private val Navy = Color(0xFF020B14)
private val Navy2 = Color(0xFF06223A)
private val Panel = Color(0xFF071A2B)
private val Cyan = Color(0xFF00E5FF)
private val Gold = Color(0xFFFFB400)
private val Red = Color(0xFFFF4A3A)
private val Mono = FontFamily.Monospace

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    private var tick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale.GERMAN }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Navy, surface = Panel)) {
                BorisScreen(this, tick) { tts?.speak(it, TextToSpeech.QUEUE_FLUSH, null, "boris") }
            }
        }
    }

    override fun onResume() { super.onResume(); tick++ }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

/** HUD-Ecken wie im Helm-Display. */
private fun Modifier.hud(color: Color, len: Float = 12f, w: Float = 2f) = this.drawBehind {
    val l = len.dp.toPx(); val sw = w.dp.toPx()
    val wd = size.width; val ht = size.height
    fun ln(x1: Float, y1: Float, x2: Float, y2: Float) = drawLine(color, Offset(x1, y1), Offset(x2, y2), sw)
    ln(0f, 0f, l, 0f); ln(0f, 0f, 0f, l)
    ln(wd, 0f, wd - l, 0f); ln(wd, 0f, wd, l)
    ln(0f, ht, l, ht); ln(0f, ht, 0f, ht - l)
    ln(wd, ht, wd - l, ht); ln(wd, ht, wd, ht - l)
}

@Composable
private fun ArcReactor(boxSize: Dp, busy: Boolean, label: String, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "reactor")
    val slow by t.animateFloat(0f, 360f, infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "slow")
    val fast by t.animateFloat(0f, 360f, infiniteRepeatable(tween(1500, easing = LinearEasing)), label = "fast")
    val glow by t.animateFloat(0.45f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "glow")
    val rot = if (busy) fast else slow
    val c = if (busy) Gold else Cyan
    Box(Modifier.size(boxSize).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val s = this.size.minDimension
            val ctr = center
            drawCircle(Brush.radialGradient(listOf(c.copy(alpha = 0.35f * glow), Color.Transparent), center = ctr, radius = s / 2), radius = s / 2)
            drawCircle(c.copy(alpha = 0.9f), radius = s * 0.46f, style = Stroke(2.dp.toPx()))
            rotate(rot) {
                for (i in 0 until 3) drawArc(
                    c, startAngle = i * 120f, sweepAngle = 70f, useCenter = false,
                    topLeft = Offset(ctr.x - s * 0.37f, ctr.y - s * 0.37f), size = Size(s * 0.74f, s * 0.74f),
                    style = Stroke(4.dp.toPx(), cap = StrokeCap.Round)
                )
            }
            rotate(-rot * 1.5f) {
                drawCircle(c.copy(alpha = 0.7f), radius = s * 0.26f,
                    style = Stroke(2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f))))
            }
            drawCircle(Brush.radialGradient(listOf(Color.White, c, Color.Transparent), center = ctr, radius = s * 0.2f), radius = s * 0.2f)
        }
        Text(label, fontSize = 8.sp, color = Navy, fontFamily = Mono, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun BorisScreen(activity: Activity, tick: Int, onSpeak: (String) -> Unit) {
    val prefs = remember { activity.getSharedPreferences("boris", 0) }
    var apiKey by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var keyInput by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<Msg>() }
    val history = remember { JSONArray() }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("BEREIT") }
    var autoOn by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    LaunchedEffect(tick) { autoOn = isAutoSendEnabled(activity) }
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    LaunchedEffect(Unit) {
        perms.launch(arrayOf(Manifest.permission.SEND_SMS, Manifest.permission.READ_CONTACTS))
    }

    fun ui(block: () -> Unit) { activity.runOnUiThread { block() } }

    fun send(text: String) {
        if (text.isBlank() || busy) return
        messages.add(Msg(0, text))
        history.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text))))
        input = ""; busy = true; status = "ANALYSIERE …"
        agentApiKey = apiKey; statusSink = { s -> ui { status = s.uppercase() } }
        scope.launch {
            val reply = try {
                withContext(Dispatchers.IO) {
                    GeminiClient.chat(apiKey, history, { s -> ui { status = s.uppercase() } }) { n, a ->
                        ui { status = statusFor(n, a).uppercase() }
                        val r = runTool(activity, n, a)
                        ui { messages.add(Msg(2, r)) }
                        r
                    }
                }
            } catch (e: Exception) { null to (e.message ?: "Unbekannter Fehler") }
            val (ok, textOut) = if (reply is String) true to reply else false to (reply as Pair<*, *>).second.toString()
            messages.add(Msg(if (ok) 1 else 3, textOut))
            busy = false; status = "BEREIT"
            if (ok) onSpeak(textOut)
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == Activity.RESULT_OK && t != null) send(t)
    }
    fun listen() {
        try {
            speech.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE"))
        } catch (e: Exception) { messages.add(Msg(3, "Keine Spracherkennung verfügbar.")) }
    }

    val shape = CutCornerShape(topEnd = 14.dp, bottomStart = 14.dp)
    val sweep = rememberInfiniteTransition(label = "sweep")
    val scan by sweep.animateFloat(0f, 1f, infiniteRepeatable(tween(1100, easing = LinearEasing)), label = "scan")
    val blink by sweep.animateFloat(0.3f, 1f, infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "blink")

    Box(Modifier.fillMaxSize()
        .background(Brush.radialGradient(listOf(Navy2, Navy), radius = 1600f))
        .drawBehind {
            val step = 32.dp.toPx()
            var x = 0f
            while (x < size.width) { drawLine(Cyan.copy(alpha = 0.05f), Offset(x, 0f), Offset(x, size.height)); x += step }
            var y = 0f
            while (y < size.height) { drawLine(Cyan.copy(alpha = 0.05f), Offset(0f, y), Offset(size.width, y)); y += step }
        }) {
        Column(Modifier.fillMaxSize().systemBarsPadding().imePadding().padding(horizontal = 16.dp)) {
            // Kopf
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("B.O.R.I.S.", fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 24.sp,
                        letterSpacing = 5.sp, color = Cyan)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(6.dp).clip(CircleShape).background(Cyan.copy(alpha = blink)))
                        Spacer(Modifier.width(6.dp))
                        Text("SYSTEME ONLINE", fontFamily = Mono, fontSize = 10.sp, letterSpacing = 2.sp,
                            color = Cyan.copy(alpha = 0.6f))
                    }
                }
                if (apiKey.isNotBlank()) {
                    Box(Modifier.border(1.dp, (if (autoOn) Cyan else Gold).copy(alpha = 0.7f), CutCornerShape(topEnd = 8.dp, bottomStart = 8.dp))
                        .clickable { if (!autoOn) activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                        .padding(horizontal = 10.dp, vertical = 6.dp)) {
                        Text(if (autoOn) "AGENT: AKTIV" else "AGENT: AUS · TIPPEN", fontFamily = Mono, fontSize = 10.sp,
                            letterSpacing = 1.sp, color = if (autoOn) Cyan else Gold)
                    }
                }
            }

            if (apiKey.isBlank()) {
                Spacer(Modifier.height(40.dp))
                Column(Modifier.background(Panel.copy(alpha = 0.8f)).hud(Cyan).padding(18.dp)) {
                    Text("ZUGANG EINRICHTEN", fontFamily = Mono, fontWeight = FontWeight.Bold, color = Cyan, letterSpacing = 2.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("Kostenlosen Gemini-API-Key einfügen (aistudio.google.com/apikey). Bleibt nur auf deinem Handy.",
                        fontSize = 12.sp, fontFamily = Mono, color = Color.White.copy(alpha = 0.7f))
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(keyInput, { keyInput = it }, Modifier.fillMaxWidth(), singleLine = true)
                    Spacer(Modifier.height(10.dp))
                    Button({ apiKey = keyInput.trim(); prefs.edit().putString("key", apiKey).apply() },
                        Modifier.fillMaxWidth(), shape = CutCornerShape(8.dp)) { Text("AKTIVIEREN", fontFamily = Mono) }
                }
                return@Column
            }

            // Live-Status
            Spacer(Modifier.height(12.dp))
            Column(Modifier.fillMaxWidth().background(Panel.copy(alpha = 0.75f)).hud(if (busy) Gold else Cyan.copy(alpha = 0.7f))
                .padding(horizontal = 14.dp, vertical = 10.dp)) {
                Text("STATUS", fontFamily = Mono, fontSize = 9.sp, letterSpacing = 3.sp, color = Cyan.copy(alpha = 0.55f))
                Spacer(Modifier.height(2.dp))
                Text("▸ $status", fontFamily = Mono, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    color = if (busy) Gold else Cyan)
                Spacer(Modifier.height(6.dp))
                Canvas(Modifier.fillMaxWidth().height(2.dp)) {
                    drawRect(Cyan.copy(alpha = 0.15f))
                    if (busy) drawRect(Gold, Offset((this.size.width * 1.25f) * scan - this.size.width * 0.25f, 0f),
                        Size(this.size.width * 0.25f, this.size.height))
                }
            }

            // Verlauf
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (messages.isEmpty()) {
                    Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("WARTE AUF BEFEHL", color = Cyan, fontFamily = Mono, fontSize = 15.sp, letterSpacing = 3.sp)
                        Spacer(Modifier.height(14.dp))
                        listOf("Spiel meine Lieblingssongs", "Stell einen Timer auf 10 Minuten",
                            "Schreib Mama in WhatsApp: bin gleich da").forEach { s ->
                            Box(Modifier.padding(vertical = 4.dp).border(1.dp, Cyan.copy(alpha = 0.4f), CutCornerShape(topEnd = 10.dp, bottomStart = 10.dp))
                                .clickable { send(s) }.padding(horizontal = 14.dp, vertical = 9.dp)) {
                                Text("› $s", color = Color.White.copy(alpha = 0.85f), fontFamily = Mono, fontSize = 13.sp)
                            }
                        }
                    }
                }
                LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(vertical = 12.dp)) {
                    items(messages) { m ->
                        if (m.kind == 2) {
                            Text("▸ ${m.text.uppercase()}", Modifier.padding(vertical = 5.dp, horizontal = 4.dp),
                                color = Color(0xFF4DFFB0), fontFamily = Mono, fontSize = 11.sp, letterSpacing = 1.sp)
                        } else {
                            val col = when (m.kind) { 0 -> Gold; 3 -> Red; else -> Cyan }
                            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp),
                                horizontalArrangement = if (m.kind == 0) Arrangement.End else Arrangement.Start) {
                                Column(Modifier.widthIn(max = 310.dp).background(Panel.copy(alpha = 0.85f), shape)
                                    .border(1.dp, col.copy(alpha = 0.6f), shape).padding(12.dp)) {
                                    Text(when (m.kind) { 0 -> "DU"; 3 -> "FEHLER"; else -> "BORIS" },
                                        fontFamily = Mono, fontSize = 9.sp, letterSpacing = 3.sp, color = col.copy(alpha = 0.8f))
                                    Spacer(Modifier.height(3.dp))
                                    Text(m.text, color = Color.White, fontSize = 14.sp, fontFamily = Mono)
                                }
                            }
                        }
                    }
                }
            }

            // Eingabe + Arc-Reaktor
            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f).border(1.dp, Cyan.copy(alpha = 0.5f), shape).background(Panel.copy(alpha = 0.8f), shape)) {
                    TextField(input, { input = it }, Modifier.fillMaxWidth(),
                        placeholder = { Text("Befehl eingeben …", fontFamily = Mono, fontSize = 13.sp,
                            color = Cyan.copy(alpha = 0.4f)) },
                        textStyle = TextStyle(fontFamily = Mono, fontSize = 14.sp),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Cyan))
                }
                Spacer(Modifier.width(8.dp))
                ArcReactor(72.dp, busy, if (input.isBlank()) "TALK" else "SEND") {
                    if (input.isBlank()) listen() else send(input)
                }
            }
        }
    }
}
