package com.boris.assistant

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

private val Void = Color(0xFF01040A)
private val Blue = Color(0xFF53D8FF)
private val White = Color(0xFFEAFBFF)
private val Dim = Color(0xFF8AA5B5)
private val Mono = FontFamily.Monospace

data class Msg(val kind: Int, val text: String)

class MainActivity : ComponentActivity() {
    companion object { @Volatile var isForeground = false }
    private var tts: TextToSpeech? = null
    private val commandReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            pendingCommand = intent.getStringExtra("command")
            commandTick++
        }
    }
    private var pendingCommand: String? = null
    private var commandTick = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(SystemBarStyle.dark(android.graphics.Color.TRANSPARENT), SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        tts = TextToSpeech(this) {
            if (it == TextToSpeech.SUCCESS) {
                tts?.language = Locale.GERMAN
                tts?.setPitch(0.68f)
                tts?.setSpeechRate(0.90f)
            }
        }
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 701)
        setContent { MaterialTheme(colorScheme = darkColorScheme(background = Void, surface = Color(0xAA07111A), primary = Blue)) { BorisScreen() } }
    }

    private fun startListenService() {
        try { if (Build.VERSION.SDK_INT >= 26) startForegroundService(Intent(this, ListenService::class.java)) else startService(Intent(this, ListenService::class.java)) } catch (_: Exception) {}
    }

    override fun onStart() {
        super.onStart()
        isForeground = true
        val f = IntentFilter(ListenService.ACTION_COMMAND)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(commandReceiver, f, RECEIVER_NOT_EXPORTED) else registerReceiver(commandReceiver, f)
    }
    override fun onStop() { isForeground = false; unregisterReceiver(commandReceiver); super.onStop() }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }

    @Composable private fun BorisScreen() {
        val activity = this@MainActivity
        val memory = remember { MemoryStore(activity) }
        val prefs = remember { activity.getSharedPreferences("boris", 0) }
        var apiKey by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
        var keyInput by remember { mutableStateOf(apiKey) }
        var showSettings by remember { mutableStateOf(false) }
        var showChat by remember { mutableStateOf(false) }
        var listening by remember { mutableStateOf(prefs.getBoolean("listening", false)) }
        var input by remember { mutableStateOf("") }
        var busy by remember { mutableStateOf(false) }
        var status by remember { mutableStateOf("READY") }
        val messages = remember { mutableStateListOf<Msg>() }
        val history = remember { memory.loadHistory() }
        val scope = rememberCoroutineScope()

        LaunchedEffect(commandTick) {
            pendingCommand?.let { cmd -> pendingCommand = null; input = cmd; sendCommand(cmd, activity, memory, history, messages, apiKey, scope, { busy = it }, { status = it }, { speak(it) }) }
        }
        val micPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startListenService()
        }
        val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (r.resultCode == Activity.RESULT_OK && !t.isNullOrBlank()) sendCommand(t, activity, memory, history, messages, apiKey, scope, { busy = it }, { status = it }, { speak(it) })
        }

        fun toggleListening() {
            listening = !listening
            prefs.edit().putBoolean("listening", listening).apply()
            if (listening) {
                if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) { micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO); return }
                startListenService()
            } else stopService(Intent(activity, ListenService::class.java))
        }

        Box(Modifier.fillMaxSize().background(Void)) {
            ParticleSwarm(busy = busy, listening = listening, modifier = Modifier.fillMaxSize()) { showChat = true }

            // Minimal state indicator; the swarm remains the visual focus.
            Row(Modifier.align(Alignment.TopStart).padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).clip(CircleShape).background(if (listening) Blue else Dim))
                Spacer(Modifier.width(7.dp))
                Text(if (listening) "BORIS · LISTENING" else "BORIS", color = Dim, fontFamily = Mono, fontSize = 10.sp)
            }

            Box(Modifier.align(Alignment.TopEnd).padding(16.dp).size(42.dp).clip(CircleShape)
                .background(Color(0x66101C25)).border(1.dp, Blue.copy(alpha = .22f), CircleShape)
                .clickable { showSettings = true }, contentAlignment = Alignment.Center) { Text("⚙", color = White, fontSize = 18.sp) }

            if (showChat) ChatOverlay(Modifier.align(Alignment.BottomStart), messages, input, { input = it }, { if (input.isNotBlank()) sendCommand(input, activity, memory, history, messages, apiKey, scope, { busy = it }, { status = it }, { speak(it) }) }, { showChat = false })

            // Small interaction core: tap swarm to listen / answer.
            if (!showChat && !showSettings) {
                Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 28.dp).size(74.dp).clip(CircleShape)
                    .background(Color(0x22000000)).border(1.dp, Blue.copy(alpha = .18f), CircleShape)
                    .clickable { if (input.isBlank()) speech.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE")) }, contentAlignment = Alignment.Center) {
                    Text(if (busy) "…" else "B", color = White, fontFamily = Mono, fontSize = 18.sp)
                }
            }

            if (showSettings) SettingsOverlay(Modifier.align(Alignment.TopEnd), apiKey, keyInput, listening, memory.recentApps(),
                onKey = { keyInput = it }, onSave = { apiKey = keyInput.trim(); prefs.edit().putString("key", apiKey).apply(); showSettings = false },
                onListen = { toggleListening() }, onAccessibility = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, onClose = { showSettings = false })
        }
    }

    private fun speak(text: String) { tts?.setPitch(.68f); tts?.setSpeechRate(.90f); tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "boris") }

    private fun sendCommand(text: String, activity: Activity, memory: MemoryStore, history: JSONArray, messages: MutableList<Msg>, apiKey: String,
                            scope: kotlinx.coroutines.CoroutineScope, setBusy: (Boolean)->Unit, setStatus: (String)->Unit, speak: (String)->Unit) {
        if (text.isBlank()) return
        messages.add(Msg(0, text)); history.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text))))
        memory.addMemory("Nutzer: $text"); memory.saveHistory(history); setBusy(true); setStatus("THINKING")
        agentApiKey = apiKey; statusSink = { setStatus(it.uppercase()) }
        scope.launch {
            val result = try {
                withContext(Dispatchers.IO) {
                    GeminiClient.chat(apiKey, history, memory.memoryText(), memory.recentApps(), { setStatus(it.uppercase()) }) { n, a ->
                        setStatus(statusFor(n, a).uppercase()); runTool(activity, n, a).also { messages.add(Msg(2, it)) }
                    }
                }
            } catch (e: Exception) { "Fehler: ${e.message}" }
            val ok = !result.startsWith("Fehler:")
            messages.add(Msg(if (ok) 1 else 3, result)); history.put(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", result))))
            memory.addMemory("Boris: $result"); memory.saveHistory(history); setBusy(false); setStatus("READY"); if (ok) speak(result)
        }
    }
}

@Composable private fun ParticleSwarm(busy: Boolean, listening: Boolean, modifier: Modifier, onTap: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "swarm")
    val time by transition.animateFloat(0f, 6.28318f, infiniteRepeatable(tween(if (busy) 1800 else 6000, easing = LinearEasing)), label = "time")
    var touch by remember { mutableStateOf(Offset.Unspecified) }
    val state = if (busy) 1.35f else if (listening) 1.0f else .55f
    Canvas(modifier.pointerInput(Unit) { detectTapGestures(onTap = { touch = it; onTap() }) }) {
        val cx = size.width / 2f; val cy = size.height / 2f
        val minS = minOf(size.width, size.height)
        val count = 150
        val points = ArrayList<Offset>(count)
        for (i in 0 until count) {
            val a = i * 2.399963f + time * (0.035f + (i % 7) * .001f)
            val ring = (i % 15) / 14f
            val base = minS * (.045f + ring * .25f)
            val breath = 1f + sin(time * 2f + i * .31f) * (.035f * state)
            var x = cx + cos(a) * base * breath + sin(time * 1.7f + i) * minS * .012f * state
            var y = cy + sin(a) * base * breath + cos(time * 1.3f + i * .7f) * minS * .012f * state
            if (touch != Offset.Unspecified) {
                val dx = x - touch.x; val dy = y - touch.y; val d = sqrt(dx*dx + dy*dy).coerceAtLeast(1f)
                if (d < minS*.18f) { val push = (1f - d/(minS*.18f)) * minS*.06f; x += dx/d*push; y += dy/d*push }
            }
            val p = Offset(x,y); points.add(p)
            val r = (1.0f + (i % 4) * .45f) * (1f + .25f * sin(time*3f+i))
            drawCircle(Brush.radialGradient(listOf(Blue.copy(alpha=.95f), Blue.copy(alpha=.05f))), r*5.5f, p)
            drawCircle(White.copy(alpha=.75f), r, p)
        }
        // subtle connections make the swarm feel like one living system
        for (i in 0 until points.size step 3) {
            val j = (i + 1) % points.size
            drawLine(Blue.copy(alpha=.045f), points[i], points[j], strokeWidth=1f)
        }
        drawCircle(Blue.copy(alpha=.055f), minS*.20f, Offset(cx,cy))
        drawCircle(White.copy(alpha=.82f), minS*.006f, Offset(cx,cy))
    }
}

@Composable private fun ChatOverlay(modifier: Modifier, messages: List<Msg>, input: String, onInput: (String)->Unit, onSend: ()->Unit, close: ()->Unit) {
    Surface(modifier.fillMaxWidth(.62f).fillMaxHeight(.42f).padding(start=14.dp,bottom=18.dp), shape=RoundedCornerShape(18.dp), color=Color(0xD9081018), tonalElevation=0.dp) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) { Text("BORIS", color=Blue, fontFamily=Mono, fontSize=11.sp); Spacer(Modifier.weight(1f)); Text("×", color=Dim, modifier=Modifier.clickable(onClick = close).padding(4.dp)) }
            LazyColumn(Modifier.weight(1f).padding(vertical=6.dp)) { items(messages.takeLast(12)) { m -> Text(if(m.kind==1) "Boris  ${m.text}" else if(m.kind==0) "Du  ${m.text}" else m.text, color=if(m.kind==1) White else Dim, fontFamily=Mono, fontSize=11.sp, modifier=Modifier.padding(vertical=3.dp)) } }
            Row(verticalAlignment=Alignment.CenterVertically) {
                TextField(input,{onInput(it)},Modifier.weight(1f),placeholder={Text("Sag etwas …",fontSize=11.sp)},singleLine=true,colors=TextFieldDefaults.colors(focusedContainerColor=Color.Transparent,unfocusedContainerColor=Color.Transparent,focusedIndicatorColor=Color.Transparent,unfocusedIndicatorColor=Color.Transparent))
                Text("➤",color=Blue,modifier=Modifier.padding(8.dp).clickable(onClick = onSend))
            }
        }
    }
}

@Composable private fun SettingsOverlay(modifier: Modifier, apiKey:String,keyInput:String,listening:Boolean,recent:String,onKey:(String)->Unit,onSave:()->Unit,onListen:()->Unit,onAccessibility:()->Unit,onClose:()->Unit) {
    Box(Modifier.fillMaxSize().background(Color(0x99000000)))
    Surface(modifier.fillMaxWidth(.86f).fillMaxHeight(.78f).padding(18.dp),shape=RoundedCornerShape(24.dp),color=Color(0xF20A121A)) {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically){Text("BORIS · SETTINGS",color=Blue,fontFamily=Mono,fontSize=13.sp);Spacer(Modifier.weight(1f));Text("×",color=Dim,modifier=Modifier.clickable(onClick = onClose).padding(6.dp))}
            Spacer(Modifier.height(20.dp))
            Text("Wake word",color=White,fontFamily=Mono,fontSize=12.sp);Text("„Hey Boris“ oder „Boris“",color=Dim,fontSize=12.sp)
            Spacer(Modifier.height(16.dp)); Button(onClick=onListen){Text(if(listening)"Always Listening · AN" else "Always Listening · AUS")}
            Spacer(Modifier.height(14.dp));Text("Gemini API Key",color=White,fontFamily=Mono,fontSize=12.sp);TextField(keyInput,onKey,singleLine=true,modifier=Modifier.fillMaxWidth(),placeholder={Text("AIza…")})
            Spacer(Modifier.height(8.dp));Button(onClick=onSave){Text("Speichern")}
            Spacer(Modifier.height(14.dp));Button(onClick=onAccessibility){Text("Bedienungshilfe für App-Steuerung öffnen")}
            Spacer(Modifier.height(18.dp));Text("Langzeitgedächtnis / zuletzt gesehene Apps",color=White,fontFamily=Mono,fontSize=11.sp);Text(recent.ifBlank{"Noch keine Daten"},color=Dim,fontSize=10.sp)
            Spacer(Modifier.height(12.dp));Text("Boris speichert Chat-Verlauf, Erinnerungen und App-Aktivität lokal auf dem Gerät.",color=Dim,fontSize=10.sp)
        }
    }
}
