package com.boris.assistant

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

// ------------------------------------------------------------------ Thema
private var Navy by mutableStateOf(Color(0xFF05070D))
private var Panel by mutableStateOf(Color(0xFF111724))
private var Cyan by mutableStateOf(Color(0xFF5AA9FF))   // Akzent
private var Gold by mutableStateOf(Color(0xFFC9E4FF))   // helleres Zweit-Akzent
private var Mint by mutableStateOf(Color(0xFF6EE7C8))
private var OnAccent by mutableStateOf(Color.White)
private val Red = Color(0xFFFF5C5C)

/** Thema: Blau oder Schwarz-Weiß. */
private fun applyTheme(bw: Boolean) {
    if (bw) {
        Navy = Color(0xFF000000); Panel = Color(0xFF131313); Cyan = Color(0xFFF2F2F2); Gold = Color(0xFFBDBDBD)
        Mint = Color(0xFFFFFFFF); OnAccent = Color.Black
    } else {
        Navy = Color(0xFF05070D); Panel = Color(0xFF111724); Cyan = Color(0xFF5AA9FF); Gold = Color(0xFFC9E4FF)
        Mint = Color(0xFF6EE7C8); OnAccent = Color.White
    }
}

// ------------------------------------------------------------------ Activity
class MainActivity : ComponentActivity() {
    val jarvis: Jarvis by lazy { Hub.jarvis(this) }
    var tick by mutableIntStateOf(0)
    private var ownListener: WakeListener? = null
    private var awaitAfterStart = false

    private fun prefs() = getSharedPreferences("boris", 0)
    fun alwaysListen() = prefs().getBoolean("always_listen", false)
    private fun micOk() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED

    /** Mit Dauer-Zuhören übernimmt der Hintergrunddienst, sonst hört die App nur im Vordergrund zu. */
    fun startListening() {
        if (!micOk()) return
        if (alwaysListen()) {
            ownListener?.stop(); ownListener = null
            try { startForegroundService(Intent(this, ListenService::class.java)) } catch (e: Exception) { Dbg.d("Dienst: ${e.message}") }
        } else {
            if (ownListener == null) ownListener = WakeListener(this, { t -> Core.handle(this, t) }, { m -> Core.voiceMode = m })
            Core.listener = ownListener
            ownListener?.start()
        }
        if (awaitAfterStart) { awaitAfterStart = false; Core.listener?.awaitCommand() }
    }

    fun setAlwaysListen(on: Boolean) {
        prefs().edit().putBoolean("always_listen", on).apply()
        if (!on) stopService(Intent(this, ListenService::class.java))
        startListening()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Brain.load(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        handleIntent(intent)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Navy, surface = Panel)) {
                BorisScreen(this)
            }
        }
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); handleIntent(intent) }

    private fun handleIntent(i: Intent?) { if (i?.hasExtra("q") == true) { awaitAfterStart = true; i.removeExtra("q") } }

    override fun onResume() { super.onResume(); tick++; Core.activityVisible = true; startListening() }

    override fun onPause() {
        Core.activityVisible = false
        if (!alwaysListen()) { ownListener?.stop(); Core.voiceMode = 0 }
        super.onPause()
    }
}

// ------------------------------------------------------------------ Plasma-Kugel aus Schwarm-Punkten
private class Orb(val n: Int) {
    val ux = FloatArray(n); val uy = FloatArray(n); val uz = FloatArray(n)
    val ox = FloatArray(n); val oy = FloatArray(n); val oz = FloatArray(n)
    val ovx = FloatArray(n); val ovy = FloatArray(n); val ovz = FloatArray(n)
    val px = FloatArray(n); val py = FloatArray(n); val pz = FloatArray(n)
    val nb = Array(n) { IntArray(5) }
    private var angY = 0f
    private var tiltExtra = 0f

    init {
        val ga = PI.toFloat() * (3f - sqrt(5f))
        for (i in 0 until n) {
            val y = 1f - 2f * (i + 0.5f) / n
            val r = sqrt(1f - y * y)
            ux[i] = cos(ga * i) * r; uy[i] = y; uz[i] = sin(ga * i) * r
        }
        for (i in 0 until n) {
            val d = FloatArray(n) { j ->
                if (j == i) 99f else (ux[i] - ux[j]) * (ux[i] - ux[j]) + (uy[i] - uy[j]) * (uy[i] - uy[j]) + (uz[i] - uz[j]) * (uz[i] - uz[j])
            }
            for (k in 0 until 5) {
                var best = 0
                for (j in 1 until n) if (d[j] < d[best]) best = j
                nb[i][k] = best; d[best] = 99f
            }
        }
    }

    /** spin = zusätzliche Drehgeschwindigkeit (rad/s), wenn Boris spricht. */
    fun step(dt: Float, time: Float, e: Float, level: Float, spin: Float, cx: Float, cy: Float, radius: Float) {
        angY += dt * (0.25f + 0.5f * e + spin)
        tiltExtra = if (spin > 0.01f) tiltExtra + dt * spin * 0.35f else tiltExtra * (1f - min(1f, dt * 0.8f))
        val tilt = 0.35f + 0.1f * sin(time * 0.4f) + tiltExtra
        val cr = cos(angY); val sr = sin(angY); val ct = cos(tilt); val st = sin(tilt)
        val amp = 0.05f + 0.22f * e
        for (i in 0 until n) {
            val tx = sin(time * 1.3f + uy[i] * 5f + uz[i] * 3f) * amp
            val ty = sin(time * 1.1f + uz[i] * 5f + ux[i] * 3f) * amp
            val tz = sin(time * 1.7f + ux[i] * 5f + uy[i] * 3f) * amp
            ovx[i] += ((tx - ox[i]) * 6f - ovx[i] * 1.5f) * dt
            ovy[i] += ((ty - oy[i]) * 6f - ovy[i] * 1.5f) * dt
            ovz[i] += ((tz - oz[i]) * 6f - ovz[i] * 1.5f) * dt
            ox[i] += ovx[i] * dt; oy[i] += ovy[i] * dt; oz[i] += ovz[i] * dt
            val pulse = 1f + level * 0.3f * sin(time * 13f + uy[i] * 6f)
            val x = (ux[i] + ox[i]) * pulse; val y = (uy[i] + oy[i]) * pulse; val z = (uz[i] + oz[i]) * pulse
            val x1 = x * cr + z * sr; val z1 = -x * sr + z * cr
            val y2 = y * ct - z1 * st; val z2 = y * st + z1 * ct
            val persp = 1f / (1f - z2 * 0.22f)
            px[i] = cx + x1 * radius * persp; py[i] = cy + y2 * radius * persp; pz[i] = z2
        }
    }
}

private class SwarmHolder {
    val orb = Orb(220)
    var w = 0f; var h = 0f; var time = 0f; var energy = 0.2f; var spin = 0f
    var touch = Offset.Zero; var touching = false
}

// ------------------------------------------------------------------ Symbole (selbst gezeichnet)
@Composable
private fun Ico(kind: String, color: Color, boxSize: Dp = 24.dp) {
    Canvas(Modifier.size(boxSize)) {
        val w = this.size.width
        val sw = w * 0.085f
        val st = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (kind) {
            "chat" -> {
                drawRoundRect(color, Offset(w * 0.12f, w * 0.14f), Size(w * 0.76f, w * 0.58f), CornerRadius(w * 0.2f), style = st)
                val tail = Path().apply { moveTo(w * 0.32f, w * 0.72f); lineTo(w * 0.27f, w * 0.9f); lineTo(w * 0.52f, w * 0.72f) }
                drawPath(tail, color, style = st)
                for (i in 0 until 3) drawCircle(color, w * 0.035f, Offset(w * (0.34f + 0.16f * i), w * 0.43f))
            }
            "mic" -> {
                drawRoundRect(color, Offset(w * 0.37f, w * 0.1f), Size(w * 0.26f, w * 0.47f), CornerRadius(w * 0.13f), style = st)
                drawArc(color, startAngle = 0f, sweepAngle = 180f, useCenter = false,
                    topLeft = Offset(w * 0.24f, w * 0.26f), size = Size(w * 0.52f, w * 0.46f), style = st)
                drawLine(color, Offset(w * 0.5f, w * 0.72f), Offset(w * 0.5f, w * 0.88f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * 0.36f, w * 0.9f), Offset(w * 0.64f, w * 0.9f), sw, StrokeCap.Round)
            }
            "send" -> {
                val p = Path().apply {
                    moveTo(w * 0.12f, w * 0.46f); lineTo(w * 0.9f, w * 0.12f); lineTo(w * 0.58f, w * 0.9f); lineTo(w * 0.46f, w * 0.58f); close()
                }
                drawPath(p, color, style = st)
                drawLine(color, Offset(w * 0.46f, w * 0.58f), Offset(w * 0.9f, w * 0.12f), sw, StrokeCap.Round)
            }
            "close" -> {
                drawLine(color, Offset(w * 0.27f, w * 0.27f), Offset(w * 0.73f, w * 0.73f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * 0.73f, w * 0.27f), Offset(w * 0.27f, w * 0.73f), sw, StrokeCap.Round)
            }
            "plus" -> {
                drawLine(color, Offset(w * 0.5f, w * 0.22f), Offset(w * 0.5f, w * 0.78f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * 0.22f, w * 0.5f), Offset(w * 0.78f, w * 0.5f), sw, StrokeCap.Round)
            }
        }
    }
}

@Composable
private fun RoundBtn(kind: String, diameter: Dp, filled: Boolean, halo: Float, onClick: () -> Unit) {
    val bg = if (filled) Modifier.background(Brush.linearGradient(listOf(Cyan, lerp(Cyan, Color.White, 0.3f))), CircleShape)
    else Modifier.background(Color.White.copy(alpha = 0.08f), CircleShape).border(1.dp, Color.White.copy(alpha = 0.14f), CircleShape)
    Box(Modifier.size(diameter)
        .drawBehind { if (halo > 0f) drawCircle(Cyan.copy(alpha = 0.28f * halo), this.size.minDimension / 2f * (1.1f + 0.45f * halo)) }
        .then(bg).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Ico(kind, if (filled) OnAccent else Color.White, diameter * 0.44f)
    }
}

@Composable
private fun SegTab(label: String, sel: Boolean, onClick: () -> Unit) {
    Text(label, Modifier.clip(RoundedCornerShape(50)).background(if (sel) Cyan.copy(alpha = 0.2f) else Color.Transparent)
        .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        fontSize = 13.sp, fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal,
        color = if (sel) Cyan else Color.White.copy(alpha = 0.55f))
}

@Composable
private fun SRow(title: String, sub: String?, onClick: (() -> Unit)?, trailing: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = 0.05f))
        .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
        .padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 14.sp)
            if (sub != null) Text(sub, color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp)
        }
        trailing()
    }
}

@Composable
private fun Toggle(on: Boolean, onChange: (Boolean) -> Unit) {
    Switch(on, onChange, colors = SwitchDefaults.colors(
        checkedThumbColor = OnAccent, checkedTrackColor = Cyan,
        uncheckedThumbColor = Color(0xFFB0B0B0), uncheckedTrackColor = Color.White.copy(alpha = 0.15f), uncheckedBorderColor = Color.Transparent))
}

@Composable
private fun PillField(value: String, hint: String, modifier: Modifier, onChange: (String) -> Unit) {
    Box(modifier.clip(RoundedCornerShape(26.dp)).background(Color.White.copy(alpha = 0.07f))) {
        TextField(value, onChange, Modifier.fillMaxWidth(), singleLine = true,
            placeholder = { Text(hint, fontSize = 14.sp, color = Color.White.copy(alpha = 0.4f)) },
            textStyle = TextStyle(fontSize = 15.sp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Cyan))
    }
}

// ------------------------------------------------------------------ Bildschirm
@Composable
private fun BorisScreen(activity: MainActivity) {
    val prefs = remember { activity.getSharedPreferences("boris", 0) }
    var apiKey by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var keyInput by remember { mutableStateOf("") }
    var input by remember { mutableStateOf("") }
    var chatOpen by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var brainTick by remember { mutableIntStateOf(0) }
    var brainInput by remember { mutableStateOf("") }
    var proactive by remember { mutableStateOf(prefs.getBoolean("proactive", true)) }
    var hq by remember { mutableStateOf(prefs.getBoolean("hq_voice", true)) }
    var notifAi by remember { mutableStateOf(prefs.getBoolean("notif_ai", true)) }
    var safety by remember { mutableStateOf(prefs.getBoolean("safety", true)) }
    var always by remember { mutableStateOf(activity.alwaysListen()) }
    var voiceName by remember { mutableStateOf(activity.jarvis.voiceName()) }
    var bw by remember { mutableStateOf(prefs.getInt("theme", 0) == 1) }
    remember { applyTheme(bw); 0 }
    var elKeyInput by remember { mutableStateOf("") }
    var elVoiceInput by remember { mutableStateOf("") }
    var elSet by remember { mutableStateOf(!prefs.getString("el_key", "").isNullOrBlank()) }
    var agentOn by remember { mutableStateOf(false) }
    var notifOn by remember { mutableStateOf(false) }
    var testing by remember { mutableStateOf(false) }
    val testResults = remember { mutableStateListOf<Pair<Boolean, String>>() }
    var crash by remember { mutableStateOf(prefs.getString("crash", null)) }
    val listState = rememberLazyListState()
    val jarvis = activity.jarvis
    val dens = LocalDensity.current.density
    val messages = Core.messages

    LaunchedEffect(activity.tick) { agentOn = isAutoSendEnabled(activity); notifOn = isNotifAccessEnabled(activity) }
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (it[Manifest.permission.RECORD_AUDIO] == true) activity.startListening()
    }
    LaunchedEffect(Unit) {
        perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.SEND_SMS, Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE, Manifest.permission.READ_CALENDAR, Manifest.permission.POST_NOTIFICATIONS))
    }
    LaunchedEffect(messages.size) { if (messages.isNotEmpty() && chatOpen && tab == 0) listState.animateScrollToItem(messages.size - 1) }

    // ---- Simulation: Energie und Drehung folgen dem, was Boris gerade tut
    val hold = remember { SwarmHolder() }
    var frame by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                val dt = if (last == 0L) 0.016f else ((now - last) / 1_000_000_000f).coerceAtMost(0.05f)
                last = now
                val speaking = jarvis.speaking
                val lvl = jarvis.level
                val tgt = when {
                    speaking -> 0.8f + lvl * 0.6f
                    Core.busy -> 0.85f
                    Core.voiceMode == 2 -> 0.6f
                    else -> 0.2f
                }
                hold.energy += (tgt - hold.energy) * min(1f, dt * 5f)
                val spinTarget = if (speaking) 3.2f + lvl * 6f else 0f
                hold.spin += (spinTarget - hold.spin) * min(1f, dt * 4f)
                hold.time += dt
                if (hold.w > 0f) {
                    val shift = if (hold.touching) (hold.touch.x - hold.w / 2) * 0.08f else 0f
                    val rad = min(hold.w, hold.h) * 0.27f * (1f + 0.03f * sin(hold.time * 2.2f) + (if (speaking) lvl * 0.14f else 0f) + hold.energy * 0.05f)
                    hold.orb.step(dt, hold.time, hold.energy, if (speaking) lvl else 0f, hold.spin, hold.w / 2 + shift, hold.h * 0.36f, rad)
                }
                frame = now
            }
        }
    }
    val tint by animateColorAsState(
        when {
            jarvis.speaking -> lerp(Cyan, Color.White, 0.5f)
            Core.busy -> Gold
            Core.voiceMode == 2 -> Mint
            else -> Cyan
        }, tween(500), label = "tint")

    val pulseT = rememberInfiniteTransition(label = "pulse")
    val pulse by pulseT.animateFloat(0.2f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "p")

    Box(Modifier.fillMaxSize().background(Navy)
        .onSizeChanged { hold.w = it.width.toFloat(); hold.h = it.height.toFloat() }
        .pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { hold.touch = it; hold.touching = true },
                onDrag = { c, _ -> hold.touch = c.position },
                onDragEnd = { hold.touching = false }, onDragCancel = { hold.touching = false })
        }) {

        Canvas(Modifier.fillMaxSize()) {
            val tk = frame
            if (tk < 0) return@Canvas
            val orb = hold.orb
            val t = hold.time
            val cxo = orb.px.average().toFloat(); val cyo = orb.py.average().toFloat()
            val rr = min(hold.w, hold.h) * 0.27f
            drawCircle(Brush.radialGradient(listOf(tint.copy(alpha = 0.30f * (0.6f + 0.4f * hold.energy)), Color.Transparent),
                center = Offset(cxo, cyo), radius = rr * 1.8f), radius = rr * 1.8f, center = Offset(cxo, cyo))
            val back = Path(); val front = Path()
            for (i in 0 until orb.n) for (k in 0 until 5) {
                val j = orb.nb[i][k]
                if (j < i && orb.nb[j].contains(i)) continue
                val x1 = orb.px[i]; val y1 = orb.py[i]; val x2 = orb.px[j]; val y2 = orb.py[j]
                val dx = x2 - x1; val dy = y2 - y1
                val len = sqrt(dx * dx + dy * dy) + 0.001f
                val nx = -dy / len; val ny = dx / len
                val amp = len * (0.10f + 0.25f * hold.energy)
                val s1 = sin(t * 9f + i * 1.7f + k * 2.3f) * amp
                val s2 = sin(t * 11f + i * 2.9f + k * 1.1f) * amp
                val p = if ((orb.pz[i] + orb.pz[j]) * 0.5f > -0.05f) front else back
                p.moveTo(x1, y1)
                p.lineTo(x1 + dx * 0.33f + nx * s1, y1 + dy * 0.33f + ny * s1)
                p.lineTo(x1 + dx * 0.66f + nx * s2, y1 + dy * 0.66f + ny * s2)
                p.lineTo(x2, y2)
            }
            drawPath(back, tint.copy(alpha = 0.18f), style = Stroke(1.2f * dens))
            drawPath(front, tint.copy(alpha = 0.28f), style = Stroke(4.5f * dens))
            drawPath(front, lerp(tint, Color.White, 0.6f).copy(alpha = 0.95f), style = Stroke(1.3f * dens))
            for (i in 0 until orb.n) {
                val depth = ((orb.pz[i] + 1f) * 0.5f).coerceIn(0f, 1f)
                drawCircle(lerp(tint, Color.White, 0.7f).copy(alpha = 0.25f + 0.7f * depth), (0.9f + 1.4f * depth) * dens, Offset(orb.px[i], orb.py[i]))
            }
        }

        if (apiKey.isBlank()) {
            Column(Modifier.align(Alignment.Center).padding(24.dp).clip(RoundedCornerShape(24.dp)).background(Panel).padding(20.dp)) {
                Text("Zugang einrichten", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Text("Kostenlosen Gemini-API-Key einfügen (aistudio.google.com/apikey). Er bleibt nur auf deinem Handy.",
                    fontSize = 13.sp, color = Color.White.copy(alpha = 0.6f))
                Spacer(Modifier.height(14.dp))
                PillField(keyInput, "API-Key", Modifier.fillMaxWidth()) { keyInput = it }
                Spacer(Modifier.height(12.dp))
                Button({ apiKey = keyInput.trim(); prefs.edit().putString("key", apiKey).apply() }, Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = OnAccent)) { Text("Starten") }
            }
        } else {
            // Kopf: Name links, Status rechts
            Row(Modifier.align(Alignment.TopCenter).fillMaxWidth().systemBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text("Boris", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Row(Modifier.clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.07f)).padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(7.dp).clip(CircleShape).background(tint.copy(alpha = if (Core.busy) pulse else 1f)))
                    Spacer(Modifier.width(8.dp))
                    Text(Core.status.lowercase().replaceFirstChar { it.uppercase() }, color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 190.dp))
                }
            }
            if (!agentOn) {
                Text("Agent-Zugriff aktivieren ›", Modifier.align(Alignment.TopStart).systemBarsPadding().padding(start = 20.dp, top = 56.dp)
                    .clip(RoundedCornerShape(50)).background(Color(0x33FFB400))
                    .clickable { activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                    .padding(horizontal = 12.dp, vertical = 6.dp), fontSize = 12.sp, color = Color(0xFFFFC857))
            }

            // Mitte unten: Überschrift oder letzte Antwort
            val lastBoris = messages.lastOrNull { it.kind == 1 || it.kind == 3 }
            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().systemBarsPadding().padding(start = 28.dp, end = 28.dp, bottom = 130.dp),
                horizontalAlignment = Alignment.CenterHorizontally) {
                when {
                    Core.voiceMode == 2 -> Text("Ich höre zu …", color = Mint, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                    lastBoris != null -> Text(lastBoris.text, color = Color.White.copy(alpha = 0.92f), fontSize = 18.sp, textAlign = TextAlign.Center,
                        maxLines = 4, overflow = TextOverflow.Ellipsis, lineHeight = 24.sp)
                    else -> {
                        Text("Dein eigener", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.SemiBold)
                        Text("KI-Assistent", fontSize = 30.sp, fontWeight = FontWeight.SemiBold,
                            style = TextStyle(brush = Brush.linearGradient(listOf(Cyan, lerp(Cyan, Color.White, 0.55f))), fontSize = 30.sp, fontWeight = FontWeight.SemiBold))
                    }
                }
            }

            // Unten: Chat links, Mikro rechts
            Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().systemBarsPadding().padding(horizontal = 24.dp, vertical = 22.dp),
                horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                RoundBtn("chat", 56.dp, false, 0f) { chatOpen = true }
                Text(if (Core.voiceMode == 0) "Mikrofon aus" else if (always) "Hört immer zu · sag „Boris“" else "Sag „Boris“",
                    color = Color.White.copy(alpha = 0.38f), fontSize = 12.sp)
                RoundBtn("mic", 66.dp, true, if (Core.voiceMode == 2) pulse else 0f) { Core.listener?.awaitCommand() }
            }

            // Chat / Gehirn / System als Sheet
            AnimatedVisibility(chatOpen, enter = fadeIn(), exit = fadeOut()) {
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f)).clickable { chatOpen = false })
            }
            AnimatedVisibility(chatOpen, enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut(),
                modifier = Modifier.align(Alignment.BottomCenter)) {
                Column(Modifier.fillMaxWidth().fillMaxHeight(0.88f).clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                    .background(Panel).imePadding().navigationBarsPadding().padding(horizontal = 16.dp)) {
                    Box(Modifier.align(Alignment.CenterHorizontally).padding(top = 10.dp).size(width = 40.dp, height = 4.dp)
                        .clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.2f)))
                    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        SegTab("Chat", tab == 0) { tab = 0 }
                        SegTab("Gehirn", tab == 1) { tab = 1 }
                        SegTab("System", tab == 2) { tab = 2 }
                        Spacer(Modifier.weight(1f))
                        Box(Modifier.size(36.dp).clip(CircleShape).clickable { chatOpen = false }, contentAlignment = Alignment.Center) {
                            Ico("close", Color.White.copy(alpha = 0.7f), 20.dp)
                        }
                    }
                    when (tab) {
                        0 -> {
                            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, contentPadding = PaddingValues(vertical = 8.dp)) {
                                itemsIndexed(messages) { _, m ->
                                    if (m.kind == 2) {
                                        Text("✓ ${m.text}", Modifier.padding(vertical = 4.dp, horizontal = 6.dp), color = Mint.copy(alpha = 0.85f), fontSize = 12.sp)
                                    } else {
                                        val mine = m.kind == 0
                                        val shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomEnd = if (mine) 6.dp else 20.dp, bottomStart = if (mine) 20.dp else 6.dp)
                                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                                            Text(m.text, Modifier.widthIn(max = 300.dp).clip(shape)
                                                .background(when (m.kind) { 0 -> Cyan; 3 -> Red.copy(alpha = 0.25f); else -> Color.White.copy(alpha = 0.08f) })
                                                .padding(horizontal = 14.dp, vertical = 10.dp),
                                                color = if (mine) OnAccent else Color.White, fontSize = 15.sp)
                                        }
                                    }
                                }
                            }
                            Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                PillField(input, "Nachricht an Boris", Modifier.weight(1f)) { input = it }
                                Spacer(Modifier.width(10.dp))
                                RoundBtn("send", 50.dp, true, 0f) { Core.handle(activity, input); input = "" }
                            }
                        }
                        1 -> {
                            val facts = remember(brainTick, tab) { Brain.all() }
                            Text("${facts.size} Einträge im dauerhaften Gedächtnis", color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp,
                                modifier = Modifier.padding(vertical = 6.dp))
                            LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                                itemsIndexed(facts) { i, f ->
                                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(14.dp))
                                        .background(Color.White.copy(alpha = 0.05f)).padding(start = 14.dp, top = 8.dp, bottom = 8.dp, end = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(f.first, color = Cyan, fontSize = 10.sp)
                                            Text(f.second, color = Color.White, fontSize = 14.sp)
                                        }
                                        Box(Modifier.size(38.dp).clip(CircleShape).clickable { Brain.removeAt(i); brainTick++ }, contentAlignment = Alignment.Center) {
                                            Ico("close", Color.White.copy(alpha = 0.5f), 18.dp)
                                        }
                                    }
                                }
                            }
                            Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                PillField(brainInput, "Boris etwas beibringen", Modifier.weight(1f)) { brainInput = it }
                                Spacer(Modifier.width(10.dp))
                                RoundBtn("plus", 50.dp, true, 0f) { Brain.add(brainInput, "manuell"); brainInput = ""; brainTick++ }
                            }
                        }
                        else -> {
                            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
                                SRow("Stimme", voiceName, { voiceName = jarvis.cycleVoice(); Core.say(activity, "Systeme online. Wie kann ich helfen?", false) }) {
                                    Text("wechseln ›", color = Cyan, fontSize = 13.sp)
                                }
                                SRow("Farbthema", if (bw) "Schwarz-Weiß" else "Blau", { bw = !bw; prefs.edit().putInt("theme", if (bw) 1 else 0).apply(); applyTheme(bw) }) {
                                    Text("wechseln ›", color = Cyan, fontSize = 13.sp)
                                }
                                SRow("Immer zuhören", "auch bei gesperrtem Handy", null) { Toggle(always) { always = it; activity.setAlwaysListen(it) } }
                                SRow("Benachrichtigungen erzählen", "kurz zusammengefasst, auf Wunsch stumm", null) {
                                    Toggle(notifAi) { notifAi = it; prefs.edit().putBoolean("notif_ai", it).apply() }
                                }
                                SRow("Proaktive Rückfragen", "z. B. wenn du lange in einer App bist", null) {
                                    Toggle(proactive) { proactive = it; prefs.edit().putBoolean("proactive", it).apply() }
                                }
                                SRow("Sicherheitsabfragen", "bei Geld, langen Texten, neuen Kontakten", null) {
                                    Toggle(safety) { safety = it; prefs.edit().putBoolean("safety", it).apply() }
                                }
                                SRow("Gemini-Stimme als Ausweichlösung", null, null) { Toggle(hq) { hq = it; prefs.edit().putBoolean("hq_voice", it).apply() } }
                                Spacer(Modifier.height(8.dp))
                                Text("ElevenLabs-Stimme (elevenlabs.io → API Keys). Der Gratis-Tarif hat nur wenige Zeichen im Monat.",
                                    color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp))
                                PillField(elKeyInput, "ElevenLabs-Key", Modifier.fillMaxWidth()) { elKeyInput = it }
                                SRow("ElevenLabs-Key speichern", if (elSet) "gesetzt" else "nicht gesetzt", {
                                    val k = elKeyInput.trim()
                                    prefs.edit().putString("el_key", k).apply()
                                    elSet = k.isNotBlank(); elKeyInput = ""
                                    voiceName = jarvis.voiceName()
                                    if (elSet) Core.say(activity, "ElevenLabs verbunden. Systeme online.", false)
                                }) { Text("speichern ›", color = Cyan, fontSize = 13.sp) }
                                PillField(elVoiceInput, "Eigene Voice-ID (optional)", Modifier.fillMaxWidth()) { elVoiceInput = it }
                                SRow("Eigene Voice-ID speichern", null, {
                                    val v = elVoiceInput.trim()
                                    if (v.isNotBlank()) { prefs.edit().putString("el_voice", v).apply(); elVoiceInput = ""; voiceName = jarvis.voiceName() }
                                }) { Text("speichern ›", color = Cyan, fontSize = 13.sp) }
                                Spacer(Modifier.height(8.dp))
                                SRow("Benachrichtigungszugriff", if (notifOn) "aktiv" else "aus, hier aktivieren",
                                    { activity.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }) {
                                    Text(if (notifOn) "✓" else "›", color = if (notifOn) Mint else Gold, fontSize = 16.sp)
                                }
                                SRow("Agent-Zugriff", if (agentOn) "aktiv" else "aus, hier aktivieren",
                                    { activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) {
                                    Text(if (agentOn) "✓" else "›", color = if (agentOn) Mint else Gold, fontSize = 16.sp)
                                }
                                SRow("Selbsttest", if (testing) "läuft …" else "prüft alles, was Boris braucht", {
                                    if (!testing) {
                                        testing = true; testResults.clear()
                                        Thread {
                                            val r = try { SelfTest.run(activity) } catch (e: Exception) { listOf(false to "Test-Fehler: ${e.message}") }
                                            activity.runOnUiThread { testResults.addAll(r); testing = false }
                                        }.start()
                                    }
                                }) { Text("starten ›", color = Cyan, fontSize = 13.sp) }
                                testResults.forEach {
                                    Text((if (it.first) "✓ " else "✗ ") + it.second, Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                        fontSize = 12.sp, color = if (it.first) Mint else Red)
                                }
                                if (crash != null) {
                                    SRow("Letzter Absturz", "antippen zum Löschen", { prefs.edit().remove("crash").apply(); crash = null }) {
                                        Text("löschen", color = Red, fontSize = 13.sp)
                                    }
                                    Text(crash!!.take(600), Modifier.padding(8.dp), fontSize = 9.sp, color = Red.copy(alpha = 0.8f))
                                }
                                Spacer(Modifier.height(8.dp))
                                Text("Protokoll", Modifier.padding(horizontal = 8.dp), fontSize = 11.sp, color = Color.White.copy(alpha = 0.5f))
                                Dbg.lines.takeLast(25).forEach {
                                    Text(it, Modifier.padding(horizontal = 8.dp, vertical = 1.dp), fontSize = 10.sp, color = Color.White.copy(alpha = 0.6f))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
