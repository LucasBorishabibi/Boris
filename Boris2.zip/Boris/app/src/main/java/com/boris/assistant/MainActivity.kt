package com.boris.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

data class Msg(val kind: Int, val text: String) // 0 = du, 1 = Boris, 2 = Aktion, 3 = Fehler

private val Bg1 = Color(0xFF0B0B16)
private val Bg2 = Color(0xFF14102A)
private val Card = Color(0xFF1B1A2E)
private val Accent = Color(0xFF8B7CFF)
private val Accent2 = Color(0xFF5CC8FF)
private val Good = Color(0xFF4ADE80)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    private var tick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale.GERMAN }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg1, surface = Card)) {
                BorisScreen(this, tick) { tts?.speak(it, TextToSpeech.QUEUE_FLUSH, null, "boris") }
            }
        }
    }

    override fun onResume() { super.onResume(); tick++ }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

@Composable
private fun BorisScreen(activity: Activity, tick: Int, onSpeak: (String) -> Unit) {
    val prefs = remember { activity.getSharedPreferences("boris", 0) }
    var apiKey by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var keyInput by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<Msg>() }
    val history = remember { JSONArray() }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Bereit") }
    var autoOn by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    LaunchedEffect(tick) { autoOn = isAutoSendEnabled(activity) }
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    LaunchedEffect(Unit) {
        perms.launch(arrayOf(Manifest.permission.SEND_SMS, Manifest.permission.READ_CONTACTS))
    }

    fun ui(block: () -> Unit) { activity.runOnUiThread { block() } }

    fun send(text: String) {
        if (text.isBlank() || busy) return
        messages.add(Msg(0, text))
        history.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text))))
        input = ""; busy = true; status = "Denke nach …"
        agentApiKey = apiKey; statusSink = { s -> ui { status = s } }
        scope.launch {
            val reply = try {
                withContext(Dispatchers.IO) {
                    GeminiClient.chat(apiKey, history, { s -> ui { status = s } }) { n, a ->
                        ui { status = statusFor(n, a) }
                        val r = runTool(activity, n, a)
                        ui { messages.add(Msg(2, r)) }
                        r
                    }
                }
            } catch (e: Exception) { null to (e.message ?: "Unbekannter Fehler") }
            val (ok, textOut) = if (reply is String) true to reply else false to (reply as Pair<*, *>).second.toString()
            messages.add(Msg(if (ok) 1 else 3, textOut))
            busy = false; status = "Bereit"
            if (ok) onSpeak(textOut)
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == Activity.RESULT_OK && t != null) send(t)
    }
    fun listen() {
        try {
            speech.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE"))
        } catch (e: Exception) { messages.add(Msg(3, "Keine Spracherkennung verfügbar.")) }
    }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Bg2, Bg1)))) {
        Column(Modifier.fillMaxSize().systemBarsPadding().imePadding().padding(horizontal = 16.dp)) {
            // Kopf
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(38.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Accent, Accent2))),
                    contentAlignment = Alignment.Center) { Text("B", fontWeight = FontWeight.Bold, color = Color.White) }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Boris", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("dein Assistent", fontSize = 12.sp, color = Color.White.copy(alpha = 0.5f))
                }
                if (apiKey.isNotBlank()) {
                    Box(Modifier.clip(RoundedCornerShape(50)).background(Card)
                        .clickable { if (!autoOn) activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                        .padding(horizontal = 12.dp, vertical = 7.dp)) {
                        Text(if (autoOn) "🤖 Agent-Zugriff an" else "🤖 Agent-Zugriff aktivieren",
                            fontSize = 12.sp, color = if (autoOn) Good else Color.White.copy(alpha = 0.7f))
                    }
                }
            }

            if (apiKey.isBlank()) {
                Spacer(Modifier.height(32.dp))
                Column(Modifier.clip(RoundedCornerShape(20.dp)).background(Card).padding(18.dp)) {
                    Text("Kostenlosen Gemini-API-Key einfügen", fontWeight = FontWeight.SemiBold, color = Color.White)
                    Text("aistudio.google.com/apikey · bleibt nur auf deinem Handy", fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.6f))
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(keyInput, { keyInput = it }, Modifier.fillMaxWidth(), singleLine = true)
                    Spacer(Modifier.height(10.dp))
                    Button({ apiKey = keyInput.trim(); prefs.edit().putString("key", apiKey).apply() },
                        Modifier.fillMaxWidth()) { Text("Speichern") }
                }
                return@Column
            }

            // Live-Status
            Spacer(Modifier.height(12.dp))
            val pulse = rememberInfiniteTransition(label = "pulse")
            val a by pulse.animateFloat(0.25f, 1f, infiniteRepeatable(tween(650), RepeatMode.Reverse), label = "a")
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                .background(if (busy) Accent.copy(alpha = 0.18f) else Card)
                .padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).alpha(if (busy) a else 1f).clip(CircleShape)
                    .background(if (busy) Accent else Good))
                Spacer(Modifier.width(10.dp))
                Text(status, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            }

            // Verlauf
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (messages.isEmpty()) {
                    Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Was kann ich für dich tun?", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(14.dp))
                        listOf("Spiel meine Lieblingssongs", "Stell einen Timer auf 10 Minuten",
                            "Schreib Mama per SMS: bin gleich da").forEach { s ->
                            Box(Modifier.padding(vertical = 4.dp).clip(RoundedCornerShape(50)).background(Card)
                                .clickable { send(s) }.padding(horizontal = 16.dp, vertical = 10.dp)) {
                                Text(s, color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
                            }
                        }
                    }
                }
                LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(vertical = 12.dp)) {
                    items(messages) { m ->
                        when (m.kind) {
                            2 -> Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.Center) {
                                Box(Modifier.clip(RoundedCornerShape(50)).background(Good.copy(alpha = 0.15f))
                                    .padding(horizontal = 12.dp, vertical = 6.dp)) {
                                    Text("✓ ${m.text}", color = Good, fontSize = 12.sp)
                                }
                            }
                            else -> Row(Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                horizontalArrangement = if (m.kind == 0) Arrangement.End else Arrangement.Start) {
                                val bg = when (m.kind) {
                                    0 -> Modifier.background(Brush.linearGradient(listOf(Accent, Color(0xFF6A5AF9))))
                                    3 -> Modifier.background(Color(0xFF3A1D24))
                                    else -> Modifier.background(Card)
                                }
                                Box(Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(
                                    topStart = 20.dp, topEnd = 20.dp,
                                    bottomStart = if (m.kind == 0) 20.dp else 4.dp,
                                    bottomEnd = if (m.kind == 0) 4.dp else 20.dp)).then(bg).padding(14.dp)) {
                                    Text(m.text, color = Color.White, fontSize = 15.sp)
                                }
                            }
                        }
                    }
                }
            }

            // Eingabe
            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp).clip(RoundedCornerShape(30.dp)).background(Card)
                .padding(start = 6.dp, end = 6.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                TextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Frag Boris …") },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent))
                if (input.isBlank()) {
                    Box(Modifier.size(46.dp).clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Accent, Accent2)))
                        .clickable { listen() }, contentAlignment = Alignment.Center) { Text("🎤", fontSize = 20.sp) }
                } else {
                    Box(Modifier.size(46.dp).clip(CircleShape).background(Accent)
                        .clickable { send(input) }, contentAlignment = Alignment.Center) {
                        Text("➤", fontSize = 18.sp, color = Color.White)
                    }
                }
            }
        }
    }
}
