package com.boris.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Random
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.PI

private var Navy by mutableStateOf(Color(0xFF01060D))
private var Panel by mutableStateOf(Color(0xFF071A2B))
private var Cyan by mutableStateOf(Color(0xFF4DA3FF))
private var Gold by mutableStateOf(Color(0xFFBFE3FF))
private var Mint by mutableStateOf(Color(0xFF7FE9FF))
private val Red = Color(0xFFFF4A3A)

/** Thema: Blau (elektrisches Blau) oder Schwarz-Weiß. */
private fun applyTheme(bw: Boolean) {
    if (bw) {
        Navy = Color(0xFF000000); Panel = Color(0xFF111111); Cyan = Color(0xFFEDEDED); Gold = Color(0xFFB4B4B4); Mint = Color(0xFFFFFFFF)
    } else {
        Navy = Color(0xFF01060D); Panel = Color(0xFF071A2B); Cyan = Color(0xFF4DA3FF); Gold = Color(0xFFBFE3FF); Mint = Color(0xFF7FE9FF)
    }
}
private val Mono = FontFamily.Monospace

class MainActivity : ComponentActivity() {
    val jarvis: Jarvis by lazy { Hub.jarvis(this) }
    var tick by mutableIntStateOf(0)
    private var ownListener: WakeListener? = null
    private var awaitAfterStart = false

    private fun prefs() = getSharedPreferences("boris", 0)
    fun alwaysListen() = prefs().getBoolean("always_listen", false)
    private fun micOk() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED

    /** Mit Dauer-Zuhören übernimmt der Hintergrunddienst, sonst hört die App nur im Vordergrund zu. */
    fun startListening() {
        if (!micOk()) return
        if (alwaysListen()) {
            ownListener?.stop(); ownListener = null
            try { startForegroundService(Intent(this, ListenService::class.java)) } catch (e: Exception) { Dbg.d("Dienst: ${e.message}") }
        } else {
            if (ownListener == null) ownListener = WakeListener(this, { t -> Core.handle(this, t) }, { m -> Core.voiceMode = m })
            Core.listener = ownListener
            ownListener?.start()
        }
        if (awaitAfterStart) { awaitAfterStart = false; Core.listener?.awaitCommand() }
    }

    fun setAlwaysListen(on: Boolean) {
        prefs().edit().putBoolean("always_listen", on).apply()
        if (!on) stopService(Intent(this, ListenService::class.java))
        startListening()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Brain.load(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        handleIntent(intent)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Navy, surface = Panel)) {
                BorisScreen(this)
            }
        }
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); handleIntent(intent) }

    private fun handleIntent(i: Intent?) { if (i?.hasExtra("q") == true) { awaitAfterStart = true; i.removeExtra("q") } }

    override fun onResume() { super.onResume(); tick++; Core.activityVisible = true; startListening() }

    override fun onPause() {
        Core.activityVisible = false
        if (!alwaysListen()) { ownListener?.stop(); Core.voiceMode = 0 }
        super.onPause()
    }
}

// ---------------------------------------------------------------- Schwarm
/** Plasma-Kugel aus Schwarm-Punkten: Punkte sitzen auf einer Kugel, driften schwarmartig, und elektrische Fäden verbinden Nachbarn. */
private class Orb(val n: Int) {
    val ux = FloatArray(n); val uy = FloatArray(n); val uz = FloatArray(n)
    val ox = FloatArray(n); val oy = FloatArray(n); val oz = FloatArray(n)
    val ovx = FloatArray(n); val ovy = FloatArray(n); val ovz = FloatArray(n)
    val px = FloatArray(n); val py = FloatArray(n); val pz = FloatArray(n)
    val nb = Array(n) { IntArray(5) }

    init {
        val ga = PI.toFloat() * (3f - sqrt(5f))
        for (i in 0 until n) {
            val y = 1f - 2f * (i + 0.5f) / n
            val r = sqrt(1f - y * y)
            ux[i] = cos(ga * i) * r; uy[i] = y; uz[i] = sin(ga * i) * r
        }
        for (i in 0 until n) {
            val d = FloatArray(n) { j ->
                if (j == i) 99f else (ux[i] - ux[j]) * (ux[i] - ux[j]) + (uy[i] - uy[j]) * (uy[i] - uy[j]) + (uz[i] - uz[j]) * (uz[i] - uz[j])
            }
            for (k in 0 until 5) {
                var best = 0
                for (j in 1 until n) if (d[j] < d[best]) best = j
                nb[i][k] = best; d[best] = 99f
            }
        }
    }

    fun step(dt: Float, time: Float, e: Float, level: Float, cx: Float, cy: Float, radius: Float) {
        val rot = time * (0.25f + 0.5f * e)
        val tilt = 0.35f + 0.1f * sin(time * 0.4f)
        val cr = cos(rot); val sr = sin(rot); val ct = cos(tilt); val st = sin(tilt)
        val amp = 0.05f + 0.22f * e
        for (i in 0 until n) {
            val tx = sin(time * 1.3f + uy[i] * 5f + uz[i] * 3f) * amp
            val ty = sin(time * 1.1f + uz[i] * 5f + ux[i] * 3f) * amp
            val tz = sin(time * 1.7f + ux[i] * 5f + uy[i] * 3f) * amp
            ovx[i] += ((tx - ox[i]) * 6f - ovx[i] * 1.5f) * dt
            ovy[i] += ((ty - oy[i]) * 6f - ovy[i] * 1.5f) * dt
            ovz[i] += ((tz - oz[i]) * 6f - ovz[i] * 1.5f) * dt
            ox[i] += ovx[i] * dt; oy[i] += ovy[i] * dt; oz[i] += ovz[i] * dt
            val pulse = 1f + level * 0.3f * sin(time * 13f + uy[i] * 6f)
            val x = (ux[i] + ox[i]) * pulse; val y = (uy[i] + oy[i]) * pulse; val z = (uz[i] + oz[i]) * pulse
            val x1 = x * cr + z * sr; val z1 = -x * sr + z * cr
            val y2 = y * ct - z1 * st; val z2 = y * st + z1 * ct
            val persp = 1f / (1f - z2 * 0.22f)
            px[i] = cx + x1 * radius * persp; py[i] = cy + y2 * radius * persp; pz[i] = z2
        }
    }
}

private class SwarmHolder {
    val orb = Orb(220)
    var w = 0f; var h = 0f; var time = 0f; var energy = 0.2f
    var touch = Offset.Zero; var touching = false
}

@Composable
private fun HudButton(glyph: String, label: String, color: Color = Cyan, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(58.dp).border(1.5.dp, color.copy(alpha = 0.8f), CutCornerShape(topEnd = 14.dp, bottomStart = 14.dp))
            .background(Panel.copy(alpha = 0.7f), CutCornerShape(topEnd = 14.dp, bottomStart = 14.dp))
            .clickable(onClick = onClick), contentAlignment = Alignment.Center) { Text(glyph, fontSize = 22.sp) }
        Spacer(Modifier.height(3.dp))
        Text(label, fontFamily = Mono, fontSize = 9.sp, letterSpacing = 2.sp, color = color.copy(alpha = 0.7f))
    }
}

@Composable
private fun Tab(label: String, sel: Boolean, onClick: () -> Unit) {
    Text(label, Modifier.clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 8.dp),
        fontFamily = Mono, fontSize = 12.sp, letterSpacing = 2.sp,
        fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal, color = if (sel) Cyan else Cyan.copy(alpha = 0.4f))
}

@Composable
private fun BorisScreen(activity: MainActivity) {
    val prefs = remember { activity.getSharedPreferences("boris", 0) }
    var apiKey by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var keyInput by remember { mutableStateOf("") }
    var input by remember { mutableStateOf("") }
    var chatOpen by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var brainTick by remember { mutableIntStateOf(0) }
    var brainInput by remember { mutableStateOf("") }
    var proactive by remember { mutableStateOf(prefs.getBoolean("proactive", true)) }
    var hq by remember { mutableStateOf(prefs.getBoolean("hq_voice", true)) }
    var notifAi by remember { mutableStateOf(prefs.getBoolean("notif_ai", true)) }
    var safety by remember { mutableStateOf(prefs.getBoolean("safety", true)) }
    var always by remember { mutableStateOf(activity.alwaysListen()) }
    var voiceName by remember { mutableStateOf(activity.jarvis.voiceName()) }
    var bw by remember { mutableStateOf(prefs.getInt("theme", 0) == 1) }
    remember { applyTheme(bw); 0 }
    var elKeyInput by remember { mutableStateOf("") }
    var elVoiceInput by remember { mutableStateOf("") }
    var elSet by remember { mutableStateOf(!prefs.getString("el_key", "").isNullOrBlank()) }
    var agentOn by remember { mutableStateOf(false) }
    var notifOn by remember { mutableStateOf(false) }
    var testing by remember { mutableStateOf(false) }
    val testResults = remember { mutableStateListOf<Pair<Boolean, String>>() }
    var crash by remember { mutableStateOf(prefs.getString("crash", null)) }
    val listState = rememberLazyListState()
    val jarvis = activity.jarvis
    val dens = LocalDensity.current.density
    val messages = Core.messages

    LaunchedEffect(activity.tick) { agentOn = isAutoSendEnabled(activity); notifOn = isNotifAccessEnabled(activity) }
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (it[Manifest.permission.RECORD_AUDIO] == true) activity.startListening()
    }
    LaunchedEffect(Unit) {
        perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.SEND_SMS, Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE, Manifest.permission.READ_CALENDAR, Manifest.permission.POST_NOTIFICATIONS))
    }
    LaunchedEffect(messages.size) { if (messages.isNotEmpty() && chatOpen && tab == 0) listState.animateScrollToItem(messages.size - 1) }

    // ---- Schwarm-Simulation
    val hold = remember { SwarmHolder() }
    var frame by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                val dt = if (last == 0L) 0.016f else ((now - last) / 1_000_000_000f).coerceAtMost(0.05f)
                last = now
                val speaking = jarvis.speaking
                val lvl = jarvis.level
                val tgt = when {
                    speaking -> 0.7f + lvl * 0.6f
                    Core.busy -> 0.85f
                    Core.voiceMode == 2 -> 0.6f
                    else -> 0.2f
                }
                hold.energy += (tgt - hold.energy) * min(1f, dt * 5f)
                hold.time += dt
                if (hold.w > 0f) {
                    val shift = if (hold.touching) (hold.touch.x - hold.w / 2) * 0.08f else 0f
                    val rad = min(hold.w, hold.h) * 0.30f * (1f + 0.03f * sin(hold.time * 2.2f) + (if (speaking) lvl * 0.12f else 0f) + hold.energy * 0.05f)
                    hold.orb.step(dt, hold.time, hold.energy, if (speaking) lvl else 0f, hold.w / 2 + shift, hold.h * 0.40f, rad)
                }
                frame = now
            }
        }
    }
    val tint by animateColorAsState(
        when {
            jarvis.speaking -> Color(0xFFCFF9FF)
            Core.busy -> Gold
            Core.voiceMode == 2 -> Mint
            else -> Cyan
        }, tween(500), label = "tint")

    val shape = CutCornerShape(topEnd = 14.dp, bottomStart = 14.dp)
    val blinkT = rememberInfiniteTransition(label = "blink")
    val blink by blinkT.animateFloat(0.3f, 1f, infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "b")

    @Composable fun field(value: String, hint: String, onChange: (String) -> Unit, modifier: Modifier) {
        Box(modifier.border(1.dp, Cyan.copy(alpha = 0.5f), shape).background(Panel.copy(alpha = 0.8f), shape)) {
            TextField(value, onChange, Modifier.fillMaxWidth(),
                placeholder = { Text(hint, fontFamily = Mono, fontSize = 13.sp, color = Cyan.copy(alpha = 0.4f)) },
                textStyle = TextStyle(fontFamily = Mono, fontSize = 14.sp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Cyan))
        }
    }

    Box(Modifier.fillMaxSize().background(Navy)
        .onSizeChanged { hold.w = it.width.toFloat(); hold.h = it.height.toFloat() }
        .pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { hold.touch = it; hold.touching = true },
                onDrag = { c, _ -> hold.touch = c.position },
                onDragEnd = { hold.touching = false }, onDragCancel = { hold.touching = false })
        }) {

        // Riesiger Schriftzug im Hintergrund wie im Vorbild
        Text("B.O.R.I.S.", Modifier.align(Alignment.Center).offset(y = 150.dp), fontSize = 92.sp, fontWeight = FontWeight.Black,
            letterSpacing = 4.sp, color = Cyan.copy(alpha = 0.06f), maxLines = 1)

        Canvas(Modifier.fillMaxSize()) {
            val tk = frame
            if (tk < 0) return@Canvas
            val orb = hold.orb
            val t = hold.time
            val cxo = orb.px.average().toFloat(); val cyo = orb.py.average().toFloat()
            val rr = min(hold.w, hold.h) * 0.30f
            drawCircle(Brush.radialGradient(listOf(tint.copy(alpha = 0.32f * (0.6f + 0.4f * hold.energy)), Color.Transparent),
                center = Offset(cxo, cyo), radius = rr * 1.8f), radius = rr * 1.8f, center = Offset(cxo, cyo))
            val back = Path(); val front = Path()
            for (i in 0 until orb.n) for (k in 0 until 5) {
                val j = orb.nb[i][k]
                if (j < i && orb.nb[j].contains(i)) continue
                val x1 = orb.px[i]; val y1 = orb.py[i]; val x2 = orb.px[j]; val y2 = orb.py[j]
                val dx = x2 - x1; val dy = y2 - y1
                val len = sqrt(dx * dx + dy * dy) + 0.001f
                val nx = -dy / len; val ny = dx / len
                val a = len * (0.10f + 0.25f * hold.energy)
                val s1 = sin(t * 9f + i * 1.7f + k * 2.3f) * a
                val s2 = sin(t * 11f + i * 2.9f + k * 1.1f) * a
                val p = if ((orb.pz[i] + orb.pz[j]) * 0.5f > -0.05f) front else back
                p.moveTo(x1, y1)
                p.lineTo(x1 + dx * 0.33f + nx * s1, y1 + dy * 0.33f + ny * s1)
                p.lineTo(x1 + dx * 0.66f + nx * s2, y1 + dy * 0.66f + ny * s2)
                p.lineTo(x2, y2)
            }
            drawPath(back, tint.copy(alpha = 0.20f), style = Stroke(1.2f * dens))
            drawPath(front, tint.copy(alpha = 0.30f), style = Stroke(4.5f * dens))
            drawPath(front, lerp(tint, Color.White, 0.6f).copy(alpha = 0.95f), style = Stroke(1.3f * dens))
            for (i in 0 until orb.n) {
                val depth = ((orb.pz[i] + 1f) * 0.5f).coerceIn(0f, 1f)
                drawCircle(lerp(tint, Color.White, 0.7f).copy(alpha = 0.25f + 0.7f * depth), (0.9f + 1.4f * depth) * dens, Offset(orb.px[i], orb.py[i]))
            }
        }

        // Kopfzeile wie im Vorbild, solange noch nichts besprochen wurde
        if (messages.isEmpty() && !Core.busy && apiKey.isNotBlank()) {
            Column(Modifier.align(Alignment.TopCenter).systemBarsPadding().padding(top = 70.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Hol dir Hilfe von deinem", fontSize = 24.sp, fontWeight = FontWeight.Light, color = Color.White.copy(alpha = 0.92f))
                Text("persönlichen KI-Assistenten", fontSize = 24.sp, fontWeight = FontWeight.Light, color = Color.White.copy(alpha = 0.40f))
            }
        }

        if (apiKey.isBlank()) {
            Column(Modifier.align(Alignment.Center).padding(24.dp).background(Panel.copy(alpha = 0.9f), shape)
                .border(1.dp, Cyan.copy(alpha = 0.6f), shape).padding(18.dp)) {
                Text("ZUGANG EINRICHTEN", fontFamily = Mono, fontWeight = FontWeight.Bold, color = Cyan, letterSpacing = 2.sp)
                Spacer(Modifier.height(6.dp))
                Text("Kostenlosen Gemini-API-Key einfügen (aistudio.google.com/apikey). Bleibt nur auf deinem Handy.",
                    fontSize = 12.sp, fontFamily = Mono, color = Color.White.copy(alpha = 0.7f))
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(keyInput, { keyInput = it }, Modifier.fillMaxWidth(), singleLine = true)
                Spacer(Modifier.height(10.dp))
                Button({ apiKey = keyInput.trim(); prefs.edit().putString("key", apiKey).apply() },
                    Modifier.fillMaxWidth(), shape = CutCornerShape(8.dp)) { Text("AKTIVIEREN", fontFamily = Mono) }
            }
        } else {
            Column(Modifier.align(Alignment.TopStart).systemBarsPadding().padding(16.dp)) {
                Text("B.O.R.I.S.", fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 22.sp, letterSpacing = 5.sp, color = Cyan)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(6.dp).clip(CircleShape).background(tint.copy(alpha = blink)))
                    Spacer(Modifier.width(6.dp))
                    Text("▸ ${Core.status}", fontFamily = Mono, fontSize = 11.sp, letterSpacing = 1.sp, color = tint.copy(alpha = 0.9f),
                        maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 230.dp))
                }
            }
            if (!agentOn) {
                Box(Modifier.align(Alignment.TopEnd).systemBarsPadding().padding(16.dp)
                    .border(1.dp, Gold.copy(alpha = 0.7f), CutCornerShape(topEnd = 8.dp, bottomStart = 8.dp))
                    .clickable { activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                    .padding(horizontal = 10.dp, vertical = 6.dp)) {
                    Text("AGENT AUS · TIPPEN", fontFamily = Mono, fontSize = 10.sp, color = Gold)
                }
            }

            val lastBoris = messages.lastOrNull { it.kind == 1 || it.kind == 3 }
            val caption = if (Core.voiceMode == 2) "ICH HÖRE …" else lastBoris?.text ?: "Sag „Boris“ …"
            Text(caption, Modifier.align(Alignment.BottomCenter).systemBarsPadding().padding(start = 24.dp, end = 24.dp, bottom = 120.dp),
                fontFamily = Mono, fontSize = 14.sp, color = Color.White.copy(alpha = 0.9f), maxLines = 4, overflow = TextOverflow.Ellipsis)

            Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().systemBarsPadding().padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                HudButton("💬", "CHAT") { chatOpen = true }
                Text(if (Core.voiceMode == 0) "MIKRO AUS" else if (always) "HÖRT IMMER ZU" else "HÖRT ZU · SAG „BORIS“",
                    fontFamily = Mono, fontSize = 9.sp, letterSpacing = 2.sp, color = Cyan.copy(alpha = 0.5f + 0.3f * blink),
                    modifier = Modifier.padding(bottom = 22.dp))
                HudButton("🎤", "SPRECHEN", Gold) { Core.listener?.awaitCommand() }
            }

            AnimatedVisibility(chatOpen, enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()) {
                Column(Modifier.fillMaxSize().background(Navy.copy(alpha = 0.94f)).systemBarsPadding().imePadding().padding(horizontal = 14.dp)) {
                    Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Tab("CHAT", tab == 0) { tab = 0 }
                        Tab("GEHIRN", tab == 1) { tab = 1 }
                        Tab("SYSTEM", tab == 2) { tab = 2 }
                        Spacer(Modifier.weight(1f))
                        Text("✕", Modifier.clickable { chatOpen = false }.padding(12.dp), color = Cyan, fontSize = 18.sp)
                    }
                    when (tab) {
                        0 -> {
                            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, contentPadding = PaddingValues(vertical = 10.dp)) {
                                itemsIndexed(messages) { _, m ->
                                    if (m.kind == 2) {
                                        Text("▸ ${m.text.uppercase()}", Modifier.padding(vertical = 4.dp, horizontal = 4.dp),
                                            color = Mint, fontFamily = Mono, fontSize = 11.sp, letterSpacing = 1.sp)
                                    } else {
                                        val col = when (m.kind) { 0 -> Gold; 3 -> Red; else -> Cyan }
                                        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp),
                                            horizontalArrangement = if (m.kind == 0) Arrangement.End else Arrangement.Start) {
                                            Column(Modifier.widthIn(max = 310.dp).background(Panel.copy(alpha = 0.9f), shape)
                                                .border(1.dp, col.copy(alpha = 0.6f), shape).padding(12.dp)) {
                                                Text(when (m.kind) { 0 -> "DU"; 3 -> "FEHLER"; else -> "BORIS" }, fontFamily = Mono,
                                                    fontSize = 9.sp, letterSpacing = 3.sp, color = col.copy(alpha = 0.8f))
                                                Spacer(Modifier.height(3.dp))
                                                Text(m.text, color = Color.White, fontSize = 14.sp, fontFamily = Mono)
                                            }
                                        }
                                    }
                                }
                            }
                            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                field(input, "Befehl eingeben …", { input = it }, Modifier.weight(1f))
                                Spacer(Modifier.width(8.dp))
                                Box(Modifier.size(52.dp).border(1.5.dp, Cyan, shape).clickable { Core.handle(activity, input); input = "" },
                                    contentAlignment = Alignment.Center) { Text("➤", color = Cyan, fontSize = 20.sp) }
                            }
                        }
                        1 -> {
                            val facts = remember(brainTick, tab) { Brain.all() }
                            Text("DAUERHAFTES GEDÄCHTNIS · ${facts.size} EINTRÄGE", fontFamily = Mono, fontSize = 10.sp, letterSpacing = 2.sp,
                                color = Cyan.copy(alpha = 0.6f), modifier = Modifier.padding(vertical = 8.dp))
                            LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                                itemsIndexed(facts) { i, f ->
                                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text("[${f.first}]", fontFamily = Mono, fontSize = 10.sp, color = Gold, modifier = Modifier.width(70.dp))
                                        Text(f.second, Modifier.weight(1f), fontFamily = Mono, fontSize = 13.sp, color = Color.White)
                                        Text("✕", Modifier.clickable { Brain.removeAt(i); brainTick++ }.padding(10.dp), color = Red)
                                    }
                                }
                            }
                            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                field(brainInput, "Boris etwas beibringen …", { brainInput = it }, Modifier.weight(1f))
                                Spacer(Modifier.width(8.dp))
                                Box(Modifier.size(52.dp).border(1.5.dp, Gold, shape)
                                    .clickable { Brain.add(brainInput, "manuell"); brainInput = ""; brainTick++ }, contentAlignment = Alignment.Center) {
                                    Text("＋", color = Gold, fontSize = 22.sp)
                                }
                            }
                        }
                        else -> {
                            @Composable fun Row2(title: String, value: String, ok: Boolean, onClick: () -> Unit) {
                                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).border(1.dp, (if (ok) Cyan else Gold).copy(alpha = 0.5f), shape)
                                    .clickable(onClick = onClick).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(title, Modifier.weight(1f), fontFamily = Mono, fontSize = 12.sp, color = Color.White, letterSpacing = 1.sp)
                                    Text(value, fontFamily = Mono, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (ok) Cyan else Gold)
                                }
                            }
                            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(top = 8.dp)) {
                                Row2("STIMME", voiceName.uppercase() + " ▸", true) {
                                    voiceName = jarvis.cycleVoice(); Core.say(activity, "Systeme online. Wie kann ich helfen?", false)
                                }
                                Row2("THEMA", if (bw) "SCHWARZ-WEISS ▸" else "BLAU ▸", true) {
                                    bw = !bw; prefs.edit().putInt("theme", if (bw) 1 else 0).apply(); applyTheme(bw)
                                }
                                Text("ELEVENLABS (JARVIS-STIMME) · elevenlabs.io → API Keys. Der Gratis-Tarif hat nur wenige Zeichen pro Monat; danach spricht Boris mit der Ausweichstimme.",
                                    Modifier.padding(horizontal = 6.dp, vertical = 4.dp), fontFamily = Mono, fontSize = 9.sp, color = Cyan.copy(alpha = 0.6f))
                                field(elKeyInput, "ElevenLabs-Key einfügen …", { elKeyInput = it }, Modifier.fillMaxWidth())
                                Row2("ELEVENLABS-KEY", if (elSet) "GESETZT · SPEICHERN ▸" else "SPEICHERN ▸", elSet) {
                                    val k = elKeyInput.trim()
                                    prefs.edit().putString("el_key", k).apply()
                                    elSet = k.isNotBlank(); elKeyInput = ""
                                    voiceName = jarvis.voiceName()
                                    if (elSet) Core.say(activity, "ElevenLabs verbunden. Systeme online.", false)
                                }
                                field(elVoiceInput, "Eigene Voice-ID (optional) …", { elVoiceInput = it }, Modifier.fillMaxWidth())
                                Row2("EIGENE VOICE-ID", "SPEICHERN ▸", true) {
                                    val v = elVoiceInput.trim()
                                    if (v.isNotBlank()) { prefs.edit().putString("el_voice", v).apply(); elVoiceInput = ""; voiceName = jarvis.voiceName() }
                                }
                                Row2("IMMER ZUHÖREN (AUCH GESPERRT)", if (always) "AN" else "AUS", always) { always = !always; activity.setAlwaysListen(always) }
                                Row2("GEMINI-STIMME (AUSWEICH)", if (hq) "AN" else "AUS", hq) { hq = !hq; prefs.edit().putBoolean("hq_voice", hq).apply() }
                                Row2("PROAKTIVE RÜCKFRAGEN", if (proactive) "AN" else "AUS", proactive) { proactive = !proactive; prefs.edit().putBoolean("proactive", proactive).apply() }
                                Row2("BENACHRICHTIGUNGEN VORLESEN", if (notifAi) "AN" else "AUS", notifAi) { notifAi = !notifAi; prefs.edit().putBoolean("notif_ai", notifAi).apply() }
                                Row2("SICHERHEITSABFRAGEN", if (safety) "AN" else "AUS", safety) { safety = !safety; prefs.edit().putBoolean("safety", safety).apply() }
                                Row2("BENACHRICHTIGUNGSZUGRIFF", if (notifOn) "AKTIV" else "AUS · TIPPEN", notifOn) {
                                    activity.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                                }
                                Row2("AGENT-ZUGRIFF", if (agentOn) "AKTIV" else "AUS · TIPPEN", agentOn) {
                                    activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                                }
                                Row2("SELBSTTEST", if (testing) "LÄUFT …" else "STARTEN ▸", !testing) {
                                    if (!testing) {
                                        testing = true; testResults.clear()
                                        Thread {
                                            val r = try { SelfTest.run(activity) } catch (e: Exception) { listOf(false to "Test-Fehler: ${e.message}") }
                                            activity.runOnUiThread { testResults.addAll(r); testing = false }
                                        }.start()
                                    }
                                }
                                testResults.forEach {
                                    Text((if (it.first) "✓ " else "✗ ") + it.second, Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        fontFamily = Mono, fontSize = 11.sp, color = if (it.first) Mint else Red)
                                }
                                if (crash != null) {
                                    Spacer(Modifier.height(8.dp))
                                    Row2("LETZTER ABSTURZ", "LÖSCHEN ✕", false) { prefs.edit().remove("crash").apply(); crash = null }
                                    Text(crash!!.take(700), Modifier.padding(6.dp), fontFamily = Mono, fontSize = 9.sp, color = Red)
                                }
                                Spacer(Modifier.height(8.dp))
                                Text("PROTOKOLL", Modifier.padding(horizontal = 6.dp), fontFamily = Mono, fontSize = 10.sp, letterSpacing = 2.sp, color = Cyan.copy(alpha = 0.6f))
                                Dbg.lines.takeLast(25).forEach {
                                    Text(it, Modifier.padding(horizontal = 6.dp, vertical = 1.dp), fontFamily = Mono, fontSize = 9.sp, color = Color.White.copy(alpha = 0.7f))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
