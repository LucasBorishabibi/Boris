package com.boris.assistant

import android.app.Activity
import android.app.SearchManager
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.KeyEvent
import android.os.Bundle
import android.provider.AlarmClock
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale.GERMAN }
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    BorisScreen(this, onSpeak = { tts?.speak(it, TextToSpeech.QUEUE_FLUSH, null, "boris") })
                }
            }
        }
    }

    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

private val PKG = mapOf(
    "spotify" to "com.spotify.music", "discord" to "com.discord", "whatsapp" to "com.whatsapp",
    "telegram" to "org.telegram.messenger", "instagram" to "com.instagram.android",
    "signal" to "org.thoughtcrime.securesms", "youtube" to "com.google.android.youtube",
    "maps" to "com.google.android.apps.maps", "chrome" to "com.android.chrome",
    "kamera" to "com.sec.android.app.camera", "einstellungen" to "com.android.settings"
)

private fun pressPlay(a: Activity, delayMs: Long) {
    Handler(Looper.getMainLooper()).postDelayed({
        val am = a.getSystemService(Activity.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY))
    }, delayMs)
}

private fun runTool(a: Activity, name: String, args: JSONObject): String = try {
    when (name) {
        "set_timer" -> {
            a.startActivity(Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, args.getInt("seconds"))
                .putExtra(AlarmClock.EXTRA_MESSAGE, args.optString("label", "Boris"))
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            "Timer gestellt."
        }
        "set_alarm" -> {
            a.startActivity(Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, args.getInt("hour"))
                .putExtra(AlarmClock.EXTRA_MINUTES, args.getInt("minute"))
                .putExtra(AlarmClock.EXTRA_MESSAGE, args.optString("label", "Boris"))
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            "Wecker gestellt."
        }
        "spotify_play" -> {
            val q = args.getString("query")
            a.startActivity(Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                .setPackage("com.spotify.music")
                .putExtra(SearchManager.QUERY, q)
                .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*"))
            "Spotify wird gestartet mit: $q. Falls nichts spielt, ist der Titel evtl. nicht abspielbar (z.B. Gratis-Konto)."
        }
        "spotify_liked" -> {
            a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("spotify:collection:tracks"))
                .setPackage("com.spotify.music"))
            pressPlay(a, 2500)
            "Lieblingssongs in Spotify geöffnet, Wiedergabe wird gestartet."
        }
        "open_app" -> {
            val pkg = PKG[args.getString("app").lowercase()]
            val i = pkg?.let { a.packageManager.getLaunchIntentForPackage(it) }
            if (i == null) "App nicht gefunden oder nicht installiert." else { a.startActivity(i); "App geöffnet." }
        }
        "send_message" -> {
            val app = args.getString("app").lowercase()
            val text = args.getString("text")
            if (app.contains("sms")) {
                val nr = args.optString("phone", "")
                a.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$nr")).putExtra("sms_body", text))
                "SMS vorbereitet. Der Nutzer muss auf Senden tippen."
            } else {
                val pkg = PKG[app]
                if (pkg == null || a.packageManager.getLaunchIntentForPackage(pkg) == null) "App nicht gefunden."
                else {
                    a.startActivity(Intent(Intent.ACTION_SEND).setType("text/plain")
                        .putExtra(Intent.EXTRA_TEXT, text).setPackage(pkg))
                    "Nachricht vorbereitet. Der Nutzer wählt den Empfänger und tippt selbst auf Senden."
                }
            }
        }
        else -> "Unbekanntes Tool."
    }
} catch (e: Exception) { "Fehler: ${e.message}" }

@Composable
private fun BorisScreen(activity: Activity, onSpeak: (String) -> Unit) {
    val prefs = remember { activity.getSharedPreferences("boris", 0) }
    var apiKey by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var keyInput by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<Pair<Boolean, String>>() }
    val history = remember { JSONArray() }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    fun send(text: String) {
        if (text.isBlank() || busy) return
        messages.add(true to text)
        history.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text))))
        input = ""; busy = true
        scope.launch {
            val reply = try {
                withContext(Dispatchers.IO) {
                    GeminiClient.chat(apiKey, history) { n, a -> runTool(activity, n, a) }
                }
            } catch (e: Exception) { "Fehler: ${e.message}" }
            messages.add(false to reply)
            busy = false
            onSpeak(reply)
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == Activity.RESULT_OK && t != null) send(t)
    }

    Column(Modifier.fillMaxSize().systemBarsPadding().imePadding().padding(12.dp)) {
        Text("Boris", style = MaterialTheme.typography.headlineSmall)
        if (apiKey.isBlank()) {
            Spacer(Modifier.height(12.dp))
            Text("Kostenlosen Gemini-API-Key einfügen (aistudio.google.com/apikey). Er wird nur auf dem Handy gespeichert:")
            OutlinedTextField(keyInput, { keyInput = it }, Modifier.fillMaxWidth(), singleLine = true)
            Button({ apiKey = keyInput.trim(); prefs.edit().putString("key", apiKey).apply() }) { Text("Speichern") }
            return@Column
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState) {
            items(messages) { (mine, text) ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                    Surface(
                        color = if (mine) MaterialTheme.colorScheme.primaryContainer
                                else MaterialTheme.colorScheme.surfaceVariant,
                        shape = MaterialTheme.shapes.medium
                    ) { Text(text, Modifier.padding(10.dp)) }
                }
            }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Frag Boris …") })
            TextButton({
                try {
                    speech.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE"))
                } catch (e: Exception) { messages.add(false to "Keine Spracherkennung verfügbar.") }
            }) { Text("🎤") }
            TextButton({ send(input) }) { Text("➤") }
        }
    }
}
