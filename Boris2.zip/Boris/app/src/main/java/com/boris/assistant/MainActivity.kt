package com.boris.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Random
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

private val Navy = Color(0xFF01060D)
private val Panel = Color(0xFF071A2B)
private val Cyan = Color(0xFF00E5FF)
private val Gold = Color(0xFFFFB400)
private val Red = Color(0xFFFF4A3A)
private val Mint = Color(0xFF4DFFB0)
private val Mono = FontFamily.Monospace

class MainActivity : ComponentActivity() {
    val jarvis: Jarvis by lazy { Hub.jarvis(this) }
    var tick by mutableIntStateOf(0)
    private var ownListener: WakeListener? = null
    private var awaitAfterStart = false

    private fun prefs() = getSharedPreferences("boris", 0)
    fun alwaysListen() = prefs().getBoolean("always_listen", false)
    private fun micOk() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED

    /** Mit Dauer-Zuhören übernimmt der Hintergrunddienst, sonst hört die App nur im Vordergrund zu. */
    fun startListening() {
        if (!micOk()) return
        if (alwaysListen()) {
            ownListener?.stop(); ownListener = null
            try { startForegroundService(Intent(this, ListenService::class.java)) } catch (e: Exception) { Dbg.d("Dienst: ${e.message}") }
        } else {
            if (ownListener == null) ownListener = WakeListener(this, { t -> Core.handle(this, t) }, { m -> Core.voiceMode = m })
            Core.listener = ownListener
            ownListener?.start()
        }
        if (awaitAfterStart) { awaitAfterStart = false; Core.listener?.awaitCommand() }
    }

    fun setAlwaysListen(on: Boolean) {
        prefs().edit().putBoolean("always_listen", on).apply()
        if (!on) stopService(Intent(this, ListenService::class.java))
        startListening()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Brain.load(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        handleIntent(intent)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Navy, surface = Panel)) {
                BorisScreen(this)
            }
        }
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); handleIntent(intent) }

    private fun handleIntent(i: Intent?) { if (i?.hasExtra("q") == true) { awaitAfterStart = true; i.removeExtra("q") } }

    override fun onResume() { super.onResume(); tick++; Core.activityVisible = true; startListening() }

    override fun onPause() {
        Core.activityVisible = false
        if (!alwaysListen()) { ownListener?.stop(); Core.voiceMode = 0 }
        super.onPause()
    }
}

// ---------------------------------------------------------------- Schwarm
private class Swarm(val n: Int) {
    val x = FloatArray(n); val y = FloatArray(n); val vx = FloatArray(n); val vy = FloatArray(n)
    var inited = false
    private val rnd = Random(7)

    fun init(w: Float, h: Float) {
        for (i in 0 until n) {
            x[i] = w / 2 + (rnd.nextFloat() - 0.5f) * w * 0.5f
            y[i] = h * 0.42f + (rnd.nextFloat() - 0.5f) * h * 0.3f
            vx[i] = (rnd.nextFloat() - 0.5f) * 80f; vy[i] = (rnd.nextFloat() - 0.5f) * 80f
        }
        inited = true
    }

    fun step(dt: Float, w: Float, h: Float, e: Float, level: Float, time: Float, tx: Float, ty: Float, dens: Float) {
        val r2 = (64f * dens) * (64f * dens)
        val sep2 = (20f * dens) * (20f * dens)
        val maxSp = (70f + 300f * e) * dens
        val orbit = 0.10f + 0.10f * e
        val cx = tx + cos(time * 0.5f) * w * orbit
        val cy = ty + sin(time * 0.37f) * h * orbit * 0.6f
        val breathe = sin(time * 11f) * level * 900f * dens
        for (i in 0 until n) {
            var cnt = 0; var avx = 0f; var avy = 0f; var mx = 0f; var my = 0f; var sx = 0f; var sy = 0f
            for (j in 0 until n) {
                if (j == i) continue
                val dx = x[j] - x[i]; val dy = y[j] - y[i]; val d2 = dx * dx + dy * dy
                if (d2 < r2) {
                    cnt++; avx += vx[j]; avy += vy[j]; mx += dx; my += dy
                    if (d2 < sep2 && d2 > 1f) { sx -= dx / d2; sy -= dy / d2 }
                }
            }
            var ax = sx * 9000f * dens; var ay = sy * 9000f * dens
            if (cnt > 0) {
                ax += (avx / cnt - vx[i]) * 2.0f + (mx / cnt) * 1.2f
                ay += (avy / cnt - vy[i]) * 2.0f + (my / cnt) * 1.2f
            }
            val rx = x[i] - cx; val ry = y[i] - cy
            ax += -rx * 1.1f - ry * 0.9f * e; ay += -ry * 1.1f + rx * 0.9f * e
            val rl = sqrt(rx * rx + ry * ry) + 1f
            ax += rx / rl * breathe; ay += ry / rl * breathe
            ax += (rnd.nextFloat() - 0.5f) * 400f * e * dens; ay += (rnd.nextFloat() - 0.5f) * 400f * e * dens
            vx[i] += ax * dt; vy[i] += ay * dt
            val sp = sqrt(vx[i] * vx[i] + vy[i] * vy[i])
            if (sp > maxSp) { vx[i] *= maxSp / sp; vy[i] *= maxSp / sp }
            vx[i] *= (1f - 0.6f * dt); vy[i] *= (1f - 0.6f * dt)
            x[i] += vx[i] * dt; y[i] += vy[i] * dt
            if (x[i] < 0f) { x[i] = 0f; vx[i] = -vx[i] }; if (x[i] > w) { x[i] = w; vx[i] = -vx[i] }
            if (y[i] < 0f) { y[i] = 0f; vy[i] = -vy[i] }; if (y[i] > h) { y[i] = h; vy[i] = -vy[i] }
        }
    }
}

private class SwarmHolder {
    val sw = Swarm(170)
    var w = 0f; var h = 0f; var time = 0f; var energy = 0.2f
    var touch = Offset.Zero; var touching = false
}

@Composable
private fun HudButton(glyph: String, label: String, color: Color = Cyan, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(58.dp).border(1.5.dp, color.copy(alpha = 0.8f), CutCornerShape(topEnd = 14.dp, bottomStart = 14.dp))
            .background(Panel.copy(alpha = 0.7f), CutCornerShape(topEnd = 14.dp, bottomStart = 14.dp))
            .clickable(onClick = onClick), contentAlignment = Alignment.Center) { Text(glyph, fontSize = 22.sp) }
        Spacer(Modifier.height(3.dp))
        Text(label, fontFamily = Mono, fontSize = 9.sp, letterSpacing = 2.sp, color = color.copy(alpha = 0.7f))
    }
}

@Composable
private fun Tab(label: String, sel: Boolean, onClick: () -> Unit) {
    Text(label, Modifier.clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 8.dp),
        fontFamily = Mono, fontSize = 12.sp, letterSpacing = 2.sp,
        fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal, color = if (sel) Cyan else Cyan.copy(alpha = 0.4f))
}

@Composable
private fun BorisScreen(activity: MainActivity) {
    val prefs = remember { activity.getSharedPreferences("boris", 0) }
    var apiKey by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var keyInput by remember { mutableStateOf("") }
    var input by remember { mutableStateOf("") }
    var chatOpen by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var brainTick by remember { mutableIntStateOf(0) }
    var brainInput by remember { mutableStateOf("") }
    var proactive by remember { mutableStateOf(prefs.getBoolean("proactive", true)) }
    var hq by remember { mutableStateOf(prefs.getBoolean("hq_voice", true)) }
    var notifAi by remember { mutableStateOf(prefs.getBoolean("notif_ai", true)) }
    var safety by remember { mutableStateOf(prefs.getBoolean("safety", true)) }
    var always by remember { mutableStateOf(activity.alwaysListen()) }
    var voiceName by remember { mutableStateOf(activity.jarvis.voiceName()) }
    var agentOn by remember { mutableStateOf(false) }
    var notifOn by remember { mutableStateOf(false) }
    var testing by remember { mutableStateOf(false) }
    val testResults = remember { mutableStateListOf<Pair<Boolean, String>>() }
    var crash by remember { mutableStateOf(prefs.getString("crash", null)) }
    val listState = rememberLazyListState()
    val jarvis = activity.jarvis
    val dens = LocalDensity.current.density
    val messages = Core.messages

    LaunchedEffect(activity.tick) { agentOn = isAutoSendEnabled(activity); notifOn = isNotifAccessEnabled(activity) }
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (it[Manifest.permission.RECORD_AUDIO] == true) activity.startListening()
    }
    LaunchedEffect(Unit) {
        perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.SEND_SMS, Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE, Manifest.permission.READ_CALENDAR, Manifest.permission.POST_NOTIFICATIONS))
    }
    LaunchedEffect(messages.size) { if (messages.isNotEmpty() && chatOpen && tab == 0) listState.animateScrollToItem(messages.size - 1) }

    // ---- Schwarm-Simulation
    val hold = remember { SwarmHolder() }
    var frame by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                val dt = if (last == 0L) 0.016f else ((now - last) / 1_000_000_000f).coerceAtMost(0.05f)
                last = now
                val speaking = jarvis.speaking
                val lvl = jarvis.level
                val tgt = when {
                    speaking -> 0.7f + lvl * 0.6f
                    Core.busy -> 0.85f
                    Core.voiceMode == 2 -> 0.6f
                    else -> 0.2f
                }
                hold.energy += (tgt - hold.energy) * min(1f, dt * 5f)
                hold.time += dt
                if (hold.w > 0f) {
                    if (!hold.sw.inited) hold.sw.init(hold.w, hold.h)
                    val tx = if (hold.touching) hold.touch.x else hold.w / 2
                    val ty = if (hold.touching) hold.touch.y else hold.h * 0.42f
                    hold.sw.step(dt, hold.w, hold.h, hold.energy, if (speaking) lvl else 0f, hold.time, tx, ty, dens)
                }
                frame = now
            }
        }
    }
    val tint by animateColorAsState(
        when {
            jarvis.speaking -> Color(0xFFCFF9FF)
            Core.busy -> Gold
            Core.voiceMode == 2 -> Mint
            else -> Cyan
        }, tween(500), label = "tint")

    val shape = CutCornerShape(topEnd = 14.dp, bottomStart = 14.dp)
    val blinkT = rememberInfiniteTransition(label = "blink")
    val blink by blinkT.animateFloat(0.3f, 1f, infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "b")

    @Composable fun field(value: String, hint: String, onChange: (String) -> Unit, modifier: Modifier) {
        Box(modifier.border(1.dp, Cyan.copy(alpha = 0.5f), shape).background(Panel.copy(alpha = 0.8f), shape)) {
            TextField(value, onChange, Modifier.fillMaxWidth(),
                placeholder = { Text(hint, fontFamily = Mono, fontSize = 13.sp, color = Cyan.copy(alpha = 0.4f)) },
                textStyle = TextStyle(fontFamily = Mono, fontSize = 14.sp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Cyan))
        }
    }

    Box(Modifier.fillMaxSize().background(Navy)
        .onSizeChanged { hold.w = it.width.toFloat(); hold.h = it.height.toFloat() }
        .pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { hold.touch = it; hold.touching = true },
                onDrag = { c, _ -> hold.touch = c.position },
                onDragEnd = { hold.touching = false }, onDragCancel = { hold.touching = false })
        }) {

        Canvas(Modifier.fillMaxSize()) {
            val tk = frame
            val sw = hold.sw
            if (!sw.inited || tk < 0) return@Canvas
            val lr = 36f * dens; val lr2 = lr * lr
            var drawn = 0
            for (i in 0 until sw.n) for (j in i + 1 until sw.n) {
                val dx = sw.x[i] - sw.x[j]; val dy = sw.y[i] - sw.y[j]; val d2 = dx * dx + dy * dy
                if (d2 < lr2 && drawn < 420) {
                    drawn++
                    drawLine(tint.copy(alpha = 0.22f * (1f - d2 / lr2)), Offset(sw.x[i], sw.y[i]), Offset(sw.x[j], sw.y[j]), 1f)
                }
            }
            val rad = (1.4f + 1.8f * hold.energy) * dens
            for (i in 0 until sw.n) {
                val sp = sqrt(sw.vx[i] * sw.vx[i] + sw.vy[i] * sw.vy[i]) / (300f * dens)
                drawCircle(tint.copy(alpha = (0.45f + sp).coerceIn(0.45f, 1f)), rad, Offset(sw.x[i], sw.y[i]))
            }
        }

        if (apiKey.isBlank()) {
            Column(Modifier.align(Alignment.Center).padding(24.dp).background(Panel.copy(alpha = 0.9f), shape)
                .border(1.dp, Cyan.copy(alpha = 0.6f), shape).padding(18.dp)) {
                Text("ZUGANG EINRICHTEN", fontFamily = Mono, fontWeight = FontWeight.Bold, color = Cyan, letterSpacing = 2.sp)
                Spacer(Modifier.height(6.dp))
                Text("Kostenlosen Gemini-API-Key einfügen (aistudio.google.com/apikey). Bleibt nur auf deinem Handy.",
                    fontSize = 12.sp, fontFamily = Mono, color = Color.White.copy(alpha = 0.7f))
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(keyInput, { keyInput = it }, Modifier.fillMaxWidth(), singleLine = true)
                Spacer(Modifier.height(10.dp))
                Button({ apiKey = keyInput.trim(); prefs.edit().putString("key", apiKey).apply() },
                    Modifier.fillMaxWidth(), shape = CutCornerShape(8.dp)) { Text("AKTIVIEREN", fontFamily = Mono) }
            }
        } else {
            Column(Modifier.align(Alignment.TopStart).systemBarsPadding().padding(16.dp)) {
                Text("B.O.R.I.S.", fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 22.sp, letterSpacing = 5.sp, color = Cyan)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(6.dp).clip(CircleShape).background(tint.copy(alpha = blink)))
                    Spacer(Modifier.width(6.dp))
                    Text("▸ ${Core.status}", fontFamily = Mono, fontSize = 11.sp, letterSpacing = 1.sp, color = tint.copy(alpha = 0.9f),
                        maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 230.dp))
                }
            }
            if (!agentOn) {
                Box(Modifier.align(Alignment.TopEnd).systemBarsPadding().padding(16.dp)
                    .border(1.dp, Gold.copy(alpha = 0.7f), CutCornerShape(topEnd = 8.dp, bottomStart = 8.dp))
                    .clickable { activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                    .padding(horizontal = 10.dp, vertical = 6.dp)) {
                    Text("AGENT AUS · TIPPEN", fontFamily = Mono, fontSize = 10.sp, color = Gold)
                }
            }

            val lastBoris = messages.lastOrNull { it.kind == 1 || it.kind == 3 }
            val caption = if (Core.voiceMode == 2) "ICH HÖRE …" else lastBoris?.text ?: "Sag „Boris“ …"
            Text(caption, Modifier.align(Alignment.BottomCenter).systemBarsPadding().padding(start = 24.dp, end = 24.dp, bottom = 120.dp),
                fontFamily = Mono, fontSize = 14.sp, color = Color.White.copy(alpha = 0.9f), maxLines = 4, overflow = TextOverflow.Ellipsis)

            Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().systemBarsPadding().padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                HudButton("💬", "CHAT") { chatOpen = true }
                Text(if (Core.voiceMode == 0) "MIKRO AUS" else if (always) "HÖRT IMMER ZU" else "HÖRT ZU · SAG „BORIS“",
                    fontFamily = Mono, fontSize = 9.sp, letterSpacing = 2.sp, color = Cyan.copy(alpha = 0.5f + 0.3f * blink),
                    modifier = Modifier.padding(bottom = 22.dp))
                HudButton("🎤", "SPRECHEN", Gold) { Core.listener?.awaitCommand() }
            }

            AnimatedVisibility(chatOpen, enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()) {
                Column(Modifier.fillMaxSize().background(Navy.copy(alpha = 0.94f)).systemBarsPadding().imePadding().padding(horizontal = 14.dp)) {
                    Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Tab("CHAT", tab == 0) { tab = 0 }
                        Tab("GEHIRN", tab == 1) { tab = 1 }
                        Tab("SYSTEM", tab == 2) { tab = 2 }
                        Spacer(Modifier.weight(1f))
                        Text("✕", Modifier.clickable { chatOpen = false }.padding(12.dp), color = Cyan, fontSize = 18.sp)
                    }
                    when (tab) {
                        0 -> {
                            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, contentPadding = PaddingValues(vertical = 10.dp)) {
                                itemsIndexed(messages) { _, m ->
                                    if (m.kind == 2) {
                                        Text("▸ ${m.text.uppercase()}", Modifier.padding(vertical = 4.dp, horizontal = 4.dp),
                                            color = Mint, fontFamily = Mono, fontSize = 11.sp, letterSpacing = 1.sp)
                                    } else {
                                        val col = when (m.kind) { 0 -> Gold; 3 -> Red; else -> Cyan }
                                        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp),
                                            horizontalArrangement = if (m.kind == 0) Arrangement.End else Arrangement.Start) {
                                            Column(Modifier.widthIn(max = 310.dp).background(Panel.copy(alpha = 0.9f), shape)
                                                .border(1.dp, col.copy(alpha = 0.6f), shape).padding(12.dp)) {
                                                Text(when (m.kind) { 0 -> "DU"; 3 -> "FEHLER"; else -> "BORIS" }, fontFamily = Mono,
                                                    fontSize = 9.sp, letterSpacing = 3.sp, color = col.copy(alpha = 0.8f))
                                                Spacer(Modifier.height(3.dp))
                                                Text(m.text, color = Color.White, fontSize = 14.sp, fontFamily = Mono)
                                            }
                                        }
                                    }
                                }
                            }
                            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                field(input, "Befehl eingeben …", { input = it }, Modifier.weight(1f))
                                Spacer(Modifier.width(8.dp))
                                Box(Modifier.size(52.dp).border(1.5.dp, Cyan, shape).clickable { Core.handle(activity, input); input = "" },
                                    contentAlignment = Alignment.Center) { Text("➤", color = Cyan, fontSize = 20.sp) }
                            }
                        }
                        1 -> {
                            val facts = remember(brainTick, tab) { Brain.all() }
                            Text("DAUERHAFTES GEDÄCHTNIS · ${facts.size} EINTRÄGE", fontFamily = Mono, fontSize = 10.sp, letterSpacing = 2.sp,
                                color = Cyan.copy(alpha = 0.6f), modifier = Modifier.padding(vertical = 8.dp))
                            LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                                itemsIndexed(facts) { i, f ->
                                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text("[${f.first}]", fontFamily = Mono, fontSize = 10.sp, color = Gold, modifier = Modifier.width(70.dp))
                                        Text(f.second, Modifier.weight(1f), fontFamily = Mono, fontSize = 13.sp, color = Color.White)
                                        Text("✕", Modifier.clickable { Brain.removeAt(i); brainTick++ }.padding(10.dp), color = Red)
                                    }
                                }
                            }
                            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                field(brainInput, "Boris etwas beibringen …", { brainInput = it }, Modifier.weight(1f))
                                Spacer(Modifier.width(8.dp))
                                Box(Modifier.size(52.dp).border(1.5.dp, Gold, shape)
                                    .clickable { Brain.add(brainInput, "manuell"); brainInput = ""; brainTick++ }, contentAlignment = Alignment.Center) {
                                    Text("＋", color = Gold, fontSize = 22.sp)
                                }
                            }
                        }
                        else -> {
                            @Composable fun Row2(title: String, value: String, ok: Boolean, onClick: () -> Unit) {
                                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).border(1.dp, (if (ok) Cyan else Gold).copy(alpha = 0.5f), shape)
                                    .clickable(onClick = onClick).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(title, Modifier.weight(1f), fontFamily = Mono, fontSize = 12.sp, color = Color.White, letterSpacing = 1.sp)
                                    Text(value, fontFamily = Mono, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (ok) Cyan else Gold)
                                }
                            }
                            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(top = 8.dp)) {
                                Row2("STIMME", voiceName.uppercase() + " ▸", true) {
                                    voiceName = jarvis.cycleVoice(); Core.say(activity, "Systeme online. Wie kann ich helfen?", false)
                                }
                                if (hq && jarvis.lastError.isNotEmpty()) Text("⚠ HQ-Stimme fehlgeschlagen, Handy-Stimme aktiv: " + jarvis.lastError,
                                    Modifier.padding(horizontal = 4.dp, vertical = 2.dp), fontFamily = Mono, fontSize = 10.sp, color = Gold)
                                Row2("IMMER ZUHÖREN (AUCH GESPERRT)", if (always) "AN" else "AUS", always) { always = !always; activity.setAlwaysListen(always) }
                                Row2("HQ-STIMME (GEMINI)", if (hq) "AN" else "AUS", hq) { hq = !hq; prefs.edit().putBoolean("hq_voice", hq).apply() }
                                Row2("PROAKTIVE RÜCKFRAGEN", if (proactive) "AN" else "AUS", proactive) { proactive = !proactive; prefs.edit().putBoolean("proactive", proactive).apply() }
                                Row2("BENACHRICHTIGUNGS-KI", if (notifAi) "AN" else "AUS", notifAi) { notifAi = !notifAi; prefs.edit().putBoolean("notif_ai", notifAi).apply() }
                                Row2("SICHERHEITSABFRAGEN", if (safety) "AN" else "AUS", safety) { safety = !safety; prefs.edit().putBoolean("safety", safety).apply() }
                                Row2("BENACHRICHTIGUNGSZUGRIFF", if (notifOn) "AKTIV" else "AUS · TIPPEN", notifOn) {
                                    activity.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                                }
                                Row2("AGENT-ZUGRIFF", if (agentOn) "AKTIV" else "AUS · TIPPEN", agentOn) {
                                    activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                                }
                                Row2("SELBSTTEST", if (testing) "LÄUFT …" else "STARTEN ▸", !testing) {
                                    if (!testing) {
                                        testing = true; testResults.clear()
                                        Thread {
                                            val r = try { SelfTest.run(activity) } catch (e: Exception) { listOf(false to "Test-Fehler: ${e.message}") }
                                            activity.runOnUiThread { testResults.addAll(r); testing = false }
                                        }.start()
                                    }
                                }
                                testResults.forEach {
                                    Text((if (it.first) "✓ " else "✗ ") + it.second, Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        fontFamily = Mono, fontSize = 11.sp, color = if (it.first) Mint else Red)
                                }
                                if (crash != null) {
                                    Spacer(Modifier.height(8.dp))
                                    Row2("LETZTER ABSTURZ", "LÖSCHEN ✕", false) { prefs.edit().remove("crash").apply(); crash = null }
                                    Text(crash!!.take(700), Modifier.padding(6.dp), fontFamily = Mono, fontSize = 9.sp, color = Red)
                                }
                                Spacer(Modifier.height(8.dp))
                                Text("PROTOKOLL", Modifier.padding(horizontal = 6.dp), fontFamily = Mono, fontSize = 10.sp, letterSpacing = 2.sp, color = Cyan.copy(alpha = 0.6f))
                                Dbg.lines.takeLast(25).forEach {
                                    Text(it, Modifier.padding(horizontal = 6.dp, vertical = 1.dp), fontFamily = Mono, fontSize = 9.sp, color = Color.White.copy(alpha = 0.7f))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
