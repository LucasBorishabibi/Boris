package com.boris.assistant

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.exp
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

// ------------------------------------------------------------------ Thema
private var Navy by mutableStateOf(Color(0xFF05070D))
private var Panel by mutableStateOf(Color(0xFF111724))
private var Cyan by mutableStateOf(Color(0xFF5AA9FF))   // Akzent
private var Gold by mutableStateOf(Color(0xFFC9E4FF))   // helleres Zweit-Akzent
private var Mint by mutableStateOf(Color(0xFF6EE7C8))
private var OnAccent by mutableStateOf(Color.White)
private val Red = Color(0xFFFF5C5C)

/** Thema: Blau oder Schwarz-Weiß. */
private fun applyTheme(bw: Boolean) {
    if (bw) {
        Navy = Color(0xFF000000); Panel = Color(0xFF131313); Cyan = Color(0xFFF2F2F2); Gold = Color(0xFFBDBDBD)
        Mint = Color(0xFFFFFFFF); OnAccent = Color.Black
    } else {
        Navy = Color(0xFF05070D); Panel = Color(0xFF111724); Cyan = Color(0xFF5AA9FF); Gold = Color(0xFFC9E4FF)
        Mint = Color(0xFF6EE7C8); OnAccent = Color.White
    }
}

// ------------------------------------------------------------------ Activity
class MainActivity : ComponentActivity() {
    val jarvis: Jarvis by lazy { Hub.jarvis(this) }
    var tick by mutableIntStateOf(0)
    private var ownListener: WakeListener? = null
    private var awaitAfterStart = false

    private fun prefs() = getSharedPreferences("boris", 0)
    fun alwaysListen() = prefs().getBoolean("always_listen", false)
    private fun micOk() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED

    /** Mit Dauer-Zuhören übernimmt der Hintergrunddienst, sonst hört die App nur im Vordergrund zu. */
    fun startListening() {
        if (!micOk()) return
        if (alwaysListen()) {
            ownListener?.stop(); ownListener = null
            try { startForegroundService(Intent(this, ListenService::class.java)) } catch (e: Exception) { Dbg.d("Dienst: ${e.message}") }
        } else {
            if (ownListener == null) ownListener = WakeListener(this, { t -> Core.handle(this, t) }, { m -> Core.voiceMode = m })
            Core.listener = ownListener
            ownListener?.start()
        }
        if (awaitAfterStart) { awaitAfterStart = false; Core.listener?.awaitCommand() }
    }

    fun setAlwaysListen(on: Boolean) {
        prefs().edit().putBoolean("always_listen", on).apply()
        if (!on) stopService(Intent(this, ListenService::class.java))
        startListening()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Brain.load(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        handleIntent(intent)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Navy, surface = Panel)) {
                BorisScreen(this)
            }
        }
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); handleIntent(intent) }

    private fun handleIntent(i: Intent?) { if (i?.hasExtra("q") == true) { awaitAfterStart = true; i.removeExtra("q") } }

    override fun onResume() { super.onResume(); tick++; Core.activityVisible = true; Learning.userActive(); startListening() }

    override fun onPause() {
        Core.activityVisible = false
        if (!alwaysListen()) { ownListener?.stop(); Core.voiceMode = 0 }
        super.onPause()
    }
}

// ------------------------------------------------------------------ Voice-Face (siehe VoiceFace.kt)
private class SwarmHolder {
    val face = VoiceFace()
    var w = 0f; var h = 0f; var time = 0f
    var touch = Offset.Zero; var touching = false
}

// ------------------------------------------------------------------ Symbole (selbst gezeichnet)
@Composable
private fun Ico(kind: String, color: Color, boxSize: Dp = 24.dp) {
    Canvas(Modifier.size(boxSize)) {
        val w = this.size.width
        val sw = w * 0.085f
        val st = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (kind) {
            "chat" -> {
                drawRoundRect(color, Offset(w * 0.12f, w * 0.14f), Size(w * 0.76f, w * 0.58f), CornerRadius(w * 0.2f), style = st)
                val tail = Path().apply { moveTo(w * 0.32f, w * 0.72f); lineTo(w * 0.27f, w * 0.9f); lineTo(w * 0.52f, w * 0.72f) }
                drawPath(tail, color, style = st)
                for (i in 0 until 3) drawCircle(color, w * 0.035f, Offset(w * (0.34f + 0.16f * i), w * 0.43f))
            }
            "mic" -> {
                drawRoundRect(color, Offset(w * 0.37f, w * 0.1f), Size(w * 0.26f, w * 0.47f), CornerRadius(w * 0.13f), style = st)
                drawArc(color, startAngle = 0f, sweepAngle = 180f, useCenter = false,
                    topLeft = Offset(w * 0.24f, w * 0.26f), size = Size(w * 0.52f, w * 0.46f), style = st)
                drawLine(color, Offset(w * 0.5f, w * 0.72f), Offset(w * 0.5f, w * 0.88f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * 0.36f, w * 0.9f), Offset(w * 0.64f, w * 0.9f), sw, StrokeCap.Round)
            }
            "send" -> {
                val p = Path().apply {
                    moveTo(w * 0.12f, w * 0.46f); lineTo(w * 0.9f, w * 0.12f); lineTo(w * 0.58f, w * 0.9f); lineTo(w * 0.46f, w * 0.58f); close()
                }
                drawPath(p, color, style = st)
                drawLine(color, Offset(w * 0.46f, w * 0.58f), Offset(w * 0.9f, w * 0.12f), sw, StrokeCap.Round)
            }
            "close" -> {
                drawLine(color, Offset(w * 0.27f, w * 0.27f), Offset(w * 0.73f, w * 0.73f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * 0.73f, w * 0.27f), Offset(w * 0.27f, w * 0.73f), sw, StrokeCap.Round)
            }
            "plus" -> {
                drawLine(color, Offset(w * 0.5f, w * 0.22f), Offset(w * 0.5f, w * 0.78f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * 0.22f, w * 0.5f), Offset(w * 0.78f, w * 0.5f), sw, StrokeCap.Round)
            }
        }
    }
}

@Composable
private fun RoundBtn(kind: String, diameter: Dp, filled: Boolean, halo: Float, onClick: () -> Unit) {
    val bg = if (filled) Modifier.background(Brush.linearGradient(listOf(Cyan, lerp(Cyan, Color.White, 0.3f))), CircleShape)
    else Modifier.background(Color.White.copy(alpha = 0.08f), CircleShape).border(1.dp, Color.White.copy(alpha = 0.14f), CircleShape)
    Box(Modifier.size(diameter)
        .drawBehind { if (halo > 0f) drawCircle(Cyan.copy(alpha = 0.28f * halo), this.size.minDimension / 2f * (1.1f + 0.45f * halo)) }
        .then(bg).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Ico(kind, if (filled) OnAccent else Color.White, diameter * 0.44f)
    }
}

@Composable
private fun QuickAction(symbol: String, title: String, subtitle: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(modifier.clip(RoundedCornerShape(18.dp))
        .background(Brush.linearGradient(listOf(Color(0xE6162232), Color(0xD90B111C))))
        .border(1.dp, Color.White.copy(alpha = 0.09f), RoundedCornerShape(18.dp))
        .clickable(onClick = onClick).padding(horizontal = 11.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(symbol, color = Cyan, fontSize = 19.sp, fontWeight = FontWeight.Medium)
            Text(title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text(subtitle, color = Color.White.copy(alpha = 0.52f), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun SegTab(label: String, sel: Boolean, onClick: () -> Unit) {
    Text(label, Modifier.clip(RoundedCornerShape(50)).background(if (sel) Cyan.copy(alpha = 0.2f) else Color.Transparent)
        .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        fontSize = 13.sp, fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal,
        color = if (sel) Cyan else Color.White.copy(alpha = 0.55f))
}

@Composable
private fun SRow(title: String, sub: String?, onClick: (() -> Unit)?, trailing: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = 0.05f))
        .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
        .padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 14.sp)
            if (sub != null) Text(sub, color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp)
        }
        trailing()
    }
}

@Composable
private fun Toggle(on: Boolean, onChange: (Boolean) -> Unit) {
    Switch(on, onChange, colors = SwitchDefaults.colors(
        checkedThumbColor = OnAccent, checkedTrackColor = Cyan,
        uncheckedThumbColor = Color(0xFFB0B0B0), uncheckedTrackColor = Color.White.copy(alpha = 0.15f), uncheckedBorderColor = Color.Transparent))
}

@Composable
private fun PillField(value: String, hint: String, modifier: Modifier, onChange: (String) -> Unit) {
    Box(modifier.clip(RoundedCornerShape(26.dp)).background(Color.White.copy(alpha = 0.07f))) {
        TextField(value, onChange, Modifier.fillMaxWidth(), singleLine = true,
            placeholder = { Text(hint, fontSize = 14.sp, color = Color.White.copy(alpha = 0.4f)) },
            textStyle = TextStyle(fontSize = 15.sp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Cyan))
    }
}

// ------------------------------------------------------------------ Bildschirm
@Composable
private fun BorisScreen(activity: MainActivity) {
    val prefs = remember { activity.getSharedPreferences("boris", 0) }
    var apiKey by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var keyInput by remember { mutableStateOf("") }
    var input by remember { mutableStateOf("") }
    var chatOpen by remember { mutableStateOf(false) }
    var showTasks by remember { mutableStateOf(false) }
    var showWebSearch by remember { mutableStateOf(false) }
    var webQuery by remember { mutableStateOf("") }
    var tab by remember { mutableIntStateOf(0) }
    var brainTick by remember { mutableIntStateOf(0) }
    var brainInput by remember { mutableStateOf("") }
    var proactive by remember { mutableStateOf(prefs.getBoolean("proactive", true)) }
    var selfLearn by remember { mutableStateOf(Learning.enabled()) }
    var selfCode by remember { mutableStateOf(prefs.getBoolean("selfcode", true)) }
    var orKeyInput by remember { mutableStateOf("") }
    var elInfo by remember { mutableStateOf(ElBudget.summary(activity)) }
    var elNotif by remember { mutableStateOf(prefs.getBoolean("el_notif", false)) }
    var orStatus by remember { mutableStateOf(if (OpenRouter.hasKey(activity)) "Key gesetzt" else "noch kein Key") }
    var hq by remember { mutableStateOf(prefs.getBoolean("hq_voice", true)) }
    var notifAi by remember { mutableStateOf(prefs.getBoolean("notif_ai", true)) }
    var safety by remember { mutableStateOf(prefs.getBoolean("safety", true)) }
    var always by remember { mutableStateOf(activity.alwaysListen()) }
    var voiceName by remember { mutableStateOf(activity.jarvis.voiceName()) }
    var bw by remember { mutableStateOf(prefs.getInt("theme", 0) == 1) }
    remember { applyTheme(bw); 0 }
    var elKeyInput by remember { mutableStateOf("") }
    var elVoiceInput by remember { mutableStateOf("") }
    var fishKeyInput by remember { mutableStateOf("") }
    var fishVoiceInput by remember { mutableStateOf(prefs.getString("fish_voice", "") ?: "") }
    var fishSet by remember { mutableStateOf(!prefs.getString("fish_key", "").isNullOrBlank()) }
    var fishStatus by remember { mutableStateOf(if (fishSet) "API-Key gespeichert · Free-Modell ausgewählt" else "Noch kein API-Key") }
    var elSet by remember { mutableStateOf(!prefs.getString("el_key", "").isNullOrBlank()) }
    var agentOn by remember { mutableStateOf(false) }
    var notifOn by remember { mutableStateOf(false) }
    var testing by remember { mutableStateOf(false) }
    val testResults = remember { mutableStateListOf<Pair<Boolean, String>>() }
    var crash by remember { mutableStateOf(prefs.getString("crash", null)) }
    val listState = rememberLazyListState()
    val jarvis = activity.jarvis
    val dens = LocalDensity.current.density
    val messages = Core.messages

    LaunchedEffect(activity.tick) { agentOn = isAutoSendEnabled(activity); notifOn = isNotifAccessEnabled(activity) }
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (it[Manifest.permission.RECORD_AUDIO] == true) activity.startListening()
    }
    LaunchedEffect(Unit) {
        // Ask only for the microphone at startup. Contacts, calls, SMS, calendar and
        // notifications are sensitive and must be requested in the feature that needs them.
        if (!micOk()) perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
    }
    LaunchedEffect(messages.size) { if (messages.isNotEmpty() && chatOpen && tab == 0) listState.animateScrollToItem(messages.size - 1) }

    // ---- Simulation: das Face folgt dem, was Boris gerade tut (zuhören, denken, sprechen)
    val hold = remember { SwarmHolder() }
    val faceIn = remember { FaceInput() }
    var frame by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                val dt = if (last == 0L) 0.016f else ((now - last) / 1_000_000_000f).coerceAtMost(0.05f)
                last = now
                hold.time += dt
                if (hold.w > 0f) {
                    val speaking = jarvis.speaking
                    faceIn.mode = when {
                        speaking -> FaceMode.SPEAK
                        Core.busy || jarvis.preparing -> FaceMode.THINK
                        Core.voiceMode == 2 -> FaceMode.LISTEN
                        Learning.active -> FaceMode.LEARN
                        else -> FaceMode.IDLE
                    }
                    val cxNow = hold.w / 2
                    val cyNow = hold.h * 0.36f
                    faceIn.mood = jarvis.mood
                    faceIn.speaking = speaking
                    faceIn.touching = hold.touching
                    faceIn.tdx = hold.touch.x - cxNow
                    faceIn.tdy = hold.touch.y - cyNow
                    faceIn.drowsy = Learning.drowsy()
                    faceIn.learnSeq = Learning.learnSeq
                    hold.face.update(dt, jarvis.vox, faceIn, cxNow, cyNow, min(hold.w, hold.h) * 0.27f)
                }
                frame = now
            }
        }
    }
    val tint by animateColorAsState(
        when {
            jarvis.speaking -> lerp(Cyan, Color.White, 0.5f)
            Core.busy -> Gold
            Core.voiceMode == 2 -> Mint
            Learning.active -> lerp(Cyan, Mint, 0.5f)
            else -> Cyan
        }, tween(500), label = "tint")

    val pulseT = rememberInfiniteTransition(label = "pulse")
    val pulse by pulseT.animateFloat(0.2f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "p")

    Box(Modifier.fillMaxSize().background(Navy)
        .onSizeChanged { hold.w = it.width.toFloat(); hold.h = it.height.toFloat() }
        .pointerInput(Unit) {
            awaitPointerEventScope { while (true) { awaitPointerEvent(PointerEventPass.Initial); Learning.userActive(true) } }
        }
        .pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { hold.touch = it; hold.touching = true },
                onDrag = { c, _ -> hold.touch = c.position },
                onDragEnd = { hold.touching = false }, onDragCancel = { hold.touching = false })
        }) {

        Canvas(Modifier.fillMaxSize()) {
            val tk = frame
            if (tk < 0) return@Canvas
            hold.face.draw(this, tint, dens)
        }

        if (apiKey.isBlank()) {
            Column(Modifier.align(Alignment.Center).padding(24.dp).clip(RoundedCornerShape(24.dp)).background(Panel).padding(20.dp)) {
                Text("Zugang einrichten", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Text("Kostenlosen Gemini-API-Key einfügen (aistudio.google.com/apikey). Er bleibt nur auf deinem Handy.",
                    fontSize = 13.sp, color = Color.White.copy(alpha = 0.6f))
                Spacer(Modifier.height(14.dp))
                PillField(keyInput, "API-Key", Modifier.fillMaxWidth()) { keyInput = it }
                Spacer(Modifier.height(12.dp))
                Button({ apiKey = keyInput.trim(); prefs.edit().putString("key", apiKey).apply() }, Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = OnAccent)) { Text("Starten") }
            }
        } else {
            // Kopf: Name links, Status rechts
            Row(Modifier.align(Alignment.TopCenter).fillMaxWidth().systemBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text("Boris", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Row(Modifier.clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.07f)).padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(7.dp).clip(CircleShape).background(tint.copy(alpha = if (Core.busy || Learning.active) pulse else 1f)))
                    Spacer(Modifier.width(8.dp))
                    Text((if (Learning.active && !Core.busy) (if (Learning.topic.isBlank()) "Lernt …" else "Lernt: " + Learning.topic) else Core.status).lowercase().replaceFirstChar { it.uppercase() }, color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 190.dp))
                }
            }
            // Schnellaktionen: echte Funktionen statt dekorativer Dashboard-Kacheln
            Column(Modifier.align(Alignment.TopCenter).fillMaxWidth().systemBarsPadding().padding(start = 16.dp, end = 16.dp, top = 66.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    QuickAction("⌕", "Websuche", "Google direkt öffnen", Modifier.weight(1f)) { showWebSearch = true }
                    QuickAction("✓", "Tasks", "Aufgaben & Planung", Modifier.weight(1f)) { showTasks = true }
                    QuickAction("◎", "Agent", if (agentOn) "Zugriff aktiv" else "Zugriff einrichten", Modifier.weight(1f)) {
                        activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    }
                }
            }

            // Kompakte Live-Systemübersicht: echte Zustände, keine statischen Demo-Badges.
            Row(
                Modifier.align(Alignment.TopCenter).fillMaxWidth().systemBarsPadding()
                    .padding(start = 18.dp, end = 18.dp, top = 126.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xD9162334), Color(0xC90B111B))))
                    .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(16.dp))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("BORIS CORE", color = Color.White.copy(alpha = 0.48f), fontSize = 9.sp, letterSpacing = 1.5.sp)
                    Text(
                        when {
                            Core.busy -> "Verarbeitet deine Anfrage"
                            jarvis.speaking -> "Spricht gerade"
                            Core.voiceMode == 2 -> "Sprachbefehl aktiv"
                            Learning.active -> "Lernmodus aktiv"
                            else -> "System bereit"
                        },
                        color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(Modifier.width(8.dp))
                Column(horizontalAlignment = Alignment.End) {
                    Text("AGENT", color = Color.White.copy(alpha = 0.48f), fontSize = 9.sp, letterSpacing = 1.5.sp)
                    Text(
                        if (agentOn) "Berechtigung aktiv" else "Berechtigung fehlt",
                        color = if (agentOn) Mint else Gold, fontSize = 11.sp, fontWeight = FontWeight.Medium,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Mitte unten: Überschrift oder letzte Antwort
            val lastBoris = messages.lastOrNull { it.kind == 1 || it.kind == 3 }
            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().systemBarsPadding().padding(start = 28.dp, end = 28.dp, bottom = 130.dp),
                horizontalAlignment = Alignment.CenterHorizontally) {
                when {
                    Core.voiceMode == 2 -> Text("Ich höre zu …", color = Mint, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                    Learning.active -> Text("Ich nutze die Ruhe zum Lernen …", color = Color.White.copy(alpha = 0.6f), fontSize = 16.sp, textAlign = TextAlign.Center)
                    lastBoris != null -> Text(lastBoris.text, color = Color.White.copy(alpha = 0.92f), fontSize = 18.sp, textAlign = TextAlign.Center,
                        maxLines = 4, overflow = TextOverflow.Ellipsis, lineHeight = 24.sp)
                    else -> {
                        Text("Dein eigener", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.SemiBold)
                        Text("KI-Assistent", fontSize = 30.sp, fontWeight = FontWeight.SemiBold,
                            style = TextStyle(brush = Brush.linearGradient(listOf(Cyan, lerp(Cyan, Color.White, 0.55f))), fontSize = 30.sp, fontWeight = FontWeight.SemiBold))
                    }
                }
            }

            // Unten: Chat links, Mikro rechts
            Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().systemBarsPadding().padding(horizontal = 24.dp, vertical = 22.dp),
                horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                RoundBtn("chat", 56.dp, false, 0f) { chatOpen = true }
                Text(if (Core.voiceMode == 0) "Mikrofon aus" else if (always) "Hört immer zu · sag „Boris“" else "Sag „Boris“",
                    color = Color.White.copy(alpha = 0.38f), fontSize = 12.sp)
                RoundBtn("mic", 66.dp, true, if (Core.voiceMode == 2) pulse else 0f) { Core.listener?.awaitCommand() }
            }

            if (showWebSearch) {
                AlertDialog(
                    onDismissRequest = { showWebSearch = false },
                    containerColor = Panel,
                    title = { Text("Websuche", color = Color.White, fontWeight = FontWeight.SemiBold) },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Was soll ich im Browser suchen?", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
                            PillField(webQuery, "Suchbegriff oder Frage", Modifier.fillMaxWidth()) { webQuery = it }
                        }
                    },
                    confirmButton = { TextButton(onClick = {
                        val q = webQuery.trim()
                        if (q.isNotEmpty()) {
                            val i = Intent(Intent.ACTION_WEB_SEARCH).putExtra(android.app.SearchManager.QUERY, q)
                            try { activity.startActivity(i) } catch (_: Exception) {
                                activity.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com/search?q=" + android.net.Uri.encode(q))))
                            }
                        }
                        showWebSearch = false
                    }) { Text("Suchen", color = Cyan) } },
                    dismissButton = { TextButton(onClick = { showWebSearch = false }) { Text("Abbrechen", color = Color.White.copy(alpha = 0.65f)) } }
                )
            }
            if (showTasks) {
                AlertDialog(
                    onDismissRequest = { showTasks = false },
                    containerColor = Panel,
                    title = { Text("Dein Task-Center", color = Color.White, fontWeight = FontWeight.SemiBold) },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Sag Boris, was erledigt werden soll – oder starte eine Aufgabe direkt hier.", color = Color.White.copy(alpha = 0.72f), fontSize = 13.sp)
                            listOf("Plane meinen Tag", "Fasse meine Benachrichtigungen zusammen", "Öffne meine letzten Aufgaben").forEach { task ->
                                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.055f))
                                    .clickable { Core.handle(activity, task); showTasks = false }
                                    .padding(horizontal = 12.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(task, Modifier.weight(1f), color = Color.White, fontSize = 13.sp)
                                    Text("→", color = Cyan, fontSize = 18.sp)
                                }
                            }
                        }
                    },
                    confirmButton = { TextButton(onClick = { showTasks = false; chatOpen = true }) { Text("Eigene Aufgabe eingeben", color = Cyan) } },
                    dismissButton = { TextButton(onClick = { showTasks = false }) { Text("Schließen", color = Color.White.copy(alpha = 0.65f)) } }
                )
            }

            // Chat / Gehirn / System als Sheet
            AnimatedVisibility(chatOpen, enter = fadeIn(), exit = fadeOut()) {
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f)).clickable { chatOpen = false })
            }
            AnimatedVisibility(chatOpen, enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut(),
                modifier = Modifier.align(Alignment.BottomCenter)) {
                Column(Modifier.fillMaxWidth().fillMaxHeight(0.88f).clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                    .background(Panel).imePadding().navigationBarsPadding().padding(horizontal = 16.dp)) {
                    Box(Modifier.align(Alignment.CenterHorizontally).padding(top = 10.dp).size(width = 40.dp, height = 4.dp)
                        .clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.2f)))
                    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        SegTab("Chat", tab == 0) { tab = 0 }
                        SegTab("Gehirn", tab == 1) { tab = 1 }
                        SegTab("System", tab == 2) { tab = 2 }
                        SegTab("Fish Audio", tab == 3) { tab = 3 }
                        Spacer(Modifier.weight(1f))
                        Box(Modifier.size(36.dp).clip(CircleShape).clickable { chatOpen = false }, contentAlignment = Alignment.Center) {
                            Ico("close", Color.White.copy(alpha = 0.7f), 20.dp)
                        }
                    }
                    when (tab) {
                        0 -> {
                            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, contentPadding = PaddingValues(vertical = 8.dp)) {
                                itemsIndexed(messages) { _, m ->
                                    if (m.kind == 2) {
                                        Text("✓ ${m.text}", Modifier.padding(vertical = 4.dp, horizontal = 6.dp), color = Mint.copy(alpha = 0.85f), fontSize = 12.sp)
                                    } else {
                                        val mine = m.kind == 0
                                        val shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomEnd = if (mine) 6.dp else 20.dp, bottomStart = if (mine) 20.dp else 6.dp)
                                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                                            Text(m.text, Modifier.widthIn(max = 300.dp).clip(shape)
                                                .background(when (m.kind) { 0 -> Cyan; 3 -> Red.copy(alpha = 0.25f); else -> Color.White.copy(alpha = 0.08f) })
                                                .padding(horizontal = 14.dp, vertical = 10.dp),
                                                color = if (mine) OnAccent else Color.White, fontSize = 15.sp)
                                        }
                                    }
                                }
                            }
                            Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                PillField(input, "Nachricht an Boris", Modifier.weight(1f)) { input = it }
                                Spacer(Modifier.width(10.dp))
                                RoundBtn("send", 50.dp, true, 0f) { Core.handle(activity, input); input = "" }
                            }
                        }
                        1 -> {
                            val facts = remember(brainTick, tab) { Brain.all() }
                            val learned = remember(brainTick, tab, Learning.summary) { Knowledge.notesView() }
                            val skillList = remember(brainTick, tab, Learning.learnSeq) { Skills.all() }
                            Text("${facts.size} Einträge im dauerhaften Gedächtnis", color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp,
                                modifier = Modifier.padding(vertical = 6.dp))
                            LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                                itemsIndexed(facts) { i, f ->
                                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(14.dp))
                                        .background(Color.White.copy(alpha = 0.05f)).padding(start = 14.dp, top = 8.dp, bottom = 8.dp, end = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(f.first, color = Cyan, fontSize = 10.sp)
                                            Text(f.second, color = Color.White, fontSize = 14.sp)
                                        }
                                        Box(Modifier.size(38.dp).clip(CircleShape).clickable { Brain.removeAt(i); brainTick++ }, contentAlignment = Alignment.Center) {
                                            Ico("close", Color.White.copy(alpha = 0.5f), 18.dp)
                                        }
                                    }
                                }
                                if (learned.isNotEmpty()) {
                                    item { Text("Selbst gelernt · ${learned.size}", color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp, modifier = Modifier.padding(top = 14.dp, bottom = 4.dp)) }
                                    itemsIndexed(learned) { _, n ->
                                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(14.dp))
                                            .background(Color.White.copy(alpha = 0.05f)).padding(start = 14.dp, top = 8.dp, bottom = 8.dp, end = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f)) {
                                                Text(n.second, color = Mint, fontSize = 10.sp)
                                                Text(n.third, color = Color.White, fontSize = 14.sp)
                                            }
                                            Box(Modifier.size(38.dp).clip(CircleShape).clickable { Knowledge.removeNote(n.first); Learning.refresh(); brainTick++ }, contentAlignment = Alignment.Center) {
                                                Ico("close", Color.White.copy(alpha = 0.5f), 18.dp)
                                            }
                                        }
                                    }
                                }
                                if (skillList.isNotEmpty()) {
                                    item { Text("Selbst programmiert · ${skillList.size}", color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp, modifier = Modifier.padding(top = 14.dp, bottom = 4.dp)) }
                                    itemsIndexed(skillList) { _, sk ->
                                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(14.dp))
                                            .background(Color.White.copy(alpha = 0.05f)).padding(start = 14.dp, top = 8.dp, bottom = 8.dp, end = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f)) {
                                                Text("${sk.optString("name")} · v${sk.optInt("ver")} · ${sk.optInt("uses")}x genutzt", color = Gold, fontSize = 10.sp)
                                                Text(sk.optString("desc"), color = Color.White, fontSize = 14.sp)
                                            }
                                            Box(Modifier.size(38.dp).clip(CircleShape).clickable { Skills.remove(sk.optString("name")); brainTick++ }, contentAlignment = Alignment.Center) {
                                                Ico("close", Color.White.copy(alpha = 0.5f), 18.dp)
                                            }
                                        }
                                    }
                                }
                            }
                            Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                PillField(brainInput, "Boris etwas beibringen", Modifier.weight(1f)) { brainInput = it }
                                Spacer(Modifier.width(10.dp))
                                RoundBtn("plus", 50.dp, true, 0f) { Brain.add(brainInput, "manuell"); brainInput = ""; brainTick++ }
                            }
                        }
                        3 -> {
                            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
                                Text("Fish Audio · S2.1 Pro Free", color = Cyan, fontSize = 20.sp, fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(vertical = 10.dp))
                                Text("Echtzeit-PCM-Streaming über WebSocket mit Low-Latency-Modus. Boris startet die Wiedergabe, sobald der erste Audio-Chunk eintrifft; häufige Antworten werden lokal gecacht. ElevenLabs bleibt als Fallback erhalten.",
                                    color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp, modifier = Modifier.padding(bottom = 12.dp))
                                PillField(fishKeyInput, "Fish Audio API-Key", Modifier.fillMaxWidth()) { fishKeyInput = it }
                                SRow("Fish Audio-Key speichern", if (fishSet) "gesetzt" else "nicht gesetzt", {
                                    val k = fishKeyInput.trim()
                                    if (k.isNotBlank()) {
                                        prefs.edit().putString("fish_key", k).putBoolean("fish_enabled", true).apply()
                                        fishSet = true; fishKeyInput = ""
                                        fishStatus = "Key gespeichert · S2.1 Pro Free aktiv"
                                        voiceName = jarvis.voiceName()
                                    }
                                }) { Text("speichern ›", color = Cyan, fontSize = 13.sp) }
                                SRow("Fish Audio aktivieren", fishStatus, {
                                    val enabled = prefs.getBoolean("fish_enabled", true)
                                    prefs.edit().putBoolean("fish_enabled", !enabled).apply()
                                    fishStatus = if (!enabled) "Fish Audio aktiviert" else "Fish Audio pausiert"
                                    voiceName = jarvis.voiceName()
                                }) { Text(if (prefs.getBoolean("fish_enabled", true)) "aktiv" else "pausiert", color = if (prefs.getBoolean("fish_enabled", true)) Mint else Gold, fontSize = 13.sp) }
                                PillField(fishVoiceInput, "Voice ID / Reference ID (optional)", Modifier.fillMaxWidth()) { fishVoiceInput = it }
                                SRow("Voice ID speichern", if (fishVoiceInput.isBlank()) "Standardstimme" else "eigene Stimme", {
                                    prefs.edit().putString("fish_voice", fishVoiceInput.trim()).apply()
                                    voiceName = jarvis.voiceName()
                                    fishStatus = if (fishVoiceInput.isBlank()) "Standardstimme gespeichert" else "Voice ID gespeichert"
                                }) { Text("speichern ›", color = Cyan, fontSize = 13.sp) }
                                SRow("Fish Audio testen", "kurze Testausgabe mit der aktuellen Stimme", {
                                    if (fishSet) Core.say(activity, "Fish Audio ist verbunden. Systeme online.", false)
                                    else fishStatus = "Bitte zuerst einen API-Key speichern"
                                }) { Text("testen ›", color = Cyan, fontSize = 13.sp) }
                                SRow("Fish Audio API-Key holen", "fish.audio/app/api-keys", {
                                    activity.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://fish.audio/app/api-keys")))
                                }) { Text("öffnen ↗", color = Cyan, fontSize = 13.sp) }
                            }
                        }
                        2 -> {
                            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
                                SRow("Stimme", voiceName, { voiceName = jarvis.cycleVoice(); Core.say(activity, "Systeme online. Wie kann ich helfen?", false) }) {
                                    Text("wechseln ›", color = Cyan, fontSize = 13.sp)
                                }
                                SRow("Farbthema", if (bw) "Schwarz-Weiß" else "Blau", { bw = !bw; prefs.edit().putInt("theme", if (bw) 1 else 0).apply(); applyTheme(bw) }) {
                                    Text("wechseln ›", color = Cyan, fontSize = 13.sp)
                                }
                                SRow("Immer zuhören", "auch bei gesperrtem Handy", null) { Toggle(always) { always = it; activity.setAlwaysListen(it) } }
                                SRow("Benachrichtigungen erzählen", "kurz zusammengefasst, auf Wunsch stumm", null) {
                                    Toggle(notifAi) { notifAi = it; prefs.edit().putBoolean("notif_ai", it).apply() }
                                }
                                SRow("Proaktive Rückfragen", "z. B. wenn du lange in einer App bist", null) {
                                    Toggle(proactive) { proactive = it; prefs.edit().putBoolean("proactive", it).apply() }
                                }
                                SRow("Selbstlernen", "nach 10 Min. Ruhe: recherchiert, prüft und merkt sich Nützliches", null) {
                                    Toggle(selfLearn) { selfLearn = it; Learning.setEnabled(it) }
                                }
                                SRow("Jetzt lernen", if (Learning.active) "lernt gerade …" else Learning.summary, { Learning.learnNow() }) {
                                    Text("starten ›", color = Cyan, fontSize = 13.sp)
                                }
                                SRow("Selfcoding", "Boris programmiert sich selbst Skills und testet sie", null) {
                                    Toggle(selfCode) { selfCode = it; prefs.edit().putBoolean("selfcode", it).apply() }
                                }
                                Text("OpenRouter (zweiter, kostenloser Key von openrouter.ai) übernimmt Selbstlernen und Selfcoding, damit Gemini frei bleibt.",
                                    color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp))
                                PillField(orKeyInput, "OpenRouter-Key", Modifier.fillMaxWidth()) { orKeyInput = it }
                                SRow("OpenRouter-Key speichern und prüfen", orStatus, {
                                    val k = orKeyInput.trim()
                                    if (k.isNotBlank()) { prefs.edit().putString("or_key", k).apply(); orKeyInput = "" }
                                    orStatus = "prüfe …"
                                    Thread { val r = OpenRouter.check(activity); activity.runOnUiThread { orStatus = r } }.start()
                                }) { Text("prüfen ›", color = Cyan, fontSize = 13.sp) }
                                SRow("Tagesbudget", Providers.status(activity), null) { Text("heute", color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp) }
                                SRow("Gelerntes zurücksetzen", "löscht recherchiertes Wissen und Regeln, nicht dein Gehirn", { Knowledge.clearLearned(); Learning.refresh(); brainTick++ }) {
                                    Text("löschen ›", color = Cyan, fontSize = 13.sp)
                                }
                                SRow("Sicherheitsabfragen", "bei Geld, langen Texten, neuen Kontakten", null) {
                                    Toggle(safety) { safety = it; prefs.edit().putBoolean("safety", it).apply() }
                                }
                                SRow("Gemini-Stimme als Ausweichlösung", null, null) { Toggle(hq) { hq = it; prefs.edit().putBoolean("hq_voice", it).apply() } }
                                Spacer(Modifier.height(8.dp))
                                Text("ElevenLabs-Stimme (elevenlabs.io → API Keys). Der Gratis-Tarif hat nur wenige Zeichen im Monat.",
                                    color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp))
                                PillField(elKeyInput, "ElevenLabs-Key", Modifier.fillMaxWidth()) { elKeyInput = it }
                                SRow("ElevenLabs-Key speichern", if (elSet) "gesetzt" else "nicht gesetzt", {
                                    val k = elKeyInput.trim()
                                    prefs.edit().putString("el_key", k).apply()
                                    elSet = k.isNotBlank(); elKeyInput = ""
                                    voiceName = jarvis.voiceName()
                                    if (elSet) Core.say(activity, "ElevenLabs verbunden. Systeme online.", false)
                                }) { Text("speichern ›", color = Cyan, fontSize = 13.sp) }
                                PillField(elVoiceInput, "Eigene Voice-ID (optional)", Modifier.fillMaxWidth()) { elVoiceInput = it }
                                SRow("ElevenLabs-Credits", elInfo, {
                                    elInfo = "prüfe …"
                                    Thread {
                                        val k = prefs.getString("el_key", "") ?: ""
                                        if (k.isNotBlank()) ElBudget.refresh(activity, k)
                                        activity.runOnUiThread { elInfo = ElBudget.summary(activity) }
                                    }.start()
                                }) { Text("aktualisieren ›", color = Cyan, fontSize = 13.sp) }
                                SRow("Benachrichtigungen mit ElevenLabs sprechen", "aus = kostenlose Handy-Stimme, spart Credits", null) {
                                    Toggle(elNotif) { elNotif = it; prefs.edit().putBoolean("el_notif", it).apply() }
                                }
                                SRow("Eigene Voice-ID speichern", null, {
                                    val v = elVoiceInput.trim()
                                    if (v.isNotBlank()) { prefs.edit().putString("el_voice", v).apply(); elVoiceInput = ""; voiceName = jarvis.voiceName() }
                                }) { Text("speichern ›", color = Cyan, fontSize = 13.sp) }
                                Spacer(Modifier.height(8.dp))
                                SRow("Benachrichtigungszugriff", if (notifOn) "aktiv" else "aus, hier aktivieren",
                                    { activity.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }) {
                                    Text(if (notifOn) "✓" else "›", color = if (notifOn) Mint else Gold, fontSize = 16.sp)
                                }
                                SRow("Boris FaceTime-Fenster", if (FloatBorisOverlay.hasPermission(activity)) "aktiv · frei verschiebbar" else "einmalig 'über anderen Apps anzeigen' erlauben",
                                    { if (FloatBorisOverlay.hasPermission(activity)) FloatBorisOverlay.show(activity, "Hey! Ich bin Boris. So sieht mein schwebendes Gesprächsfenster aus.") else FloatBorisOverlay.requestPermission(activity) }) {
                                    Text(if (FloatBorisOverlay.hasPermission(activity)) "testen ↗" else "aktivieren ›", color = Cyan, fontSize = 13.sp)
                                }
                                SRow("Agent-Zugriff", if (agentOn) "aktiv" else "aus, hier aktivieren",
                                    { activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) {
                                    Text(if (agentOn) "✓" else "›", color = if (agentOn) Mint else Gold, fontSize = 16.sp)
                                }
                                SRow("Selbsttest", if (testing) "läuft …" else "prüft alles, was Boris braucht", {
                                    if (!testing) {
                                        testing = true; testResults.clear()
                                        Thread {
                                            val r = try { SelfTest.run(activity) } catch (e: Exception) { listOf(false to "Test-Fehler: ${e.message}") }
                                            activity.runOnUiThread { testResults.addAll(r); testing = false }
                                        }.start()
                                    }
                                }) { Text("starten ›", color = Cyan, fontSize = 13.sp) }
                                testResults.forEach {
                                    Text((if (it.first) "✓ " else "✗ ") + it.second, Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                        fontSize = 12.sp, color = if (it.first) Mint else Red)
                                }
                                if (crash != null) {
                                    SRow("Letzter Absturz", "antippen zum Löschen", { prefs.edit().remove("crash").apply(); crash = null }) {
                                        Text("löschen", color = Red, fontSize = 13.sp)
                                    }
                                    Text(crash!!.take(600), Modifier.padding(8.dp), fontSize = 9.sp, color = Red.copy(alpha = 0.8f))
                                }
                                Spacer(Modifier.height(8.dp))
                                Text("Protokoll", Modifier.padding(horizontal = 8.dp), fontSize = 11.sp, color = Color.White.copy(alpha = 0.5f))
                                Dbg.lines.takeLast(25).forEach {
                                    Text(it, Modifier.padding(horizontal = 8.dp, vertical = 1.dp), fontSize = 10.sp, color = Color.White.copy(alpha = 0.6f))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
