package com.boris.assistant

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.max
import kotlin.math.min

/**
 * Boris' Selbstlernsystem. Nach ca. 10 Minuten ohne Nutzung (und solange die App oder der Zuhör-Dienst läuft)
 * wechselt Boris in den Lernmodus. Das Lernen ist gezielt, nicht zufällig:
 *
 *  - AUSWERTEN: wertet vergangene Gespräche aus (Vorlieben, Themen, Fehlschläge, Wissenslücken, Verhaltenshinweise)
 *  - RECHERCHIEREN: beantwortet offene Lernfragen mit echter Google-Suche; gespeichert wird nur, was belegt ist
 *  - ÜBERPRÜFEN: prüft älteres Wissen erneut und korrigiert oder löscht Veraltetes
 *  - VERKNÜPFEN: leitet nützliche Zusammenhänge aus vorhandenem Wissen ab
 *  - LÜCKEN: erkennt, was dem Nutzer künftig helfen würde und noch fehlt, und plant dazu Recherchen
 *
 * Jede Interaktion des Nutzers unterbricht das Lernen sofort (siehe [interrupt]).
 */
object Learner {
    /** Ruhezeit bis zum Lernmodus. */
    const val IDLE_MS = 10 * 60 * 1000L
    private const val DAY = 24 * 60 * 60 * 1000L
    private const val HOUR = 60 * 60 * 1000L
    private const val GAP_MS = 4 * 60 * 1000L        // Pause zwischen zwei Lernsitzungen
    private const val DAILY_MAX = 30                 // Obergrenze an Sitzungen pro Tag (schont das API-Kontingent)
    private const val MAX_KNOW = 300
    private const val MAX_QUEUE = 30
    private const val MAX_LESSONS = 12
    private const val PREF = "boris_learn"

    private enum class Task { REVIEW, RESEARCH, VERIFY, CONNECT, GAPS, CODE }

    private var ctx: Context? = null
    private val know = ArrayList<JSONObject>()      // t, topic, kind (fakt|zusammenhang), conf, src[], ts, v (zuletzt geprüft), ttl (Tage, 0 = zeitlos), id
    private val topics = ArrayList<JSONObject>()    // n, w, ts  (Interessen des Nutzers, gewichtet)
    private val queue = ArrayList<JSONObject>()     // q, topic, p, ts, tries  (offene Lernfragen)
    private val lessons = ArrayList<JSONObject>()   // t, ts  (gelernte Verhaltenshinweise)
    private val log = ArrayList<JSONObject>()       // u, r, ok, ts, rev  (Gesprächsprotokoll für die Auswertung)
    private var meta = JSONObject()
    private var idSeq = 0L

    /** Boris lernt gerade aktiv (steuert Gesicht und Status). */
    var working by mutableStateOf(false)
        private set
    /** Zählt hoch, wenn etwas Neues gelernt wurde (das Gesicht reagiert darauf). */
    var insightSeq by mutableIntStateOf(0)
        private set

    @Volatile private var cancelFlag = false
    @Volatile private var activeConn: HttpURLConnection? = null
    @Volatile private var thread: Thread? = null
    private val main = Handler(Looper.getMainLooper())
    private val gains = ArrayList<String>()

    private val ticker = object : Runnable {
        override fun run() {
            try { tick() } catch (e: Exception) { Dbg.d("Lernen: ${e.message?.take(60)}") }
            main.postDelayed(this, 30_000)
        }
    }

    // ------------------------------------------------------------------ Start, Speicher
    @Synchronized fun init(c: Context) {
        if (ctx != null) return
        ctx = c.applicationContext
        val p = pref()
        fun load(key: String, into: ArrayList<JSONObject>) {
            try { val a = JSONArray(p.getString(key, "[]") ?: "[]"); for (i in 0 until a.length()) into.add(a.getJSONObject(i)) } catch (e: Exception) {}
        }
        load("know", know); load("topics", topics); load("queue", queue); load("lessons", lessons); load("log", log)
        meta = try { JSONObject(p.getString("meta", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
        main.postDelayed(ticker, 60_000)
    }

    private fun pref() = ctx!!.getSharedPreferences(PREF, 0)
    private fun arr(l: List<JSONObject>) = JSONArray().also { a -> l.forEach { a.put(it) } }

    @Synchronized private fun save() {
        pref().edit().putString("know", arr(know).toString()).putString("topics", arr(topics).toString())
            .putString("queue", arr(queue).toString()).putString("lessons", arr(lessons).toString())
            .putString("log", arr(log).toString()).putString("meta", meta.toString()).apply()
    }

    fun enabled(c: Context) = c.getSharedPreferences("boris", 0).getBoolean("self_learn", true)

    fun setEnabled(c: Context, on: Boolean) {
        c.getSharedPreferences("boris", 0).edit().putBoolean("self_learn", on).apply()
        if (!on) interrupt()
    }

    private fun now() = System.currentTimeMillis()

    // ------------------------------------------------------------------ Unterbrechen
    /** Sofort pausieren: Abbruch-Flag setzen, laufende Anfrage kappen, Gesicht und Status zurücksetzen. */
    fun interrupt() {
        SelfCoder.interrupt()
        if (!working && thread?.isAlive != true) return
        cancelFlag = true
        val c = activeConn
        if (c != null) Thread { try { c.disconnect() } catch (e: Exception) {} }.start()
        Core.onUi {
            working = false
            if (Core.status.startsWith("LERNE")) Core.status = "BEREIT"
        }
    }

    // ------------------------------------------------------------------ Gespräche merken (Material zum Lernen)
    private val sensitive = listOf("passwort", "iban", "kreditkarte", "pin ", "cvv", "geheimzahl", "tan ")

    @Synchronized fun logInteraction(u: String, r: String, ok: Boolean) {
        if (ctx == null || u.trim().length < 3) return
        val low = u.lowercase()
        if (sensitive.any { low.contains(it) }) return
        log.add(JSONObject().put("ts", now()).put("u", u.trim().take(200)).put("r", r.trim().take(160)).put("ok", ok).put("rev", false))
        while (log.size > 150) log.removeAt(0)
        save()
    }

    // ------------------------------------------------------------------ Taktgeber
    private fun tick() {
        val c = ctx ?: return
        if (thread?.isAlive == true) return
        if (!canLearn(c)) return
        start(c, false)
    }

    private fun canLearn(c: Context): Boolean {
        if (!enabled(c) || Core.key(c).isBlank()) return false
        val n = now()
        if (Core.voiceMode == 2 || Core.busy || PhoneAgent.running || Hub.speakingNow()) return false
        if (n - Core.lastInteraction < IDLE_MS) return false
        if (n < meta.optLong("backoff")) return false
        if (n - meta.optLong("lastEnd") < GAP_MS) return false
        if (meta.optString("day") == dayKey() && meta.optInt("dayCount") >= DAILY_MAX) return false
        return online(c) && batteryOk(c)
    }

    private fun dayKey() = java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(java.util.Date())

    private fun online(c: Context): Boolean {
        val cm = c.getSystemService(ConnectivityManager::class.java) ?: return false
        val net = cm.activeNetwork ?: return false
        val cap = cm.getNetworkCapabilities(net) ?: return false
        return cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) && cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    private fun batteryOk(c: Context): Boolean {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return true
        val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1); val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        return charging || lvl < 0 || lvl * 100f / max(1, sc) >= 20f
    }

    /** Manuell aus den Einstellungen: ignoriert Ruhezeit und Pausen, nicht aber die Abbruchlogik. */
    fun startNow(c: Context): String {
        if (!enabled(c)) return "Selbstlernen ist ausgeschaltet."
        if (Core.key(c).isBlank()) return "Kein API-Key."
        if (thread?.isAlive == true) return "Boris lernt bereits."
        if (!online(c)) return "Keine Internetverbindung."
        start(c, true)
        return "Lernsitzung gestartet."
    }

    private fun start(c: Context, force: Boolean) {
        cancelFlag = false
        val th = Thread {
            try { session(force) } catch (e: GeminiClient.Cancelled) { Dbg.d("Lernen: pausiert")
            } catch (e: Throwable) { Dbg.d("Lernen: ${e.message?.take(70)}") } finally { finish() }
        }
        thread = th
        th.start()
    }

    private fun phase(s: String) {
        if (cancelFlag) return
        Core.onUi { if (working && !Core.busy && !cancelFlag) Core.status = s.uppercase() }
    }

    private fun finish() {
        activeConn = null
        synchronized(this) { meta.put("lastEnd", now()); save() }
        val g = ArrayList(gains); gains.clear()
        Core.onUi {
            working = false
            if (Core.status.startsWith("LERNE")) Core.status = "BEREIT"
            if (g.isNotEmpty()) {
                Core.messages.add(Msg(2, "Gelernt: " + g.first().take(90) + if (g.size > 1) " (+${g.size - 1} weitere)" else ""))
            }
        }
    }

    private fun gained(text: String) { gains.add(text); Core.onUi { insightSeq++ } }

    // ------------------------------------------------------------------ Sitzung
    private fun session(force: Boolean) {
        Core.onUi { working = true; if (!Core.busy) Core.status = "LERNE …" }
        gains.clear()
        maintain()
        val task = pick()
        if (task == null) {
            Dbg.d("Lernen: gerade nichts Sinnvolles zu tun")
            if (force) Core.onUi { Core.messages.add(Msg(2, "Lernen: noch zu wenig Gespräche oder Wissen über dich, um gezielt zu lernen.")) }
            synchronized(this) { meta.put("backoff", now() + 20 * 60 * 1000L) }
            return
        }
        Dbg.d("Lernen: $task")
        synchronized(this) {
            val d = dayKey()
            if (meta.optString("day") != d) meta.put("day", d).put("dayCount", 0)
            meta.put("dayCount", meta.optInt("dayCount") + 1)
        }
        when (task) {
            Task.REVIEW -> doReview()
            Task.RESEARCH -> doResearch()
            Task.VERIFY -> doVerify()
            Task.CONNECT -> doConnect()
            Task.GAPS -> doGaps()
            Task.CODE -> doCode()
        }
    }

    @Synchronized private fun due(): List<JSONObject> =
        know.filter { it.optInt("ttl") == 0 && it.optString("kind") == "fakt" && now() - it.optLong("v") > 21 * DAY }.sortedBy { it.optLong("v") }

    @Synchronized private fun profileSize() = Brain.all().size + log.size + topics.size

    private fun pick(): Task? {
        val n = now()
        val unrev = synchronized(this) { log.count { !it.optBoolean("rev") } }
        if (unrev >= 5 || (unrev >= 1 && n - meta.optLong("lastReview") > DAY)) return Task.REVIEW
        if (synchronized(this) { queue.isNotEmpty() }) return Task.RESEARCH
        if (due().isNotEmpty()) return Task.VERIFY
        if (synchronized(this) { know.size } >= 8 && n - meta.optLong("lastConnect") > 3 * DAY) return Task.CONNECT
        if (profileSize() >= 3 && n - meta.optLong("lastGaps") > 12 * HOUR) return Task.GAPS
        // Wenn im Wissenssystem gerade nichts Dringendes ansteht, nutzt Boris seine
        // Ruhephase auch für eine kleine, begründete Self-Coding-Verbesserung.
        if (n - meta.optLong("lastCode") > 30 * 60 * 1000L) return Task.CODE
        return null
    }

    // ------------------------------------------------------------------ Pflege
    @Synchronized private fun maintain() {
        val n = now()
        know.removeAll { it.optInt("ttl") > 0 && n > it.optLong("ts") + it.optInt("ttl") * DAY }
        queue.removeAll { n - it.optLong("ts") > 30 * DAY || it.optInt("tries") >= 2 }
        if (meta.optLong("lastDecay") < n - DAY) {
            for (t in topics) t.put("w", t.optDouble("w") * 0.97)
            topics.removeAll { it.optDouble("w") < 0.3 }
            meta.put("lastDecay", n)
        }
        save()
    }

    private fun doCode() {
        val c = ctx ?: return
        phase("ENTWICKLE …")
        val result = try { SelfCoder.autonomousPass(c) } catch (e: Exception) {
            "Self-Coding: ${e.message}"
        }
        synchronized(this) {
            meta.put("lastCode", now())
            meta.put("codeResult", result.take(500))
            save()
        }
        if (result.startsWith("Änderung übernommen")) gained(result.removePrefix("Änderung übernommen:").trim())
        else if (result.startsWith("Fehler")) Dbg.d(result)
    }

    // ------------------------------------------------------------------ Hilfen
    private class Res(val text: String, val sources: List<String>)

    private fun tok(s: String): Set<String> = Regex("[a-zäöüß0-9]{4,}").findAll(s.lowercase()).map { it.value }.toSet()
    private fun jac(a: Set<String>, b: Set<String>): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val i = a.count { it in b }
        return i.toDouble() / (a.size + b.size - i)
    }

    private fun json(t: String): JSONObject? {
        val a = t.indexOf('{'); val b = t.lastIndexOf('}')
        if (a < 0 || b <= a) return null
        return try { JSONObject(t.substring(a, b + 1)) } catch (e: Exception) { null }
    }

    private fun ask(system: String, prompt: String, grounded: Boolean): Res? {
        val c = ctx ?: return null
        val key = Core.key(c)
        if (key.isBlank() || cancelFlag) return null
        val h = JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt))))
        val tools = if (grounded) JSONArray().put(JSONObject().put("google_search", JSONObject())) else JSONArray()
        val models = if (grounded) listOf("gemini-flash-latest", "gemini-3.5-flash-lite", "gemini-flash-lite-latest")
                     else listOf("gemini-3.5-flash-lite", "gemini-flash-lite-latest")
        try {
            val res = GeminiClient.generate(key, system, tools, h, models, { activeConn = it }, { cancelFlag })
            activeConn = null
            val cand = res.optJSONArray("candidates")?.optJSONObject(0) ?: return null
            val parts = cand.optJSONObject("content")?.optJSONArray("parts") ?: return null
            val text = (0 until parts.length()).map { parts.getJSONObject(it) }.filter { !it.optBoolean("thought") }.joinToString("") { it.optString("text") }
            val src = LinkedHashSet<String>()
            val ch = cand.optJSONObject("groundingMetadata")?.optJSONArray("groundingChunks")
            if (ch != null) for (i in 0 until ch.length()) {
                val w = ch.getJSONObject(i).optJSONObject("web") ?: continue
                val d = w.optString("title").ifBlank { try { URL(w.optString("uri")).host } catch (e: Exception) { "" } }
                if (d.isNotBlank()) src.add(d.lowercase().removePrefix("www."))
            }
            return Res(text, src.toList())
        } catch (e: GeminiClient.Cancelled) { throw e
        } catch (e: GeminiClient.ApiException) {
            Dbg.d("Lernen: API ${e.code}")
            if (e.code in listOf(400, 401, 403)) synchronized(this) { meta.put("backoff", now() + 6 * HOUR) }
        } catch (e: Exception) {
            if (cancelFlag) throw GeminiClient.Cancelled()
            Dbg.d("Lernen: ${e.message?.take(60)}")
            if (e.message?.contains("überlastet") == true) synchronized(this) { meta.put("backoff", now() + 45 * 60 * 1000L) }
        }
        return null
    }

    private fun profile(): String {
        val tp = synchronized(this) { topics.sortedByDescending { it.optDouble("w") }.take(8).joinToString(", ") { it.getString("n") } }
        val ls = synchronized(this) { lessons.takeLast(5).joinToString("; ") { it.getString("t") } }
        return "Gespeichertes über den Nutzer:\n${Brain.prompt().take(1400)}\nInteressen: ${tp.ifBlank { "(noch unbekannt)" }}" +
            (if (ls.isNotBlank()) "\nBekannte Hinweise: $ls" else "")
    }

    private fun nowText() = java.text.SimpleDateFormat("EEEE, dd.MM.yyyy", java.util.Locale.GERMAN).format(java.util.Date())

    @Synchronized private fun bumpTopic(name: String, w: Double) {
        val n = name.trim().lowercase().take(40)
        if (n.length < 3) return
        val ex = topics.firstOrNull { it.getString("n") == n }
        if (ex != null) ex.put("w", min(10.0, ex.optDouble("w") * 0.9 + w)).put("ts", now())
        else topics.add(JSONObject().put("n", n).put("w", w).put("ts", now()))
        if (topics.size > 40) { topics.sortByDescending { it.optDouble("w") }; while (topics.size > 40) topics.removeAt(topics.size - 1) }
    }

    @Synchronized private fun enqueue(q0: String, topic: String, prio: Int): Boolean {
        val q = q0.trim().take(160)
        if (q.length < 12) return false
        val tk = tok(q)
        if (queue.any { jac(tok(it.getString("q")), tk) >= 0.6 }) return false
        if (know.any { jac(tok(it.getString("t")), tk) >= 0.6 }) return false     // schon abgedeckt
        queue.add(JSONObject().put("q", q).put("topic", topic.ifBlank { "allgemein" }.take(40)).put("p", prio.coerceIn(1, 5)).put("ts", now()).put("tries", 0))
        if (queue.size > MAX_QUEUE) {
            queue.sortWith(compareByDescending<JSONObject> { it.getInt("p") }.thenByDescending { it.getLong("ts") })
            while (queue.size > MAX_QUEUE) queue.removeAt(queue.size - 1)
        }
        return true
    }

    /** Speichert Wissen nur, wenn es nicht schon (sinngemäß) vorhanden ist. true = wirklich neu. */
    @Synchronized private fun addKnow(t0: String, topic: String, kind: String, conf: Double, src: List<String>, ttl: Int): Boolean {
        val t = t0.trim().replace(Regex("\\s+"), " ").take(240)
        if (t.length < 12) return false
        val tk = tok(t)
        for (k in know) if (jac(tk, tok(k.getString("t"))) >= 0.7) {
            k.put("v", now()).put("conf", max(k.optDouble("conf"), conf)); return false
        }
        know.add(JSONObject().put("t", t).put("topic", topic.take(40)).put("kind", kind).put("conf", conf)
            .put("src", JSONArray(src.take(3))).put("ts", now()).put("v", now()).put("ttl", ttl).put("id", now() * 100 + (idSeq++ % 100)))
        if (know.size > MAX_KNOW) prune()
        return true
    }

    private fun topicWeight(topic: String): Double =
        topics.firstOrNull { topic.lowercase().contains(it.getString("n")) || it.getString("n").contains(topic.lowercase()) }?.optDouble("w") ?: 0.0

    private fun score(k: JSONObject): Double {
        val age = (now() - k.optLong("v")).toDouble() / (180 * DAY)
        return k.optDouble("conf") * 2 + (1.0 - min(1.0, age)) + topicWeight(k.optString("topic")) / 10.0
    }

    private fun prune() {
        know.sortByDescending { score(it) }
        while (know.size > MAX_KNOW - 20) know.removeAt(know.size - 1)
    }

    // ------------------------------------------------------------------ 1) Gespräche auswerten
    private fun doReview() {
        phase("Lerne · Gespräche auswerten")
        val items = synchronized(this) { log.filter { !it.optBoolean("rev") }.takeLast(30) }
        if (items.isEmpty()) return
        val conv = items.mapIndexed { i, o ->
            "${i + 1}. Nutzer: ${o.getString("u")} | Boris: ${o.optString("r")}${if (!o.optBoolean("ok", true)) " [FEHLGESCHLAGEN]" else ""}"
        }.joinToString("\n")
        val sys = "Du wertest Gespräche eines Sprachassistenten namens Boris mit seinem Nutzer aus, damit Boris langfristig nützlicher wird. " +
            "Sei streng: nur Belegtes, nichts erfinden. Antworte ausschließlich mit einem JSON-Objekt."
        val p = "Bereits gespeichert:\n${profile()}\n\nGespräche:\n$conv\n\n" +
            "Liefere höchstens 3 Einträge je Liste als JSON:\n" +
            "{\"facts\":[{\"t\":\"dauerhafte Tatsache über den Nutzer, vom Nutzer selbst gesagt, noch nicht gespeichert\",\"c\":\"person|vorliebe|gewohnheit|wichtig|app|allgemein\"}]," +
            "\"topics\":[{\"name\":\"Thema, das den Nutzer erkennbar interessiert\",\"weight\":1-5}]," +
            "\"lessons\":[{\"t\":\"Verhaltenshinweis für Boris, z. B. wie Boris eine wiederkehrende oder fehlgeschlagene Anfrage besser lösen soll\",\"evidence\":Anzahl der Gespräche, die das belegen}]," +
            "\"gaps\":[{\"q\":\"konkrete, per Websuche beantwortbare Frage, deren Antwort dem Nutzer künftig helfen würde\",\"topic\":\"Thema\",\"prio\":1-5}]}\n" +
            "Leere Listen sind völlig in Ordnung. Keine Wiederholungen von Bekanntem."
        val r = ask(sys, p, false) ?: return
        val j = json(r.text) ?: return
        var n = 0
        j.optJSONArray("facts")?.let { a -> for (i in 0 until min(3, a.length())) {
            val f = a.optJSONObject(i) ?: continue
            val t = f.optString("t"); if (t.length < 8) continue
            if (Brain.add(t, f.optString("c", "allgemein").ifBlank { "allgemein" }) == "Gemerkt.") { n++; gained(t) }
        } }
        j.optJSONArray("topics")?.let { a -> for (i in 0 until min(4, a.length())) {
            val o = a.optJSONObject(i) ?: continue; bumpTopic(o.optString("name"), o.optDouble("weight", 1.0).coerceIn(1.0, 5.0))
        } }
        j.optJSONArray("lessons")?.let { a -> for (i in 0 until min(3, a.length())) {
            val o = a.optJSONObject(i) ?: continue
            val t = o.optString("t").trim().take(200)
            if (t.length < 12 || o.optInt("evidence") < 2) continue     // nur, was sich mehrfach gezeigt hat
            val added = synchronized(this) {
                val tk = tok(t)
                if (lessons.any { jac(tok(it.getString("t")), tk) >= 0.6 }) false
                else { lessons.add(JSONObject().put("t", t).put("ts", now())); while (lessons.size > MAX_LESSONS) lessons.removeAt(0); true }
            }
            if (added) { n++; gained("Hinweis: $t") }
        } }
        j.optJSONArray("gaps")?.let { a -> for (i in 0 until min(3, a.length())) {
            val o = a.optJSONObject(i) ?: continue
            enqueue(o.optString("q"), o.optString("topic"), o.optInt("prio", 3))
        } }
        synchronized(this) { items.forEach { it.put("rev", true) }; meta.put("lastReview", now()); save() }
        Dbg.d("Lernen: Auswertung, $n neu")
    }

    // ------------------------------------------------------------------ 2) Recherchieren
    private fun doResearch() {
        val todo = synchronized(this) { queue.sortedWith(compareByDescending<JSONObject> { it.getInt("p") }.thenBy { it.getLong("ts") }).take(2) }
        for (q in todo) {
            if (cancelFlag) throw GeminiClient.Cancelled()
            val question = q.getString("q"); val topic = q.optString("topic", "allgemein")
            phase("Lerne · $topic")
            val tk = tok(question)
            val related = synchronized(this) { know.filter { jac(tok(it.getString("t")), tk) > 0.1 }.take(5).joinToString("\n") { "- " + it.getString("t") } }
            val sys = "Du bist ein gewissenhafter Recherche-Assistent für einen persönlichen KI-Assistenten. Nutze die Google-Suche. " +
                "Nimm nur Aussagen auf, die Suchergebnisse belegen. Antworte ausschließlich mit einem JSON-Objekt."
            val p = "Heute ist ${nowText()}. Der Nutzer wohnt in Deutschland.\nFrage: $question\n${profile()}\n" +
                (if (related.isNotBlank()) "Schon bekannt (nicht wiederholen):\n$related\n" else "") +
                "Liefere 1 bis 3 eigenständig verständliche, überprüfbare Fakten auf Deutsch (je höchstens 200 Zeichen, keine Meinungen, keine Spekulation, nur das für den Nutzer Nützliche). " +
                "conf = wie gut belegt (0.0 bis 1.0), ttl_days = 0 wenn zeitlos, sonst nach wie vielen Tagen der Fakt veralten kann.\n" +
                "JSON: {\"facts\":[{\"t\":\"...\",\"conf\":0.9,\"ttl_days\":0}]}. Ergibt die Suche nichts Verlässliches: {\"facts\":[]}."
            val r = ask(sys, p, true)
            var stored = 0
            if (r != null && r.sources.isNotEmpty()) {           // ohne belegte Quellen wird nichts gespeichert
                val facts = json(r.text)?.optJSONArray("facts")
                if (facts != null) for (i in 0 until min(3, facts.length())) {
                    val f = facts.optJSONObject(i) ?: continue
                    val conf = f.optDouble("conf", 0.0)
                    if (conf < 0.7) continue
                    val c2 = if (r.sources.size >= 2) conf else conf * 0.92
                    if (addKnow(f.optString("t"), topic, "fakt", c2, r.sources, f.optInt("ttl_days", 0).coerceIn(0, 365))) { stored++; gained(f.optString("t").trim()) }
                }
            }
            synchronized(this) {
                if (r != null && (stored > 0 || r.sources.isNotEmpty())) queue.remove(q)
                else { q.put("tries", q.optInt("tries") + 1) }
                save()
            }
            Dbg.d("Lernen: „${question.take(40)}“ → $stored neu")
        }
    }

    // ------------------------------------------------------------------ 3) Überprüfen
    private fun doVerify() {
        phase("Lerne · Wissen prüfen")
        val batch = due().take(4)
        if (batch.isEmpty()) return
        val list = batch.mapIndexed { i, k -> "${i + 1}. ${k.getString("t")}" }.joinToString("\n")
        val sys = "Du überprüfst gespeichertes Wissen mit der Google-Suche auf Richtigkeit und Aktualität. Antworte ausschließlich mit einem JSON-Objekt."
        val p = "Heute ist ${nowText()}.\nPrüfe diese Aussagen:\n$list\n" +
            "JSON: {\"results\":[{\"i\":1,\"status\":\"bestaetigt|veraltet|falsch|unklar\",\"korrektur\":\"korrigierte Aussage (höchstens 200 Zeichen) oder leer\"}]}"
        val r = ask(sys, p, true) ?: return
        val res = json(r.text)?.optJSONArray("results") ?: return
        var changed = 0
        synchronized(this) {
            for (x in 0 until res.length()) {
                val o = res.optJSONObject(x) ?: continue
                val k = batch.getOrNull(o.optInt("i") - 1) ?: continue
                val korr = o.optString("korrektur").trim()
                when (o.optString("status")) {
                    "bestaetigt" -> if (r.sources.isNotEmpty()) k.put("v", now()).put("conf", min(1.0, k.optDouble("conf") + 0.05))
                    "veraltet", "falsch" -> if (r.sources.isNotEmpty()) {
                        if (korr.length >= 12) { k.put("t", korr.take(240)).put("conf", 0.75).put("v", now()).put("src", JSONArray(r.sources.take(3))); changed++ }
                        else { know.remove(k); changed++ }
                    }
                    else -> { k.put("conf", k.optDouble("conf") - 0.15); k.put("v", now() - 14 * DAY); if (k.optDouble("conf") < 0.4) know.remove(k) }
                }
            }
            save()
        }
        if (changed > 0) gained("Wissen aktualisiert ($changed)")
        Dbg.d("Lernen: Prüfung, $changed korrigiert")
    }

    // ------------------------------------------------------------------ 4) Verknüpfen
    private fun doConnect() {
        phase("Lerne · Zusammenhänge")
        val pool = synchronized(this) {
            know.filter { it.optString("kind") == "fakt" }.sortedByDescending { topicWeight(it.optString("topic")) + it.optDouble("conf") }.take(14)
        }
        meta.put("lastConnect", now())
        if (pool.size < 6) return
        val list = pool.mapIndexed { i, k -> "${i + 1}. [${k.optString("topic")}] ${k.getString("t")}" }.joinToString("\n")
        val sys = "Du findest nützliche Zusammenhänge im Wissen eines persönlichen Assistenten. Erfinde nichts, nur logische Schlüsse aus den gegebenen Einträgen. Antworte ausschließlich mit JSON."
        val p = "${profile()}\n\nWissen:\n$list\n\nFinde höchstens 2 Zusammenhänge zwischen mindestens zwei Einträgen (oder einem Eintrag und dem Nutzerprofil), die dem Nutzer als Assistent konkret helfen können. " +
            "JSON: {\"links\":[{\"t\":\"Zusammenhang in einem Satz (höchstens 220 Zeichen)\",\"basis\":[Nummern der Einträge]}]}. Leere Liste ist in Ordnung."
        val r = ask(sys, p, false) ?: return
        val links = json(r.text)?.optJSONArray("links") ?: return
        for (i in 0 until min(2, links.length())) {
            val o = links.optJSONObject(i) ?: continue
            val basis = o.optJSONArray("basis") ?: continue
            val valid = (0 until basis.length()).map { basis.optInt(it) }.filter { it in 1..pool.size }.toSet()
            if (valid.size < 2) continue
            val cnt = synchronized(this) { know.count { it.optString("kind") == "zusammenhang" } }
            if (cnt >= 40) break
            val topic = pool[valid.first() - 1].optString("topic")
            if (addKnow(o.optString("t"), topic, "zusammenhang", 0.6, emptyList(), 0)) gained(o.optString("t").trim())
        }
        synchronized(this) { save() }
    }

    // ------------------------------------------------------------------ 5) Wissenslücken erkennen
    private fun doGaps() {
        phase("Lerne · Lücken erkennen")
        meta.put("lastGaps", now())
        val have = synchronized(this) { know.sortedByDescending { it.optLong("ts") }.take(40).joinToString("\n") { "- " + it.getString("t").take(80) } }
        val pending = synchronized(this) { queue.joinToString("\n") { "- " + it.getString("q") } }
        val recent = synchronized(this) { log.takeLast(15).joinToString("\n") { "- " + it.getString("u") } }
        val sys = "Du planst, was ein persönlicher KI-Assistent als Nächstes lernen sollte, damit er diesem Nutzer immer besser hilft. " +
            "Wähle gezielt und relevant, nichts Beliebiges. Antworte ausschließlich mit JSON."
        val p = "Heute ist ${nowText()}.\n${profile()}\nLetzte Anfragen des Nutzers:\n${recent.ifBlank { "(keine)" }}\n" +
            "Bereits gelernt:\n${have.ifBlank { "(nichts)" }}\nBereits geplant:\n${pending.ifBlank { "(nichts)" }}\n\n" +
            "Nenne höchstens 4 neue, konkrete und per Websuche beantwortbare Lernfragen, die zu den Interessen, dem Alltag oder den Anfragen des Nutzers passen und noch nicht abgedeckt sind. " +
            "JSON: {\"gaps\":[{\"q\":\"Frage\",\"topic\":\"Thema\",\"prio\":1-5}]}"
        val r = ask(sys, p, false) ?: return
        val gaps = json(r.text)?.optJSONArray("gaps") ?: return
        var n = 0
        for (i in 0 until min(4, gaps.length())) {
            val o = gaps.optJSONObject(i) ?: continue
            if (enqueue(o.optString("q"), o.optString("topic"), o.optInt("prio", 3))) n++
        }
        synchronized(this) { save() }
        Dbg.d("Lernen: $n neue Lernfragen")
    }

    // ------------------------------------------------------------------ Nutzung des Gelernten
    /** Relevantes Wissen und Verhaltenshinweise für den System-Prompt (leer, solange nichts gelernt wurde). */
    @Synchronized fun prompt(query: String): String {
        if (ctx == null || (know.isEmpty() && lessons.isEmpty())) return ""
        val sb = StringBuilder()
        if (know.isNotEmpty()) {
            val q = tok(query)
            val ranked = know.sortedByDescending { jac(q, tok(it.getString("t") + " " + it.optString("topic"))) * 4 + score(it) / 3.0 }
            val pick = ranked.take(10)
            sb.append("Selbst Gelerntes (aus eigener Recherche, je mit Stand; bei Aktuellem trotzdem web_answer nutzen, nutze es unaufdringlich):\n")
            val fmt = java.text.SimpleDateFormat("dd.MM.yy", java.util.Locale.GERMAN)
            for (k in pick) {
                val line = "- [${k.optString("topic")} · ${fmt.format(java.util.Date(k.optLong("v")))}] ${k.getString("t")}\n"
                if (sb.length + line.length > 1800) break
                sb.append(line)
            }
        }
        if (lessons.isNotEmpty()) {
            sb.append("Gelernte Hinweise für dein Verhalten:\n")
            lessons.takeLast(8).forEach { sb.append("- ").append(it.getString("t")).append('\n') }
        }
        return sb.toString()
    }

    // ------------------------------------------------------------------ Werkzeuge und Anzeige
    @Synchronized fun addTopic(topic: String): String {
        val t = topic.trim()
        if (t.length < 3) return "Welches Thema denn?"
        bumpTopic(t, 3.0)
        enqueue("Was sind die wichtigsten, aktuellen und nützlichen Fakten zum Thema $t?", t, 5)
        save()
        return "Okay, das Thema „$t“ lerne ich in meiner nächsten Ruhephase."
    }

    @Synchronized fun report(): String {
        if (know.isEmpty() && lessons.isEmpty()) return "INFO: Ich habe noch nichts Eigenes gelernt (Wissen: 0, offene Lernfragen: ${queue.size}). Lernen startet nach etwa 10 Minuten Ruhe."
        val recent = know.sortedByDescending { it.optLong("ts") }.take(5).joinToString(" | ") { it.getString("t").take(120) }
        val tp = topics.sortedByDescending { it.optDouble("w") }.take(5).joinToString(", ") { it.getString("n") }
        return "INFO: Wissensstand: ${know.size} Einträge, ${lessons.size} Verhaltenshinweise, ${queue.size} offene Lernfragen. " +
            "Interessen: ${tp.ifBlank { "noch unklar" }}. Zuletzt gelernt: $recent. Fasse das kurz und natürlich zusammen."
    }

    @Synchronized fun statusLine(c: Context): String {
        if (!enabled(c)) return "aus"
        val last = meta.optLong("lastEnd")
        val ago = if (last == 0L) "noch keine Sitzung" else {
            val m = (now() - last) / 60000
            "zuletzt vor " + if (m < 60) "$m Min." else if (m < 1440) "${m / 60} Std." else "${m / 1440} Tg."
        }
        return "lernt nach 10 Min. Ruhe · ${know.size} Einträge · $ago"
    }

    @Synchronized fun knowledgeCount() = know.size

    /** Zeilen für die Gehirn-Ansicht: Thema, Text, ID. */
    @Synchronized fun rows(): List<Triple<String, String, Long>> =
        know.sortedByDescending { it.optLong("ts") }.map { Triple(it.optString("topic").ifBlank { "gelernt" }, it.getString("t"), it.optLong("id")) }

    @Synchronized fun removeKnowledge(id: Long) { know.removeAll { it.optLong("id") == id }; save() }
}
