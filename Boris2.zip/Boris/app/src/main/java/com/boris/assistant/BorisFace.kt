package com.boris.assistant

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

enum class FaceMode { IDLE, LISTEN, THINK, SPEAK, LEARN }

private fun sm(x: Float): Float { val c = x.coerceIn(0f, 1f); return c * c * (3f - 2f * c) }
private fun hash01(x: Int): Float {
    var h = x * -1640531535
    h = h xor (h ushr 15); h *= 0x2c1b3c6d; h = h xor (h ushr 12)
    return (h and 0xffff) / 65535f
}

/** Eine gedämpfte Feder: folgt einem Ziel weich, mit leichtem Überschwingen (wirkt organisch statt linear). */
private class Spring(var v: Float, private val freq: Float = 12f, private val damp: Float = 0.88f) {
    private var vel = 0f
    fun step(target: Float, dt: Float): Float {
        val f = freq
        val d = damp
        vel += ((target - v) * f * f - vel * 2f * d * f) * dt
        // Anti-Explosion bei Frame-Drops
        val maxVel = 80f + f * 4f
        if (vel > maxVel) vel = maxVel else if (vel < -maxVel) vel = -maxVel
        v += vel * dt
        return v
    }
    fun kick(impulse: Float) { vel += impulse * 0.72f }
}

/**
 * Boris' Gesicht: zwei Kapselaugen und ein Mund aus feinen Linien, wie ein ruhiges, futuristisches KI-Display.
 * Alles ist Federsimulation: Blinzeln, Blickbewegungen, Kopfneigung, Ausdruck und Mundform.
 * Zuhören, Denken, Sprechen und Lernen sind weich überblendete Zustände; der Mund folgt der echten Stimme.
 */
class BorisFace {
    private var cx = 0f; private var cy = 0f; private var u = 1f
    private var t = 0f

    // Zustandsgewichte (überblenden weich)
    private var wIdle = 1f; private var wListen = 0f; private var wThink = 0f; private var wSpeak = 0f; private var wLearn = 0f

    // Ausdrucks-Federn (etwas weicher + stärker gedämpft = smoother)
    private val eyeOpen = Spring(1f, 18f, 0.9f)      // 0 geschlossen .. 1 normal .. >1 weit
    private val eyeW = Spring(1f, 10f, 0.9f)
    private val happy = Spring(0f, 8f, 0.92f)        // 0 neutral .. 1 strahlend (Augenbögen, breites Lächeln)
    private val tiltL = Spring(0f, 9f, 0.9f); private val tiltR = Spring(0f, 9f, 0.9f)
    private val sizeL = Spring(1f, 10f, 0.9f); private val sizeR = Spring(1f, 10f, 0.9f)
    private val gazeX = Spring(0f, 13f, 0.88f); private val gazeY = Spring(0f, 13f, 0.88f)
    private val headRot = Spring(0f, 6.5f, 0.85f)
    private val headX = Spring(0f, 7f, 0.88f); private val headY = Spring(0f, 7f, 0.88f)
    private val smile = Spring(0.35f, 10f, 0.9f)     // Mundkrümmung -1 traurig .. 1 breit lächelnd
    private val mouthW = Spring(1f, 10f, 0.9f)
    private val mouthOpen = Spring(0f, 24f, 0.9f)    // Sprechöffnung (schnell, aber nicht nervös)
    private val mouthShift = Spring(0f, 9f, 0.9f)
    private val mouthWave = Spring(0f, 7f, 0.9f)

    // Stimme (geglättet)
    private var lvl = 0f; private var body = 0f; private var bright = 0f; private var pitch = 0f; private var mic = 0f
    private var lastSeq = 0

    // Blinzeln
    private var blinkT = 2.5f; private var blinkPhase = -1f; private var doubleBlink = false
    // Blickbewegung (Sakkaden)
    private var gazeTimer = 1.5f; private var tgx = 0f; private var tgy = 0f
    // Mikro-Ausdrücke im Ruhezustand
    private var microTimer = 7f; private var microKind = 0; private var microLeft = 0f
    // kurze Reaktionen (z. B. etwas gelernt)
    private var flashHappy = 0f
    private var lastInsight = -1
    private var lastMode = FaceMode.IDLE; private var modeAge = 0f
    // Berührung
    private var touchX = 0f; private var touchY = 0f; private var touchW = 0f
    private var learnWork = 0f

    private class Particle { var x = 0f; var y = 0f; var life = 1f; var spd = 0f; var seed = 0 }
    private val parts = Array(14) { Particle().also { p -> p.life = 1f; p.seed = it } }
    private var nextPart = 0f

    private val path = Path(); private val lowerP = Path(); private val innerP = Path()

    fun update(dt0: Float, mode: FaceMode, va: VoiceAnalyzer, speaking: Boolean, micLevel: Float, learnWorking: Boolean,
               insightSeq: Int, touching: Boolean, tdx: Float, tdy: Float, cx: Float, cy: Float, unit: Float) {
        this.cx = cx; this.cy = cy; this.u = unit
        // Festere Substeps halten die Feder stabil und vermeiden Ruckeln bei 30/45/60 Hz
        val dt = dt0.coerceIn(0.001f, 0.05f)
        val n = when {
            dt > 0.028f -> 3
            dt > 0.016f -> 2
            else -> 1
        }
        repeat(n) { step(dt / n, mode, va, speaking, micLevel, learnWorking, insightSeq, touching, tdx, tdy) }
    }

    private fun step(dt: Float, mode: FaceMode, va: VoiceAnalyzer, speaking: Boolean, micLevel: Float, learnWorking: Boolean,
                     insightSeq: Int, touching: Boolean, tdx: Float, tdy: Float) {
        t += dt
        if (mode != lastMode) { lastMode = mode; modeAge = 0f; onModeChange(mode) }
        modeAge += dt
        // LiveRuntime kann modeBlend überschreiben (sofort, ohne Rebuild)
        val liveBlend = try {
            val f = LiveRuntime.faceParams(BorisApp.appCtx())
            if (f.has("modeBlend")) f.optDouble("modeBlend", 2.4).toFloat().coerceIn(1.2f, 5f) else 2.4f
        } catch (_: Exception) { 2.4f }
        val kw = 1f - exp(-dt * liveBlend)
        wIdle += ((if (mode == FaceMode.IDLE) 1f else 0f) - wIdle) * kw
        wListen += ((if (mode == FaceMode.LISTEN) 1f else 0f) - wListen) * kw
        wThink += ((if (mode == FaceMode.THINK) 1f else 0f) - wThink) * kw
        wSpeak += ((if (mode == FaceMode.SPEAK) 1f else 0f) - wSpeak) * kw
        wLearn += ((if (mode == FaceMode.LEARN) 1f else 0f) - wLearn) * kw
        learnWork += ((if (learnWorking) 1f else 0f) - learnWork) * (1f - exp(-dt * 1.6f))

        // Stimme: schnell hinein, langsam heraus
        val tl = if (speaking) va.level else 0f
        val tb = if (speaking) va.body else 0f
        val tbr = if (speaking) va.bright else 0f
        val tp = if (speaking) va.pitch else 0f
        lvl += (tl - lvl) * (1f - exp(-dt * (if (tl > lvl) 30f else 11f)))
        body += (tb - body) * (1f - exp(-dt * 6f))
        bright += (tbr - bright) * (1f - exp(-dt * 8f))
        pitch += (tp - pitch) * (1f - exp(-dt * 6f))
        mic += (micLevel - mic) * (1f - exp(-dt * (if (micLevel > mic) 18f else 6f)))

        // Neue Erkenntnis beim Lernen: kurzes Aufleuchten
        if (lastInsight < 0) lastInsight = insightSeq
        if (insightSeq != lastInsight) { lastInsight = insightSeq; flashHappy = 1f; happy.kick(6f); eyeOpen.kick(4f) }
        flashHappy = max(0f, flashHappy - dt / 1.6f)

        // Silbenstoß: Augen und Kopf reagieren minimal auf jede Betonung
        val seq = va.onsetSeq
        if (speaking && seq != lastSeq) {
            val s = va.onsetStrength.coerceIn(0f, 1f)
            headY.kick(-s * 38f * u / 260f); eyeOpen.kick(s * 1.4f)
            headRot.kick((hash01(seq) - 0.5f) * s * 6f)
        }
        lastSeq = seq

        // ----- Blinzeln (etwas länger = weicher)
        blinkT -= dt
        if (blinkT <= 0f && blinkPhase < 0f) { blinkPhase = 0f }
        var blink = 1f
        if (blinkPhase >= 0f) {
            blinkPhase += dt / 0.22f
            val p = min(blinkPhase, 1f)
            // Smoothstep-ähnliche Kurve statt harter sin²
            blink = 1f - (p * p * (3f - 2f * p))
            if (blinkPhase >= 1f) {
                blinkPhase = -1f
                if (!doubleBlink && hash01((t * 977f).toInt()) < 0.16f) { doubleBlink = true; blinkT = 0.14f }
                else { doubleBlink = false; blinkT = (if (mode == FaceMode.THINK) 3.8f else 2.4f) + hash01((t * 1013f).toInt()) * 4.2f }
            }
        }

        // ----- Blick
        gazeTimer -= dt
        if (gazeTimer <= 0f) {
            val r1 = hash01((t * 811f).toInt() + 3); val r2 = hash01((t * 523f).toInt() + 11)
            when (mode) {
                FaceMode.IDLE -> { tgx = (r1 - 0.5f) * 0.9f; tgy = (r2 - 0.5f) * 0.5f; gazeTimer = 1.2f + r1 * 2.8f }
                FaceMode.LISTEN -> { tgx = (r1 - 0.5f) * 0.18f; tgy = (r2 - 0.5f) * 0.12f; gazeTimer = 1.5f + r2 * 2f }
                FaceMode.THINK -> { tgx = 0.45f + r1 * 0.35f; tgy = -0.55f - r2 * 0.2f; gazeTimer = 0.9f + r2 * 1.2f; if (r1 > 0.55f) tgx = -tgx }
                FaceMode.SPEAK -> { tgx = (r1 - 0.5f) * 0.35f; tgy = (r2 - 0.5f) * 0.2f; gazeTimer = 1.4f + r1 * 2f }
                FaceMode.LEARN -> { tgx = (if (r1 > 0.5f) 1f else -1f) * (0.5f + r2 * 0.3f); tgy = 0.1f + (r2 - 0.5f) * 0.3f; gazeTimer = 0.7f + r1 * 0.8f }
            }
        }
        var gx = tgx; var gy = tgy
        if (touching) {
            val d = max(1f, kotlin.math.sqrt(tdx * tdx + tdy * tdy))
            gx = (tdx / d).coerceIn(-1f, 1f) * min(1f, d / (u * 2f)); gy = (tdy / d).coerceIn(-1f, 1f) * min(1f, d / (u * 2f))
        }
        touchW += ((if (touching) 1f else 0f) - touchW) * (1f - exp(-dt * 8f))
        // Lernen: die Augen "lesen" gleichmäßig von links nach rechts
        if (mode == FaceMode.LEARN) { gx = sin(t * (1.1f + 0.9f * learnWork)) * 0.75f; gy = 0.12f + 0.08f * sin(t * 0.7f) }
        gazeX.step(gx, dt); gazeY.step(gy, dt)

        // ----- Mikro-Ausdrücke im Ruhezustand
        if (mode == FaceMode.IDLE) {
            microTimer -= dt
            if (microTimer <= 0f) {
                microKind = 1 + (hash01((t * 331f).toInt() + 5) * 3.99f).toInt()
                microLeft = 1.4f + hash01((t * 191f).toInt()) * 1.2f
                microTimer = 7f + hash01((t * 613f).toInt() + 2) * 12f
            }
        }
        if (microLeft > 0f) microLeft -= dt else microKind = 0

        // ----- Zielwerte je Zustand
        var tOpen = 1f; var tEW = 1f; var tHappy = 0f; var tTL = 0f; var tTR = 0f; var tSL = 1f; var tSR = 1f
        var tHR = 0f; var tHX = 0f; var tHY = 0f; var tSmile = 0.35f; var tMW = 1f; var tMO = 0f; var tMS = 0f; var tWave = 0f

        // Ruhe: Atmen, kleines Lächeln, Mikro-Ausdrücke
        val br = sin(t * 1.3f)
        if (wIdle > 0.01f) {
            val w = wIdle
            tHY += br * 0.010f * u * w
            tHR += sin(t * 0.37f) * 0.7f * w
            tSmile += (0.08f + 0.04f * br) * w
            when (microKind) {
                1 -> { tHappy += 0.7f * w; tSmile += 0.45f * w; tOpen += 0.0f }                 // kurzes Lächeln
                2 -> { tTL += -9f * w; tSR += 0.12f * w; tHR += -3f * w; tOpen += 0.1f * w }     // neugierig, eine Seite hoch
                3 -> { tHR += 5f * w; tHX += 0.04f * u * w; tSmile += 0.2f * w }                // Kopfneigung
                4 -> { tOpen += -0.35f * w; tSmile += 0.1f * w }                                // kurz träge
            }
        }
        // Zuhören: wach, weit, aufmerksam; reagiert auf die eigene Stimme des Nutzers
        if (wListen > 0.01f) {
            val w = wListen
            tOpen += (0.18f + 0.35f * mic) * w
            tEW += 0.12f * w
            tSL += (0.04f + 0.08f * mic) * w; tSR += (0.04f + 0.08f * mic) * w
            tHR += (-3.5f + sin(t * 0.9f) * 0.8f) * w
            tHY += -0.012f * u * w
            tSmile += (0.1f + 0.15f * mic) * w
            tMW += -0.12f * w
            tHappy += 0.12f * mic * w
        }
        // Denken: Blick nach oben und zur Seite, ein Auge kleiner, Mund schmal und schief
        if (wThink > 0.01f) {
            val w = wThink
            tOpen += -0.12f * w
            tSL += 0.08f * w; tSR += -0.2f * w
            tTL += -8f * w; tTR += -3f * w
            tHR += 2.5f * sin(t * 0.8f) * w + 3f * w
            tSmile += -0.3f * w
            tMW += -0.45f * w
            tMS += 0.22f * w * sin(t * 0.6f + 1f) + 0.18f * w
            tWave += w
        }
        // Lernen: halb geschlossene, konzentrierte Augen, ruhiges zufriedenes Lächeln
        if (wLearn > 0.01f) {
            val w = wLearn
            tOpen += (-0.38f + 0.12f * sin(t * 2.1f) * learnWork) * w
            tEW += 0.05f * w
            tSmile += (0.05f + 0.1f * learnWork) * w
            tMW += -0.2f * w
            tHR += 2f * sin(t * 0.6f) * w
            tHY += -0.01f * u * w
            tHappy += 0.18f * w
        }
        // Sprechen: Ausdruck folgt Satzmelodie und Pegel, Mund folgt der Stimme
        if (wSpeak > 0.01f) {
            val w = wSpeak
            tOpen += (0.04f + 0.14f * lvl) * w
            tHappy += (0.1f + 0.22f * body) * w
            tHR += (pitch * 3.2f + sin(t * 1.4f) * 0.8f) * w
            tHY += -lvl * 0.014f * u * w
            tSmile += 0.2f * w
            val open = (lvl * 0.95f + body * 0.25f).coerceIn(0f, 1f)
            tMO += open * w
            tMW += (0.15f * bright - 0.22f * open) * w
            tMS += pitch * 0.05f * w
        }
        // Kurzer Freudenblitz bei Erkenntnis
        tHappy += 0.9f * sm(flashHappy)
        tSmile += 0.5f * sm(flashHappy)
        // Berührung: Kopf folgt dem Finger leicht
        tHX += gx * 0.05f * u * touchW
        tHY += gy * 0.04f * u * touchW

        eyeOpen.step(tOpen * blink, dt)
        eyeW.step(tEW, dt)
        happy.step(tHappy.coerceIn(0f, 1f), dt)
        tiltL.step(tTL, dt); tiltR.step(tTR, dt)
        sizeL.step(tSL, dt); sizeR.step(tSR, dt)
        headRot.step(tHR, dt); headX.step(tHX, dt); headY.step(tHY, dt)
        smile.step(tSmile, dt); mouthW.step(tMW, dt); mouthOpen.step(tMO, dt)
        mouthShift.step(tMS, dt); mouthWave.step(tWave, dt)

        // ----- Partikel (Lernen: Datenpunkte steigen auf)
        val pRate = wLearn * (0.35f + 0.9f * learnWork)
        nextPart -= dt * pRate * 4f
        for (p in parts) {
            if (p.life < 1f) { p.life += dt / (2.6f - 0.8f * learnWork); p.y -= p.spd * dt }
            else if (nextPart <= 0f && pRate > 0.05f) {
                p.life = 0f; p.seed++
                p.x = (hash01(p.seed * 7 + (t * 100f).toInt()) - 0.5f) * 3.4f
                p.y = 0.9f + hash01(p.seed * 13) * 0.6f
                p.spd = 0.18f + hash01(p.seed * 29) * 0.25f
                nextPart = 1f
            }
        }
    }

    private fun onModeChange(m: FaceMode) {
        when (m) {
            FaceMode.LISTEN -> { eyeOpen.kick(4.5f); headRot.kick(-14f) }  // sanftes Aufhorchen
            FaceMode.THINK -> { eyeOpen.kick(-2f); gazeTimer = 0f }
            FaceMode.SPEAK -> { happy.kick(1.4f); eyeOpen.kick(1.4f) }
            FaceMode.LEARN -> { eyeOpen.kick(-1.8f); gazeTimer = 0f }
            FaceMode.IDLE -> { smile.kick(1.4f) }
        }
        blinkT = min(blinkT, 0.35f)                                      // Moduswechsel mit weichem Blinzeln
    }

    // ------------------------------------------------------------------ Zeichnen
    fun draw(sc: DrawScope, tint: Color, dens: Float) {
        with(sc) {
            val ink = lerp(tint, Color.White, 0.82f)
            val energy = wIdle * 0.2f + wListen * (0.45f + 0.4f * mic) + wThink * 0.5f + wSpeak * (0.45f + 0.5f * lvl) + wLearn * (0.4f + 0.3f * learnWork)
            val E = u * 0.66f                                    // Augenhöhe als Grundmaß
            val hx = cx + headX.v; val hy = cy + headY.v

            // Weicher Schein hinter dem Gesicht
            val glowR = u * 2.6f
            drawCircle(Brush.radialGradient(listOf(tint.copy(alpha = (0.05f + 0.13f * energy).coerceIn(0f, 1f)), Color.Transparent),
                center = Offset(hx, hy), radius = glowR), radius = glowR, center = Offset(hx, hy))

            // Lern-Partikel hinter dem Gesicht
            if (wLearn > 0.02f) for (p in parts) {
                if (p.life >= 1f) continue
                val a = sin(p.life * PI.toFloat()) * 0.55f * wLearn
                val px = hx + p.x * E * 0.62f + sin(t * 0.8f + p.seed) * E * 0.05f
                val py = hy + p.y * E * 1.5f
                drawCircle(ink.copy(alpha = a.coerceIn(0f, 1f)), (1.3f + 1.6f * hash01(p.seed * 5)) * dens, Offset(px, py))
            }

            rotate(headRot.v, Offset(hx, hy + E * 0.6f)) {
                val eyeY = hy - E * 0.62f
                val spacing = E * (0.78f + 0.03f * happy.v)
                val gxPx = gazeX.v * E * 0.20f; val gyPx = gazeY.v * E * 0.14f
                drawEye(Offset(hx - spacing + gxPx * 1.1f, eyeY + gyPx), E, sizeL.v, tiltL.v, ink, dens, true)
                drawEye(Offset(hx + spacing + gxPx * 1.1f, eyeY + gyPx), E, sizeR.v, tiltR.v, ink, dens, false)
                drawMouth(Offset(hx + gxPx * 0.55f + mouthShift.v * E, hy + E * 1.28f + gyPx * 0.4f), E, ink, dens)
            }

            // Denken: drei feine Punkte schweben über dem Gesicht
            if (wThink > 0.03f) for (i in 0 until 3) {
                val ph = (t * 1.6f - i * 0.28f)
                val s = 0.5f + 0.5f * sin(ph * 2f)
                drawCircle(ink.copy(alpha = (0.25f + 0.6f * s) * wThink), (2.2f + 1.6f * s) * dens,
                    Offset(hx + (i - 1) * E * 0.2f + sin(t * 0.8f) * E * 0.05f, hy - E * 1.62f - s * E * 0.05f))
            }
            // Lernen: feine Leselinie unter den Augen
            if (wLearn > 0.03f) {
                val lw = E * 1.5f
                val sx = hx + sin(t * (1.1f + 0.9f * learnWork)) * lw * 0.5f
                drawLine(Brush.horizontalGradient(listOf(Color.Transparent, ink.copy(alpha = 0.55f * wLearn), Color.Transparent),
                    startX = sx - E * 0.5f, endX = sx + E * 0.5f),
                    Offset(sx - E * 0.5f, hy - E * 0.05f), Offset(sx + E * 0.5f, hy - E * 0.05f), 1.6f * dens, StrokeCap.Round)
            }
        }
    }

    private fun DrawScope.drawEye(c: Offset, E: Float, sizeMul: Float, tilt: Float, ink: Color, dens: Float, left: Boolean) {
        val open = eyeOpen.v.coerceIn(0.04f, 1.5f)
        val w = E * 0.22f * eyeW.v * (1f + 0.15f * (1f - min(open, 1f)))   // geschlossen wird das Auge etwas breiter
        val h = E * 0.9f * open * sizeMul
        val hp = happy.v.coerceIn(0f, 1f)
        rotate(if (left) tilt else -tilt, c) {
            // Kapselauge (blendet bei Freude in einen Bogen)
            val capA = 1f - sm(hp * 1.3f)
            if (capA > 0.01f) {
                val hh = max(h * (1f - 0.18f * hp), w)
                val tl = Offset(c.x - w / 2f, c.y - hh / 2f)
                // Schein
                drawRoundRect(ink.copy(alpha = 0.10f * capA), Offset(tl.x - w * 0.5f, tl.y - w * 0.5f), Size(w * 2f, hh + w), CornerRadius(w), style = androidx.compose.ui.graphics.drawscope.Fill)
                drawRoundRect(ink.copy(alpha = 0.95f * capA), tl, Size(w, hh), CornerRadius(w / 2f))
            }
            val arcA = sm((hp - 0.25f) * 1.4f)
            if (arcA > 0.01f) {
                val aw = E * 0.34f; val ah = E * 0.16f
                path.rewind()
                path.moveTo(c.x - aw, c.y + ah * 0.6f)
                path.quadraticBezierTo(c.x, c.y - ah * 1.6f, c.x + aw, c.y + ah * 0.6f)
                drawPath(path, ink.copy(alpha = 0.12f * arcA), style = Stroke(w * 2f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                drawPath(path, ink.copy(alpha = 0.95f * arcA), style = Stroke(w * 0.9f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
    }

    private fun DrawScope.drawMouth(c: Offset, E: Float, ink: Color, dens: Float) {
        val sw = (1.9f + 0.9f * happy.v) * dens
        val width = E * 0.78f * mouthW.v * (1f + 0.25f * happy.v)
        val open = mouthOpen.v.coerceIn(0f, 1f)
        val curve = smile.v + 0.5f * happy.v
        val corner = E * 0.26f * curve * (1f - 0.55f * open)
        val l = Offset(c.x - width, c.y - corner * 0.4f)
        val r = Offset(c.x + width, c.y - corner * 0.4f)
        val wob = mouthWave.v * E * 0.025f
        // obere Lippenlinie
        path.rewind()
        path.moveTo(l.x, l.y)
        if (open < 0.04f) {
            // geschlossen: eine einzige feine, leicht gekrümmte Linie (wie im Referenz-Display)
            val dip = E * 0.26f * curve + E * 0.012f
            if (wob > 0.001f) {
                path.cubicTo(l.x + width * 0.55f, l.y + dip * 0.5f + wob * sin(t * 4f), c.x + width * 0.1f, c.y + dip - wob * sin(t * 4f + 1f), r.x, r.y)
            } else {
                path.quadraticBezierTo(c.x, c.y + dip * 1.8f, r.x, r.y)
            }
            drawPath(path, ink.copy(alpha = 0.10f), style = Stroke(sw * 4.5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            drawPath(path, ink.copy(alpha = 0.95f), style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
        } else {
            val upY = c.y + E * 0.05f - E * 0.06f * open + corner * 0.5f
            val lowY = c.y + E * 0.05f + E * (0.10f + 0.50f * open) + corner * 0.6f
            path.quadraticBezierTo(c.x, upY, r.x, r.y)
            val lower = lowerP.also { it.rewind() }
            lower.moveTo(l.x, l.y)
            lower.quadraticBezierTo(c.x, lowY * 1.0f + (lowY - c.y) * 0.6f, r.x, r.y)
            // Mundinneres: schwach gefüllt, Lippenlinien kräftig
            val inner = innerP.also { it.rewind() }
            inner.moveTo(l.x, l.y)
            inner.quadraticBezierTo(c.x, upY, r.x, r.y)
            inner.quadraticBezierTo(c.x, lowY * 1.0f + (lowY - c.y) * 0.6f, l.x, l.y)
            inner.close()
            drawPath(inner, ink.copy(alpha = 0.10f + 0.12f * open))
            drawPath(path, ink.copy(alpha = 0.12f), style = Stroke(sw * 4.5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            drawPath(path, ink.copy(alpha = 0.95f), style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
            drawPath(lower, ink.copy(alpha = 0.12f), style = Stroke(sw * 4.5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            drawPath(lower, ink.copy(alpha = 0.95f), style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}
