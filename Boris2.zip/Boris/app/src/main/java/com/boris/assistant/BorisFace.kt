package com.boris.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

class BorisFace @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    enum class Mood { IDLE, LISTENING, THINKING, SPEAKING, HAPPY, ANGRY }

    var currentMood: Mood = Mood.IDLE

    private var targetMouthOpen = 0f
    private var currentMouthOpen = 0f

    private var targetEyeScaleY = 1f
    private var currentEyeScaleY = 1f

    private var targetSquint = 0f
    private var currentSquint = 0f

    private var targetBrowsY = 0f
    private var currentBrowsY = 0f

    private var targetEyeX = 0f
    private var currentEyeX = 0f
    private var targetEyeY = 0f
    private var currentEyeY = 0f

    private var time = 0f
    private var blinkTimer = 0f
    private var isBlinking = false

    private val eyePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E5FF")
        style = Paint.Style.FILL
    }

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#3300E5FF")
        style = Paint.Style.FILL
    }

    private val mouthPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E5FF")
        style = Paint.Style.STROKE
        strokeWidth = 8f
        strokeCap = Paint.Cap.ROUND
    }

    private val mouthPath = Path()

    fun updateAudioAmplitude(amplitude: Float) {
        if (currentMood == Mood.SPEAKING || currentMood == Mood.LISTENING) {
            targetMouthOpen = (amplitude * 1.5f).coerceIn(0.05f, 1f)
        }
    }

    fun setEyeTarget(x: Float, y: Float) {
        targetEyeX = x.coerceIn(-30f, 30f)
        targetEyeY = y.coerceIn(-30f, 30f)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        time += 0.03f

        val smoothFactor = 0.12f

        when (currentMood) {
            Mood.IDLE -> {
                targetEyeScaleY = 1f
                targetSquint = 0f
                targetBrowsY = sin(time * 2f) * 2f
            }
            Mood.LISTENING -> {
                targetEyeScaleY = 1.15f
                targetSquint = -0.1f
                targetBrowsY = -8f + sin(time * 3f) * 3f
            }
            Mood.THINKING -> {
                targetEyeScaleY = 0.85f
                targetSquint = 0.3f
                targetBrowsY = 5f
                targetEyeX = cos(time * 4f) * 15f
                targetEyeY = sin(time * 4f) * 10f
            }
            Mood.SPEAKING -> {
                targetEyeScaleY = 1.05f
                targetSquint = 0f
                targetBrowsY = -3f + sin(time * 5f) * 4f
            }
            Mood.HAPPY -> {
                targetEyeScaleY = 0.9f
                targetSquint = 0.5f
                targetBrowsY = -10f
                targetMouthOpen = 0.6f
            }
            Mood.ANGRY -> {
                targetEyeScaleY = 0.7f
                targetSquint = 0.6f
                targetBrowsY = 12f
                targetMouthOpen = 0.1f
            }
        }

        blinkTimer += 0.03f
        if (blinkTimer > 3.5f) {
            isBlinking = true
            if (blinkTimer > 3.7f) {
                isBlinking = false
                blinkTimer = 0f
            }
        }

        val effectiveTargetEyeScaleY = if (isBlinking) 0.05f else targetEyeScaleY

        currentMouthOpen += (targetMouthOpen - currentMouthOpen) * smoothFactor
        currentEyeScaleY += (effectiveTargetEyeScaleY - currentEyeScaleY) * smoothFactor
        currentSquint += (targetSquint - currentSquint) * smoothFactor
        currentBrowsY += (targetBrowsY - currentBrowsY) * smoothFactor
        currentEyeX += (targetEyeX - currentEyeX) * smoothFactor
        currentEyeY += (targetEyeY - currentEyeY) * smoothFactor

        val cx = width / 2f
        val cy = height / 2f

        val breathY = sin(time * 1.8f) * 4f

        val eyeDistance = 110f
        val eyeWidth = 45f
        val baseEyeHeight = 55f * currentEyeScaleY

        drawEye(canvas, cx - eyeDistance + currentEyeX, cy - 20f + breathY + currentEyeY + currentBrowsY, eyeWidth, baseEyeHeight)
        drawEye(canvas, cx + eyeDistance + currentEyeX, cy - 20f + breathY + currentEyeY + currentBrowsY, eyeWidth, baseEyeHeight)

        mouthPath.reset()
        val mouthWidth = 80f + currentMouthOpen * 20f
        val mouthY = cy + 60f + breathY
        val curveY = mouthY + (currentMouthOpen * 45f) - (currentSquint * 15f)

        mouthPath.moveTo(cx - mouthWidth / 2f, mouthY)
        mouthPath.quadraticTo(cx, curveY, cx + mouthWidth / 2f, mouthY)

        canvas.drawPath(mouthPath, mouthPaint)

        postInvalidateOnAnimation()
    }

    private fun drawEye(canvas: Canvas, x: Float, y: Float, w: Float, h: Float) {
        canvas.drawCircle(x, y, w + 12f, glowPaint)
        canvas.drawOval(x - w / 2, y - h / 2, x + w / 2, y + h / 2, eyePaint)
    }
}
