package com.boris.assistant

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sin

/** Boris' Stimme: tiefe männliche KI-Stimme über Gemini-TTS, mit Ausweichlösung auf die Handy-Stimme. */
class Jarvis(private val ctx: Context) {
    companion object {
        /** Vorgefertigte ElevenLabs-Stimmen (männlich, britisch/ruhig). Eigene Stimme per ID im SYSTEM-Reiter. */
        val EL_VOICES = listOf("Daniel" to "onwK4e9ZLuTAKqWW03F9", "George" to "JBFqnCBsd6RMkjVDRZzb",
            "Brian" to "nPczCjzI2devNxkB4yrw", "Adam" to "pNInz6obpgDQGcFmaJgB", "Callum" to "N2lVS1w4EtoT3dr4eOWO")
        val VOICES = listOf("Charon", "Orus", "Algenib", "Alnilam", "Iapetus", "Fenrir")
        private val MODELS = listOf("gemini-3.1-flash-tts-preview", "gemini-2.5-flash-preview-tts")
        // ElevenLabs: Stimme und Einstellungen bleiben exakt wie bisher, nur der Verbrauch wird gesenkt.
        private const val EL_MODEL = "eleven_flash_v2_5"
        private const val EL_STABILITY = 0.55
        private const val EL_SIMILARITY = 0.8
        private const val EL_SIG = "m=eleven_flash_v2_5;s=0.55;b=0.8;f=pcm_24000"
        private const val EL_MAX_CHARS = 220      // gesprochen wird höchstens das, am Satzende gekürzt; der Chat zeigt weiter alles
        private const val EL_COALESCE_MS = 90L    // wird in dieser Zeit ein neuer Text angefordert, geht die alte Anfrage nie raus
    }

    private val prefs = ctx.getSharedPreferences("boris", 0)
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var track: AudioTrack? = null
    @Volatile private var fishPlayer: MediaPlayer? = null
    @Volatile private var gen = 0
    @Volatile private var doneCb: (() -> Unit)? = null
    @Volatile var speaking = false
    /** Merkmale der Stimme im Takt der Wiedergabe, für das Gesicht. */
    val vox = VoiceAnalyzer()
    /** Grundstimmung der aktuellen Äußerung fürs Gesicht (aus dem Text abgeleitet). */
    @Volatile var mood = FaceMood.NEUTRAL
    private val concernRx = Regex("leider|fehler|nicht geklappt|konnte nicht|problem|achtung|vorsicht|warnung|entschuldig|tut mir leid|nicht möglich|kein zugriff")
    private val happyRx = Regex("gern|klar|super|prima|erledigt|gemacht|willkommen|freut|perfekt|glückwunsch|danke|gespeichert|gemerkt")
    private fun moodOf(s: String): FaceMood {
        val l = s.lowercase()
        return when {
            concernRx.containsMatchIn(l) -> FaceMood.CONCERNED
            l.trim().takeLast(80).contains("?") -> FaceMood.CURIOUS
            l.contains("!") || happyRx.containsMatchIn(l) -> FaceMood.HAPPY
            else -> FaceMood.NEUTRAL
        }
    }
    val level: Float get() = vox.level
    /** Text ist angenommen, die Stimme beginnt gleich: das Gesicht bleibt im Denken statt kurz zur Ruhe zu fallen. */
    val preparing: Boolean get() = !speaking && activeKey != null
    @Volatile private var conn: HttpURLConnection? = null
    private val activeLock = Any()
    @Volatile private var activeKey: String? = null
    private var activeGen = -1
    private var activeSince = 0L
    private val extraDone = ArrayList<() -> Unit>()
    @Volatile private var elBlockedUntil = 0L
    @Volatile private var elBlockedKey = ""

    init {
        Thread { TtsCache.purgeLegacy(ctx) }.start()
        tts = TextToSpeech(ctx) { s ->
            if (s == TextToSpeech.SUCCESS) { ttsReady = true; setupDeviceVoice() }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { speaking = true; pulse() }
            override fun onDone(id: String?) { finish() }
            @Deprecated("Deprecated in Java") override fun onError(id: String?) { finish() }
        })
    }

    private fun score(v: Voice): Int {
        val n = v.name.lowercase()
        var s = 0
        if ("female" in n) s -= 5
        if ("male" in n) s += 4
        if (Regex("smt-m|-m\\d").containsMatchIn(n)) s += 4
        if (!v.isNetworkConnectionRequired) s += 1
        return s
    }

    private fun setupDeviceVoice() {
        val t = tts ?: return
        t.language = Locale.GERMAN
        t.setPitch(0.72f)
        t.setSpeechRate(0.95f)
        val v = t.voices?.filter { it.locale.language == "de" }?.maxByOrNull { score(it) }
        if (v != null) t.voice = v
    }

    /** Nur für die Handy-Stimme: liefert kein Audio, also ein plausibles Sprechmuster fürs Gesicht. */
    private fun pulse() {
        vox.reset()
        Thread {
            var last = System.nanoTime()
            while (speaking && track == null) {
                val now = System.nanoTime()
                val dt = ((now - last) / 1e9f).coerceIn(0.005f, 0.1f); last = now
                vox.synth(dt)
                try { Thread.sleep(20) } catch (e: InterruptedException) { break }
            }
        }.start()
    }

    private fun finish() {
        speaking = false; vox.idle()
        val cb = doneCb; doneCb = null
        main.post { cb?.invoke() }
    }

    /** Misst im 20-ms-Takt an der echten Abspielposition, was gerade gesprochen wird. */
    private inner class Meter(private val t: AudioTrack, private val ring: PcmRing, private val g: Int) : Thread("boris-meter") {
        @Volatile var alive = true
        override fun run() {
            var last = System.nanoTime(); var lastHead = -1L; var still = 0
            while (alive && g == gen) {
                val now = System.nanoTime()
                val dt = ((now - last) / 1e9f).coerceIn(0.005f, 0.1f); last = now
                val head = try { t.playbackHeadPosition.toLong() and 0xFFFFFFFFL } catch (e: Exception) { break }
                if (head == lastHead) still++ else { still = 0; lastHead = head }
                // steht die Wiedergabe (Pufferleer, Ende), zählt das als Stille statt als eingefrorener Pegel
                if (still > 4) vox.update(null, 0L, dt) else vox.update(ring, head, dt)
                try { Thread.sleep(20) } catch (e: InterruptedException) { break }
            }
        }
    }

    private fun fishKey(): String = prefs.getString("fish_key", "") ?: ""
    private fun fishVoice(): String = prefs.getString("fish_voice", "") ?: ""
    private fun elKey(): String = prefs.getString("el_key", "") ?: ""
    private fun elVoice(): String = prefs.getString("el_voice", EL_VOICES[0].second) ?: EL_VOICES[0].second

    fun voiceName(): String =
        if (fishKey().isNotBlank()) "Fish Audio S2.1 Pro Free" + if (fishVoice().isNotBlank()) " · eigene Stimme" else ""
        else if (elKey().isNotBlank()) "ElevenLabs " + (EL_VOICES.firstOrNull { it.second == elVoice() }?.first ?: "eigene ID")
        else prefs.getString("gvoice", VOICES[0]) ?: VOICES[0]

    fun cycleVoice(): String {
        if (fishKey().isNotBlank() && prefs.getBoolean("fish_enabled", true)) return voiceName()
        if (elKey().isNotBlank()) {
            val i = (EL_VOICES.indexOfFirst { it.second == elVoice() } + 1) % EL_VOICES.size
            prefs.edit().putString("el_voice", EL_VOICES[i].second).apply()
            return voiceName()
        }
        val g = (VOICES.indexOf(prefs.getString("gvoice", VOICES[0]) ?: VOICES[0]) + 1) % VOICES.size
        prefs.edit().putString("gvoice", VOICES[g]).apply()
        return VOICES[g]
    }

    fun elOk(key: String): Boolean = try {
        val c = URL("https://api.elevenlabs.io/v1/models").openConnection() as HttpURLConnection
        c.connectTimeout = 6000; c.readTimeout = 8000; c.setRequestProperty("xi-api-key", key)
        c.responseCode in 200..299
    } catch (e: Exception) { false }

    fun stop() {
        gen++
        synchronized(activeLock) { activeKey = null; extraDone.clear() }
        conn?.let { c -> Thread { try { c.disconnect() } catch (e: Exception) {} }.start() }
        try { fishPlayer?.setOnCompletionListener(null); fishPlayer?.stop(); fishPlayer?.release() } catch (e: Exception) {}; fishPlayer = null
        try { track?.stop() } catch (e: Exception) {}
        tts?.stop()
        speaking = false; vox.idle()
    }

    private fun elBlocked(k: String) = k == elBlockedKey && System.currentTimeMillis() < elBlockedUntil

    /** Bei abgelaufenem Kontingent oder ungültigem Key nicht bei jedem Satz neu anklopfen. */
    private fun noteElError(code: Int, k: String) {
        val ms = when (code) { 401, 402, 403 -> 180_000L; 429 -> 15_000L; else -> 0L }
        if (ms > 0) { elBlockedKey = k; elBlockedUntil = System.currentTimeMillis() + ms }
    }

    fun speak(apiKey: String, text: String, onStart: () -> Unit = {}, onDone: () -> Unit = {}, eco: Boolean = false) {
        val clean = SpeechText.clean(text)
        if (clean.isBlank()) { main.post { onDone() }; return }
        mood = moodOf(clean)
        val ek = elKey()
        val ident = (if (fishKey().isNotBlank() && prefs.getBoolean("fish_enabled", true)) "fish:" + fishVoice() else if (ek.isNotBlank()) "el:" + elVoice() else "g:" + voiceName()) + "|" + clean
        // Derselbe Text läuft schon (doppelter Aufruf aus Callbacks): nicht noch einmal anfragen, nur das Ende melden
        synchronized(activeLock) {
            if (activeKey == ident && System.currentTimeMillis() - activeSince < 45_000) {
                extraDone.add(onDone); Dbg.d("TTS: Duplikat zusammengelegt"); return
            }
        }
        stop()
        val g = gen
        synchronized(activeLock) { activeKey = ident; activeGen = g; activeSince = System.currentTimeMillis(); extraDone.clear() }
        val done: () -> Unit = {
            val extras = synchronized(activeLock) {
                if (activeGen == g && activeKey == ident) { activeKey = null; ArrayList(extraDone).also { extraDone.clear() } } else ArrayList<() -> Unit>()
            }
            onDone(); extras.forEach { it() }
        }
        Thread {
            try {
                val fk = fishKey()
                if (fk.isNotBlank() && prefs.getBoolean("fish_enabled", true)) {
                    if (streamFish(fk, SpeechText.cap(clean, 700), g, onStart, done)) return@Thread
                    if (g != gen) return@Thread
                }
                val k = elKey()
                if (k.isNotBlank() && !elBlocked(k)) {
                    // Credits sparen: Hintergrundmeldungen (eco) und ein überzogenes Tagesbudget nutzen nur gespeicherte Sätze
                    val allowNet = !eco && ElBudget.allow(ctx)
                    if (streamEleven(k, SpeechText.cap(clean, EL_MAX_CHARS), g, onStart, done, allowNet)) return@Thread
                    if (g != gen) return@Thread
                    if (eco) { deviceSpeak(SpeechText.cap(clean, 400), onStart, done); return@Thread }
                }
                val gText = SpeechText.cap(clean, 400)
                val pcm = if (prefs.getBoolean("hq_voice", true) && apiKey.isNotBlank()) fetchPcm(apiKey, gText) else null
                if (g != gen) return@Thread
                if (pcm != null) playPcm(pcm, g, onStart, done) else deviceSpeak(SpeechText.cap(clean, 900), onStart, done)
            } catch (e: Throwable) {
                Dbg.d("TTS: " + e.message?.take(60))
                if (g == gen) main.post { done() }
            }
        }.start()
    }

    /** Fish Audio S2.1 Pro Free: cached playback first; ElevenLabs remains as fallback. */
    private fun streamFish(key: String, text: String, g: Int, onStart: () -> Unit, onDone: () -> Unit): Boolean {
        val voice = fishVoice()
        val cacheDir = File(ctx.cacheDir, "fish_tts_cache").also { it.mkdirs() }
        val cacheKey = try {
            val bytes = java.security.MessageDigest.getInstance("SHA-256")
                .digest(("s2.1-pro-free|" + voice + "|" + text).toByteArray(Charsets.UTF_8))
            bytes.joinToString("") { "%02x".format(it) }
        } catch (_: Exception) { (voice + text).hashCode().toUInt().toString(16) }
        val file = File(cacheDir, "$cacheKey.mp3")
        var cached = file.exists() && file.length() > 256
        if (!cached) {
            val part = File(cacheDir, "$cacheKey.part")
            val cn = try {
                val c = URL("https://api.fish.audio/v1/tts").openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 5000
                c.readTimeout = 22000
                c.setRequestProperty("Authorization", "Bearer $key")
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("model", "s2.1-pro-free")
                c.setRequestProperty("Connection", "keep-alive")
                c.doOutput = true
                val body = JSONObject().put("text", text).put("format", "mp3")
                if (voice.isNotBlank()) body.put("reference_id", voice)
                c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = c.responseCode
                if (code !in 200..299) {
                    val err = try { c.errorStream?.bufferedReader()?.readText()?.take(120) } catch (_: Exception) { "" }
                    Dbg.d("Fish Audio $code $err"); c.disconnect(); part.delete(); return false
                }
                c
            } catch (e: Exception) { Dbg.d("Fish Audio: " + e.message?.take(80)); part.delete(); return false }
            conn = cn
            try {
                cn.inputStream.use { input -> part.outputStream().use { output ->
                    val buf = ByteArray(8192)
                    while (g == gen) {
                        val n = input.read(buf)
                        if (n < 0) break
                        if (n > 0) output.write(buf, 0, n)
                    }
                } }
                cn.disconnect(); conn = null
                if (g != gen) { part.delete(); return true }
                if (!part.exists() || part.length() < 256) { part.delete(); return false }
                if (file.exists()) file.delete()
                if (!part.renameTo(file)) {
                    try { part.copyTo(file, overwrite = true); part.delete() }
                    catch (_: Exception) { part.delete(); return false }
                }
                cached = true
                // Bound cache size so speech caching cannot grow without limit.
                val entries = cacheDir.listFiles { f -> f.isFile && f.name.endsWith(".mp3") }?.toList().orEmpty()
                if (entries.size > 60) entries.filter { it != file }.sortedBy { it.lastModified() }
                    .take(entries.size - 60).forEach { it.delete() }
            } catch (e: Exception) {
                try { cn.disconnect() } catch (_: Exception) {}; conn = null; part.delete()
                Dbg.d("Fish Audio read: " + e.message?.take(60)); return false
            }
        }
        if (g != gen) return true
        if (!cached || !file.exists()) return false
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK).build()
            am.requestAudioFocus(focus)
            val player = MediaPlayer()
            fishPlayer = player
            player.setDataSource(file.absolutePath)
            player.setOnPreparedListener {
                if (g != gen) { try { player.release() } catch (_: Exception) {}; return@setOnPreparedListener }
                speaking = true; vox.reset(); main.post { onStart() }
                player.start()
                Thread {
                    while (g == gen && try { player.isPlaying } catch (_: Exception) { false }) {
                        vox.synth(0.02f)
                        try { Thread.sleep(20) } catch (_: InterruptedException) { break }
                    }
                }.start()
            }
            player.setOnCompletionListener {
                speaking = false; vox.idle()
                try { player.release() } catch (_: Exception) {}
                if (fishPlayer === player) fishPlayer = null
                am.abandonAudioFocusRequest(focus)
                if (g == gen) main.post { onDone() }
            }
            player.setOnErrorListener { mp, what, extra ->
                speaking = false; vox.idle()
                try { mp.release() } catch (_: Exception) {}
                if (fishPlayer === mp) fishPlayer = null
                am.abandonAudioFocusRequest(focus)
                Dbg.d("Fish MediaPlayer error $what/$extra")
                if (g == gen) main.post { onDone() }
                true
            }
            // Do not block the worker while MediaPlayer prepares the audio decoder.
            player.prepareAsync()
            Dbg.d(if (file.lastModified() > System.currentTimeMillis() - 3000) "Fish Audio: generated audio ready" else "Fish Audio: cache")
            return true
        } catch (e: Exception) { try { fishPlayer?.release() } catch (_: Exception) {}; fishPlayer = null; Dbg.d("Fish playback: " + e.message?.take(60)); return false }
    }

    /** Spielt aus dem lokalen Cache oder streamt die ElevenLabs-Stimme (Stimme und Einstellungen unverändert). */
    private fun streamEleven(key: String, text: String, g: Int, onStart: () -> Unit, onDone: () -> Unit, allowNet: Boolean = true): Boolean {
        val voice = elVoice()
        val ck = TtsCache.key(voice, EL_SIG, text)
        val cached = TtsCache.get(ctx, ck)
        if (cached != null) { Dbg.d("TTS: aus Cache (0 Zeichen)"); playPcm(cached, g, onStart, onDone); return true }
        if (!allowNet) { Dbg.d("TTS: ElevenLabs-Sparmodus, keine neue Anfrage"); return false }
        // Kurz warten: kommt in dieser Zeit schon der nächste Text, wird gar nichts angefragt
        try { Thread.sleep(EL_COALESCE_MS) } catch (e: InterruptedException) {}
        if (g != gen) return true
        val c = try {
            val cn = URL("https://api.elevenlabs.io/v1/text-to-speech/$voice/stream?output_format=pcm_24000").openConnection() as HttpURLConnection
            cn.requestMethod = "POST"; cn.connectTimeout = 8000; cn.readTimeout = 20000
            cn.setRequestProperty("content-type", "application/json"); cn.setRequestProperty("xi-api-key", key)
            cn.doOutput = true
            val body = JSONObject().put("text", text).put("model_id", EL_MODEL)
                .put("voice_settings", JSONObject().put("stability", EL_STABILITY).put("similarity_boost", EL_SIMILARITY))
            if (g != gen) { cn.disconnect(); return true }
            cn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = cn.responseCode
            if (code !in 200..299) {
                val err = try { cn.errorStream?.bufferedReader()?.readText()?.take(90) } catch (e: Exception) { null }
                Dbg.d("ElevenLabs $code ${err ?: ""}")
                noteElError(code, key); cn.disconnect(); return false
            }
            if (g != gen) { cn.disconnect(); return true }
            cn
        } catch (e: Exception) { Dbg.d("ElevenLabs: " + e.message?.take(60)); return false }
        conn = c
        val cost = c.getHeaderField("character-cost")?.toFloatOrNull() ?: (text.length * 0.5f)
        ElBudget.add(ctx, cost)
        Dbg.d("TTS: ElevenLabs ${text.length} Zeichen, ${cost.toInt()} Credits")

        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK).build()
        am.requestAudioFocus(focus)
        val minBuf = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(minBuf, 12000))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track = t
        val ring = PcmRing(24000 * 4)
        vox.reset()
        speaking = true
        main.post { onStart() }
        t.play()
        val meter = Meter(t, ring, g).also { it.start() }

        val part = TtsCache.partFile(ctx, ck)
        var sink: java.io.OutputStream? = try { java.io.BufferedOutputStream(java.io.FileOutputStream(part)) } catch (e: Exception) { null }
        var sinkOk = sink != null
        var complete = false
        var left: Byte? = null
        var frames = 0L
        try {
            try {
                val inp = c.inputStream
                val buf = ByteArray(4096)
                while (g == gen) {
                    val n = inp.read(buf)
                    if (n < 0) { complete = true; break }
                    if (n == 0) continue
                    val chunk = if (left != null) byteArrayOf(left) + buf.copyOf(n) else buf.copyOf(n)
                    val even = chunk.size and 1.inv()
                    left = if (chunk.size > even) chunk[even] else null
                    if (even > 0) {
                        ring.push(chunk, 0, even)
                        t.write(chunk, 0, even)
                        if (sinkOk) try { sink?.write(chunk, 0, even) } catch (e: Exception) { sinkOk = false }
                        frames += even / 2
                    }
                }
            } catch (e: Exception) { Dbg.d("EL-Stream: " + e.message?.take(50)) }
            finally { try { c.disconnect() } catch (e: Exception) {}; conn = null }
            try { sink?.flush(); sink?.close() } catch (e: Exception) { sinkOk = false }
            sink = null
            // Nur ein vollständig geladener Stream wird gecacht, nie ein abgebrochener
            if (complete && sinkOk && frames > 0) TtsCache.commit(ctx, ck, part) else part.delete()

            if (g == gen) {
                val deadline = System.currentTimeMillis() + 2000 + frames * 1000 / 24000
                while (g == gen && t.playbackHeadPosition < frames && System.currentTimeMillis() < deadline) Thread.sleep(30)
            }
        } finally {
            meter.alive = false
            try { sink?.close() } catch (e: Exception) {}
            speaking = false; vox.idle()
            try { t.stop() } catch (e: Exception) {}
            t.release(); track = null
            am.abandonAudioFocusRequest(focus)
        }
        if (g == gen) main.post { onDone() }
        return frames > 0 || g != gen
    }

    private fun deviceSpeak(text: String, onStart: () -> Unit, onDone: () -> Unit) {
        if (!ttsReady) { main.post { onDone() }; return }
        doneCb = onDone
        main.post { onStart() }
        tts?.speak(text.take(900), TextToSpeech.QUEUE_FLUSH, null, "boris")
    }

    fun hqAvailable(apiKey: String): Boolean = apiKey.isNotBlank() && fetchPcmRaw(apiKey, "Test") != null

    private fun fetchPcm(apiKey: String, text: String): ByteArray? {
        val f = java.io.File(ctx.cacheDir, "tts_" + (voiceName() + "|" + text).hashCode().toUInt().toString(16) + ".pcm")
        if (f.exists()) return try { f.readBytes() } catch (e: Exception) { null }
        val pcm = fetchPcmRaw(apiKey, text) ?: return null
        if (text.length <= 90) try {
            val files = ctx.cacheDir.listFiles { x -> x.name.startsWith("tts_") }
            if (files != null && files.size > 60) files.minByOrNull { it.lastModified() }?.delete()
            f.writeBytes(pcm)
        } catch (e: Exception) {}
        return pcm
    }

    private fun fetchPcmRaw(apiKey: String, text: String): ByteArray? {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text",
                "Sage ruhig, tief und souverän, mit trockenem Understatement: ${text.take(400)}")))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig",
                    JSONObject().put("voiceName", voiceName())))))
        for (m in MODELS) {
            try {
                val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.connectTimeout = 8000; c.readTimeout = 20000
                c.setRequestProperty("content-type", "application/json")
                c.setRequestProperty("x-goog-api-key", apiKey)
                c.doOutput = true
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                if (c.responseCode !in 200..299) { if (c.responseCode == 429) return null; continue }
                val j = JSONObject(c.inputStream.bufferedReader().readText())
                val data = j.getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
                    .getJSONArray("parts").getJSONObject(0).getJSONObject("inlineData").getString("data")
                return Base64.decode(data, Base64.DEFAULT)
            } catch (e: Exception) { }
        }
        return null
    }

    private fun playPcm(pcm: ByteArray, g: Int, onStart: () -> Unit, onDone: () -> Unit) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK).build()
        am.requestAudioFocus(focus)
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(pcm.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(pcm, 0, pcm.size)
        track = t
        val frames = pcm.size / 2
        val ring = PcmRing(frames)
        ring.push(pcm, 0, pcm.size)
        vox.reset()
        speaking = true
        main.post { onStart() }
        t.play()
        val meter = Meter(t, ring, g).also { it.start() }
        try {
            val deadline = System.currentTimeMillis() + frames * 1000L / 24000 + 1500
            while (g == gen && System.currentTimeMillis() < deadline && t.playbackHeadPosition < frames) Thread.sleep(30)
        } finally {
            meter.alive = false
            speaking = false; vox.idle()
            try { t.stop() } catch (e: Exception) {}
            t.release(); track = null
            am.abandonAudioFocusRequest(focus)
        }
        if (g == gen) main.post { onDone() }
    }

    fun shutdown() { stop(); tts?.shutdown() }
}
