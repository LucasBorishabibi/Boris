package com.boris.assistant

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sin

/** Boris' Stimme: tiefe männliche KI-Stimme über Gemini-TTS, mit Ausweichlösung auf die Handy-Stimme. */
class Jarvis(private val ctx: Context) {
    companion object {
        /** Vorgefertigte ElevenLabs-Stimmen (männlich, britisch/ruhig). Eigene Stimme per ID im SYSTEM-Reiter. */
        val EL_VOICES = listOf("Daniel" to "onwK4e9ZLuTAKqWW03F9", "George" to "JBFqnCBsd6RMkjVDRZzb",
            "Brian" to "nPczCjzI2devNxkB4yrw", "Adam" to "pNInz6obpgDQGcFmaJgB", "Callum" to "N2lVS1w4EtoT3dr4eOWO")
        val VOICES = listOf("Charon", "Orus", "Algenib", "Alnilam", "Iapetus", "Fenrir")
        private val MODELS = listOf("gemini-3.1-flash-tts-preview", "gemini-2.5-flash-preview-tts")
        // ElevenLabs: Stimme und Einstellungen bleiben exakt wie bisher, nur der Verbrauch wird gesenkt.
        private const val EL_MODEL = "eleven_flash_v2_5"
        private const val EL_STABILITY = 0.55
        private const val EL_SIMILARITY = 0.8
        private const val EL_SIG = "m=eleven_flash_v2_5;s=0.55;b=0.8;f=pcm_24000"
        private const val EL_MAX_CHARS = 300      // gesprochen wird höchstens das, am Satzende gekürzt; der Chat zeigt weiter alles
        private const val EL_COALESCE_MS = 90L    // wird in dieser Zeit ein neuer Text angefordert, geht die alte Anfrage nie raus
    }

    private val prefs = ctx.getSharedPreferences("boris", 0)
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var track: AudioTrack? = null
    @Volatile private var gen = 0
    @Volatile private var doneCb: (() -> Unit)? = null
    @Volatile var speaking = false
    /** Merkmale der Stimme im Takt der Wiedergabe, für das Gesicht. */
    val vox = VoiceAnalyzer()
    /** Grundstimmung der aktuellen Äußerung fürs Gesicht (aus dem Text abgeleitet). */
    @Volatile var mood = FaceMood.NEUTRAL
    private val concernRx = Regex("leider|fehler|nicht geklappt|konnte nicht|problem|achtung|vorsicht|warnung|entschuldig|tut mir leid|nicht möglich|kein zugriff")
    private val happyRx = Regex("gern|klar|super|prima|erledigt|gemacht|willkommen|freut|perfekt|glückwunsch|danke|gespeichert|gemerkt")
    private fun moodOf(s: String): FaceMood {
        val l = s.lowercase()
        return when {
            concernRx.containsMatchIn(l) -> FaceMood.CONCERNED
            l.trim().takeLast(80).contains("?") -> FaceMood.CURIOUS
            l.contains("!") || happyRx.containsMatchIn(l) -> FaceMood.HAPPY
            else -> FaceMood.NEUTRAL
        }
    }
    val level: Float get() = vox.level
    /** Text ist angenommen, die Stimme beginnt gleich: das Gesicht bleibt im Denken statt kurz zur Ruhe zu fallen. */
    val preparing: Boolean get() = !speaking && activeKey != null
    @Volatile private var conn: HttpURLConnection? = null
    private val activeLock = Any()
    @Volatile private var activeKey: String? = null
    private var activeGen = -1
    private var activeSince = 0L
    private val extraDone = ArrayList<() -> Unit>()
    @Volatile private var elBlockedUntil = 0L
    @Volatile private var elBlockedKey = ""

    init {
        Thread { TtsCache.purgeLegacy(ctx) }.start()
        tts = TextToSpeech(ctx) { s ->
            if (s == TextToSpeech.SUCCESS) { ttsReady = true; setupDeviceVoice() }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { speaking = true; pulse() }
            override fun onDone(id: String?) { finish() }
            @Deprecated("Deprecated in Java") override fun onError(id: String?) { finish() }
        })
    }

    private fun score(v: Voice): Int {
        val n = v.name.lowercase()
        var s = 0
        if ("female" in n) s -= 5
        if ("male" in n) s += 4
        if (Regex("smt-m|-m\\d").containsMatchIn(n)) s += 4
        if (!v.isNetworkConnectionRequired) s += 1
        return s
    }

    private fun setupDeviceVoice() {
        val t = tts ?: return
        t.language = Locale.GERMAN
        t.setPitch(0.72f)
        t.setSpeechRate(0.95f)
        val v = t.voices?.filter { it.locale.language == "de" }?.maxByOrNull { score(it) }
        if (v != null) t.voice = v
    }

    /** Nur für die Handy-Stimme: liefert kein Audio, also ein plausibles Sprechmuster fürs Gesicht. */
    private fun pulse() {
        vox.reset()
        Thread {
            var last = System.nanoTime()
            while (speaking && track == null) {
                val now = System.nanoTime()
                val dt = ((now - last) / 1e9f).coerceIn(0.005f, 0.1f); last = now
                vox.synth(dt)
                try { Thread.sleep(20) } catch (e: InterruptedException) { break }
            }
        }.start()
    }

    private fun finish() {
        speaking = false; vox.idle()
        val cb = doneCb; doneCb = null
        main.post { cb?.invoke() }
    }

    /** Misst im 20-ms-Takt an der echten Abspielposition, was gerade gesprochen wird. */
    private inner class Meter(private val t: AudioTrack, private val ring: PcmRing, private val g: Int) : Thread("boris-meter") {
        @Volatile var alive = true
        override fun run() {
            var last = System.nanoTime(); var lastHead = -1L; var still = 0
            while (alive && g == gen) {
                val now = System.nanoTime()
                val dt = ((now - last) / 1e9f).coerceIn(0.005f, 0.1f); last = now
                val head = try { t.playbackHeadPosition.toLong() and 0xFFFFFFFFL } catch (e: Exception) { break }
                if (head == lastHead) still++ else { still = 0; lastHead = head }
                // steht die Wiedergabe (Pufferleer, Ende), zählt das als Stille statt als eingefrorener Pegel
                if (still > 4) vox.update(null, 0L, dt) else vox.update(ring, head, dt)
                try { Thread.sleep(20) } catch (e: InterruptedException) { break }
            }
        }
    }

    private fun elKey(): String = prefs.getString("el_key", "") ?: ""
    private fun elVoice(): String = prefs.getString("el_voice", EL_VOICES[0].second) ?: EL_VOICES[0].second

    fun voiceName(): String =
        if (elKey().isNotBlank()) "ElevenLabs " + (EL_VOICES.firstOrNull { it.second == elVoice() }?.first ?: "eigene ID")
        else prefs.getString("gvoice", VOICES[0]) ?: VOICES[0]

    fun cycleVoice(): String {
        if (elKey().isNotBlank()) {
            val i = (EL_VOICES.indexOfFirst { it.second == elVoice() } + 1) % EL_VOICES.size
            prefs.edit().putString("el_voice", EL_VOICES[i].second).apply()
            return voiceName()
        }
        val g = (VOICES.indexOf(prefs.getString("gvoice", VOICES[0]) ?: VOICES[0]) + 1) % VOICES.size
        prefs.edit().putString("gvoice", VOICES[g]).apply()
        return VOICES[g]
    }

    fun elOk(key: String): Boolean = try {
        val c = URL("https://api.elevenlabs.io/v1/models").openConnection() as HttpURLConnection
        c.connectTimeout = 6000; c.readTimeout = 8000; c.setRequestProperty("xi-api-key", key)
        c.responseCode in 200..299
    } catch (e: Exception) { false }

    fun stop() {
        gen++
        synchronized(activeLock) { activeKey = null; extraDone.clear() }
        conn?.let { c -> Thread { try { c.disconnect() } catch (e: Exception) {} }.start() }
        try { track?.stop() } catch (e: Exception) {}
        tts?.stop()
        speaking = false; vox.idle()
    }

    private var elBlockLoaded = false
    private fun fp(k: String) = k.hashCode().toString()

    private fun elBlocked(k: String): Boolean {
        if (!elBlockLoaded) {
            elBlockLoaded = true
            val p = (prefs.getString("el_block", "") ?: "").split("|")
            if (p.size == 2) { elBlockedKey = p[0]; elBlockedUntil = p[1].toLongOrNull() ?: 0L }
        }
        return fp(k) == elBlockedKey && System.currentTimeMillis() < elBlockedUntil
    }

    /**
     * Bei Sperre, abgelaufenem Kontingent oder ungültigem Key nicht bei jedem Satz neu anklopfen.
     * „Ungewöhnliche Aktivität“ ist eine Kontosperre von ElevenLabs (Gratis-Tarif, oft wegen VPN, Proxy oder privatem DNS):
     * Die lässt sich in der App nicht aufheben, also wird 6 Stunden lang gar nicht mehr angefragt und das einmal erklärt.
     */
    private fun noteElError(code: Int, k: String, body: String) {
        val unusual = body.contains("unusual_activity", true) || body.contains("unusual activity", true)
        val ms = if (unusual) 6 * 3_600_000L else when (code) { 401, 402, 403 -> 180_000L; 429 -> 15_000L; else -> 0L }
        if (ms <= 0) return
        val already = elBlocked(k)
        elBlockedKey = fp(k); elBlockedUntil = System.currentTimeMillis() + ms
        prefs.edit().putString("el_block", "$elBlockedKey|$elBlockedUntil").apply()
        if (unusual && !already) {
            Core.onUi {
                Core.messages.add(Msg(3, "ElevenLabs hat den Gratis-Zugang gesperrt („ungewöhnliche Aktivität“). Das entscheidet ElevenLabs für dein Konto, " +
                    "in der App lässt es sich nicht umgehen. Meist hilft: VPN, Proxy oder privates DNS ausschalten, ein anderes Netz nutzen oder einen bezahlten Tarif nehmen. " +
                    "Bis dahin spricht Boris mit der Ausweichstimme, und ich frage ElevenLabs 6 Stunden lang nicht mehr an."))
            }
        }
    }

    fun speak(apiKey: String, text: String, onStart: () -> Unit = {}, onDone: () -> Unit = {}) {
        val clean = SpeechText.clean(text)
        if (clean.isBlank()) { main.post { onDone() }; return }
        mood = moodOf(clean)
        val ek = elKey()
        val ident = (if (ek.isNotBlank()) "el:" + elVoice() else "g:" + voiceName()) + "|" + clean
        // Derselbe Text läuft schon (doppelter Aufruf aus Callbacks): nicht noch einmal anfragen, nur das Ende melden
        synchronized(activeLock) {
            if (activeKey == ident && System.currentTimeMillis() - activeSince < 45_000) {
                extraDone.add(onDone); Dbg.d("TTS: Duplikat zusammengelegt"); return
            }
        }
        stop()
        val g = gen
        synchronized(activeLock) { activeKey = ident; activeGen = g; activeSince = System.currentTimeMillis(); extraDone.clear() }
        val done: () -> Unit = {
            val extras = synchronized(activeLock) {
                if (activeGen == g && activeKey == ident) { activeKey = null; ArrayList(extraDone).also { extraDone.clear() } } else ArrayList<() -> Unit>()
            }
            onDone(); extras.forEach { it() }
        }
        Thread {
            try {
                val k = elKey()
                if (k.isNotBlank() && !elBlocked(k) && streamEleven(k, SpeechText.cap(clean, EL_MAX_CHARS), g, onStart, done)) return@Thread
                if (g != gen) return@Thread
                val gText = SpeechText.cap(clean, 400)
                val pcm = if (prefs.getBoolean("hq_voice", true) && apiKey.isNotBlank()) fetchPcm(apiKey, gText) else null
                if (g != gen) return@Thread
                if (pcm != null) playPcm(pcm, g, onStart, done) else deviceSpeak(SpeechText.cap(clean, 900), onStart, done)
            } catch (e: Throwable) {
                Dbg.d("TTS: " + e.message?.take(60))
                if (g == gen) main.post { done() }
            }
        }.start()
    }

    /** Spielt aus dem lokalen Cache oder streamt die ElevenLabs-Stimme (Stimme und Einstellungen unverändert). */
    private fun streamEleven(key: String, text: String, g: Int, onStart: () -> Unit, onDone: () -> Unit): Boolean {
        val voice = elVoice()
        val ck = TtsCache.key(voice, EL_SIG, text)
        val cached = TtsCache.get(ctx, ck)
        if (cached != null) { Dbg.d("TTS: aus Cache (0 Zeichen)"); playPcm(cached, g, onStart, onDone); return true }
        // Kurz warten: kommt in dieser Zeit schon der nächste Text, wird gar nichts angefragt
        try { Thread.sleep(EL_COALESCE_MS) } catch (e: InterruptedException) {}
        if (g != gen) return true
        val c = try {
            val cn = URL("https://api.elevenlabs.io/v1/text-to-speech/$voice/stream?output_format=pcm_24000").openConnection() as HttpURLConnection
            cn.requestMethod = "POST"; cn.connectTimeout = 8000; cn.readTimeout = 20000
            cn.setRequestProperty("content-type", "application/json"); cn.setRequestProperty("xi-api-key", key)
            cn.doOutput = true
            val body = JSONObject().put("text", text).put("model_id", EL_MODEL)
                .put("voice_settings", JSONObject().put("stability", EL_STABILITY).put("similarity_boost", EL_SIMILARITY))
            if (g != gen) { cn.disconnect(); return true }
            cn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = cn.responseCode
            if (code !in 200..299) {
                val err = try { cn.errorStream?.bufferedReader()?.readText()?.take(500) } catch (e: Exception) { null }
                Dbg.d("ElevenLabs $code ${err?.take(90) ?: ""}")
                noteElError(code, key, err ?: ""); cn.disconnect(); return false
            }
            if (g != gen) { cn.disconnect(); return true }
            cn
        } catch (e: Exception) { Dbg.d("ElevenLabs: " + e.message?.take(60)); return false }
        conn = c
        Dbg.d("TTS: ElevenLabs ${text.length} Zeichen")

        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK).build()
        am.requestAudioFocus(focus)
        val minBuf = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(minBuf, 12000))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track = t
        val ring = PcmRing(24000 * 4)
        vox.reset()
        speaking = true
        main.post { onStart() }
        t.play()
        val meter = Meter(t, ring, g).also { it.start() }

        val part = TtsCache.partFile(ctx, ck)
        var sink: java.io.OutputStream? = try { java.io.BufferedOutputStream(java.io.FileOutputStream(part)) } catch (e: Exception) { null }
        var sinkOk = sink != null
        var complete = false
        var left: Byte? = null
        var frames = 0L
        try {
            try {
                val inp = c.inputStream
                val buf = ByteArray(4096)
                while (g == gen) {
                    val n = inp.read(buf)
                    if (n < 0) { complete = true; break }
                    if (n == 0) continue
                    val chunk = if (left != null) byteArrayOf(left) + buf.copyOf(n) else buf.copyOf(n)
                    val even = chunk.size and 1.inv()
                    left = if (chunk.size > even) chunk[even] else null
                    if (even > 0) {
                        ring.push(chunk, 0, even)
                        t.write(chunk, 0, even)
                        if (sinkOk) try { sink?.write(chunk, 0, even) } catch (e: Exception) { sinkOk = false }
                        frames += even / 2
                    }
                }
            } catch (e: Exception) { Dbg.d("EL-Stream: " + e.message?.take(50)) }
            finally { try { c.disconnect() } catch (e: Exception) {}; conn = null }
            try { sink?.flush(); sink?.close() } catch (e: Exception) { sinkOk = false }
            sink = null
            // Nur ein vollständig geladener Stream wird gecacht, nie ein abgebrochener
            if (complete && sinkOk && frames > 0) TtsCache.commit(ctx, ck, part) else part.delete()

            if (g == gen) {
                val deadline = System.currentTimeMillis() + 2000 + frames * 1000 / 24000
                while (g == gen && t.playbackHeadPosition < frames && System.currentTimeMillis() < deadline) Thread.sleep(30)
            }
        } finally {
            meter.alive = false
            try { sink?.close() } catch (e: Exception) {}
            speaking = false; vox.idle()
            try { t.stop() } catch (e: Exception) {}
            t.release(); track = null
            am.abandonAudioFocusRequest(focus)
        }
        if (g == gen) main.post { onDone() }
        return frames > 0 || g != gen
    }

    private fun deviceSpeak(text: String, onStart: () -> Unit, onDone: () -> Unit) {
        if (!ttsReady) { main.post { onDone() }; return }
        doneCb = onDone
        main.post { onStart() }
        tts?.speak(text.take(900), TextToSpeech.QUEUE_FLUSH, null, "boris")
    }

    fun hqAvailable(apiKey: String): Boolean = apiKey.isNotBlank() && fetchPcmRaw(apiKey, "Test") != null

    private fun fetchPcm(apiKey: String, text: String): ByteArray? {
        val f = java.io.File(ctx.cacheDir, "tts_" + (voiceName() + "|" + text).hashCode().toUInt().toString(16) + ".pcm")
        if (f.exists()) return try { f.readBytes() } catch (e: Exception) { null }
        val pcm = fetchPcmRaw(apiKey, text) ?: return null
        if (text.length <= 90) try {
            val files = ctx.cacheDir.listFiles { x -> x.name.startsWith("tts_") }
            if (files != null && files.size > 60) files.minByOrNull { it.lastModified() }?.delete()
            f.writeBytes(pcm)
        } catch (e: Exception) {}
        return pcm
    }

    private fun fetchPcmRaw(apiKey: String, text: String): ByteArray? {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text",
                "Sage ruhig, tief und souverän, mit trockenem Understatement: ${text.take(400)}")))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig",
                    JSONObject().put("voiceName", voiceName())))))
        for (m in MODELS) {
            try {
                val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.connectTimeout = 8000; c.readTimeout = 20000
                c.setRequestProperty("content-type", "application/json")
                c.setRequestProperty("x-goog-api-key", apiKey)
                c.doOutput = true
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                if (c.responseCode !in 200..299) { if (c.responseCode == 429) return null; continue }
                val j = JSONObject(c.inputStream.bufferedReader().readText())
                val data = j.getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
                    .getJSONArray("parts").getJSONObject(0).getJSONObject("inlineData").getString("data")
                return Base64.decode(data, Base64.DEFAULT)
            } catch (e: Exception) { }
        }
        return null
    }

    private fun playPcm(pcm: ByteArray, g: Int, onStart: () -> Unit, onDone: () -> Unit) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK).build()
        am.requestAudioFocus(focus)
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(pcm.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(pcm, 0, pcm.size)
        track = t
        val frames = pcm.size / 2
        val ring = PcmRing(frames)
        ring.push(pcm, 0, pcm.size)
        vox.reset()
        speaking = true
        main.post { onStart() }
        t.play()
        val meter = Meter(t, ring, g).also { it.start() }
        try {
            val deadline = System.currentTimeMillis() + frames * 1000L / 24000 + 1500
            while (g == gen && System.currentTimeMillis() < deadline && t.playbackHeadPosition < frames) Thread.sleep(30)
        } finally {
            meter.alive = false
            speaking = false; vox.idle()
            try { t.stop() } catch (e: Exception) {}
            t.release(); track = null
            am.abandonAudioFocusRequest(focus)
        }
        if (g == gen) main.post { onDone() }
    }

    fun shutdown() { stop(); tts?.shutdown() }
}
