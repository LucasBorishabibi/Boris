package com.boris.assistant

import android.content.Context
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sin

/**
 * Boris' Stimme.
 *
 * Absichtlich komplett lokal: Die Sprachausgabe verwendet die auf dem Handy
 * installierte Android/Samsung-TTS-Engine. Dadurch verbraucht die Stimme
 * weder Gemini-Guthaben noch einen API-Call.
 *
 * Die Parameter sind auf eine tiefe, ruhige, maskuline Stimme abgestimmt.
 * Welche konkrete männliche deutsche Stimme verfügbar ist, hängt vom
 * installierten TTS-Engine/Sprachpaket ab.
 */
class Jarvis(private val ctx: Context) {
    companion object {
        private const val LOCAL_VOICE = "BORIS – TIEFE MÄNNERSTIMME"
        private const val PITCH = 0.48f
        private const val RATE = 0.88f
    }

    private val prefs = ctx.getSharedPreferences("boris", 0)
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    @Volatile var speaking = false
    @Volatile var level = 0f
    var lastError by mutableStateOf("")

    init {
        tts = TextToSpeech(ctx) { s ->
            if (s == TextToSpeech.SUCCESS) {
                ttsReady = true
                setupDeviceVoice()
            } else {
                lastError = "Lokale TTS-Engine konnte nicht gestartet werden"
            }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {
                speaking = true
                pulse()
            }

            override fun onDone(id: String?) {
                finish()
            }

            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) {
                finish()
            }
        })
    }

    /** Bewertet deutsche Stimmen: lokal + männlich werden bevorzugt. */
    private fun score(v: Voice): Int {
        val n = v.name.lowercase(Locale.ROOT)
        var s = 0

        // Keine Netzwerkstimme verwenden: so bleibt Boris wirklich kostenlos/offline.
        if (!v.isNetworkConnectionRequired) s += 100
        else s -= 100

        // Bekannte männliche/neutral benannte Google/Samsung-Varianten bevorzugen.
        if ("male" in n || "-m" in n || "masc" in n) s += 30
        if ("smt" in n) s += 20
        if ("local" in n) s += 15
        if ("de-de" in n || "deu-deu" in n) s += 10

        return s
    }

    private fun setupDeviceVoice() {
        val t = tts ?: return

        t.language = Locale.GERMANY
        t.setPitch(PITCH)
        t.setSpeechRate(RATE)

        val candidates = t.voices
            ?.filter { it.locale.language == "de" }
            ?.sortedByDescending { score(it) }
            ?: emptyList()

        // Erst eine echte lokale deutsche Stimme. Falls keine lokale deutsche
        // Stimme vorhanden ist, nehmen wir die beste deutsche Systemstimme.
        val local = candidates.firstOrNull { !it.isNetworkConnectionRequired }
        val selected = local ?: candidates.firstOrNull()

        if (selected != null) {
            t.voice = selected
            Dbg.d("Lokale Boris-Stimme: ${selected.name} · Netzwerk=${selected.isNetworkConnectionRequired}")
        } else {
            lastError = "Keine deutsche TTS-Stimme installiert"
        }
    }

    private fun pulse() {
        Thread {
            var t = 0f
            while (speaking) {
                level = 0.35f + 0.35f * abs(sin(t))
                t += 0.5f
                Thread.sleep(50)
            }
            level = 0f
        }.start()
    }

    private fun finish() {
        speaking = false
        level = 0f
        val cb = doneCb
        doneCb = null
        main.post { cb?.invoke() }
    }

    @Volatile private var doneCb: (() -> Unit)? = null

    /** Name, der in Boris' Einstellungen angezeigt wird. */
    fun voiceName(): String = LOCAL_VOICE

    /** Für die bestehende UI: bleibt dieselbe lokale Boris-Stimme. */
    fun cycleVoice(): String {
        setupDeviceVoice()
        return LOCAL_VOICE
    }

    fun stop() {
        try { tts?.stop() } catch (_: Exception) {}
        speaking = false
        level = 0f
        doneCb = null
    }

    /**
     * Spricht immer lokal. apiKey wird absichtlich ignoriert:
     * TTS darf keinen Gemini-Request auslösen.
     */
    fun speak(apiKey: String, text: String, onStart: () -> Unit = {}, onDone: () -> Unit = {}) {
        stop()
        if (!ttsReady) {
            main.post { onDone() }
            return
        }

        doneCb = onDone
        main.post { onStart() }

        // TTS muss auf dem Thread mit der Android-TTS-Instanz angestoßen werden.
        tts?.setPitch(PITCH)
        tts?.setSpeechRate(RATE)
        tts?.speak(
            text.take(1200),
            TextToSpeech.QUEUE_FLUSH,
            null,
            "boris_local"
        )
    }

    /**
     * Immer false: Es gibt bewusst keine HQ/Gemini-TTS mehr.
     * Die eigentliche Gemini-KI für Antworten bleibt davon unberührt.
     */
    fun hqAvailable(apiKey: String): Boolean = false

    fun shutdown() {
        stop()
        tts?.shutdown()
    }
}
