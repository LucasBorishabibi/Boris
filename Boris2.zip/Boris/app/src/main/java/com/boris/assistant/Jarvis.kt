package com.boris.assistant

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sin

/** Boris' Stimme: tiefe männliche KI-Stimme über Gemini-TTS, mit Ausweichlösung auf die Handy-Stimme. */
class Jarvis(private val ctx: Context) {
    companion object {
        val VOICES = listOf("Charon", "Orus", "Algenib", "Alnilam", "Iapetus", "Fenrir")
        private val MODELS = listOf("gemini-3.1-flash-tts-preview", "gemini-2.5-flash-preview-tts")
    }

    private val prefs = ctx.getSharedPreferences("boris", 0)
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var track: AudioTrack? = null
    @Volatile private var gen = 0
    @Volatile private var doneCb: (() -> Unit)? = null
    @Volatile var speaking = false
    @Volatile var level = 0f

    init {
        tts = TextToSpeech(ctx) { s ->
            if (s == TextToSpeech.SUCCESS) { ttsReady = true; setupDeviceVoice() }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { speaking = true; pulse() }
            override fun onDone(id: String?) { finish() }
            @Deprecated("Deprecated in Java") override fun onError(id: String?) { finish() }
        })
    }

    private fun score(v: Voice): Int {
        val n = v.name.lowercase()
        var s = 0
        if ("female" in n) s -= 5
        if ("male" in n) s += 4
        if (Regex("smt-m|-m\\d").containsMatchIn(n)) s += 4
        if (!v.isNetworkConnectionRequired) s += 1
        return s
    }

    private fun setupDeviceVoice() {
        val t = tts ?: return
        t.language = Locale.GERMAN
        t.setPitch(0.72f)
        t.setSpeechRate(0.95f)
        val v = t.voices?.filter { it.locale.language == "de" }?.maxByOrNull { score(it) }
        if (v != null) t.voice = v
    }

    private fun pulse() {
        Thread {
            var t = 0f
            while (speaking && track == null) { level = 0.35f + 0.35f * abs(sin(t)); t += 0.5f; Thread.sleep(50) }
            if (track == null) level = 0f
        }.start()
    }

    private fun finish() {
        speaking = false; level = 0f
        val cb = doneCb; doneCb = null
        main.post { cb?.invoke() }
    }

    fun voiceName(): String = prefs.getString("gvoice", VOICES[0]) ?: VOICES[0]

    fun cycleVoice(): String {
        val i = (VOICES.indexOf(voiceName()) + 1) % VOICES.size
        prefs.edit().putString("gvoice", VOICES[i]).apply()
        return VOICES[i]
    }

    fun stop() {
        gen++
        try { track?.stop() } catch (e: Exception) {}
        tts?.stop()
        speaking = false; level = 0f
    }

    fun speak(apiKey: String, text: String, onStart: () -> Unit = {}, onDone: () -> Unit = {}) {
        stop()
        val g = gen
        Thread {
            val pcm = if (prefs.getBoolean("hq_voice", true) && apiKey.isNotBlank()) fetchPcm(apiKey, text) else null
            if (g != gen) return@Thread
            if (pcm != null) playPcm(pcm, g, onStart, onDone) else deviceSpeak(text, onStart, onDone)
        }.start()
    }

    private fun deviceSpeak(text: String, onStart: () -> Unit, onDone: () -> Unit) {
        if (!ttsReady) { main.post { onDone() }; return }
        doneCb = onDone
        main.post { onStart() }
        tts?.speak(text.take(900), TextToSpeech.QUEUE_FLUSH, null, "boris")
    }

    fun hqAvailable(apiKey: String): Boolean = apiKey.isNotBlank() && fetchPcmRaw(apiKey, "Test") != null

    private fun fetchPcm(apiKey: String, text: String): ByteArray? {
        val f = java.io.File(ctx.cacheDir, "tts_" + (voiceName() + "|" + text).hashCode().toUInt().toString(16) + ".pcm")
        if (f.exists()) return try { f.readBytes() } catch (e: Exception) { null }
        val pcm = fetchPcmRaw(apiKey, text) ?: return null
        if (text.length <= 90) try {
            val files = ctx.cacheDir.listFiles { x -> x.name.startsWith("tts_") }
            if (files != null && files.size > 60) files.minByOrNull { it.lastModified() }?.delete()
            f.writeBytes(pcm)
        } catch (e: Exception) {}
        return pcm
    }

    private fun fetchPcmRaw(apiKey: String, text: String): ByteArray? {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text",
                "Sage ruhig, tief und souverän, mit trockenem Understatement: ${text.take(400)}")))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig",
                    JSONObject().put("voiceName", voiceName())))))
        for (m in MODELS) {
            try {
                val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.connectTimeout = 8000; c.readTimeout = 20000
                c.setRequestProperty("content-type", "application/json")
                c.setRequestProperty("x-goog-api-key", apiKey)
                c.doOutput = true
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                if (c.responseCode !in 200..299) { if (c.responseCode == 429) return null; continue }
                val j = JSONObject(c.inputStream.bufferedReader().readText())
                val data = j.getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
                    .getJSONArray("parts").getJSONObject(0).getJSONObject("inlineData").getString("data")
                return Base64.decode(data, Base64.DEFAULT)
            } catch (e: Exception) { }
        }
        return null
    }

    private fun rms(pcm: ByteArray, byteOff: Int, len: Int): Float {
        var sum = 0.0; var n = 0
        var i = byteOff.coerceAtLeast(0)
        val end = (byteOff + len).coerceAtMost(pcm.size - 1)
        while (i < end) {
            val s = ((pcm[i].toInt() and 0xFF) or (pcm[i + 1].toInt() shl 8)).toShort().toInt()
            sum += (s / 32768.0) * (s / 32768.0); n++; i += 2
        }
        return if (n == 0) 0f else (Math.sqrt(sum / n) * 3.5).toFloat().coerceIn(0f, 1f)
    }

    private fun playPcm(pcm: ByteArray, g: Int, onStart: () -> Unit, onDone: () -> Unit) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK).build()
        am.requestAudioFocus(focus)
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(pcm.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(pcm, 0, pcm.size)
        track = t
        val frames = pcm.size / 2
        speaking = true
        main.post { onStart() }
        t.play()
        val deadline = System.currentTimeMillis() + frames * 1000L / 24000 + 1500
        while (g == gen && System.currentTimeMillis() < deadline && t.playbackHeadPosition < frames) {
            level = rms(pcm, t.playbackHeadPosition * 2, 1000)
            Thread.sleep(40)
        }
        level = 0f; speaking = false
        try { t.stop() } catch (e: Exception) {}
        t.release(); track = null
        am.abandonAudioFocusRequest(focus)
        if (g == gen) main.post { onDone() }
    }

    fun shutdown() { stop(); tts?.shutdown() }
}
