package com.boris.assistant

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sin

/** Boris' Stimme: tiefe männliche KI-Stimme über Gemini-TTS, mit Ausweichlösung auf die Handy-Stimme. */
class Jarvis(private val ctx: Context) {
    companion object {
        /** Vorgefertigte ElevenLabs-Stimmen (männlich, britisch/ruhig). Eigene Stimme per ID im SYSTEM-Reiter. */
        val EL_VOICES = listOf("Daniel" to "onwK4e9ZLuTAKqWW03F9", "George" to "JBFqnCBsd6RMkjVDRZzb",
            "Brian" to "nPczCjzI2devNxkB4yrw", "Adam" to "pNInz6obpgDQGcFmaJgB", "Callum" to "N2lVS1w4EtoT3dr4eOWO")
        val VOICES = listOf("Charon", "Orus", "Algenib", "Alnilam", "Iapetus", "Fenrir")
        private val MODELS = listOf("gemini-3.1-flash-tts-preview", "gemini-2.5-flash-preview-tts")
    }

    private val prefs = ctx.getSharedPreferences("boris", 0)
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var track: AudioTrack? = null
    @Volatile private var gen = 0
    @Volatile private var doneCb: (() -> Unit)? = null
    @Volatile var speaking = false
    @Volatile var level = 0f

    init {
        tts = TextToSpeech(ctx) { s ->
            if (s == TextToSpeech.SUCCESS) { ttsReady = true; setupDeviceVoice() }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { speaking = true; pulse() }
            override fun onDone(id: String?) { finish() }
            @Deprecated("Deprecated in Java") override fun onError(id: String?) { finish() }
        })
    }

    private fun score(v: Voice): Int {
        val n = v.name.lowercase()
        var s = 0
        if ("female" in n) s -= 5
        if ("male" in n) s += 4
        if (Regex("smt-m|-m\\d").containsMatchIn(n)) s += 4
        if (!v.isNetworkConnectionRequired) s += 1
        return s
    }

    private fun setupDeviceVoice() {
        val t = tts ?: return
        t.language = Locale.GERMAN
        t.setPitch(0.72f)
        t.setSpeechRate(0.95f)
        val v = t.voices?.filter { it.locale.language == "de" }?.maxByOrNull { score(it) }
        if (v != null) t.voice = v
    }

    private fun pulse() {
        Thread {
            var t = 0f
            while (speaking && track == null) { level = 0.35f + 0.35f * abs(sin(t)); t += 0.5f; Thread.sleep(50) }
            if (track == null) level = 0f
        }.start()
    }

    private fun finish() {
        speaking = false; level = 0f
        val cb = doneCb; doneCb = null
        main.post { cb?.invoke() }
    }

    private fun elKey(): String = prefs.getString("el_key", "") ?: ""
    private fun elVoice(): String = prefs.getString("el_voice", EL_VOICES[0].second) ?: EL_VOICES[0].second

    fun voiceName(): String =
        if (elKey().isNotBlank()) "ElevenLabs " + (EL_VOICES.firstOrNull { it.second == elVoice() }?.first ?: "eigene ID")
        else prefs.getString("gvoice", VOICES[0]) ?: VOICES[0]

    fun cycleVoice(): String {
        if (elKey().isNotBlank()) {
            val i = (EL_VOICES.indexOfFirst { it.second == elVoice() } + 1) % EL_VOICES.size
            prefs.edit().putString("el_voice", EL_VOICES[i].second).apply()
            return voiceName()
        }
        val g = (VOICES.indexOf(prefs.getString("gvoice", VOICES[0]) ?: VOICES[0]) + 1) % VOICES.size
        prefs.edit().putString("gvoice", VOICES[g]).apply()
        return VOICES[g]
    }

    fun elOk(key: String): Boolean = try {
        val c = URL("https://api.elevenlabs.io/v1/models").openConnection() as HttpURLConnection
        c.connectTimeout = 6000; c.readTimeout = 8000; c.setRequestProperty("xi-api-key", key)
        c.responseCode in 200..299
    } catch (e: Exception) { false }

    fun stop() {
        gen++
        try { track?.stop() } catch (e: Exception) {}
        tts?.stop()
        speaking = false; level = 0f
    }

    fun speak(apiKey: String, text: String, onStart: () -> Unit = {}, onDone: () -> Unit = {}) {
        stop()
        val g = gen
        Thread {
            if (elKey().isNotBlank() && streamEleven(elKey(), text, g, onStart, onDone)) return@Thread
            if (g != gen) return@Thread
            val pcm = if (prefs.getBoolean("hq_voice", true) && apiKey.isNotBlank()) fetchPcm(apiKey, text) else null
            if (g != gen) return@Thread
            if (pcm != null) playPcm(pcm, g, onStart, onDone) else deviceSpeak(text, onStart, onDone)
        }.start()
    }

    /** Streamt die ElevenLabs-Stimme und spielt sie ab, sobald die ersten Daten da sind (geringste Verzögerung). */
    private fun streamEleven(key: String, text: String, g: Int, onStart: () -> Unit, onDone: () -> Unit): Boolean {
        val voice = elVoice()
        val cache = File(ctx.cacheDir, "el_" + (voice + "|" + text).hashCode().toUInt().toString(16) + ".pcm")
        if (cache.exists()) { try { playPcm(cache.readBytes(), g, onStart, onDone); return true } catch (e: Exception) {} }
        val c = try {
            val cn = URL("https://api.elevenlabs.io/v1/text-to-speech/$voice/stream?output_format=pcm_24000").openConnection() as HttpURLConnection
            cn.requestMethod = "POST"; cn.connectTimeout = 8000; cn.readTimeout = 20000
            cn.setRequestProperty("content-type", "application/json"); cn.setRequestProperty("xi-api-key", key)
            cn.doOutput = true
            val body = JSONObject().put("text", text.take(500)).put("model_id", "eleven_flash_v2_5")
                .put("voice_settings", JSONObject().put("stability", 0.55).put("similarity_boost", 0.8))
            cn.outputStream.use { it.write(body.toString().toByteArray()) }
            if (cn.responseCode !in 200..299) { Dbg.d("ElevenLabs " + cn.responseCode); return false }
            cn
        } catch (e: Exception) { Dbg.d("ElevenLabs: " + e.message?.take(60)); return false }

        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK).build()
        am.requestAudioFocus(focus)
        val minBuf = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(minBuf, 12000))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track = t
        speaking = true
        main.post { onStart() }
        t.play()
        val all = ByteArrayOutputStream()
        var left: Byte? = null
        var frames = 0L
        try {
            val inp = c.inputStream
            val buf = ByteArray(4096)
            while (g == gen) {
                val n = inp.read(buf)
                if (n <= 0) break
                val chunk = if (left != null) byteArrayOf(left) + buf.copyOf(n) else buf.copyOf(n)
                val even = chunk.size and 1.inv()
                left = if (chunk.size > even) chunk[even] else null
                if (even > 0) {
                    t.write(chunk, 0, even)
                    all.write(chunk, 0, even)
                    frames += even / 2
                    level = rms(chunk, 0, even)
                }
            }
        } catch (e: Exception) { Dbg.d("EL-Stream: " + e.message?.take(50)) }
        if (g == gen) {
            val deadline = System.currentTimeMillis() + 2000 + frames * 1000 / 24000
            while (g == gen && t.playbackHeadPosition < frames && System.currentTimeMillis() < deadline) {
                level *= 0.95f; Thread.sleep(40)
            }
        }
        level = 0f; speaking = false
        try { t.stop() } catch (e: Exception) {}
        t.release(); track = null
        am.abandonAudioFocusRequest(focus)
        if (frames > 0 && all.size() <= 24000 * 2 * 6) try { cache.writeBytes(all.toByteArray()) } catch (e: Exception) {}
        if (g == gen) main.post { onDone() }
        return frames > 0 || g != gen
    }

    private fun deviceSpeak(text: String, onStart: () -> Unit, onDone: () -> Unit) {
        if (!ttsReady) { main.post { onDone() }; return }
        doneCb = onDone
        main.post { onStart() }
        tts?.speak(text.take(900), TextToSpeech.QUEUE_FLUSH, null, "boris")
    }

    fun hqAvailable(apiKey: String): Boolean = apiKey.isNotBlank() && fetchPcmRaw(apiKey, "Test") != null

    private fun fetchPcm(apiKey: String, text: String): ByteArray? {
        val f = java.io.File(ctx.cacheDir, "tts_" + (voiceName() + "|" + text).hashCode().toUInt().toString(16) + ".pcm")
        if (f.exists()) return try { f.readBytes() } catch (e: Exception) { null }
        val pcm = fetchPcmRaw(apiKey, text) ?: return null
        if (text.length <= 90) try {
            val files = ctx.cacheDir.listFiles { x -> x.name.startsWith("tts_") }
            if (files != null && files.size > 60) files.minByOrNull { it.lastModified() }?.delete()
            f.writeBytes(pcm)
        } catch (e: Exception) {}
        return pcm
    }

    private fun fetchPcmRaw(apiKey: String, text: String): ByteArray? {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text",
                "Sage ruhig, tief und souverän, mit trockenem Understatement: ${text.take(400)}")))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig",
                    JSONObject().put("voiceName", voiceName())))))
        for (m in MODELS) {
            try {
                val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.connectTimeout = 8000; c.readTimeout = 20000
                c.setRequestProperty("content-type", "application/json")
                c.setRequestProperty("x-goog-api-key", apiKey)
                c.doOutput = true
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                if (c.responseCode !in 200..299) { if (c.responseCode == 429) return null; continue }
                val j = JSONObject(c.inputStream.bufferedReader().readText())
                val data = j.getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
                    .getJSONArray("parts").getJSONObject(0).getJSONObject("inlineData").getString("data")
                return Base64.decode(data, Base64.DEFAULT)
            } catch (e: Exception) { }
        }
        return null
    }

    private fun rms(pcm: ByteArray, byteOff: Int, len: Int): Float {
        var sum = 0.0; var n = 0
        var i = byteOff.coerceAtLeast(0)
        val end = (byteOff + len).coerceAtMost(pcm.size - 1)
        while (i < end) {
            val s = ((pcm[i].toInt() and 0xFF) or (pcm[i + 1].toInt() shl 8)).toShort().toInt()
            sum += (s / 32768.0) * (s / 32768.0); n++; i += 2
        }
        return if (n == 0) 0f else (Math.sqrt(sum / n) * 3.5).toFloat().coerceIn(0f, 1f)
    }

    private fun playPcm(pcm: ByteArray, g: Int, onStart: () -> Unit, onDone: () -> Unit) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK).build()
        am.requestAudioFocus(focus)
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(pcm.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(pcm, 0, pcm.size)
        track = t
        val frames = pcm.size / 2
        speaking = true
        main.post { onStart() }
        t.play()
        val deadline = System.currentTimeMillis() + frames * 1000L / 24000 + 1500
        while (g == gen && System.currentTimeMillis() < deadline && t.playbackHeadPosition < frames) {
            level = rms(pcm, t.playbackHeadPosition * 2, 1000)
            Thread.sleep(40)
        }
        level = 0f; speaking = false
        try { t.stop() } catch (e: Exception) {}
        t.release(); track = null
        am.abandonAudioFocusRequest(focus)
        if (g == gen) main.post { onDone() }
    }

    fun shutdown() { stop(); tts?.shutdown() }
}
