package com.boris.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Persistenter Langzeitspeicher für Boris. Bleibt auch nach App-Neustart erhalten. */
class MemoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("boris_memory", Context.MODE_PRIVATE)

    fun loadHistory(): JSONArray = try {
        JSONArray(prefs.getString("history", "[]") ?: "[]")
    } catch (_: Exception) { JSONArray() }

    @Synchronized fun saveHistory(history: JSONArray) {
        // Alte Tool-/Screen-Daten nicht endlos aufheben. Textgedächtnis bleibt erhalten.
        val out = JSONArray()
        val start = 0
        for (i in start until history.length()) {
            val item = history.getJSONObject(i)
            val copy = JSONObject()
            copy.put("role", item.optString("role"))
            val parts = item.optJSONArray("parts") ?: continue
            val textParts = JSONArray()
            for (j in 0 until parts.length()) {
                val p = parts.optJSONObject(j) ?: continue
                if (p.has("text")) textParts.put(JSONObject().put("text", p.optString("text")))
            }
            if (textParts.length() > 0) { copy.put("parts", textParts); out.put(copy) }
        }
        prefs.edit().putString("history", out.toString()).apply()
    }

    @Synchronized fun addMemory(text: String) {
        if (text.isBlank()) return
        val memories = try { JSONArray(prefs.getString("memories", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        memories.put(JSONObject().put("text", text.take(500)).put("time", System.currentTimeMillis()))
        // No hard limit: explicit long-term memory.
        prefs.edit().putString("memories", memories.toString()).apply()
    }

    fun memoryText(): String {
        val m = try { JSONArray(prefs.getString("memories", "[]") ?: "[]") } catch (_: Exception) { return "" }
        val start = maxOf(0, m.length() - 80)
        return buildString {
            for (i in start until m.length()) append("- ").append(m.optJSONObject(i)?.optString("text")).append('\n')
        }
    }

    @Synchronized fun recordApp(packageName: String) {
        val apps = try { JSONArray(prefs.getString("apps", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        if (packageName.isBlank() || packageName == "com.boris.assistant") return
        apps.put(packageName)
        while (apps.length() > 100) apps.remove(0)
        prefs.edit().putString("apps", apps.toString()).apply()
    }

    fun recentApps(): String {
        val apps = try { JSONArray(prefs.getString("apps", "[]") ?: "[]") } catch (_: Exception) { return "" }
        val seen = LinkedHashSet<String>()
        for (i in apps.length() - 1 downTo 0) seen.add(apps.optString(i))
        return seen.take(12).joinToString(", ")
    }
}
