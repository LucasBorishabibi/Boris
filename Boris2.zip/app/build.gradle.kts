plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android { namespace = "com.boris.assistant"; compileSdk = 35
    defaultConfig { applicationId = "com.boris.assistant"; minSdk = 26; targetSdk = 35; versionCode = 3; versionName = "2.0.0" }
    buildTypes { release { isMinifyEnabled = false; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro") } }
}
