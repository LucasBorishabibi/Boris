package com.boris.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class ChatMessage(val role: String, val text: String)
class ChatStore(context: Context) {
    private val prefs = context.getSharedPreferences("boris_chat", Context.MODE_PRIVATE)
    private val key = "messages"
    fun all(): List<ChatMessage> { val a=JSONArray(prefs.getString(key,"[]")); return (0 until a.length()).map { val o=a.getJSONObject(it); ChatMessage(o.getString("role"),o.getString("text")) } }
    fun add(m: ChatMessage) { val a=JSONArray(); all().plus(m).takeLast(80).forEach { a.put(JSONObject().put("role",it.role).put("text",it.text)) }; prefs.edit().putString(key,a.toString()).apply() }
    fun clear()=prefs.edit().remove(key).apply()
}
