package com.boris.assistant

import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import org.json.JSONObject

object FreeWeb {
    fun search(query: String): String {
        return try {
            val q=URLEncoder.encode(query,"UTF-8")
            val u=URL("https://api.duckduckgo.com/?q=$q&format=json&no_html=1&skip_disambig=1")
            val c=u.openConnection() as HttpURLConnection; c.connectTimeout=8000; c.readTimeout=10000
            val text=c.inputStream.bufferedReader().use { it.readText() }; val o=JSONObject(text)
            val abstract=o.optString("AbstractText"); val heading=o.optString("Heading")
            if (abstract.isNotBlank()) "Web-Ergebnis: $heading\n\n$abstract\n\nQuelle: DuckDuckGo Instant Answers" else {
                val related=o.optJSONArray("RelatedTopics")
                val out=StringBuilder("Keine direkte Antwort gefunden. Relevante Treffer:\n")
                if (related!=null) for(i in 0 until minOf(related.length(),5)){ val x=related.optJSONObject(i); if(x!=null){ val t=x.optString("Text"); if(t.isNotBlank()) out.append("• ").append(t).append('\n') } }
                out.toString()
            }
        } catch(e: Exception){ "Webzugriff fehlgeschlagen: ${e.message ?: "Netzwerkfehler"}" }
    }
    fun weather(city: String): String {
        return try {
            val geo=URL("https://geocoding-api.open-meteo.com/v1/search?name=${URLEncoder.encode(city,"UTF-8")}&count=1&language=de&format=json").openConnection() as HttpURLConnection
            val g=JSONObject(geo.inputStream.bufferedReader().use{it.readText()}); val r=g.optJSONArray("results")?.optJSONObject(0) ?: return "Ort nicht gefunden."
            val lat=r.getDouble("latitude"); val lon=r.getDouble("longitude"); val name=r.getString("name")
            val w=URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,wind_speed_10m&timezone=auto").openConnection() as HttpURLConnection
            val c=JSONObject(w.inputStream.bufferedReader().use{it.readText()}).getJSONObject("current")
            "$name: ${c.getDouble("temperature_2m")} °C, Luftfeuchte ${c.getInt("relative_humidity_2m")} %, Wind ${c.getDouble("wind_speed_10m")} km/h.\nQuelle: Open-Meteo"
        } catch(e: Exception){ "Wetter konnte nicht geladen werden: ${e.message ?: "Netzwerkfehler"}" }
    }
}
