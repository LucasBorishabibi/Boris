package com.boris.assistant

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object RoutineScheduler {
    fun schedule(context: Context, r: Routine) {
        val am=context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val i=Intent(context,RoutineReceiver::class.java).putExtra("id",r.id).putExtra("prompt",r.prompt).putExtra("name",r.name)
        val pi=PendingIntent.getBroadcast(context,r.id.toInt(),i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val c=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,r.hour);set(Calendar.MINUTE,r.minute);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0);if(timeInMillis<=System.currentTimeMillis())add(Calendar.DAY_OF_YEAR,1)}
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP,c.timeInMillis,AlarmManager.INTERVAL_DAY,pi)
    }
    fun cancel(context:Context,r:Routine){val am=context.getSystemService(Context.ALARM_SERVICE) as AlarmManager;val i=Intent(context,RoutineReceiver::class.java);val pi=PendingIntent.getBroadcast(context,r.id.toInt(),i,PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE);if(pi!=null)am.cancel(pi)}
    fun sync(context:Context){RoutineStore(context).all().forEach{if(it.enabled)schedule(context,it)else cancel(context,it)}}
}
