package com.boris.assistant

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Lightweight agent/router. Keeps the Android app useful even without a remote model. */
class AgentEngine(private val context: Context, private val memory: MemoryStore, private val remote: RemoteBrain, private val evolution: EvolutionEngine) {
    fun systemPrompt(): String = """
Du bist Boris, ein persönlicher KI-Assistent im Stil eines modernen persönlichen AI-Employees.
Du bist proaktiv, präzise, höflich und handlungsorientiert. Du kennst den Nutzer über sein lokales Memory.
Arbeite nicht nur als Chatbot: erkenne Ziele, zerlege Aufgaben in Schritte und nutze verfügbare Tools.
Wenn eine Aktion auf dem Android-Gerät nötig ist, beschreibe sie als konkrete Tool-Aktion.
Sicherheitsregel: Finanz-, Nachrichten-, Lösch-, Versand-, Kauf- oder irreversible Aktionen nie ohne Bestätigung ausführen.
Erfinde niemals erledigte Aktionen. Sage klar, wenn nur eine Android-Seite geöffnet oder eine Aktion vorbereitet wurde.
Heute ist ${SimpleDateFormat("EEEE, dd.MM.yyyy HH:mm", Locale.GERMAN).format(Date())}.
Lokales Memory:\n${memory.all().joinToString("\n") { "- $it" }}\n\n${evolution.contextBlock()}
""".trimIndent()

    fun localIntent(text: String): String? {
        val l = text.lowercase(Locale.GERMAN)
        return when {
            l.contains("morgenbriefing") || l.contains("morgen briefing") || l.contains("guten morgen") || l == "briefing" ->
                buildBriefing()
            l.startsWith("was steht heute an") || l.contains("mein tag") -> buildBriefing()
            l.startsWith("merke ") || l.startsWith("merk dir ") -> null
            l.contains("was weißt du über mich") -> memory.all().joinToString("\n") { "• $it" }.ifBlank { "Noch keine persönlichen Erinnerungen gespeichert." }
            else -> null
        }
    }

    private fun buildBriefing(): String {
        val time = SimpleDateFormat("HH:mm", Locale.GERMAN).format(Date())
        val mem = memory.all()
        val focus = if (mem.isEmpty()) "Noch keine langfristigen Prioritäten gespeichert." else mem.takeLast(5).joinToString("\n") { "• $it" }
        return "Guten Morgen. Es ist $time Uhr.\n\nDein Boris-Briefing:\n$focus\n\nIch kann daraus mit einer KI-Verbindung konkrete Prioritäten, nächste Schritte und einen Tagesplan erstellen."
    }
}
