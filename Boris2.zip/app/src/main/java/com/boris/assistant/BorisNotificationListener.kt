package com.boris.assistant

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class BorisNotificationListener: NotificationListenerService(){
    override fun onNotificationPosted(sbn:StatusBarNotification){
        val extras=sbn.notification.extras
        val title=extras.getString(Notification.EXTRA_TITLE).orEmpty()
        val text=extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if(title.isBlank()&&text.isBlank())return
        getSharedPreferences("boris_notifications",MODE_PRIVATE).edit().putString("last", "$title\n$text").apply()
    }
}
