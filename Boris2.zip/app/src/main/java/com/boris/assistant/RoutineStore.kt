package com.boris.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Routine(val id: Long, val name: String, val prompt: String, val hour: Int, val minute: Int, val enabled: Boolean = true)

class RoutineStore(private val context: Context) {
    private val p = context.getSharedPreferences("boris_routines", Context.MODE_PRIVATE)
    fun all(): List<Routine> {
        val a = JSONArray(p.getString("items", "[]"))
        return buildList { for (i in 0 until a.length()) { val o=a.getJSONObject(i); add(Routine(o.getLong("id"),o.getString("name"),o.getString("prompt"),o.getInt("hour"),o.getInt("minute"),o.optBoolean("enabled",true))) } }
    }
    fun add(name:String,prompt:String,hour:Int,minute:Int):Routine { val r=Routine(System.currentTimeMillis(),name,prompt,hour,minute,true); save(all()+r); return r }
    fun remove(id:Long){save(all().filterNot{it.id==id})}
    fun setEnabled(id:Long,e:Boolean){save(all().map{if(it.id==id)it.copy(enabled=e)else it})}
    private fun save(items:List<Routine>){ val a=JSONArray(); items.forEach{a.put(JSONObject().put("id",it.id).put("name",it.name).put("prompt",it.prompt).put("hour",it.hour).put("minute",it.minute).put("enabled",it.enabled))}; p.edit().putString("items",a.toString()).apply() }
}
