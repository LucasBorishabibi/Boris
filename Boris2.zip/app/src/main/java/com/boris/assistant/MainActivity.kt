package com.boris.assistant

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.*
import android.widget.*
import java.util.*
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var chat: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var modeLabel: TextView
    private lateinit var face: BorisFaceView
    private lateinit var memory: MemoryStore
    private lateinit var chats: ChatStore
    private lateinit var remote: RemoteBrain
    private lateinit var agent: AgentEngine
    private lateinit var tts: TextToSpeech
    private lateinit var routines: RoutineStore
    private lateinit var evolution: EvolutionEngine
    private lateinit var updates: UpdateManager
    private lateinit var phone: PhoneAgent
    private var speech: SpeechRecognizer? = null
    private var wakeMode = false
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val speechCode = 42

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        bindViews()
        memory = MemoryStore(this); chats = ChatStore(this); remote = RemoteBrain(this)
        evolution = EvolutionEngine(this); updates = UpdateManager(this)
        agent = AgentEngine(this, memory, remote, evolution); routines = RoutineStore(this)
        phone = PhoneAgent(this)
        tts = TextToSpeech(this) { code ->
            if (code == TextToSpeech.SUCCESS) {
                tts.language = Locale.GERMANY
                tts.setSpeechRate(0.98f)
            }
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) = runOnUiThread { setMode(BorisFaceView.State.SPEAKING, "SPEAKING") }
            override fun onRangeStart(id: String?, start: Int, end: Int, frame: Int) = runOnUiThread { face.setState(BorisFaceView.State.SPEAKING) }
            override fun onDone(id: String?) = runOnUiThread { setMode(BorisFaceView.State.IDLE, "AT YOUR SERVICE") }
            override fun onError(id: String?) = runOnUiThread { setMode(BorisFaceView.State.IDLE, "AT YOUR SERVICE") }
        })

        BriefingScheduler.schedule(this); RoutineScheduler.sync(this)
        requestCorePermissions()
        findViewById<ImageButton>(R.id.send).setOnClickListener { send() }
        findViewById<ImageButton>(R.id.mic).setOnClickListener { voice() }
        findViewById<ImageButton>(R.id.menu).setOnClickListener { menu() }
        findViewById<TextView>(R.id.chipBriefing).setOnClickListener { handle("briefing") }
        findViewById<TextView>(R.id.chipSearch).setOnClickListener { input.setText("Recherchiere "); input.requestFocus() }
        findViewById<TextView>(R.id.chipMemory).setOnClickListener { showMemory() }
        findViewById<TextView>(R.id.chipListen).setOnClickListener { toggleWakeMode() }
        renderHistory()
        if (chats.all().isEmpty()) addBot("Guten Abend. Boris ist bereit. Sag einfach „Hey Boris“ oder gib mir eine Aufgabe, Sir.")
    }

    private fun bindViews() {
        chat = findViewById(R.id.chat); scroll = findViewById(R.id.scroll); input = findViewById(R.id.input)
        status = findViewById(R.id.status); modeLabel = findViewById(R.id.modeLabel); face = findViewById(R.id.borisFace)
    }

    private fun requestCorePermissions() {
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
    }

    private fun setMode(state: BorisFaceView.State, label: String) {
        face.setState(state)
        modeLabel.text = label
        status.text = when (state) {
            BorisFaceView.State.IDLE -> "●  READY"
            BorisFaceView.State.LISTENING -> "●  LISTENING"
            BorisFaceView.State.THINKING -> "●  THINKING"
            BorisFaceView.State.SPEAKING -> "●  SPEAKING"
        }
        status.setTextColor(getColor(if (state == BorisFaceView.State.SPEAKING) R.color.boris_green else R.color.boris_accent))
    }

    private fun renderHistory() { chat.removeAllViews(); chats.all().forEach { bubble(it.role, it.text) } }

    private fun bubble(role: String, text: String) {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 14f
        tv.setTextColor(getColor(R.color.boris_text))
        tv.setPadding(15, 11, 15, 11)
        tv.setBackgroundResource(if (role == "user") R.drawable.boris_pill else R.drawable.boris_card)
        val lp = LinearLayout.LayoutParams(-2, -2)
        lp.width = (resources.displayMetrics.widthPixels * 0.82f).toInt()
        lp.gravity = if (role == "user") Gravity.END else Gravity.START
        lp.setMargins(4, 4, 4, 4)
        chat.addView(tv, lp)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun addUser(s: String) { chats.add(ChatMessage("user", s)); bubble("user", s) }
    private fun addBot(s: String, speak: Boolean = true) {
        chats.add(ChatMessage("assistant", s)); bubble("assistant", s)
        if (speak) speak(s)
    }

    private fun send() {
        val s = input.text.toString().trim(); if (s.isBlank()) return
        input.setText(""); addUser(s); handle(s)
    }

    private fun handle(original: String) {
        var s = original.trim()
        val l = s.lowercase(Locale.GERMAN)
        val wake = l.matches(Regex("^(hey\\s+)?boris[.!?, ]*$")) || l.startsWith("hey boris") || l.startsWith("hey, boris") || l == "boris"
        if (wake) { addBot("Was gibt's, Sir? Checkste."); return }
        s = s.replaceFirst(Regex("(?i)^(hey[ ,]*)?boris[, ]*"), "").trim()
        if (s.isBlank()) { addBot("Was gibt's, Sir? Checkste."); return }

        setMode(BorisFaceView.State.THINKING, "THINKING")
        agent.localIntent(s)?.let { addBot(it); setMode(BorisFaceView.State.IDLE, "AT YOUR SERVICE"); return }
        val sl = s.lowercase(Locale.GERMAN)
        if (sl.startsWith("merke ") || sl.startsWith("merk dir ")) {
            val v = s.substringAfter(' ').trim(); memory.add(v)
            addBot("Gespeichert, Sir. Das bleibt in deinem lokalen Boris-Memory."); return
        }
        if (sl.contains("meine erinnerungen") || sl == "memory" || sl == "gedächtnis") { showMemory(); return }
        if (sl.contains("kalender") || sl.contains("termine heute")) {
            if (checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.READ_CALENDAR), 12)
                addBot("Ich brauche Kalender-Leserechte, Sir. Android fragt dich einmal nach der Zustimmung.")
            } else addBot(CalendarTools.today(this))
            return
        }
        if (sl.contains("letzte benachrichtigung") || sl.contains("letzte notification")) {
            val n = getSharedPreferences("boris_notifications", MODE_PRIVATE).getString("last", null)
            addBot(n?.let { "Letzte erfasste Benachrichtigung:\n$it" } ?: "Noch keine Benachrichtigung erfasst. Aktiviere den Benachrichtigungszugriff im Menü."); return
        }
        if (sl.startsWith("wetter ")) { io.execute { val r = FreeWeb.weather(s.substringAfter(' ').trim()); runOnUiThread { addBot(r) } }; return }
        if (sl.startsWith("suche ") || sl.startsWith("recherchiere ")) { io.execute { val r = FreeWeb.search(s.substringAfter(' ').trim()); runOnUiThread { addBot(r) } }; return }
        if (sl.startsWith("öffne ") || sl.startsWith("oeffne ")) { openTarget(s.substringAfter(' ').trim()); return }
        if (sl.contains("timer")) { timerDialog(); return }
        if (sl.contains("wecker")) { alarm(); return }
        if (sl.startsWith("sprich ") || sl.startsWith("lies vor ")) { speak(s.substringAfter(' ')); return }

        if (handlePhoneCommand(s)) return

        if (remote.configured()) {
            remote.ask(chats.all(), agent.systemPrompt()) { r -> runOnUiThread { evolution.observe(s, r, !r.startsWith("KI-Verbindung fehlgeschlagen")); addBot(r) } }
            return
        }
        val fallback = localFallback(s)
        evolution.observe(s, fallback, false)
        addBot(fallback)
    }

    private fun handlePhoneCommand(s: String): Boolean {
        val l = s.lowercase(Locale.GERMAN)
        if (l == "zurück" || l == "zurueck" || l == "geh zurück" || l == "geh zurueck") {
            val r = phone.executeAccessibility(PhoneAgent.PhoneAccessibilityCommand.Back); addBot(r.message); return true
        }
        if (l == "home" || l == "geh nach hause") {
            val r = phone.executeAccessibility(PhoneAgent.PhoneAccessibilityCommand.Home); addBot(r.message); return true
        }
        if (l == "app übersicht" || l == "app-übersicht" || l == "apps") {
            val r = phone.executeAccessibility(PhoneAgent.PhoneAccessibilityCommand.Recents); addBot(r.message); return true
        }
        if (l.startsWith("tippe auf ") || l.startsWith("klicke auf ") || l.startsWith("drücke ") || l.startsWith("druecke ")) {
            val q = s.substringAfter(' ').removePrefix("auf ").removePrefix("Auf ").trim()
            val r = phone.executeAccessibility(PhoneAgent.PhoneAccessibilityCommand.TapText(q)); addBot(r.message); return true
        }
        if (l.startsWith("lange auf ") || l.startsWith("halte ")) {
            val q = s.substringAfter(' ').removePrefix("auf ").trim()
            val r = phone.executeAccessibility(PhoneAgent.PhoneAccessibilityCommand.LongPressText(q)); addBot(r.message); return true
        }
        if (l.startsWith("schreibe ") || l.startsWith("tippe ")) {
            val q = s.substringAfter(' ').trim()
            val r = phone.executeAccessibility(PhoneAgent.PhoneAccessibilityCommand.TypeText(q)); addBot(r.message); return true
        }
        if (l.contains("scrolle hoch") || l.contains("nach oben scroll")) {
            val r = phone.executeAccessibility(PhoneAgent.PhoneAccessibilityCommand.Scroll(PhoneAgent.PhoneAccessibilityCommand.Direction.UP)); addBot(r.message); return true
        }
        if (l.contains("scrolle runter") || l.contains("nach unten scroll")) {
            val r = phone.executeAccessibility(PhoneAgent.PhoneAccessibilityCommand.Scroll(PhoneAgent.PhoneAccessibilityCommand.Direction.DOWN)); addBot(r.message); return true
        }
        if (l.startsWith("öffne einstellungen") || l.startsWith("oeffne einstellungen")) {
            val section = s.substringAfter("einstellungen", "").trim(); addBot(phone.openSettings(section).message); return true
        }
        if (l.startsWith("öffne ") || l.startsWith("oeffne ")) {
            val target = s.substringAfter(' ').trim()
            // If it looks like a URL, open it. Otherwise use web search rather than pretending to launch an arbitrary app.
            if (target.contains(".") || target.startsWith("http")) { addBot(phone.openUri(target).message); return true }
        }
        if (l.contains("barrierefreiheit") && (l.contains("öffne") || l.contains("oeffnen") || l.contains("aktivier"))) {
            addBot(phone.openAccessibilitySettings().message); return true
        }
        return false
    }

    private fun localFallback(s: String) = when {
        s.contains("hallo", true) -> "Hallo, Sir. Was steht an?"
        s.contains("wer bist du", true) -> "Ich bin Boris — dein persönlicher Executive Assistant auf diesem Gerät."
        s.contains("zeit", true) -> SimpleDateFormat("HH:mm", Locale.GERMAN).format(Date())
        s.contains("hilfe", true) -> "Sag mir ein Ziel statt eines Menüs. Zum Beispiel: „Recherchiere …“, „Öffne YouTube“, „Merke …“, „Was steht heute an?“ oder „Hey Boris“."
        else -> "Ich habe den Auftrag verstanden, brauche dafür aber noch eine KI-Engine oder ein konkretes lokales Tool. Ich erfinde keine ausgeführten Aktionen."
    }

    private fun voice() {
        if (wakeMode) { toggleWakeMode(); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { addBot("Auf diesem Gerät ist keine Android-Spracherkennung verfügbar."); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10); return }
        setMode(BorisFaceView.State.LISTENING, "LISTENING")
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.GERMANY.toLanguageTag())
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Sprich mit Boris")
        startActivityForResult(i, speechCode)
    }

    private fun toggleWakeMode() {
        if (wakeMode) stopWakeMode() else startWakeMode()
    }

    private fun startWakeMode() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { addBot("Die Android-Spracherkennung ist auf diesem Gerät nicht verfügbar."); return }
        wakeMode = true; setMode(BorisFaceView.State.LISTENING, "WAKE MODE · SAY BORIS")
        speech = SpeechRecognizer.createSpeechRecognizer(this).also { recognizer ->
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim() ?: ""
                    if (heard.isNotBlank()) {
                        val low = heard.lowercase(Locale.GERMAN)
                        if (low.contains("boris")) {
                            handle(heard)
                        }
                    }
                    if (wakeMode) main.postDelayed({ beginWakeListen() }, 450)
                }
                override fun onError(error: Int) { if (wakeMode) main.postDelayed({ beginWakeListen() }, 700) }
                override fun onReadyForSpeech(params: Bundle?) { setMode(BorisFaceView.State.LISTENING, "WAKE MODE · LISTENING") }
                override fun onBeginningOfSpeech() { setMode(BorisFaceView.State.LISTENING, "LISTENING") }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
                override fun onAudioBufferReceived(buffer: ByteArray?) {}
            })
        }
        beginWakeListen()
    }

    private fun beginWakeListen() {
        if (!wakeMode) return
        try {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.GERMANY.toLanguageTag())
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            speech?.startListening(i)
        } catch (_: Exception) { }
    }

    private fun stopWakeMode() {
        wakeMode = false
        speech?.cancel(); speech?.destroy(); speech = null
        setMode(BorisFaceView.State.IDLE, "AT YOUR SERVICE")
    }

    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d)
        if (r == speechCode && c == RESULT_OK) {
            val s = d?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (s != null) { input.setText(s); send() }
        }
        if (r == 77 && c == RESULT_OK && d?.data != null) analyzeFile(d.data!!)
    }

    private fun analyzeFile(uri: Uri) {
        try {
            val name = uri.lastPathSegment ?: "Datei"; val type = contentResolver.getType(uri) ?: "unbekannt"
            if (type.startsWith("text/") || type.contains("json") || type.contains("xml") || type.contains("javascript") || type.contains("kotlin") || type.contains("python")) {
                val raw = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                addBot("Datei: $name\nTyp: $type\nZeichen: ${raw.length}\n\nInhalt (gekürzt):\n${raw.take(12000)}", false)
            } else if (type.startsWith("image/")) addBot("Bild ausgewählt: $name. Die Vision-/OCR-Engine wird als eigenes Boris-Modul nachgerüstet.", false)
            else if (type == "application/pdf") addBot("PDF ausgewählt: $name. Eine vollständige lokale PDF-Analyse ist noch ein separates Modul.", false)
            else addBot("Datei ausgewählt: $name ($type).", false)
        } catch (e: Exception) { addBot("Datei konnte nicht gelesen werden: ${e.message ?: "Zugriff verweigert"}") }
    }

    private fun speak(s: String) {
        if (s.isBlank()) return
        setMode(BorisFaceView.State.SPEAKING, "SPEAKING")
        tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "boris_${System.currentTimeMillis()}")
    }

    private fun openTarget(target: String) {
        val i = when {
            target.startsWith("http") -> Intent(Intent.ACTION_VIEW, Uri.parse(target))
            target.contains("einstellungen", true) -> Intent(Settings.ACTION_SETTINGS)
            target.contains("youtube", true) -> Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
            target.contains("google", true) -> Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))
            else -> Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(target)))
        }
        try { startActivity(i); addBot("Erledigt. Ich habe $target geöffnet.") } catch (_: Exception) { addBot("Ich konnte $target nicht öffnen.") }
    }

    private fun timerDialog() {
        val e = EditText(this); e.inputType = 2; e.hint = "Minuten"
        AlertDialog.Builder(this).setTitle("Timer").setView(e).setPositiveButton("Starten") { _, _ ->
            val m = e.text.toString().toLongOrNull() ?: 1
            val i = Intent(android.provider.AlarmClock.ACTION_SET_TIMER).putExtra(android.provider.AlarmClock.EXTRA_LENGTH, m * 60).putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, "Boris Timer")
            startActivity(i); addBot("Timer über $m Minuten ist vorbereitet.")
        }.setNegativeButton("Abbrechen", null).show()
    }

    private fun alarm() { startActivity(Intent(android.provider.AlarmClock.ACTION_SET_ALARM)); addBot("Ich habe den Android-Wecker vorbereitet. Die finale Aktivierung bestätigst du selbst.") }

    private fun menu() {
        val items = arrayOf("Erinnerungen", "KI-Verbindung", "Jarvis-Briefing", "Routinen", "Kalender", "Benachrichtigungen", "Datei öffnen", "Android-Einstellungen", "Bedienungshilfe", "Chat löschen", "Wake Mode", "Adaptive Core", "Updates", "Über Boris")
        AlertDialog.Builder(this).setTitle("Boris Control") .setItems(items) { _, w -> when (w) {
            0 -> showMemory(); 1 -> providerDialog(); 2 -> addBot(agent.localIntent("briefing") ?: "Bereit.")
            3 -> routinesDialog(); 4 -> { if (checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.READ_CALENDAR), 12) else addBot(CalendarTools.today(this)) }
            5 -> startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); 6 -> filePicker(); 7 -> startActivity(Intent(Settings.ACTION_SETTINGS)); 8 -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            9 -> { chats.clear(); renderHistory() }; 10 -> toggleWakeMode(); 11 -> evolutionDialog(); 12 -> updateDialog(); 13 -> about()
        }}.show()
    }

    private fun routinesDialog() {
        val list = routines.all(); val labels = (list.map { "${it.name} · %02d:%02d".format(it.hour, it.minute) } + "＋ Neue Routine").toTypedArray()
        AlertDialog.Builder(this).setTitle("Boris Routinen").setItems(labels) { _, which ->
            if (which == list.size) addRoutineDialog() else { val r = list[which]; AlertDialog.Builder(this).setTitle(r.name).setMessage("${r.prompt}\n\n${if (r.enabled) "Aktiv" else "Pausiert"}").setPositiveButton(if (r.enabled) "Pausieren" else "Aktivieren") { _, _ -> routines.setEnabled(r.id, !r.enabled); RoutineScheduler.sync(this); routinesDialog() }.setNegativeButton("Löschen") { _, _ -> routines.remove(r.id); RoutineScheduler.cancel(this, r); routinesDialog() }.setNeutralButton("Schließen", null).show() }
        }.setNegativeButton("Schließen", null).show()
    }

    private fun addRoutineDialog() {
        val box = LinearLayout(this); box.orientation = LinearLayout.VERTICAL; box.setPadding(24, 0, 24, 0)
        val name = EditText(this); name.hint = "Name, z.B. Morgenbriefing"; val prompt = EditText(this); prompt.hint = "Was soll Boris vorbereiten?"; val time = EditText(this); time.hint = "Uhrzeit HH:MM"
        box.addView(name); box.addView(prompt); box.addView(time)
        AlertDialog.Builder(this).setTitle("Neue Routine").setView(box).setPositiveButton("Speichern") { _, _ ->
            val parts = time.text.toString().split(":"); val h = parts.getOrNull(0)?.toIntOrNull() ?: 8; val m = parts.getOrNull(1)?.toIntOrNull() ?: 0
            val r = routines.add(name.text.toString().ifBlank { "Boris Routine" }, prompt.text.toString().ifBlank { "Erstelle mein persönliches Briefing." }, h.coerceIn(0, 23), m.coerceIn(0, 59)); RoutineScheduler.schedule(this, r); addBot("Routine '${r.name}' ist für %02d:%02d Uhr eingerichtet.".format(r.hour, r.minute))
        }.setNegativeButton("Abbrechen", null).show()
    }

    private fun showMemory() {
        val list = memory.all(); if (list.isEmpty()) { AlertDialog.Builder(this).setTitle("Memory").setMessage("Noch nichts gespeichert.").setPositiveButton("OK", null).show(); return }
        AlertDialog.Builder(this).setTitle("Boris Memory").setItems(list.toTypedArray()) { _, which -> AlertDialog.Builder(this).setTitle("Erinnerung löschen?").setMessage(list[which]).setPositiveButton("Löschen") { _, _ -> memory.remove(which); showMemory() }.setNegativeButton("Abbrechen", null).show() }.setNegativeButton("Schließen", null).setNeutralButton("Alle löschen") { _, _ -> memory.clear(); showMemory() }.show()
    }

    private fun providerDialog() {
        val box = LinearLayout(this); box.orientation = LinearLayout.VERTICAL; box.setPadding(32, 0, 32, 0)
        val ep = EditText(this); ep.hint = "Endpoint, z.B. https://…/v1"; ep.setText(remote.endpoint()); val model = EditText(this); model.hint = "Modellname"; model.setText(remote.model()); val key = EditText(this); key.hint = "API-Key (optional)"; key.inputType = 129
        box.addView(ep); box.addView(model); box.addView(key)
        AlertDialog.Builder(this).setTitle("KI-Verbindung").setMessage("Boris bleibt provider-unabhängig. Zugangsdaten werden nur lokal gespeichert.").setView(box).setPositiveButton("Speichern") { _, _ -> remote.set(ep.text.toString(), model.text.toString(), key.text.toString()); addBot("KI-Verbindung gespeichert.") }.setNegativeButton("Abbrechen", null).show()
    }

    private fun filePicker() { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 77) }

    private fun evolutionDialog() {
        val options = arrayOf("Status anzeigen", "Lernprofil löschen")
        AlertDialog.Builder(this).setTitle("Boris Adaptive Core").setItems(options) { _, which ->
            if (which == 0) AlertDialog.Builder(this).setTitle("Selbstlernen").setMessage(evolution.status()).setPositiveButton("OK", null).show()
            else AlertDialog.Builder(this).setTitle("Lernprofil löschen?").setMessage("Damit werden automatisch gelernte Präferenzen und Lernsignale gelöscht. Dein normales Memory bleibt erhalten.").setPositiveButton("Löschen") { _, _ -> evolution.reset(); addBot("Adaptive Lernsignale wurden gelöscht, Sir.") }.setNegativeButton("Abbrechen", null).show()
        }.setNegativeButton("Schließen", null).show()
    }

    private fun updateDialog() {
        val box = LinearLayout(this); box.orientation = LinearLayout.VERTICAL; box.setPadding(32, 0, 32, 0)
        val repo = EditText(this); repo.hint = "GitHub: owner/repository"; repo.setText(updates.repo()); box.addView(repo)
        AlertDialog.Builder(this).setTitle("Boris Updates").setMessage("Boris kann nach signierten GitHub-Releases suchen. Android verlangt bei einer APK-Installation deine Zustimmung.").setView(box).setPositiveButton("Prüfen") { _, _ ->
            updates.setRepo(repo.text.toString()); updates.check { result -> runOnUiThread {
                when (result) {
                    is UpdateManager.UpdateResult.Available -> AlertDialog.Builder(this).setTitle("Update verfügbar").setMessage("Version ${result.version} ist verfügbar.").setPositiveButton("Release öffnen") { _, _ -> updates.openRelease(result.url) }.setNegativeButton("Später", null).show()
                    is UpdateManager.UpdateResult.Current -> Toast.makeText(this, "Boris ist aktuell: ${result.version}", Toast.LENGTH_LONG).show()
                    is UpdateManager.UpdateResult.None -> Toast.makeText(this, result.reason, Toast.LENGTH_LONG).show()
                    is UpdateManager.UpdateResult.Error -> Toast.makeText(this, result.reason, Toast.LENGTH_LONG).show()
                }
            } }
        }.setNegativeButton("Abbrechen", null).setNeutralButton("Installationsrechte") { _, _ -> updates.openInstallPermission() }.show()
    }

    private fun about() { AlertDialog.Builder(this).setTitle("Boris").setMessage("Boris ist als persönlicher Executive Assistant gebaut: Voice, Memory, Routinen, Web, Android-Aktionen und ein Agentenkern. Die Oberfläche reagiert visuell auf Zuhören, Denken und Sprechen. Riskante Aktionen sollen immer bestätigt werden.").setPositiveButton("OK", null).show() }

    override fun onDestroy() {
        stopWakeMode(); tts.shutdown(); io.shutdown(); super.onDestroy()
    }
}
