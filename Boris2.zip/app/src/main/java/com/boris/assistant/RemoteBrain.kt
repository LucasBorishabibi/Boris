package com.boris.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class RemoteBrain(context: Context) {
    private val p=context.getSharedPreferences("boris_provider",Context.MODE_PRIVATE)
    fun configured()=p.getString("endpoint","")!!.isNotBlank()
    fun endpoint()=p.getString("endpoint","") ?: ""
    fun model()=p.getString("model","") ?: ""
    fun set(endpoint:String, model:String, key:String){ p.edit().putString("endpoint",endpoint.trim()).putString("model",model.trim()).putString("key",key).apply() }
    fun ask(history: List<ChatMessage>, systemPrompt: String = "", callback:(String)->Unit){
        Thread {
            try {
                val base=endpoint().trimEnd('/'); val target=if(base.endsWith("/chat/completions"))base else "$base/chat/completions"; val url=URL(target); val c=url.openConnection() as HttpURLConnection
                c.requestMethod="POST"; c.connectTimeout=15000; c.readTimeout=30000; c.doOutput=true; c.setRequestProperty("Content-Type","application/json")
                val k=p.getString("key","")!!; if(k.isNotBlank()) c.setRequestProperty("Authorization","Bearer $k")
                val msgs=JSONArray(); if(systemPrompt.isNotBlank()) msgs.put(JSONObject().put("role","system").put("content",systemPrompt)); history.takeLast(16).forEach{ msgs.put(JSONObject().put("role",it.role).put("content",it.text)) }
                val body=JSONObject().put("model",model()).put("messages",msgs).put("temperature",0.7).toString(); c.outputStream.use{it.write(body.toByteArray())}
                val raw=(if(c.responseCode in 200..299)c.inputStream else c.errorStream).bufferedReader().use{it.readText()}; val o=JSONObject(raw)
                val answer=o.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content") ?: raw
                callback(answer)
            } catch(e:Exception){ callback("KI-Verbindung fehlgeschlagen: ${e.message ?: "Unbekannter Fehler"}\n\nTipp: In Einstellungen kannst du einen kostenlosen OpenAI-kompatiblen Endpunkt eintragen.") }
        }.start()
    }
}
