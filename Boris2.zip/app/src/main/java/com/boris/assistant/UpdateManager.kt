package com.boris.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Checks a user-configured GitHub repository for signed releases. Installation is user-confirmed by Android. */
class UpdateManager(context: Context) {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("boris_updates", Context.MODE_PRIVATE)

    fun repo(): String = prefs.getString("repo", "") ?: ""
    fun setRepo(value: String) = prefs.edit().putString("repo", value.trim().removeSuffix("/" )).apply()

    fun check(callback: (UpdateResult) -> Unit) {
        val r = repo()
        if (r.isBlank()) { callback(UpdateResult.None("Kein Update-Repository eingerichtet.")); return }
        Thread {
            try {
                val normalized = r.replace("https://github.com/", "").removeSuffix("/")
                val parts = normalized.split("/").filter { it.isNotBlank() }
                if (parts.size < 2) throw IllegalArgumentException("GitHub-Repository muss owner/name sein")
                val url = URL("https://api.github.com/repos/${parts[0]}/${parts[1]}/releases/latest")
                val c = url.openConnection() as HttpURLConnection
                c.connectTimeout = 10000; c.readTimeout = 15000
                c.setRequestProperty("Accept", "application/vnd.github+json")
                val raw = c.inputStream.bufferedReader().use { it.readText() }
                val o = JSONObject(raw)
                val tag = o.optString("tag_name").removePrefix("v")
                val current = app.packageManager.getPackageInfo(app.packageName, 0).versionName ?: "0.0.0"
                if (compareVersions(tag, current) > 0) {
                    callback(UpdateResult.Available(tag, o.optString("html_url")))
                } else callback(UpdateResult.Current(current))
            } catch (e: Exception) { callback(UpdateResult.Error(e.message ?: "Update-Prüfung fehlgeschlagen")) }
        }.start()
    }

    fun openRelease(url: String) = app.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    fun openInstallPermission() {
        if (Build.VERSION.SDK_INT >= 26) app.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${app.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun compareVersions(a: String, b: String): Int {
        val aa = a.split(".").map { it.toIntOrNull() ?: 0 }
        val bb = b.split(".").map { it.toIntOrNull() ?: 0 }
        for (i in 0 until maxOf(aa.size, bb.size)) {
            val x = aa.getOrElse(i) { 0 }; val y = bb.getOrElse(i) { 0 }
            if (x != y) return x.compareTo(y)
        }
        return 0
    }

    sealed class UpdateResult {
        data class Available(val version: String, val url: String): UpdateResult()
        data class Current(val version: String): UpdateResult()
        data class None(val reason: String): UpdateResult()
        data class Error(val reason: String): UpdateResult()
    }
}
