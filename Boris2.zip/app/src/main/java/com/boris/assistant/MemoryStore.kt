package com.boris.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class MemoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("boris_memory", Context.MODE_PRIVATE)
    private val key = "items"
    fun all(): List<String> {
        val a = JSONArray(prefs.getString(key, "[]")); return (0 until a.length()).map { a.getString(it) }
    }
    fun add(value: String) { val a = JSONArray(); all().plus(value.trim()).distinct().takeLast(100).forEach { a.put(it) }; prefs.edit().putString(key, a.toString()).apply() }
    fun remove(index: Int) { val a = JSONArray(); all().filterIndexed { i, _ -> i != index }.forEach { a.put(it) }; prefs.edit().putString(key, a.toString()).apply() }
    fun clear() = prefs.edit().remove(key).apply()
}
