package com.boris.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.View
import kotlin.math.sin

/** Minimal, premium-looking Boris avatar. It reacts to listening/thinking/speaking states. */
class BorisFaceView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {
    enum class State { IDLE, LISTENING, THINKING, SPEAKING }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val handler = Handler(Looper.getMainLooper())
    private var state = State.IDLE
    private var phase = 0f
    private var pulse = 0f
    private val tick = object : Runnable {
        override fun run() {
            phase += 0.12f
            pulse = when (state) {
                State.SPEAKING -> (sin(phase * 4.0) + 1f) / 2f
                State.LISTENING -> (sin(phase) + 1f) / 2f
                State.THINKING -> (sin(phase * 0.65) + 1f) / 2f
                State.IDLE -> 0.12f + (sin(phase * 0.4) + 1f) * 0.04f
            }
            invalidate()
            handler.postDelayed(this, 28L)
        }
    }

    init { handler.post(tick) }

    fun setState(value: State) { state = value; invalidate() }

    override fun onDetachedFromWindow() {
        handler.removeCallbacksAndMessages(null)
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2f; val cy = h / 2f
        val r = minOf(w, h) * 0.37f

        paint.style = Paint.Style.FILL
        paint.color = 0xFF15181D.toInt()
        canvas.drawCircle(cx, cy, r, paint)

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2.5f
        paint.color = when (state) {
            State.LISTENING -> 0xFF6EA8FF.toInt()
            State.THINKING -> 0xFFB8C7FF.toInt()
            State.SPEAKING -> 0xFF7FE0C1.toInt()
            State.IDLE -> 0xFF4B535F.toInt()
        }
        canvas.drawCircle(cx, cy, r + 7f + pulse * 8f, paint)
        paint.style = Paint.Style.FILL

        val eyeY = cy - r * 0.22f
        val eyeGap = r * 0.42f
        paint.color = 0xFFF4F7FB.toInt()
        canvas.drawRoundRect(RectF(cx - eyeGap - 5f, eyeY - 14f, cx - eyeGap + 5f, eyeY + 14f), 5f, 5f, paint)
        canvas.drawRoundRect(RectF(cx + eyeGap - 5f, eyeY - 14f, cx + eyeGap + 5f, eyeY + 14f), 5f, 5f, paint)

        val mouthWidth = r * 0.48f
        val mouthY = cy + r * 0.30f
        paint.color = 0xFFF4F7FB.toInt()
        paint.strokeWidth = 5f + if (state == State.SPEAKING) pulse * 9f else 0f
        paint.style = Paint.Style.STROKE
        val smile = RectF(cx - mouthWidth, mouthY - 8f, cx + mouthWidth, mouthY + 18f)
        canvas.drawArc(smile, 15f, 150f, false, paint)

        if (state == State.THINKING) {
            paint.style = Paint.Style.FILL
            paint.color = 0xFFB8C7FF.toInt()
            for (i in 0..2) canvas.drawCircle(cx - 13f + i * 13f, cy + r * 0.62f, 3f + pulse * 2f, paint)
        }
        paint.style = Paint.Style.FILL
    }
}
