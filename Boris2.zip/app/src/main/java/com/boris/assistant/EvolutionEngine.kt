package com.boris.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Boris' adaptive layer. It learns from interaction outcomes and preferences without
 * pretending to be conscious. It may change local routing, prompts, routines and
 * preferences automatically; APK/source-code changes are handled as signed updates.
 */
class EvolutionEngine(context: Context) {
    data class Insight(val key: String, val value: String, val confidence: Float, val updatedAt: Long)

    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("boris_evolution", Context.MODE_PRIVATE)
    private val observationsKey = "observations"
    private val insightsKey = "insights"

    fun observe(input: String, output: String, success: Boolean) {
        val clean = input.trim().take(240)
        if (clean.isBlank()) return
        val a = JSONArray(prefs.getString(observationsKey, "[]"))
        val item = JSONObject()
            .put("time", System.currentTimeMillis())
            .put("input", clean)
            .put("success", success)
            .put("output", output.take(180))
        a.put(item)
        while (a.length() > 200) a.remove(0)
        prefs.edit().putString(observationsKey, a.toString()).apply()
        learnFrom(clean)
    }

    private fun learnFrom(text: String) {
        val l = text.lowercase(Locale.GERMAN)
        val candidates = linkedMapOf(
            "language" to if (l.contains("englisch") || l.contains("english")) "en" else if (l.contains("deutsch") || l.contains("german")) "de" else null,
            "style" to when {
                l.contains("kurz") || l.contains("kurze antwort") -> "concise"
                l.contains("detailliert") || l.contains("ausführlich") -> "detailed"
                else -> null
            },
            "tone" to when {
                l.contains("business") || l.contains("geschäftlich") -> "executive"
                l.contains("locker") || l.contains("entspannt") -> "casual"
                else -> null
            }
        )
        candidates.forEach { (key, value) -> if (value != null) putInsight(key, value, 0.7f) }
    }

    fun learnExplicit(key: String, value: String, confidence: Float = 0.95f) {
        putInsight(key.trim().take(80), value.trim().take(240), confidence.coerceIn(0f, 1f))
    }

    private fun putInsight(key: String, value: String, confidence: Float) {
        val all = JSONArray(prefs.getString(insightsKey, "[]"))
        val filtered = JSONArray()
        for (i in 0 until all.length()) if (all.getJSONObject(i).optString("key") != key) filtered.put(all.getJSONObject(i))
        filtered.put(JSONObject().put("key", key).put("value", value).put("confidence", confidence).put("updatedAt", System.currentTimeMillis()))
        while (filtered.length() > 80) filtered.remove(0)
        prefs.edit().putString(insightsKey, filtered.toString()).apply()
    }

    fun insights(): List<Insight> {
        val a = JSONArray(prefs.getString(insightsKey, "[]"))
        return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Insight(o.optString("key"), o.optString("value"), o.optDouble("confidence", 0.5).toFloat(), o.optLong("updatedAt"))
        }.reversed()
    }

    fun recentFailures(): List<String> {
        val a = JSONArray(prefs.getString(observationsKey, "[]"))
        return (0 until a.length()).mapNotNull { i ->
            val o = a.getJSONObject(i)
            if (!o.optBoolean("success", true)) o.optString("input").takeIf { it.isNotBlank() } else null
        }.takeLast(10).reversed()
    }

    fun contextBlock(): String = buildString {
        append("ADAPTIVE PROFILE:\n")
        insights().take(12).forEach { append("- ${it.key}: ${it.value} (confidence ${"%.0f".format(Locale.US, it.confidence * 100)}%)\n") }
        if (recentFailures().isNotEmpty()) {
            append("RECENT FAILURES TO LEARN FROM:\n")
            recentFailures().forEach { append("- $it\n") }
        }
    }.trim()

    fun status(): String {
        val date = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.GERMAN)
        val i = insights().size
        val failures = recentFailures().size
        return "Adaptive Core\n\nGelernte Muster: $i\nOffene Lernsignale: $failures\nLetzte Aktualisierung: ${date.format(Date())}\n\nBoris passt lokale Präferenzen, Routing und Prompts automatisch an. Quellcode wird nicht heimlich zur Laufzeit verändert; Code-Updates laufen über signierte APK-Releases."
    }

    fun reset() = prefs.edit().clear().apply()
}
