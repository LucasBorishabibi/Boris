package com.boris.assistant

import android.app.Notification
import android.app.NotificationManager
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject

/** Stumm geschaltete Quellen (App oder Absender), optional mit Ablaufzeit. */
object Mute {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("boris", 0)
    private fun load(ctx: Context): JSONArray = JSONArray(prefs(ctx).getString("muted", "[]") ?: "[]")

    fun add(ctx: Context, target: String, minutes: Int): String {
        val t = target.trim().lowercase()
        val a = load(ctx)
        a.put(JSONObject().put("t", t).put("until", if (minutes > 0) System.currentTimeMillis() + minutes * 60_000L else 0L))
        prefs(ctx).edit().putString("muted", a.toString()).apply()
        return "Verstanden, ${if (t == "alle") "ich lese vorerst gar nichts mehr vor" else "ich lese $target nicht mehr vor"}" +
            (if (minutes > 0) " (für $minutes Minuten)." else ".")
    }

    fun remove(ctx: Context, target: String): Int {
        val t = target.trim().lowercase()
        val a = load(ctx); val keep = JSONArray(); var n = 0
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (t == "alle" || o.getString("t").contains(t)) n++ else keep.put(o)
        }
        prefs(ctx).edit().putString("muted", keep.toString()).apply()
        return n
    }

    fun isMuted(ctx: Context, vararg haystack: String): Boolean {
        val a = load(ctx)
        val now = System.currentTimeMillis()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val until = o.getLong("until")
            if (until != 0L && until < now) continue
            val t = o.getString("t")
            if (t == "alle") return true
            if (haystack.any { it.lowercase().contains(t) }) return true
        }
        return false
    }
}

/** Spricht Zusammenfassungen nacheinander, ohne laufende Antworten zu unterbrechen. ask = Boris stellt eine Rückfrage und hört zu. */
object NotifSpeaker {
    private val q = java.util.ArrayDeque<Pair<String, Boolean>>()
    private var playing = false
    private var token = 0
    private val h = Handler(Looper.getMainLooper())

    @Synchronized fun add(ctx: Context, text: String, ask: Boolean) {
        if (q.size >= 6) q.pollFirst()
        q.addLast(text to ask)
        if (!playing) { playing = true; h.post { next(ctx, 0) } }
    }

    private fun next(ctx: Context, waited: Int) {
        val busy = Core.busy || PhoneAgent.running || Hub.jarvis(ctx).speaking
        if (busy && waited < 40) { h.postDelayed({ next(ctx, waited + 1) }, 1000); return }
        val item = synchronized(this) { q.pollFirst() }
        if (item == null) { FloatBorisOverlay.dismiss(); synchronized(this) { playing = false }; return }
        val tok = ++token
        val done = { if (tok == token) h.post { FloatBorisOverlay.dismiss(); next(ctx, 0) } }
        FloatBorisOverlay.show(ctx, item.first)
        val eco = !ctx.getSharedPreferences("boris", 0).getBoolean("el_notif", false)
        if (item.second) Core.announce(ctx, item.first, true, done, eco) else Core.say(ctx, item.first, false, done, eco)
        h.postDelayed({ if (tok == token) next(ctx, 0) }, 30_000)
    }
}

/** Liest jede eingehende Benachrichtigung vor (ohne zu antworten), außer die Quelle ist stumm geschaltet. */
class NotifService : NotificationListenerService() {
    companion object {
        @Volatile var instance: NotifService? = null
        @Volatile var lastApp = ""
        @Volatile var lastSender = ""
        private val CHAT_APPS = setOf(
            "com.whatsapp", "org.telegram.messenger", "org.thoughtcrime.securesms", "com.discord",
            "com.instagram.android", "com.google.android.apps.messaging", "com.samsung.android.messaging", "com.facebook.orca"
        )
        private val SKIP = setOf(
            Notification.CATEGORY_PROGRESS, Notification.CATEGORY_SERVICE, Notification.CATEGORY_TRANSPORT,
            Notification.CATEGORY_SYSTEM, Notification.CATEGORY_STATUS, "navigation"
        )
    }

    private val seen = HashMap<String, Long>()

    override fun onListenerConnected() { instance = this; Brain.load(this) }
    override fun onListenerDisconnected() { instance = null }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        Thread { try { handle(sbn) } catch (e: Exception) { Dbg.d("Benachrichtigung: " + e.message?.take(60)) } }.start()
    }

    private fun handle(sbn: StatusBarNotification) {
        val prefs = getSharedPreferences("boris", 0)
        val n = sbn.notification
        val pkg = sbn.packageName
        if (pkg == packageName || sbn.isOngoing || (n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if (n.category in SKIP) return
        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = (ex.getCharSequence(Notification.EXTRA_TEXT) ?: ex.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString() ?: ""
        if (title.isBlank() && text.isBlank()) return
        Scheduler.matchWatch(this, title)?.let { w ->
            Core.announce(this, w.optString("text").ifBlank { "$title hat dir geschrieben" } + ": " + text.take(80), false)
            return
        }
        if (!prefs.getBoolean("notif_ai", true)) return
        if (AutoSendService.instance?.curPkg == pkg) return
        if (getSystemService(NotificationManager::class.java).currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL) return
        if (!(getSystemService(POWER_SERVICE) as PowerManager).isInteractive) return
        val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }
        if (Mute.isMuted(this, label, title, pkg)) return
        val now = System.currentTimeMillis()
        synchronized(this) {
            val k = "$pkg|$title|$text"
            if (now - (seen[k] ?: 0L) < 20_000) return
            seen[k] = now
            if (seen.size > 200) seen.clear()
        }
        lastApp = label; lastSender = title
        val sys = "Du bist Boris, ein souveräner KI-Assistent im Stil von J.A.R.V.I.S. Fasse die Benachrichtigung für den Nutzer in EINEM kurzen, gesprochenen deutschen Satz zusammen (höchstens 18 Wörter). " +
            "Nenne Absender oder App und worum es geht, aber gib NICHT den Wortlaut wieder. " +
            "Nur wenn der Absender etwas fragt, etwas entschieden werden muss oder eine Antwort naheliegt, setze ask auf true und beende den Satz mit einer kurzen Rückfrage (z.B. ‚Soll ich antworten?‘). " +
            "Bekanntes über den Nutzer:\n${Brain.prompt()}\n" +
            "Antworte NUR mit JSON {\"say\":\"...\",\"ask\":true oder false}"
        val out = Notify.ask(this, sys, "App: $label\nAbsender oder Titel: $title\nText: $text")
        val js = try { JSONObject(out!!.substring(out.indexOf('{'), out.lastIndexOf('}') + 1)) } catch (e: Exception) { null }
        if (js != null && js.optString("say").isNotBlank()) NotifSpeaker.add(this, js.optString("say"), js.optBoolean("ask"))
        else NotifSpeaker.add(this, line(label, title, text, pkg in CHAT_APPS || n.category == Notification.CATEGORY_MESSAGE).take(110), false)
    }

    private fun line(label: String, title: String, text: String, chat: Boolean): String {
        val t = text.replace(Regex("https?://\\S+"), "Link").replace(Regex("\\s+"), " ").trim().take(160)
        val head = title.trim().take(60)
        return when {
            head.isBlank() -> "$label: $t"
            t.isBlank() -> "$label: $head"
            chat -> "$label von $head: $t"
            else -> "$label. $head. $t"
        }
    }

    /** Antwortet direkt über die Antwort-Funktion einer offenen Benachrichtigung (nur auf ausdrücklichen Wunsch). */
    fun reply(match: String, text: String): String? {
        val list = try { activeNotifications } catch (e: Exception) { return null }
        for (sbn in list) {
            val ex = sbn.notification.extras
            val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            val conv = ex.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString() ?: ""
            if (!title.contains(match, true) && !conv.contains(match, true)) continue
            val act = sbn.notification.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true } ?: continue
            val ri = act.remoteInputs
            val i = Intent()
            val b = Bundle(); b.putCharSequence(ri[0].resultKey, text)
            RemoteInput.addResultsToIntent(ri, i, b)
            act.actionIntent.send(this, 0, i)
            return "Antwort an ${title.ifBlank { conv }} gesendet."
        }
        return null
    }

    fun summary(): String {
        val list = try { activeNotifications } catch (e: Exception) { return "Benachrichtigungszugriff nicht verfügbar." }
        val lines = list.filter { !it.isOngoing && it.packageName != packageName }.take(15).map {
            val ex = it.notification.extras
            val app = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(it.packageName, 0)).toString() } catch (e: Exception) { it.packageName }
            "$app: ${ex.getCharSequence(Notification.EXTRA_TITLE) ?: ""} – ${ex.getCharSequence(Notification.EXTRA_TEXT) ?: ""}"
        }
        return if (lines.isEmpty()) "INFO: Keine offenen Benachrichtigungen." else "INFO: Offene Benachrichtigungen:\n" + lines.joinToString("\n")
    }
}
