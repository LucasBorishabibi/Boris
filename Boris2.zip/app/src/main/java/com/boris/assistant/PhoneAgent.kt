package com.boris.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

/**
 * PhoneAgent is Boris' safe action facade. It prefers public Android intents and
 * delegates cross-app UI actions to the user's explicitly enabled AccessibilityService.
 */
class PhoneAgent(private val context: Context) {
    data class Result(val ok: Boolean, val message: String)

    fun openUri(raw: String): Result = try {
        val uri = if (raw.startsWith("http://") || raw.startsWith("https://")) Uri.parse(raw)
        else Uri.parse("https://www.google.com/search?q=" + Uri.encode(raw))
        context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        Result(true, "Geöffnet: $raw")
    } catch (e: Exception) { Result(false, "Konnte $raw nicht öffnen: ${e.message ?: "unbekannter Fehler"}") }

    fun openSettings(section: String = ""): Result = try {
        val action = when (section.lowercase()) {
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "wifi", "wlan" -> Settings.ACTION_WIFI_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "ton", "sound" -> Settings.ACTION_SOUND_SETTINGS
            "anzeige", "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "akku", "batterie" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "barrierefreiheit", "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        Result(true, "Einstellungen geöffnet.")
    } catch (e: Exception) { Result(false, "Einstellungen konnten nicht geöffnet werden.") }

    fun openAccessibilitySettings(): Result = openSettings("accessibility")

    fun executeAccessibility(command: PhoneAccessibilityCommand): Result {
        val service = BorisAccessibilityService.instance
            ?: return Result(false, "Phone-Agent ist nicht verbunden. Aktiviere zuerst den Boris-Barrierefreiheitsdienst.")
        return service.execute(command)
    }

    fun isAccessibilityEnabled(): Boolean = BorisAccessibilityService.instance != null

    sealed class PhoneAccessibilityCommand {
        data class TapText(val text: String) : PhoneAccessibilityCommand()
        data class TapDescription(val text: String) : PhoneAccessibilityCommand()
        data class TypeText(val text: String) : PhoneAccessibilityCommand()
        data class LongPressText(val text: String) : PhoneAccessibilityCommand()
        data class Scroll(val direction: Direction) : PhoneAccessibilityCommand()
        data object Back : PhoneAccessibilityCommand()
        data object Home : PhoneAccessibilityCommand()
        data object Recents : PhoneAccessibilityCommand()
        enum class Direction { UP, DOWN, LEFT, RIGHT }
    }
}
