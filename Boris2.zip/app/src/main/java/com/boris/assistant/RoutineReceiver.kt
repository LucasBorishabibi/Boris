package com.boris.assistant

import android.app.*
import android.content.*
import android.os.IBinder

class RoutineReceiver: BroadcastReceiver(){
    override fun onReceive(context:Context,intent:Intent){
        val nm=context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if(android.os.Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(NotificationChannel("boris_routines","Boris Routinen",NotificationManager.IMPORTANCE_DEFAULT))
        val prompt=intent.getStringExtra("prompt")?:"Routine"
        val name=intent.getStringExtra("name")?:"Boris"
        val pi=PendingIntent.getActivity(context,991,Intent(context,MainActivity::class.java).putExtra("routine_prompt",prompt),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n=Notification.Builder(context,"boris_routines").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Boris · $name").setContentText(prompt.take(120)).setAutoCancel(true).setContentIntent(pi).build()
        nm.notify((intent.getLongExtra("id",System.currentTimeMillis())).toInt(),n)
    }
}
