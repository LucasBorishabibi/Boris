package com.boris.assistant

import android.content.Context
import android.provider.CalendarContract
import java.text.SimpleDateFormat
import java.util.*

object CalendarTools {
    fun today(context:Context):String {
        if(context.checkSelfPermission(android.Manifest.permission.READ_CALENDAR)!=android.content.pm.PackageManager.PERMISSION_GRANTED) return "Kalenderzugriff ist noch nicht erlaubt."
        val start=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}.timeInMillis
        val end=start+24*60*60*1000L
        val cur=context.contentResolver.query(CalendarContract.Instances.CONTENT_URI.buildUpon().appendPath(start.toString()).appendPath(end.toString()).build(),arrayOf(CalendarContract.Instances.TITLE,CalendarContract.Instances.BEGIN,CalendarContract.Instances.END),null,null,CalendarContract.Instances.BEGIN+" ASC")?:return "Kalender konnte nicht gelesen werden."
        val f=SimpleDateFormat("HH:mm",Locale.GERMAN); val out=StringBuilder("Heutiger Kalender:\n")
        cur.use{while(it.moveToNext()){out.append("• ").append(it.getString(0)).append(" — ").append(f.format(Date(it.getLong(1)))).append("–").append(f.format(Date(it.getLong(2)))).append('\n')}}
        return if(out.toString()=="Heutiger Kalender:\n")"Heute sind keine Termine eingetragen." else out.toString().trim()
    }
}
