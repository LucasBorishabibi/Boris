package com.boris.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo

class BorisAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: BorisAccessibilityService? = null }

    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) { }
    override fun onInterrupt() { }

    fun execute(command: PhoneAgent.PhoneAccessibilityCommand): PhoneAgent.Result {
        return when (command) {
            is PhoneAgent.PhoneAccessibilityCommand.TapText -> clickText(command.text, false)
            is PhoneAgent.PhoneAccessibilityCommand.LongPressText -> clickText(command.text, true)
            is PhoneAgent.PhoneAccessibilityCommand.TapDescription -> clickDescription(command.text)
            is PhoneAgent.PhoneAccessibilityCommand.TypeText -> typeIntoFocused(command.text)
            is PhoneAgent.PhoneAccessibilityCommand.Scroll -> scroll(command.direction)
            PhoneAgent.PhoneAccessibilityCommand.Back -> PhoneAgent.Result(performGlobalAction(GLOBAL_ACTION_BACK), "Zurück ausgeführt.")
            PhoneAgent.PhoneAccessibilityCommand.Home -> PhoneAgent.Result(performGlobalAction(GLOBAL_ACTION_HOME), "Home ausgeführt.")
            PhoneAgent.PhoneAccessibilityCommand.Recents -> PhoneAgent.Result(performGlobalAction(GLOBAL_ACTION_RECENTS), "App-Übersicht geöffnet.")
        }
    }

    private fun clickText(query: String, long: Boolean): PhoneAgent.Result {
        val root = rootInActiveWindow ?: return PhoneAgent.Result(false, "Kein aktiver Bildschirm verfügbar.")
        val nodes = root.findAccessibilityNodeInfosByText(query)
        val node = nodes.firstOrNull { it.isVisibleToUser && it.isClickable } ?: nodes.firstOrNull { it.isVisibleToUser }
            ?: return PhoneAgent.Result(false, "Kein sichtbares Element mit „$query“ gefunden.")
        if (long && node.isLongClickable) node.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)
        else if (!node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            val parent = node.parent
            if (parent != null) parent.performAction(AccessibilityNodeInfo.ACTION_CLICK) else return PhoneAgent.Result(false, "Element konnte nicht geklickt werden.")
        }
        return PhoneAgent.Result(true, if (long) "„$query“ lange gedrückt." else "„$query“ angeklickt.")
    }

    private fun clickDescription(query: String): PhoneAgent.Result {
        val root = rootInActiveWindow ?: return PhoneAgent.Result(false, "Kein aktiver Bildschirm verfügbar.")
        val queue = ArrayDeque<AccessibilityNodeInfo>(); queue.add(root)
        while (queue.isNotEmpty()) {
            val n = queue.removeFirst()
            if (n.isVisibleToUser && n.contentDescription?.toString()?.contains(query, true) == true) {
                val ok = n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                return PhoneAgent.Result(ok, if (ok) "„$query“ angeklickt." else "Element konnte nicht geklickt werden.")
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let(queue::add)
        }
        return PhoneAgent.Result(false, "Keine Beschreibung „$query“ gefunden.")
    }

    private fun typeIntoFocused(text: String): PhoneAgent.Result {
        val root = rootInActiveWindow ?: return PhoneAgent.Result(false, "Kein aktiver Bildschirm verfügbar.")
        val node = findFocused(root) ?: return PhoneAgent.Result(false, "Kein Eingabefeld ist fokussiert.")
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        val ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        return PhoneAgent.Result(ok, if (ok) "Text eingegeben." else "Text konnte nicht eingegeben werden.")
    }

    private fun findFocused(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (root.isFocused && root.isEditable) return root
        for (i in 0 until root.childCount) root.getChild(i)?.let { findFocused(it)?.let { found -> return found } }
        return null
    }

    private fun scroll(direction: PhoneAgent.PhoneAccessibilityCommand.Direction): PhoneAgent.Result {
        val root = rootInActiveWindow ?: return PhoneAgent.Result(false, "Kein aktiver Bildschirm verfügbar.")
        val nodes = mutableListOf<AccessibilityNodeInfo>(); collectScrollable(root, nodes)
        val node = nodes.firstOrNull() ?: return PhoneAgent.Result(false, "Keine scrollbare Oberfläche gefunden.")
        val action = when (direction) {
            PhoneAgent.PhoneAccessibilityCommand.Direction.UP -> AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            PhoneAgent.PhoneAccessibilityCommand.Direction.DOWN -> AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            else -> AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        }
        val ok = node.performAction(action)
        return PhoneAgent.Result(ok, if (ok) "Gesrollt." else "Scrollen nicht möglich.")
    }

    private fun collectScrollable(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>) {
        if (node.isVisibleToUser && node.isScrollable) out += node
        for (i in 0 until node.childCount) node.getChild(i)?.let { collectScrollable(it, out) }
    }
}
