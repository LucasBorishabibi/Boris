package com.boris.assistant.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

data class Particle(
    var x: Float,
    var y: Float,
    var radius: Float,
    var alpha: Float,
    val speed: Float,
    val angle: Float
)

@Composable
fun BorisParticleUI(isListening: Boolean, modifier: Modifier = Modifier) {
    val particleCount = 70
    val particles = remember {
        List(particleCount) {
            Particle(
                x = Random.nextFloat() * 1000f,
                y = Random.nextFloat() * 1000f,
                radius = Random.nextFloat() * 6f + 2f,
                alpha = Random.nextFloat() * 0.7f + 0.3f,
                speed = Random.nextFloat() * 2f + 1f,
                angle = Random.nextFloat() * 360f
            )
        }
    }

    var time by remember { mutableStateOf(0f) }

    LaunchedEffect(Unit) {
        while (true) {
            withFrameNanos {
                time += 0.05f
            }
        }
    }

    Canvas(modifier = modifier.fillMaxSize().background(Color(0xFF0A0E17))) {
        val centerX = size.width / 2
        val centerY = size.height / 2
        val pulseFactor = if (isListening) 1.5f else 1.0f

        particles.forEachIndexed { index, p ->
            val rad = Math.toRadians((p.angle + time * 20 * p.speed).toDouble())
            val offsetRadius = 150f * pulseFactor + (index % 5) * 20f
            
            val currentX = centerX + cos(rad).toFloat() * offsetRadius
            val currentY = centerY + sin(rad).toFloat() * offsetRadius + sin(time + index) * 15f

            val color = if (isListening) Color(0xFF00E5FF) else Color(0xFF3D5AFE)

            drawCircle(
                color = color.copy(alpha = p.alpha),
                radius = p.radius * pulseFactor,
                center = Offset(currentX, currentY)
            )
        }
    }
}
