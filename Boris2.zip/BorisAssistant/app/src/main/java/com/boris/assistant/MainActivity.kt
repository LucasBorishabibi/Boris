package com.boris.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.boris.assistant.ui.BorisParticleUI
import com.boris.assistant.voice.BorisVoiceEngine

class MainActivity : ComponentActivity() {

    private lateinit var voiceEngine: BorisVoiceEngine
    private var isListeningState = mutableStateOf(false)
    private var lastTranscriptState = mutableStateOf("Boris hört zu...")

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            voiceEngine.startListening()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        voiceEngine = BorisVoiceEngine(
            context = this,
            onSpeechResult = { text ->
                lastTranscriptState.value = text
                voiceEngine.speak("Ich habe verstanden: $text")
            },
            onListeningStateChanged = { listening ->
                isListeningState.value = listening
            }
        )

        checkAudioPermissions()

        setContent {
            Surface(modifier = Modifier.fillMaxSize()) {
                Box(contentAlignment = Alignment.Center) {
                    BorisParticleUI(isListening = isListeningState.value)

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Text(
                            text = "BORIS",
                            style = MaterialTheme.typography.headlineLarge,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = lastTranscriptState.value,
                            style = MaterialTheme.typography.bodyLarge,
                            color = Color.Cyan
                        )
                    }
                }
            }
        }
    }

    private fun checkAudioPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        } else {
            voiceEngine.startListening()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceEngine.destroy()
    }
}
