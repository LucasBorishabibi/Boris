package com.boris.assistant.data

import io.objectbox.annotation.Entity
import io.objectbox.annotation.HnswIndex
import io.objectbox.annotation.Id

@Entity
data class MemoryEntry(
    @Id var id: Long = 0,
    var text: String = "",
    var timestamp: Long = System.currentTimeMillis(),
    
    @HnswIndex(dimensions = 384)
    var embedding: FloatArray = FloatArray(384)
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as MemoryEntry
        return id == other.id
    }

    override fun hashCode(): Int = id.hashCode()
}
