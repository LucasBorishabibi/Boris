
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("io.objectbox")
}

android {
    namespace = "com.boris.assistant"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.boris.assistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.8"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.activity:activity-compose:1.8.2")
    implementation(platform("androidx.compose:compose-bom:2024.02.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")

    debugImplementation("io.objectbox:objectbox-android-objectbrowser:3.8.0")
    releaseImplementation("io.objectbox:objectbox-android:3.8.0")
}
