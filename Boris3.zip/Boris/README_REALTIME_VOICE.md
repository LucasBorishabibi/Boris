# Boris – Realtime Voice Update

## Was geändert wurde

- Fish Audio bevorzugt weiterhin `s2.1-pro-free`; ElevenLabs bleibt als Fallback erhalten.
- Fish Audio nutzt jetzt den offiziellen WebSocket-TTS-Endpunkt (`/v1/tts/live`) mit MessagePack und `format=pcm`, 24 kHz mono PCM sowie `latency=low`.
- Die Wiedergabe beginnt, sobald der erste Audio-Chunk eintrifft. Der Rest der Antwort wird parallel empfangen und in einen `AudioTrack`-Stream geschrieben.
- Vollständig abgeschlossene Fish-Audio-Antworten werden in einem begrenzten lokalen PCM-Cache gespeichert.
- Bei WebSocket-Fehlern vor dem ersten Audio-Chunk wird auf den bisherigen REST/MP3-Weg zurückgefallen.
- Boris hört nicht zu, während er spricht (Halbduplex, damit er sich nicht selbst versteht). Unterbrechen geht per Antippen des Orbs oder des Stopp-Knopfs.
- Ein neuer Sprachbefehl bricht die Wiedergabe ab und invalidiert ältere noch laufende Antwortgenerationen.

## Abhängigkeiten

- OkHttp 4.12.0 (WebSocket)
- MessagePack Core 0.9.8 (Fish Audio WebSocket-Protokoll)

## Hinweise / Grenzen

- Das ist keine lokale/offline Spracherkennung: Die Latenz hängt weiterhin von Netzwerk, Fish-Audio-Serverlast, Modellgenerierung und Android-Spracherkennung ab.
- Wenn der WebSocket vor dem ersten Audio ausfällt, fällt Boris auf den bisherigen REST-Weg zurück; das kann bei einem Fehler die erste Antwort verzögern.
- Dieses ZIP wurde statisch geprüft, aber in dieser Umgebung nicht mit Gradle gebaut oder auf einem Android-Gerät ausgeführt, da kein Gradle-Wrapper und keine Android-SDK-Installation im Projekt/Container verfügbar waren.
