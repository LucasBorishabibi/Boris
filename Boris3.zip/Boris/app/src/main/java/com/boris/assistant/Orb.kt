package com.boris.assistant

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

enum class FaceMode { IDLE, LISTEN, THINK, SPEAK, LEARN }
enum class FaceMood { NEUTRAL, HAPPY, CONCERNED, CURIOUS }

/** Alles, was der Orb von außen wissen muss. Wird jedes Bild neu befüllt. */
class FaceInput {
    var mode = FaceMode.IDLE
    var mood = FaceMood.NEUTRAL
    var speaking = false
    var touching = false
    var tdx = 0f; var tdy = 0f      // Fingerposition relativ zur Mitte
    var drowsy = 0f                 // 0 wach .. 1 sehr müde (lange Ruhe)
    var learnSeq = 0                // zählt hoch, wenn Boris etwas Neues gelernt hat
}

private const val N = 300       // Punkte auf der Kugel
private const val NR = 56       // Punkte im Ring
private const val NRAY = 40     // Strahlen
private const val NSP = 24      // Funken
private const val SEG = 30      // Segmente pro Gitterlinie
private const val TAU = 6.2831855f

private fun smooth01(x: Float): Float { val c = x.coerceIn(0f, 1f); return c * c * (3f - 2f * c) }
private fun approach(cur: Float, tgt: Float, rate: Float, dt: Float) = cur + (tgt - cur) * (1f - exp(-rate * dt))

/**
 * Boris als leuchtender Partikel-Orb: Gitterkugel aus Punkten, kreisender Ring mit Kometenschweif, Strahlen.
 * Beim Sprechen pumpt die Stimme die Oberfläche auf, Strahlen schießen bei jeder Silbe, und es erscheint ein Gesicht
 * (zwei senkrechte Pillen-Augen, der Mund bewegt sich mit dem Pegel). Beim Lernen strömen Datenfunken ein.
 */
class BorisOrb {
    private var cx = 0f; private var cy = 0f; private var u = 1f
    private var t = 0f
    private val rnd = java.util.Random(11)

    private val bx = FloatArray(N); private val by = FloatArray(N); private val bz = FloatArray(N); private val ph = FloatArray(N)

    // Zustandsgewichte
    private var wIdle = 1f; private var wListen = 0f; private var wThink = 0f; private var wSpeak = 0f; private var wLearn = 0f
    private var lastMode = FaceMode.IDLE

    // Stimme
    private var lvl = 0f; private var bright = 0f
    private var lastSeq = 0; private var lastLearn = 0

    // Bewegung
    private var yaw = 0f; private var tilt = 0.38f; private var spin = 0.1f
    private var swell = 0f; private var radScale = 1f; private var energy = 0.2f
    private var flick = 0f; private var pulse = 0f; private var aha = 0f

    // Gesicht
    private var faceW = 0f; private var mOpen = 0f; private var mW = 1f
    private var mHappy = 0f; private var mConc = 0f
    private var eyeK = 1f; private var smileK = 0.35f
    private var gx = 0f; private var gy = 0f; private var gtx = 0f; private var gty = 0f; private var gazeT = 1f
    private var blink = 0f; private var blinkT = -1f; private var nextBlink = 2f

    // Ring, Strahlen, Funken
    private var ringAng = 0f
    private val rayT = FloatArray(NRAY)
    private var spawnAcc = 0f
    private val spA = FloatArray(NSP); private val spR = FloatArray(NSP); private val spV = FloatArray(NSP)
    private val spAge = FloatArray(NSP) { 1f }; private val spLife = FloatArray(NSP) { 1f }

    // Zeichenpuffer (nichts wird pro Bild neu angelegt)
    private val pf = Path(); private val pb = Path(); private val smile = Path()
    private val vx = FloatArray(SEG + 1); private val vy = FloatArray(SEG + 1); private val vz = FloatArray(SEG + 1)
    private var rx = 0f; private var ry = 0f; private var rz = 0f
    private var cyw = 1f; private var syw = 0f; private var ctl = 1f; private var stl = 0f

    init {
        val golden = 2.3999632f
        for (i in 0 until N) {
            val y = 1f - 2f * (i + 0.5f) / N
            val rr = sqrt((1f - y * y).coerceAtLeast(0f))
            val th = i * golden
            bx[i] = cos(th) * rr; by[i] = y; bz[i] = sin(th) * rr
            ph[i] = ((i * 7919) % 1000) / 1000f * TAU
        }
    }

    /** Dreht einen Punkt der Einheitskugel mit der aktuellen Lage; Ergebnis in rx, ry, rz (rz > 0 = vorne). */
    private fun rot(x: Float, y: Float, z: Float) {
        val x1 = x * cyw + z * syw
        val z1 = -x * syw + z * cyw
        rx = x1
        ry = y * ctl - z1 * stl
        rz = y * stl + z1 * ctl
    }

    // ------------------------------------------------------------------ Simulation
    fun update(dt0: Float, va: VoiceAnalyzer, inp: FaceInput, cx: Float, cy: Float, rr: Float) {
        this.cx = cx; this.cy = cy; this.u = rr
        val dt = dt0.coerceIn(0.001f, 0.05f)
        t += dt
        val speaking = inp.speaking

        val k = 1f - exp(-dt * 3.2f)
        wIdle += ((if (inp.mode == FaceMode.IDLE) 1f else 0f) - wIdle) * k
        wListen += ((if (inp.mode == FaceMode.LISTEN) 1f else 0f) - wListen) * k
        wThink += ((if (inp.mode == FaceMode.THINK) 1f else 0f) - wThink) * k
        wSpeak += ((if (inp.mode == FaceMode.SPEAK) 1f else 0f) - wSpeak) * k
        wLearn += ((if (inp.mode == FaceMode.LEARN) 1f else 0f) - wLearn) * k
        if (inp.mode != lastMode) {
            if (inp.mode == FaceMode.LISTEN) pulse = 1f      // Aufmerken, wenn er angesprochen wird
            lastMode = inp.mode
        }

        // Stimme
        val rawL = if (speaking) va.level else 0f
        lvl = approach(lvl, rawL, if (rawL > lvl) 24f else 9f, dt)
        bright = approach(bright, if (speaking) va.bright else 0f, 8f, dt)
        val seq = va.onsetSeq
        if (speaking && seq != lastSeq) {
            flick = min(1f, flick + 0.5f + va.onsetStrength * 0.8f)
            repeat(3 + (va.onsetStrength * 6f).toInt().coerceIn(0, 6)) { rayT[rnd.nextInt(NRAY)] = 0.22f + rnd.nextFloat() * 0.55f }
        }
        lastSeq = seq
        flick *= exp(-dt * 7f); pulse *= exp(-dt * 2.4f); aha *= exp(-dt * 1.5f)
        val dec = exp(-dt * 3.2f)
        for (i in 0 until NRAY) rayT[i] *= dec

        if (inp.learnSeq != lastLearn) { lastLearn = inp.learnSeq; aha = 1f; repeat(14) { spawnSpark(true) } }

        // Stimmungen nur, solange er spricht
        val on = if (speaking) 1f else 0f
        mHappy = approach(mHappy, if (inp.mood == FaceMood.HAPPY) on else 0f, 2.6f, dt)
        mConc = approach(mConc, if (inp.mood == FaceMood.CONCERNED) on else 0f, 2.6f, dt)

        // Drehung und Lage
        val drowsy = inp.drowsy * wIdle
        val spinT = 0.10f + wListen * 0.16f + wThink * 1.15f + wSpeak * (0.38f + 0.9f * lvl) + wLearn * 0.5f
        spin = approach(spin, spinT * (1f - 0.55f * drowsy), 2.5f, dt)
        yaw += spin * dt
        if (inp.touching) yaw += (inp.tdx / u).coerceIn(-1.5f, 1.5f) * 1.2f * dt
        val tiltT = 0.38f + (if (inp.touching) (inp.tdy / u).coerceIn(-1.5f, 1.5f) * 0.18f else 0f)
        tilt = approach(tilt, tiltT, 4f, dt)

        // Atmen, Aufblähen, Helligkeit
        val breath = 0.018f * sin(t * 1.3f) + 0.012f * sin(t * 0.53f)
        val swellT = wListen * 0.05f + wSpeak * 0.03f + pulse * 0.07f + aha * 0.08f + (if (inp.touching) 0.05f else 0f)
        swell = approach(swell, swellT, 6f, dt)
        radScale = 1f + breath + swell + 0.06f * lvl
        energy = wIdle * 0.25f * (1f - 0.4f * inp.drowsy) + wListen * 0.55f + wThink * 0.6f + wSpeak * (0.55f + 0.45f * lvl) + wLearn * 0.55f + aha * 0.3f

        // Gesicht: nur beim Sprechen
        faceW = approach(faceW, if (speaking) 1f else 0f, if (speaking) 5f else 7f, dt)
        val tOpen = if (rawL < 0.06f) 0f else 0.25f + 0.75f * rawL.coerceIn(0f, 1f)
        mOpen = approach(mOpen, tOpen, if (tOpen > mOpen) 32f else 16f, dt)
        mW = approach(mW, 0.9f + 0.35f * bright - 0.25f * lvl * (1f - bright), 12f, dt)
        eyeK = approach(eyeK, 1f - 0.2f * mHappy + 0.12f * mConc, 6f, dt)
        smileK = approach(smileK, 0.35f + 0.65f * mHappy - 0.6f * mConc, 5f, dt)

        gazeT -= dt
        if (inp.touching) {
            gtx = (inp.tdx / (u * 1.5f)).coerceIn(-1f, 1f); gty = (inp.tdy / (u * 1.5f)).coerceIn(-1f, 1f); gazeT = 0.2f
        } else if (gazeT <= 0f) {
            val r1 = rnd.nextFloat(); val r2 = rnd.nextFloat()
            if (r1 < 0.3f) { gtx = 0f; gty = 0f } else { gtx = (r1 - 0.5f) * 1.1f; gty = (r2 - 0.5f) * 0.5f }
            gazeT = 0.9f + r2 * 2.4f
        }
        gx = approach(gx, gtx, 14f, dt); gy = approach(gy, gty, 14f, dt)

        nextBlink -= dt
        if (blinkT < 0f && nextBlink <= 0f) { blinkT = 0f; nextBlink = 2.2f + rnd.nextFloat() * 3f }
        if (blinkT >= 0f) {
            blinkT += dt / 0.16f
            if (blinkT >= 1f) { blinkT = -1f; blink = 0f }
            else blink = smooth01(if (blinkT < 0.4f) blinkT / 0.4f else 1f - (blinkT - 0.4f) / 0.6f)
        }

        // Ring und Funken
        ringAng += dt * (0.45f + 1.6f * wThink + 0.9f * wLearn + 0.5f * wSpeak + 0.3f * wListen)
        if (ringAng > TAU) ringAng -= TAU
        if (wLearn > 0.3f) {
            spawnAcc += dt * 9f * wLearn
            while (spawnAcc >= 1f) { spawnAcc -= 1f; spawnSpark(false) }
        }
        for (i in 0 until NSP) if (spAge[i] < 1f) { spAge[i] = min(1f, spAge[i] + dt / spLife[i]); spR[i] += spV[i] * dt }
    }

    private fun spawnSpark(burst: Boolean) {
        var slot = -1
        for (i in 0 until NSP) if (spAge[i] >= 1f) { slot = i; break }
        if (slot < 0) return
        spA[slot] = rnd.nextFloat() * TAU
        spR[slot] = if (burst) 1.05f else 1.9f + rnd.nextFloat() * 0.4f
        spV[slot] = if (burst) 0.9f else -0.5f
        spLife[slot] = if (burst) 1.2f else 1.8f + rnd.nextFloat() * 0.8f
        spAge[slot] = 0f
    }

    // ------------------------------------------------------------------ Zeichnen
    fun draw(sc: DrawScope, tint: Color, dens: Float) {
        val hi = lerp(tint, Color.White, 0.55f)
        cyw = cos(yaw); syw = sin(yaw); ctl = cos(tilt); stl = sin(tilt)
        val r = u * radScale
        val vd = lvl * wSpeak
        val center = Offset(cx, cy)
        with(sc) {
            // Schein hinter und in der Kugel
            drawCircle(Brush.radialGradient(listOf(tint.copy(alpha = (0.08f + 0.20f * energy).coerceIn(0f, 1f)), Color.Transparent), center = center, radius = u * 2.4f),
                radius = u * 2.4f, center = center)
            drawCircle(Brush.radialGradient(listOf(tint.copy(alpha = (0.05f + 0.16f * energy).coerceIn(0f, 1f)), Color.Transparent), center = center, radius = r * 1.05f),
                radius = r * 1.05f, center = center)

            // Zuhören: ruhige Halo-Ringe
            if (wListen > 0.02f) {
                drawCircle(hi.copy(alpha = (wListen * (0.12f + 0.06f * sin(t * 2f))).coerceIn(0f, 1f)), u * (1.62f + 0.03f * sin(t * 2f)), center, style = Stroke(1.2f * dens))
                drawCircle(hi.copy(alpha = (wListen * (0.07f + 0.04f * sin(t * 2f + 2.1f))).coerceIn(0f, 1f)), u * (1.78f + 0.04f * sin(t * 2f + 2.1f)), center, style = Stroke(1.0f * dens))
            }

            drawRing(this, tint, dens, false)

            // Gitterlinien der Kugel: erst die Linien auf der Rückseite, nach den Punkten die vordere
            pf.rewind(); pb.rewind()
            for (k in -2..2) {
                val lat = k * 0.5f
                val yy = sin(lat); val rr0 = cos(lat)
                for (s in 0..SEG) { val a = s * TAU / SEG; rot(cos(a) * rr0, yy, sin(a) * rr0); vx[s] = rx; vy[s] = ry; vz[s] = rz }
                addCurve(r)
            }
            for (k in 0 until 6) {
                val th = k * PI.toFloat() / 6f
                val c = cos(th); val s0 = sin(th)
                for (s in 0..SEG) { val a = s * TAU / SEG; val ca = cos(a); rot(ca * c, sin(a), ca * s0); vx[s] = rx; vy[s] = ry; vz[s] = rz }
                addCurve(r)
            }
            drawPath(pb, tint.copy(alpha = (0.06f + 0.10f * energy).coerceIn(0f, 1f)), style = Stroke(1f * dens))

            // Partikel
            for (i in 0 until N) {
                val d = 1f + vd * (0.5f + 0.5f * sin(ph[i] * 2f + t * 9f)) * 0.24f -
                    0.04f * wListen * sin(t * 3f + ph[i]) + 0.10f * aha * sin(ph[i] * 3f + t * 10f)
                rot(bx[i], by[i], bz[i])
                val f = (rz + 1f) * 0.5f
                val p = 1f + 0.14f * rz
                val a = ((0.16f + 0.84f * f * f) * (0.5f + 0.7f * energy)).coerceIn(0f, 1f)
                drawCircle(lerp(tint, hi, f), (0.7f + 1.9f * f) * dens * (1f + 0.4f * lvl),
                    Offset(cx + rx * r * d * p, cy + ry * r * d * p), alpha = a, blendMode = BlendMode.Plus)
            }

            drawPath(pf, hi.copy(alpha = (0.14f + 0.22f * energy).coerceIn(0f, 1f)), style = Stroke(1.1f * dens))

            if (faceW > 0.02f) drawFace(this, tint, hi, dens)

            // Strahlen
            for (i in 0 until NRAY) {
                val ang = i * TAU / NRAY + ph[(i * 7) % N] * 0.05f
                val amb = (0.03f + 0.05f * energy) * (0.5f + 0.5f * sin(t * 0.9f + i * 1.7f))
                val len = max(amb, rayT[i])
                if (len < 0.01f) continue
                val c = cos(ang); val s = sin(ang)
                val a0 = r * 1.10f; val a1 = a0 + len * u
                drawLine(hi.copy(alpha = (0.18f + 0.7f * len).coerceIn(0f, 1f)), Offset(cx + c * a0, cy + s * a0), Offset(cx + c * a1, cy + s * a1),
                    (1f + 1.4f * len) * dens, StrokeCap.Round)
            }

            drawRing(this, tint, dens, true)

            // Datenfunken (Lernen) und Funkenschauer (etwas Neues gelernt)
            for (i in 0 until NSP) {
                val age = spAge[i]
                if (age >= 1f) continue
                val a = sin(age * PI.toFloat()) * 0.85f
                drawCircle(hi, (1.2f + 1.4f * (i % 3)) * dens, Offset(cx + cos(spA[i]) * spR[i] * u, cy + sin(spA[i]) * spR[i] * u * 0.95f), alpha = a.coerceIn(0f, 1f))
            }
        }
    }

    private fun addCurve(r: Float) {
        for (s in 0 until SEG) {
            val zm = vz[s] + vz[s + 1]
            val p = if (zm > 0f) pf else pb
            val pa = 1f + 0.14f * vz[s]; val pc = 1f + 0.14f * vz[s + 1]
            p.moveTo(cx + vx[s] * r * pa, cy + vy[s] * r * pa)
            p.lineTo(cx + vx[s + 1] * r * pc, cy + vy[s + 1] * r * pc)
        }
    }

    /** Kreisender Ring mit Kometenschweif; hinten und vorne getrennt, damit er um die Kugel läuft. */
    private fun drawRing(sc: DrawScope, tint: Color, dens: Float, front: Boolean) {
        val rr = u * 1.46f
        val tr = 1.18f
        val ctr = cos(tr); val str = sin(tr)
        val ry2 = t * 0.18f
        val cr = cos(ry2); val sr = sin(ry2)
        val base = 0.4f + 0.6f * min(1f, energy * 1.4f + 0.25f)
        for (j in 0 until NR) {
            val th = j * TAU / NR
            val x = cos(th) * rr
            val y0 = sin(th) * rr
            val y = y0 * ctr
            val z = y0 * str
            val x2 = x * cr + z * sr
            val z2 = -x * sr + z * cr
            if ((z2 > 0f) != front) continue
            var d = (ringAng - th) % TAU
            if (d < 0f) d += TAU
            val c1 = 1f - d / TAU
            val comet = c1 * c1 * c1
            val depth = (z2 / rr + 1f) * 0.5f
            val a = (0.10f + 0.85f * comet) * (0.5f + 0.5f * depth) * base
            sc.drawCircle(lerp(tint, Color.White, comet * 0.7f), (0.9f + 2.2f * comet) * dens, Offset(cx + x2, cy + y), alpha = a.coerceIn(0f, 1f))
        }
    }

    private fun drawFace(sc: DrawScope, tint: Color, hi: Color, dens: Float) {
        val fw = smooth01(faceW)
        with(sc) {
            // dunkle Platte, damit das Gesicht auf den Punkten lesbar bleibt
            val plate = Offset(cx, cy + u * 0.04f)
            drawCircle(Brush.radialGradient(listOf(Color.Black.copy(alpha = 0.62f * fw), Color.Transparent), center = plate, radius = u * 0.68f),
                radius = u * 0.68f, center = plate)

            val ew = u * 0.115f * (1f + 0.1f * flick)
            val eh = u * 0.36f * eyeK * (1f - 0.92f * blink) + u * 0.03f
            val ey = cy - u * 0.10f + gy * u * 0.04f
            val core = lerp(tint, Color.White, 0.8f)
            for (s in floatArrayOf(-1f, 1f)) {
                val x = cx + s * u * 0.27f + gx * u * 0.05f
                drawRoundRect(tint.copy(alpha = 0.22f * fw), Offset(x - ew * 0.95f, ey - eh * 0.66f), Size(ew * 1.9f, eh * 1.32f), CornerRadius(ew * 0.95f))
                drawRoundRect(core.copy(alpha = 0.95f * fw), Offset(x - ew / 2f, ey - eh / 2f), Size(ew, eh), CornerRadius(ew / 2f))
            }

            // Mund: geschlossen ein sanftes Lächeln, offen eine Pille, die dem Pegel folgt
            val mx = cx + gx * u * 0.03f
            val my = cy + u * 0.34f
            val mw = u * 0.26f * mW
            val opn = (mOpen * 4f).coerceIn(0f, 1f)
            if (opn < 0.98f) {
                smile.rewind()
                smile.moveTo(mx - mw / 2f, my)
                smile.quadraticBezierTo(mx, my + u * 0.06f * smileK, mx + mw / 2f, my)
                drawPath(smile, hi.copy(alpha = (0.85f * fw * (1f - opn)).coerceIn(0f, 1f)), style = Stroke(2.6f * dens, cap = StrokeCap.Round))
            }
            if (opn > 0.02f) {
                val h = u * (0.03f + 0.15f * mOpen)
                drawRoundRect(tint.copy(alpha = 0.25f * fw * opn), Offset(mx - mw * 0.6f, my - h * 0.2f - h * 0.3f), Size(mw * 1.2f, h * 1.6f), CornerRadius(h * 0.8f))
                drawRoundRect(core.copy(alpha = (0.95f * fw * opn).coerceIn(0f, 1f)), Offset(mx - mw / 2f, my - h * 0.2f), Size(mw, h), CornerRadius(h / 2f))
            }
        }
    }
}
