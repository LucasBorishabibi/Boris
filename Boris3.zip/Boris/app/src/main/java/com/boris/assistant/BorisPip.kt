package com.boris.assistant

import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import androidx.compose.ui.graphics.Color as CColor
import androidx.compose.ui.graphics.toArgb
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Boris als schwebendes Mini-Fenster wie bei einem minimierten Videoanruf: sein Gesicht (Orb) bleibt über
 * anderen Apps sichtbar, solange er spricht, zuhört, denkt oder der Agent arbeitet. Frei verschiebbar,
 * rastet am Rand ein, Antippen öffnet Boris. Läuft über die Bedienungshilfe, braucht also keine Zusatzberechtigung.
 */
class BorisPip(private val svc: AutoSendService) {
    private val d = svc.resources.displayMetrics.density
    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val prefs = svc.getSharedPreferences("boris", 0)
    private var view: PipView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var snap: ValueAnimator? = null
    val w = (104 * d).toInt()
    val h = (132 * d).toInt()

    val shown: Boolean get() = view != null

    private fun sw() = svc.resources.displayMetrics.widthPixels
    private fun sh() = svc.resources.displayMetrics.heightPixels

    fun show() {
        if (view != null) return
        try {
            val dm = svc.resources.displayMetrics
            val x0 = prefs.getInt("pip_x", dm.widthPixels - w - (10 * d).toInt())
            val y0 = prefs.getInt("pip_y", (96 * d).toInt())
            val p = WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT)
            p.gravity = Gravity.TOP or Gravity.START
            p.x = x0.coerceIn(0, max(0, dm.widthPixels - w))
            p.y = y0.coerceIn(0, max(0, dm.heightPixels - h))
            val v = PipView(svc, this)
            v.alpha = 0f; v.scaleX = 0.6f; v.scaleY = 0.6f
            wm.addView(v, p)
            v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(1.1f)).start()
            view = v; lp = p
        } catch (e: Exception) { view = null; lp = null }
    }

    fun hide(now: Boolean = false) {
        val v = view ?: return
        view = null
        snap?.cancel()
        val kill = { try { wm.removeView(v) } catch (e: Exception) {} }
        if (now) kill()
        else v.animate().alpha(0f).scaleX(0.7f).scaleY(0.7f).setDuration(220).withEndAction { kill() }.start()
    }

    /** Mitte des Fensters in Bildschirmkoordinaten: von hier fliegt die Maus los und hierher kehrt sie zurück. */
    fun anchor(): Pair<Float, Float> {
        val p = lp ?: return (sw() - 60f * d) to (110f * d)
        return (p.x + w / 2f) to (p.y + h * 0.42f)
    }

    /** Weicht aus, wenn der Agent genau unter dem Fenster tippen muss. Gibt true zurück, wenn es sich bewegt. */
    fun dodge(x: Float, y: Float): Boolean {
        val p = lp ?: return false
        if (view == null) return false
        val m = 28f * d
        if (x < p.x - m || x > p.x + w + m || y < p.y - m || y > p.y + h + m) return false
        val tx = if (x < sw() / 2f) sw() - w - (8 * d).toInt() else (8 * d).toInt()
        Core.onUi { animateX(tx, false) }
        return true
    }

    private fun animateX(target: Int, save: Boolean) {
        val p = lp ?: return
        val v = view ?: return
        snap?.cancel()
        snap = ValueAnimator.ofInt(p.x, target).apply {
            duration = 260
            interpolator = if (save) OvershootInterpolator(0.8f) else DecelerateInterpolator(1.5f)
            addUpdateListener {
                p.x = it.animatedValue as Int
                try { wm.updateViewLayout(v, p) } catch (e: Exception) {}
            }
            start()
        }
        if (save) prefs.edit().putInt("pip_x", target).putInt("pip_y", p.y).apply()
    }

    // ---- Berührung (vom View weitergereicht)
    private var downX = 0f; private var downY = 0f
    private var startX = 0; private var startY = 0
    private var moved = false
    private var onStop = false

    fun touch(v: View, e: MotionEvent, stopHit: Boolean): Boolean {
        val p = lp ?: return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                snap?.cancel()
                downX = e.rawX; downY = e.rawY; startX = p.x; startY = p.y; moved = false; onStop = stopHit
                v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start()
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX; val dy = e.rawY - downY
                if (!moved && sqrt(dx * dx + dy * dy) > 8 * d) moved = true
                if (moved) {
                    p.x = (startX + dx).toInt().coerceIn(0, max(0, sw() - w))
                    p.y = (startY + dy).toInt().coerceIn(0, max(0, sh() - h))
                    try { wm.updateViewLayout(v, p) } catch (x: Exception) {}
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                if (e.actionMasked == MotionEvent.ACTION_UP) {
                    if (moved) {
                        // am näheren Seitenrand einrasten
                        val mid = p.x + w / 2
                        val target = if (mid < sw() / 2) (8 * d).toInt() else sw() - w - (8 * d).toInt()
                        animateX(target, true)
                    } else if (onStop && PhoneAgent.running) {
                        PhoneAgent.abort()
                    } else {
                        try {
                            svc.startActivity(Intent(svc, MainActivity::class.java)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
                        } catch (x: Exception) {}
                    }
                }
            }
        }
        return true
    }
}

/** Zeichnet das Mini-Gesicht: Partikelkugel, kreisender Ring, beim Sprechen Augen und Mund im Takt der Stimme. */
class PipView(ctx: Context, private val host: BorisPip) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val TAU = 6.2831855f
    private val N = 110
    private val NR = 34
    private val bx = FloatArray(N); private val by = FloatArray(N); private val bz = FloatArray(N)

    private var last = 0L
    private var t = 0f
    private var yaw = 0f
    private var spin = 0.3f
    private var energy = 0.3f
    private var lvl = 0f
    private var faceW = 0f
    private var mOpen = 0f
    private var ringAng = 0f
    private var blink = 0f; private var blinkT = -1f; private var nextBlink = 2f
    private var gx = 0f; private var gtx = 0f; private var gazeT = 1f
    private val rnd = java.util.Random(5)

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()
    private val smile = Path()
    private var shownText = ""
    private var rawText = ""
    private var lastW = 0
    private var stopHit = false

    init {
        val golden = 2.3999632f
        for (i in 0 until N) {
            val y = 1f - 2f * (i + 0.5f) / N
            val rr = sqrt((1f - y * y).coerceAtLeast(0f))
            val th = i * golden
            bx[i] = cos(th) * rr; by[i] = y; bz[i] = sin(th) * rr
        }
    }

    private fun argb(c: CColor) = c.toArgb()
    private fun mix(a: Int, b: Int, f: Float): Int {
        val k = f.coerceIn(0f, 1f)
        return Color.argb(255,
            (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt())
    }
    private fun approach(cur: Float, tgt: Float, rate: Float, dt: Float) = cur + (tgt - cur) * (1f - exp(-rate * dt))

    private fun stopRect(): RectF = RectF(width - 26f * d, 5f * d, width - 5f * d, 26f * d)

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            val r = stopRect()
            stopHit = PhoneAgent.running &&
                RectF(r.left - 8 * d, r.top - 8 * d, r.right + 8 * d, r.bottom + 8 * d).contains(e.x, e.y)
        }
        return host.touch(this, e, stopHit)
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = if (last == 0L) 0.016f else ((now - last) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
        last = now
        t += dt

        val j = Hub.peek()
        val speaking = j?.speaking == true
        val agent = PhoneAgent.running
        // 0 ruhig, 1 hört zu, 2 denkt, 3 spricht, 4 Agent arbeitet
        val mode = when {
            speaking -> 3
            agent -> 4
            Core.busy || j?.preparing == true -> 2
            Core.voiceMode == 2 -> 1
            else -> 0
        }
        val raw = if (speaking) (j?.vox?.level ?: 0f) else 0f
        lvl = approach(lvl, raw, if (raw > lvl) 24f else 9f, dt)
        val spinT = when (mode) { 0 -> 0.25f; 1 -> 0.4f; 2 -> 1.2f; 3 -> 0.5f + 0.9f * lvl; else -> 1.0f }
        val enT = when (mode) { 0 -> 0.3f; 1 -> 0.55f; 2 -> 0.6f; 3 -> 0.6f + 0.4f * lvl; else -> 0.65f }
        spin = approach(spin, spinT, 2.5f, dt)
        energy = approach(energy, enT, 3f, dt)
        yaw += spin * dt
        ringAng += dt * (0.6f + 1.4f * (if (mode == 2 || mode == 4) 1f else 0f) + 0.4f * (if (mode == 3) 1f else 0f))
        if (ringAng > TAU) ringAng -= TAU
        faceW = approach(faceW, if (speaking) 1f else 0f, if (speaking) 5f else 7f, dt)
        val tOpen = if (raw < 0.06f) 0f else 0.25f + 0.75f * raw.coerceIn(0f, 1f)
        mOpen = approach(mOpen, tOpen, if (tOpen > mOpen) 32f else 16f, dt)
        gazeT -= dt
        if (gazeT <= 0f) { gtx = (rnd.nextFloat() - 0.5f) * 1.1f; gazeT = 0.9f + rnd.nextFloat() * 2f }
        gx = approach(gx, gtx, 12f, dt)
        nextBlink -= dt
        if (blinkT < 0f && nextBlink <= 0f) { blinkT = 0f; nextBlink = 2.2f + rnd.nextFloat() * 3f }
        if (blinkT >= 0f) {
            blinkT += dt / 0.16f
            if (blinkT >= 1f) { blinkT = -1f; blink = 0f } else blink = if (blinkT < 0.4f) blinkT / 0.4f else 1f - (blinkT - 0.4f) / 0.6f
        }

        val w = width.toFloat(); val h = height.toFloat()
        val accent = argb(Pal.accent)
        val tint = when (mode) {
            3 -> mix(accent, Color.WHITE, 0.35f)
            1 -> argb(Pal.accent2)
            4 -> argb(Pal.accent2)
            else -> accent
        }
        val hi = mix(tint, Color.WHITE, 0.55f)

        // Glasplatte
        box.set(0f, 0f, w, h)
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#F0090B10")
        c.drawRoundRect(box, 22f * d, 22f * d, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.2f * d
        p.color = tint; p.alpha = (60 + 60 * energy).toInt().coerceIn(0, 255)
        box.inset(0.6f * d, 0.6f * d)
        c.drawRoundRect(box, 22f * d, 22f * d, p)

        val cx = w / 2f
        val cy = h * 0.42f
        val u = w * 0.27f * (1f + 0.05f * lvl + 0.012f * sin(t * 1.3f))

        // Schein
        p.style = Paint.Style.FILL
        for (k in 3 downTo 1) {
            p.color = tint; p.alpha = ((8 + 18 * energy) / k).toInt().coerceIn(0, 255)
            c.drawCircle(cx, cy, u * (1f + 0.4f * k), p)
        }

        // Ring
        val rr = u * 1.5f
        val tr = 1.18f
        val ctr = cos(tr); val str = sin(tr)
        val base = 0.4f + 0.6f * min(1f, energy * 1.4f + 0.25f)
        for (jx in 0 until NR) {
            val th = jx * TAU / NR
            val x = cos(th) * rr
            val y0 = sin(th) * rr
            var dd = (ringAng - th) % TAU
            if (dd < 0f) dd += TAU
            val c1 = 1f - dd / TAU
            val comet = c1 * c1 * c1
            val depth = (y0 * str / rr + 1f) * 0.5f
            p.color = mix(tint, Color.WHITE, comet * 0.7f)
            p.alpha = (255 * ((0.10f + 0.85f * comet) * (0.5f + 0.5f * depth) * base)).toInt().coerceIn(0, 255)
            c.drawCircle(cx + x, cy + y0 * ctr * 0.9f, (0.7f + 1.9f * comet) * d, p)
        }

        // Kugel aus Punkten
        val tilt = 0.38f
        val cyw = cos(yaw); val syw = sin(yaw); val ct = cos(tilt); val st = sin(tilt)
        for (i in 0 until N) {
            val x1 = bx[i] * cyw + bz[i] * syw
            val z1 = -bx[i] * syw + bz[i] * cyw
            val y2 = by[i] * ct - z1 * st
            val z2 = by[i] * st + z1 * ct
            val f = (z2 + 1f) * 0.5f
            val pr = 1f + 0.14f * z2
            val wob = 1f + lvl * 0.2f * sin(i * 1.7f + t * 9f)
            p.color = mix(tint, hi, f)
            p.alpha = (255 * ((0.16f + 0.84f * f * f) * (0.5f + 0.7f * energy))).toInt().coerceIn(0, 255)
            c.drawCircle(cx + x1 * u * pr * wob, cy + y2 * u * pr * wob, (0.6f + 1.5f * f) * d * (1f + 0.4f * lvl), p)
        }

        if (faceW > 0.02f) drawFace(c, cx, cy, u, tint, hi)

        // Stopp-Knopf, solange der Agent arbeitet
        if (agent) {
            val r = stopRect()
            p.style = Paint.Style.FILL; p.color = Color.parseColor("#FF4D4D"); p.alpha = 255
            c.drawCircle(r.centerX(), r.centerY(), r.width() / 2f, p)
            p.color = Color.WHITE
            val s = 4f * d
            c.drawRoundRect(RectF(r.centerX() - s, r.centerY() - s, r.centerX() + s, r.centerY() + s), 1.5f * d, 1.5f * d, p)
        }

        // Statuszeile
        val text = when (mode) {
            3 -> "Spricht"
            4 -> Core.status.lowercase().replaceFirstChar { it.uppercase() }.ifBlank { "Agent arbeitet" }
            2 -> "Denkt nach"
            1 -> "Hört zu"
            else -> "Boris"
        }
        if (text != rawText || width != lastW) {
            rawText = text; lastW = width
            p.style = Paint.Style.FILL; p.textSize = 10.5f * d; p.typeface = Typeface.DEFAULT
            var s = text
            val maxW = w - 16f * d
            if (p.measureText(s) > maxW) {
                while (s.length > 3 && p.measureText("$s…") > maxW) s = s.dropLast(1)
                s = "$s…"
            }
            shownText = s
        }
        p.style = Paint.Style.FILL; p.textSize = 10.5f * d; p.typeface = Typeface.DEFAULT
        p.textAlign = Paint.Align.CENTER
        p.color = Color.WHITE; p.alpha = 190
        c.drawText(shownText, cx, h - 13f * d, p)
        p.textAlign = Paint.Align.LEFT

        postInvalidateOnAnimation()
    }

    private fun drawFace(c: Canvas, cx: Float, cy: Float, u: Float, tint: Int, hi: Int) {
        val fw = faceW.coerceIn(0f, 1f)
        p.style = Paint.Style.FILL
        p.color = Color.BLACK; p.alpha = (150 * fw).toInt()
        c.drawCircle(cx, cy + u * 0.04f, u * 0.66f, p)
        val ew = u * 0.125f
        val eh = u * 0.36f * (1f - 0.92f * blink) + u * 0.03f
        val ey = cy - u * 0.10f
        val core = mix(tint, Color.WHITE, 0.8f)
        for (s in floatArrayOf(-1f, 1f)) {
            val x = cx + s * u * 0.27f + gx * u * 0.05f
            p.color = tint; p.alpha = (56 * fw).toInt()
            box.set(x - ew * 0.95f, ey - eh * 0.66f, x + ew * 0.95f, ey + eh * 0.66f)
            c.drawRoundRect(box, ew * 0.95f, ew * 0.95f, p)
            p.color = core; p.alpha = (240 * fw).toInt()
            box.set(x - ew / 2f, ey - eh / 2f, x + ew / 2f, ey + eh / 2f)
            c.drawRoundRect(box, ew / 2f, ew / 2f, p)
        }
        val mx = cx + gx * u * 0.03f
        val my = cy + u * 0.34f
        val mw = u * 0.26f
        val opn = (mOpen * 4f).coerceIn(0f, 1f)
        if (opn < 0.98f) {
            smile.rewind()
            smile.moveTo(mx - mw / 2f, my)
            smile.quadTo(mx, my + u * 0.05f, mx + mw / 2f, my)
            p.style = Paint.Style.STROKE; p.strokeWidth = 2.2f * d; p.strokeCap = Paint.Cap.ROUND
            p.color = hi; p.alpha = (215 * fw * (1f - opn)).toInt().coerceIn(0, 255)
            c.drawPath(smile, p)
            p.style = Paint.Style.FILL
        }
        if (opn > 0.02f) {
            val mh = u * (0.03f + 0.15f * mOpen)
            p.color = core; p.alpha = (240 * fw * opn).toInt().coerceIn(0, 255)
            box.set(mx - mw / 2f, my - mh * 0.2f, mx + mw / 2f, my - mh * 0.2f + mh)
            c.drawRoundRect(box, mh / 2f, mh / 2f, p)
        }
    }
}
