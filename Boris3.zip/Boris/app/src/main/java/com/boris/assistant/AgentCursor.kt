package com.boris.assistant

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import android.view.animation.PathInterpolator

/**
 * Die Maus des Agenten: ein schlichter Pfeil, der weich über den Bildschirm gleitet.
 * Sie taucht nicht irgendwo auf, sondern blendet am Mini-Fenster von Boris ein, fliegt von dort zum Ziel
 * und kehrt am Ende dorthin zurück. Beim Klick federt die Spitze kurz ein und eine zarte Welle läuft aus.
 */
class CursorView(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private var cx = -1f
    private var cy = -1f
    private var label = ""
    private var appear = 0f          // 0 unsichtbar .. 1 sichtbar
    private var press = 0f           // 0 .. 1 Klick-Einfedern
    private var ripple = -1f
    private var move: ValueAnimator? = null

    private val arrow = Path().apply {
        moveTo(0f, 0f); lineTo(0f, 16.5f); lineTo(4.1f, 12.9f); lineTo(6.9f, 19.2f)
        lineTo(9.7f, 18f); lineTo(7f, 11.8f); lineTo(12.4f, 11.8f); close()
    }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.WHITE }
    private val edgeP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.parseColor("#14161A"); strokeJoin = Paint.Join.ROUND; strokeWidth = 1.5f
    }
    private val shadowP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.BLACK }
    private val ringP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f * d }
    private val pillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.parseColor("#D9101216") }
    private val textP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 11.5f * d; color = Color.WHITE; typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
    }
    private val ease = PathInterpolator(0.4f, 0f, 0.2f, 1f)

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        if (cx < 0f) { cx = w * 0.5f; cy = h * 0.82f }
    }

    /** Startposition vor dem Einblenden (Bildschirmkoordinaten). */
    fun startAt(x: Float, y: Float) { cx = x; cy = y }

    fun setLabel(l: String) { label = l; invalidate() }

    fun fadeIn() {
        ValueAnimator.ofFloat(appear, 1f).apply {
            duration = 260
            addUpdateListener { appear = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    fun fadeOut(end: () -> Unit) {
        ValueAnimator.ofFloat(appear, 0f).apply {
            duration = 220
            addUpdateListener { appear = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() { override fun onAnimationEnd(a: Animator) { end() } })
            start()
        }
    }

    /** Gleitet mit sanfter Kurve zum Ziel. Gibt die Dauer in Millisekunden zurück. */
    fun moveTo(x: Float, y: Float, l: String): Long {
        label = l
        val sx = cx; val sy = cy
        val dx = x - sx; val dy = y - sy
        val dist = kotlin.math.sqrt(dx * dx + dy * dy)
        if (dist < 2f * d) { cx = x; cy = y; invalidate(); return 60L }
        val dur = (300f + dist / d * 0.8f).toLong().coerceIn(420L, 950L)
        // Steuerpunkt seitlich der Geraden: die Bahn schwingt leicht, wie bei einer echten Hand
        val bend = (dist * 0.1f).coerceIn(10f * d, 60f * d) * (if (dx >= 0f) -1f else 1f)
        val mx = (sx + x) * 0.5f + (dy / dist) * bend
        val my = (sy + y) * 0.5f - (dx / dist) * bend
        move?.cancel()
        move = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = dur
            interpolator = ease
            addUpdateListener {
                val f = it.animatedValue as Float
                val inv = 1f - f
                cx = inv * inv * sx + 2f * inv * f * mx + f * f * x
                cy = inv * inv * sy + 2f * inv * f * my + f * f * y
                invalidate()
            }
            start()
        }
        return dur
    }

    /** Klick: Spitze federt ein, eine Welle läuft aus. */
    fun tapFlash() {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 420
            addUpdateListener {
                val f = it.animatedValue as Float
                ripple = f
                press = if (f < 0.25f) f / 0.25f else 1f - (f - 0.25f) / 0.75f
                invalidate()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) { ripple = -1f; press = 0f; invalidate() }
            })
            start()
        }
    }

    override fun onDraw(c: Canvas) {
        if (cx < 0f || appear <= 0.01f) return
        val a = (appear * 255).toInt().coerceIn(0, 255)

        if (ripple >= 0f) {
            ringP.color = Color.WHITE
            ringP.alpha = ((1f - ripple) * 150 * appear).toInt().coerceIn(0, 255)
            c.drawCircle(cx, cy, (6f + 26f * ripple) * d, ringP)
        }

        val s = 1.5f * d * (0.75f + 0.25f * appear) * (1f - 0.14f * press)
        // weicher Schatten: zwei versetzte, durchscheinende Kopien
        for (k in 1..2) {
            c.save()
            c.translate(cx + k * 1.1f * d, cy + k * 1.7f * d)
            c.scale(s, s)
            shadowP.alpha = (a * 0.16f).toInt()
            c.drawPath(arrow, shadowP)
            c.restore()
        }
        c.save()
        c.translate(cx, cy)
        c.scale(s, s)
        fillP.alpha = a
        c.drawPath(arrow, fillP)
        edgeP.alpha = a
        c.drawPath(arrow, edgeP)
        c.restore()

        if (label.isNotEmpty()) {
            val tw = textP.measureText(label)
            val padX = 9f * d
            val w = tw + padX * 2
            val h = 24f * d
            val x = (cx + 14f * d).coerceAtMost(width - w - 8f * d).coerceAtLeast(8f * d)
            val y = (cy + 26f * d).coerceAtMost(height - h - 8f * d)
            pillP.alpha = (a * 0.85f).toInt()
            c.drawRoundRect(RectF(x, y, x + w, y + h), h / 2f, h / 2f, pillP)
            textP.alpha = a
            c.drawText(label, x + padX, y + h / 2f - (textP.ascent() + textP.descent()) / 2f, textP)
        }
    }
}
