package com.boris.assistant

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.min

// ------------------------------------------------------------------ Activity
class MainActivity : ComponentActivity() {
    val jarvis: Jarvis by lazy { Hub.jarvis(this) }
    var tick by mutableIntStateOf(0)
    private var ownListener: WakeListener? = null
    private var awaitAfterStart = false

    private fun prefs() = getSharedPreferences("boris", 0)
    fun alwaysListen() = prefs().getBoolean("always_listen", false)
    private fun micOk() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED

    /** Mit Dauer-Zuhören übernimmt der Hintergrunddienst, sonst hört die App nur im Vordergrund zu. */
    fun startListening() {
        if (!micOk()) return
        if (alwaysListen()) {
            ownListener?.stop(); ownListener = null
            try { startForegroundService(Intent(this, ListenService::class.java)) } catch (e: Exception) { Dbg.d("Dienst: ${e.message}") }
        } else {
            if (ownListener == null) ownListener = WakeListener(this, { t -> Core.handle(this, t) }, { m -> Core.voiceMode = m })
            Core.listener = ownListener
            ownListener?.start()
        }
        if (awaitAfterStart) { awaitAfterStart = false; Core.listener?.awaitCommand() }
    }

    fun setAlwaysListen(on: Boolean) {
        prefs().edit().putBoolean("always_listen", on).apply()
        if (!on) stopService(Intent(this, ListenService::class.java))
        startListening()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Brain.load(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Pal.use(prefs().getInt("theme", 2))
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        handleIntent(intent)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Pal.accent, background = Pal.bg, surface = Pal.panel)) {
                BorisScreen(this)
            }
        }
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); handleIntent(intent) }

    private fun handleIntent(i: Intent?) { if (i?.hasExtra("q") == true) { awaitAfterStart = true; i.removeExtra("q") } }

    override fun onResume() { super.onResume(); tick++; Core.activityVisible = true; Learning.userActive(); startListening() }

    override fun onPause() {
        Core.activityVisible = false
        if (!alwaysListen()) { ownListener?.stop(); Core.voiceMode = 0 }
        super.onPause()
    }
}

// ------------------------------------------------------------------ Bildschirm
private class OrbHolder {
    val orb = BorisOrb()
    var w = 0f; var h = 0f
    var touch = Offset.Zero; var touching = false
}

@Composable
private fun BorisScreen(activity: MainActivity) {
    val prefs = remember { activity.getSharedPreferences("boris", 0) }
    var apiKey by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var keyInput by remember { mutableStateOf("") }
    var sheetOpen by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var always by remember { mutableStateOf(activity.alwaysListen()) }
    var agentOn by remember { mutableStateOf(false) }
    var notifOn by remember { mutableStateOf(false) }
    var hideAgent by remember { mutableStateOf(prefs.getBoolean("hint_agent_off", false)) }
    var hideNotif by remember { mutableStateOf(prefs.getBoolean("hint_notif_off", false)) }
    val jarvis = activity.jarvis
    val dens = LocalDensity.current.density
    val messages = Core.messages

    fun openSheet(t: Int) { tab = t; sheetOpen = true }

    LaunchedEffect(activity.tick) { agentOn = isAutoSendEnabled(activity); notifOn = isNotifAccessEnabled(activity) }
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (it[Manifest.permission.RECORD_AUDIO] == true) activity.startListening()
    }
    LaunchedEffect(Unit) {
        perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.SEND_SMS, Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE, Manifest.permission.READ_CALENDAR, Manifest.permission.POST_NOTIFICATIONS))
    }
    BackHandler(enabled = sheetOpen) { sheetOpen = false }

    // ---- Simulation: der Orb folgt dem, was Boris gerade tut (zuhören, denken, sprechen, lernen)
    val hold = remember { OrbHolder() }
    val inp = remember { FaceInput() }
    var frame by remember { mutableLongStateOf(0L) }
    var mode by remember { mutableStateOf(FaceMode.IDLE) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                val dt = if (last == 0L) 0.016f else ((now - last) / 1_000_000_000f).coerceAtMost(0.05f)
                last = now
                val speaking = jarvis.speaking
                val m = when {
                    speaking -> FaceMode.SPEAK
                    Core.busy || jarvis.preparing -> FaceMode.THINK
                    Core.voiceMode == 2 -> FaceMode.LISTEN
                    Learning.active -> FaceMode.LEARN
                    else -> FaceMode.IDLE
                }
                if (m != mode) mode = m
                if (hold.w > 0f) {
                    val cxNow = hold.w / 2f
                    val cyNow = hold.h * 0.38f
                    inp.mode = m
                    inp.mood = jarvis.mood
                    inp.speaking = speaking
                    inp.touching = hold.touching
                    inp.tdx = hold.touch.x - cxNow
                    inp.tdy = hold.touch.y - cyNow
                    inp.drowsy = Learning.drowsy()
                    inp.learnSeq = Learning.learnSeq
                    hold.orb.update(dt, jarvis.vox, inp, cxNow, cyNow, min(hold.w, hold.h * 0.5f) * 0.25f)
                }
                frame = now
            }
        }
    }
    val tint by animateColorAsState(
        when (mode) {
            FaceMode.SPEAK -> lerp(Pal.accent, Color.White, 0.35f)
            FaceMode.THINK -> lerp(Pal.accent, Color.White, 0.15f)
            FaceMode.LISTEN, FaceMode.LEARN -> Pal.accent2
            else -> Pal.accent
        }, tween(500), label = "tint")

    val pulseT = rememberInfiniteTransition(label = "pulse")
    val pulse by pulseT.animateFloat(0.2f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "p")

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Pal.bgTop, Pal.bg)))
        .onSizeChanged { hold.w = it.width.toFloat(); hold.h = it.height.toFloat() }
        .pointerInput(Unit) {
            awaitPointerEventScope { while (true) { awaitPointerEvent(PointerEventPass.Initial); Learning.userActive(true) } }
        }) {

        Canvas(Modifier.fillMaxSize()) {
            val tk = frame
            if (tk < 0) return@Canvas
            hold.orb.draw(this, tint, dens)
        }

        // Berührungsfläche des Orbs: ziehen lässt ihn folgen, Antippen unterbricht oder startet das Zuhören
        Box(Modifier.fillMaxWidth().fillMaxHeight(0.62f).align(Alignment.TopCenter).pointerInput(Unit) {
            awaitPointerEventScope {
                while (true) {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    hold.touch = down.position; hold.touching = true
                    val slop = viewConfiguration.touchSlop
                    var moved = false
                    while (true) {
                        val ev = awaitPointerEvent()
                        val ch = ev.changes.firstOrNull() ?: break
                        hold.touch = ch.position
                        if ((ch.position - down.position).getDistance() > slop) moved = true
                        if (!ch.pressed) {
                            if (!moved && ch.uptimeMillis - down.uptimeMillis < 500L) {
                                if (jarvis.speaking || Core.busy) Core.interrupt(activity) else Core.listener?.awaitCommand()
                            }
                            break
                        }
                    }
                    hold.touching = false
                }
            }
        })

        if (apiKey.isBlank()) {
            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().systemBarsPadding().imePadding().padding(16.dp)
                .glass(RoundedCornerShape(28.dp), 0.92f).padding(20.dp)) {
                Text("Willkommen", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("Boris braucht einen kostenlosen Gemini-Key. Er bleibt nur auf deinem Handy.",
                    fontSize = 13.sp, color = Color.White.copy(alpha = 0.65f), lineHeight = 18.sp)
                Spacer(Modifier.height(14.dp))
                Setting("Key holen", "aistudio.google.com/apikey", {
                    activity.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://aistudio.google.com/apikey")))
                }) { ActionText("öffnen ↗") }
                Spacer(Modifier.height(8.dp))
                PillField(keyInput, "API-Key einfügen", Modifier.fillMaxWidth()) { keyInput = it }
                Spacer(Modifier.height(12.dp))
                Button({ val k = keyInput.trim(); if (k.isNotBlank()) { apiKey = k; prefs.edit().putString("key", k).apply() } }, Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Pal.accent, contentColor = Pal.onAccent)) { Text("Starten") }
            }
        } else {
            // Kopf: Name und Zustand links, Einstellungen rechts
            val stateLabel = when (mode) {
                FaceMode.SPEAK -> "SPRICHT"
                FaceMode.THINK -> if (Core.busy && Core.status != "BEREIT") Core.status else "DENKT NACH"
                FaceMode.LISTEN -> "HÖRT ZU"
                FaceMode.LEARN -> if (Learning.topic.isBlank()) "LERNT" else "LERNT · " + Learning.topic.uppercase()
                else -> if (Core.voiceMode == 0) "MIKROFON AUS" else "BEREIT"
            }
            Row(Modifier.align(Alignment.TopCenter).fillMaxWidth().systemBarsPadding().padding(horizontal = 20.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("BORIS", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 5.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(6.dp).clip(CircleShape).background(tint.copy(alpha = if (mode == FaceMode.IDLE) 1f else pulse)))
                        Spacer(Modifier.width(7.dp))
                        Text(stateLabel, color = tint, fontSize = 11.sp, fontFamily = FontFamily.Monospace, letterSpacing = 1.5.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 240.dp))
                    }
                }
                RoundBtn("gear", 44.dp, false, 0f) { openSheet(3) }
            }

            // Hinweise nur, solange ein Zugriff fehlt (jeder lässt sich wegklicken)
            Column(Modifier.align(Alignment.TopCenter).fillMaxWidth().systemBarsPadding().padding(top = 72.dp, start = 20.dp, end = 20.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!agentOn && !hideAgent) HintChip("Agent-Zugriff einrichten", { activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                    { hideAgent = true; prefs.edit().putBoolean("hint_agent_off", true).apply() })
                if (!notifOn && !hideNotif) HintChip("Benachrichtigungen freigeben", { activity.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
                    { hideNotif = true; prefs.edit().putBoolean("hint_notif_off", true).apply() })
            }

            // Mitte unten: was Boris gerade tut oder zuletzt gesagt hat
            val lastBoris = messages.lastOrNull { it.kind == 1 || it.kind == 3 }
            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().systemBarsPadding().padding(start = 28.dp, end = 28.dp, bottom = 150.dp),
                horizontalAlignment = Alignment.CenterHorizontally) {
                when {
                    mode == FaceMode.LISTEN -> Text("Ich höre zu …", color = Pal.accent2, fontSize = 22.sp, fontWeight = FontWeight.Medium)
                    mode == FaceMode.LEARN -> Text(if (Learning.topic.isBlank()) "Ich nutze die Ruhe zum Lernen …" else "Ich lerne: " + Learning.topic,
                        color = Color.White.copy(alpha = 0.6f), fontSize = 16.sp, textAlign = TextAlign.Center)
                    mode == FaceMode.THINK -> Text("Einen Moment …", color = Color.White.copy(alpha = 0.6f), fontSize = 18.sp)
                    lastBoris != null -> Text(lastBoris.text, color = if (lastBoris.kind == 3) Pal.red else Color.White.copy(alpha = 0.92f),
                        fontSize = 18.sp, textAlign = TextAlign.Center, maxLines = 4, overflow = TextOverflow.Ellipsis, lineHeight = 25.sp,
                        modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable { openSheet(0) }.padding(horizontal = 6.dp, vertical = 2.dp))
                    else -> {
                        Text("Sag „Boris“", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.SemiBold)
                        Text("oder tippe auf das Mikrofon", color = Color.White.copy(alpha = 0.5f), fontSize = 14.sp)
                    }
                }
            }

            // Unten: Chat links, Mikrofon in der Mitte, Gehirn rechts
            Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().systemBarsPadding().padding(horizontal = 24.dp, vertical = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                RoundBtn("chat", 56.dp, false, 0f) { openSheet(0) }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    val active = mode == FaceMode.SPEAK || mode == FaceMode.THINK
                    RoundBtn(if (active) "stop" else "mic", 76.dp, true, if (mode == FaceMode.LISTEN) pulse else 0f) {
                        if (active) Core.interrupt(activity) else Core.listener?.awaitCommand()
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(if (Core.voiceMode == 0) "Mikrofon aus" else if (always) "Hört immer zu" else "Sag „Boris“",
                        color = Color.White.copy(alpha = 0.38f), fontSize = 11.sp)
                }
                RoundBtn("spark", 56.dp, false, 0f) { openSheet(1) }
            }

            // Sheet: Chat, Gehirn, Aufgaben, Mehr
            AnimatedVisibility(sheetOpen, enter = fadeIn(), exit = fadeOut()) {
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)).clickable { sheetOpen = false })
            }
            AnimatedVisibility(sheetOpen, enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut(),
                modifier = Modifier.align(Alignment.BottomCenter)) {
                Sheet(activity, tab, { tab = it }, { sheetOpen = false }, always, { always = it; activity.setAlwaysListen(it) },
                    { apiKey = it }, agentOn, notifOn)
            }
        }
    }
}

@Composable
private fun Sheet(activity: MainActivity, tab: Int, onTab: (Int) -> Unit, onClose: () -> Unit, always: Boolean, onAlways: (Boolean) -> Unit,
                  onKeyChanged: (String) -> Unit, agentOn: Boolean, notifOn: Boolean) {
    Column(Modifier.fillMaxWidth().fillMaxHeight(0.9f).clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
        .background(Pal.panel).imePadding().navigationBarsPadding().padding(horizontal = 16.dp)) {
        // Griff: nach unten ziehen schließt
        Box(Modifier.fillMaxWidth().height(26.dp).pointerInput(Unit) {
            var sum = 0f
            detectVerticalDragGestures(onDragStart = { sum = 0f }, onDragEnd = { if (sum > 120f) onClose() }, onVerticalDrag = { _, d -> sum += d })
        }, contentAlignment = Alignment.Center) {
            Box(Modifier.size(width = 40.dp, height = 4.dp).clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.2f)))
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Chip("Chat", tab == 0) { onTab(0) }
                Chip("Gehirn", tab == 1) { onTab(1) }
                Chip("Aufgaben", tab == 2) { onTab(2) }
                Chip("Mehr", tab == 3) { onTab(3) }
            }
            Box(Modifier.size(36.dp).clip(CircleShape).clickable(onClick = onClose), contentAlignment = Alignment.Center) {
                Ico("close", Color.White.copy(alpha = 0.7f), 20.dp)
            }
        }
        when (tab) {
            0 -> ChatTab(activity)
            1 -> BrainTab()
            2 -> TasksTab(activity)
            else -> MoreTab(activity, always, onAlways, onKeyChanged, agentOn, notifOn)
        }
    }
}

// ------------------------------------------------------------------ Chat
@Composable
private fun ColumnScope.ChatTab(activity: MainActivity) {
    var input by remember { mutableStateOf("") }
    val messages = Core.messages
    val listState = rememberLazyListState()
    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1) }
    fun send() { val s = input.trim(); if (s.isNotEmpty()) { Core.handle(activity, s); input = "" } }

    if (messages.isEmpty()) {
        Column(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Frag Boris etwas", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(14.dp))
            listOf("Was kannst du alles?", "Fasse meine Benachrichtigungen zusammen", "Plane meinen Tag").forEach { s ->
                Text(s, Modifier.padding(vertical = 4.dp).clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.06f))
                    .clickable { Core.handle(activity, s) }.padding(horizontal = 16.dp, vertical = 10.dp),
                    color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
            }
        }
    } else {
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, contentPadding = PaddingValues(vertical = 8.dp)) {
            itemsIndexed(messages) { _, m ->
                if (m.kind == 2) {
                    Row(Modifier.padding(vertical = 4.dp, horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Ico("check", Pal.ok.copy(alpha = 0.85f), 14.dp)
                        Spacer(Modifier.width(6.dp))
                        Text(m.text, color = Pal.ok.copy(alpha = 0.85f), fontSize = 12.sp)
                    }
                } else {
                    val mine = m.kind == 0
                    val shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomEnd = if (mine) 6.dp else 20.dp, bottomStart = if (mine) 20.dp else 6.dp)
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                        Text(m.text, Modifier.widthIn(max = 300.dp).clip(shape)
                            .background(when (m.kind) { 0 -> Pal.accent; 3 -> Pal.red.copy(alpha = 0.25f); else -> Color.White.copy(alpha = 0.08f) })
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                            color = if (mine) Pal.onAccent else Color.White, fontSize = 15.sp)
                    }
                }
            }
        }
    }
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        PillField(input, "Nachricht an Boris", Modifier.weight(1f), onSend = { send() }) { input = it }
        Spacer(Modifier.width(10.dp))
        RoundBtn("send", 50.dp, true, 0f) { send() }
    }
}

// ------------------------------------------------------------------ Gehirn
@Composable
private fun ColumnScope.BrainTab() {
    var tick by remember { mutableIntStateOf(0) }
    var input by remember { mutableStateOf("") }
    val facts = remember(tick) { Brain.all() }
    val learned = remember(tick, Learning.summary) { Knowledge.notesView() }
    val skills = remember(tick, Learning.learnSeq) { Skills.all() }
    fun add() { if (input.isNotBlank()) { Brain.add(input, "manuell"); input = ""; tick++ } }

    Text("${facts.size} Einträge im dauerhaften Gedächtnis", color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp))
    LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
        if (facts.isEmpty() && learned.isEmpty() && skills.isEmpty()) {
            item { Note("Noch leer. Sag Boris, was er sich merken soll, oder schreib es unten hinein.") }
        }
        itemsIndexed(facts) { i, f -> BrainRow(f.first, Pal.accent, f.second) { Brain.removeAt(i); tick++ } }
        if (learned.isNotEmpty()) {
            item { GroupLabel("Selbst gelernt · ${learned.size}") }
            itemsIndexed(learned) { _, n -> BrainRow(n.second, Pal.ok, n.third) { Knowledge.removeNote(n.first); Learning.refresh(); tick++ } }
        }
        if (skills.isNotEmpty()) {
            item { GroupLabel("Selbst programmiert · ${skills.size}") }
            itemsIndexed(skills) { _, sk ->
                BrainRow("${sk.optString("name")} · v${sk.optInt("ver")} · ${sk.optInt("uses")}x genutzt", Pal.accent2, sk.optString("desc")) {
                    Skills.remove(sk.optString("name")); tick++
                }
            }
        }
    }
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        PillField(input, "Boris etwas beibringen", Modifier.weight(1f), onSend = { add() }) { input = it }
        Spacer(Modifier.width(10.dp))
        RoundBtn("plus", 50.dp, true, 0f) { add() }
    }
}

// ------------------------------------------------------------------ Aufgaben (echt: Erinnerungen, Beobachtungen, Routinen)
@Composable
private fun ColumnScope.TasksTab(activity: MainActivity) {
    var tick by remember { mutableIntStateOf(0) }
    val tasks = remember(tick) { Scheduler.all(activity) }
    Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(bottom = 12.dp)) {
        if (tasks.isEmpty()) {
            Note("Keine geplanten Aufgaben. Sag zum Beispiel: „Erinnere mich um 18 Uhr an den Anruf“ oder „Sag Bescheid, wenn Mama schreibt“.")
        }
        for (o in tasks) {
            val type = o.optString("type")
            val label = when (type) {
                "reminder" -> "ERINNERUNG · " + java.text.SimpleDateFormat("dd.MM. HH:mm", java.util.Locale.GERMAN).format(java.util.Date(o.optLong("at")))
                "watch" -> "BEOBACHTUNG"
                else -> "ROUTINE · " + o.optString("trigger")
            }
            val text = if (type == "watch") "Sagt Bescheid, sobald ${o.optString("contact")} schreibt" else o.optString("text")
            BrainRow(label, if (type == "reminder") Pal.accent else Pal.accent2, text) { Scheduler.cancel(activity, o.optLong("id").toString()); tick++ }
        }
        Note("Gelernte Kurzbefehle für den Agenten: ${Recipes.count(activity)}")
    }
}

// ------------------------------------------------------------------ Mehr: Einstellungen in aufklappbaren Gruppen
@Composable
private fun ColumnScope.MoreTab(activity: MainActivity, always: Boolean, onAlways: (Boolean) -> Unit, onKeyChanged: (String) -> Unit,
                                agentOn: Boolean, notifOn: Boolean) {
    val prefs = remember { activity.getSharedPreferences("boris", 0) }
    val jarvis = activity.jarvis
    var sel by remember { mutableIntStateOf(-1) }
    fun toggle(i: Int) { sel = if (sel == i) -1 else i }

    var voiceName by remember { mutableStateOf(jarvis.voiceName()) }
    var hq by remember { mutableStateOf(prefs.getBoolean("hq_voice", true)) }
    var fishKeyInput by remember { mutableStateOf("") }
    var fishVoiceInput by remember { mutableStateOf(prefs.getString("fish_voice", "") ?: "") }
    var fishSet by remember { mutableStateOf(!prefs.getString("fish_key", "").isNullOrBlank()) }
    var fishOn by remember { mutableStateOf(prefs.getBoolean("fish_enabled", true)) }
    var fishStatus by remember { mutableStateOf(if (fishSet) "API-Key gespeichert · Free-Modell ausgewählt" else "Noch kein API-Key") }
    var elKeyInput by remember { mutableStateOf("") }
    var elVoiceInput by remember { mutableStateOf("") }
    var elSet by remember { mutableStateOf(!prefs.getString("el_key", "").isNullOrBlank()) }
    var elInfo by remember { mutableStateOf(ElBudget.summary(activity)) }
    var elNotif by remember { mutableStateOf(prefs.getBoolean("el_notif", false)) }

    var notifAi by remember { mutableStateOf(prefs.getBoolean("notif_ai", true)) }
    var proactive by remember { mutableStateOf(prefs.getBoolean("proactive", true)) }
    var pip by remember { mutableStateOf(prefs.getBoolean("pip", true)) }
    var safety by remember { mutableStateOf(prefs.getBoolean("safety", true)) }

    var selfLearn by remember { mutableStateOf(Learning.enabled()) }
    var selfCode by remember { mutableStateOf(prefs.getBoolean("selfcode", true)) }
    var tavInput by remember { mutableStateOf("") }
    var tavStatus by remember { mutableStateOf(if (WebSearch.tavilyKey(activity).isNotBlank()) "Key gesetzt" else "noch kein Key") }
    var orKeyInput by remember { mutableStateOf("") }
    var orStatus by remember { mutableStateOf(if (OpenRouter.hasKey(activity)) "Key gesetzt" else "noch kein Key") }

    var gemInput by remember { mutableStateOf("") }
    var gemSet by remember { mutableStateOf(!prefs.getString("key", "").isNullOrBlank()) }

    var theme by remember { mutableIntStateOf(Pal.id) }

    var testing by remember { mutableStateOf(false) }
    val testResults = remember { mutableStateListOf<Pair<Boolean, String>>() }
    var crash by remember { mutableStateOf(prefs.getString("crash", null)) }

    Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {

        Section("Stimme", voiceName, "voice", sel == 0, { toggle(0) }) {
            Setting("Stimme wechseln", voiceName, { voiceName = jarvis.cycleVoice(); Core.say(activity, "Systeme online. Wie kann ich helfen?", false) }) { ActionText("wechseln ›") }

            GroupLabel("Fish Audio · S2.1 Pro Free")
            Note("Echtzeit-Streaming: Boris spricht, sobald der erste Audio-Schnipsel da ist. Häufige Antworten werden lokal gespeichert. ElevenLabs bleibt als Ausweichlösung.")
            PillField(fishKeyInput, "Fish Audio API-Key", Modifier.fillMaxWidth(), secret = true) { fishKeyInput = it }
            Setting("Key speichern", if (fishSet) "gesetzt" else "nicht gesetzt", {
                val k = fishKeyInput.trim()
                if (k.isNotBlank()) {
                    prefs.edit().putString("fish_key", k).putBoolean("fish_enabled", true).apply()
                    fishSet = true; fishOn = true; fishKeyInput = ""
                    fishStatus = "Key gespeichert · S2.1 Pro Free aktiv"
                    voiceName = jarvis.voiceName()
                }
            }) { ActionText("speichern ›") }
            Setting("Fish Audio aktiv", fishStatus, null) {
                Toggle(fishOn) {
                    fishOn = it; prefs.edit().putBoolean("fish_enabled", it).apply()
                    fishStatus = if (it) "Fish Audio aktiviert" else "Fish Audio pausiert"
                    voiceName = jarvis.voiceName()
                }
            }
            PillField(fishVoiceInput, "Voice-ID (optional)", Modifier.fillMaxWidth()) { fishVoiceInput = it }
            Setting("Voice-ID speichern", if (fishVoiceInput.isBlank()) "Standardstimme" else "eigene Stimme", {
                prefs.edit().putString("fish_voice", fishVoiceInput.trim()).apply()
                voiceName = jarvis.voiceName()
                fishStatus = if (fishVoiceInput.isBlank()) "Standardstimme gespeichert" else "Voice-ID gespeichert"
            }) { ActionText("speichern ›") }
            Setting("Fish Audio testen", "kurze Testausgabe mit der aktuellen Stimme", {
                if (fishSet) Core.say(activity, "Fish Audio ist verbunden. Systeme online.", false)
                else fishStatus = "Bitte zuerst einen API-Key speichern"
            }) { ActionText("testen ›") }
            Setting("API-Key holen", "fish.audio/app/api-keys", {
                activity.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://fish.audio/app/api-keys")))
            }) { ActionText("öffnen ↗") }

            GroupLabel("ElevenLabs")
            Note("Key unter elevenlabs.io → API Keys. Der Gratis-Tarif hat nur wenige Zeichen im Monat.")
            PillField(elKeyInput, "ElevenLabs-Key", Modifier.fillMaxWidth(), secret = true) { elKeyInput = it }
            Setting("Key speichern", if (elSet) "gesetzt" else "nicht gesetzt", {
                val k = elKeyInput.trim()
                prefs.edit().putString("el_key", k).apply()
                elSet = k.isNotBlank(); elKeyInput = ""
                voiceName = jarvis.voiceName()
                if (elSet) Core.say(activity, "ElevenLabs verbunden. Systeme online.", false)
            }) { ActionText("speichern ›") }
            PillField(elVoiceInput, "Eigene Voice-ID (optional)", Modifier.fillMaxWidth()) { elVoiceInput = it }
            Setting("Voice-ID speichern", null, {
                val v = elVoiceInput.trim()
                if (v.isNotBlank()) { prefs.edit().putString("el_voice", v).apply(); elVoiceInput = ""; voiceName = jarvis.voiceName() }
            }) { ActionText("speichern ›") }
            Setting("Credits", elInfo, {
                elInfo = "prüfe …"
                Thread {
                    val k = prefs.getString("el_key", "") ?: ""
                    if (k.isNotBlank()) ElBudget.refresh(activity, k)
                    activity.runOnUiThread { elInfo = ElBudget.summary(activity) }
                }.start()
            }) { ActionText("aktualisieren ›") }
            Setting("Meldungen mit ElevenLabs sprechen", "aus = kostenlose Handy-Stimme, spart Credits", null) {
                Toggle(elNotif) { elNotif = it; prefs.edit().putBoolean("el_notif", it).apply() }
            }

            GroupLabel("Ausweichlösung")
            Setting("Gemini-Stimme", "springt ein, wenn keine andere Stimme läuft", null) { Toggle(hq) { hq = it; prefs.edit().putBoolean("hq_voice", it).apply() } }
        }

        Section("Zuhören & Sicherheit", if (always) "hört immer zu" else "hört nur bei offener App", "mic", sel == 1, { toggle(1) }) {
            Setting("Immer zuhören", "auch bei gesperrtem Handy", null) { Toggle(always) { onAlways(it) } }
            Setting("Benachrichtigungen erzählen", "kurz zusammengefasst, auf Wunsch stumm", null) {
                Toggle(notifAi) { notifAi = it; prefs.edit().putBoolean("notif_ai", it).apply() }
            }
            Setting("Proaktive Rückfragen", "z. B. wenn du lange in einer App bist", null) {
                Toggle(proactive) { proactive = it; prefs.edit().putBoolean("proactive", it).apply() }
            }
            Setting("Mini-Fenster mit Gesicht", "schwebt verschiebbar über anderen Apps, wenn Boris spricht oder der Agent arbeitet", null) {
                Toggle(pip) { pip = it; prefs.edit().putBoolean("pip", it).apply() }
            }
            Setting("Sicherheitsabfragen", "bei Geld, langen Texten, neuen Kontakten", null) {
                Toggle(safety) { safety = it; prefs.edit().putBoolean("safety", it).apply() }
            }
        }

        Section("Lernen & Selfcoding", Learning.summary.ifBlank { if (selfLearn) "Selbstlernen an" else "Selbstlernen aus" }, "spark", sel == 2, { toggle(2) }) {
            Setting("Selbstlernen", "nach 10 Min. Ruhe: recherchiert, prüft und merkt sich Nützliches", null) {
                Toggle(selfLearn) { selfLearn = it; Learning.setEnabled(it) }
            }
            Setting("Jetzt lernen", if (Learning.active) "lernt gerade …" else Learning.summary, { Learning.learnNow() }) { ActionText("starten ›") }
            Setting("Selfcoding", "Boris programmiert sich selbst Skills und testet sie", null) {
                Toggle(selfCode) { selfCode = it; prefs.edit().putBoolean("selfcode", it).apply() }
            }
            Note("OpenRouter (zweiter, kostenloser Key von openrouter.ai) übernimmt Selbstlernen und Selfcoding, damit Gemini frei bleibt.")
            PillField(orKeyInput, "OpenRouter-Key", Modifier.fillMaxWidth(), secret = true) { orKeyInput = it }
            Setting("Key speichern und prüfen", orStatus, {
                val k = orKeyInput.trim()
                if (k.isNotBlank()) { prefs.edit().putString("or_key", k).apply(); orKeyInput = "" }
                orStatus = "prüfe …"
                Thread { val r = OpenRouter.check(activity); activity.runOnUiThread { orStatus = r } }.start()
            }) { ActionText("prüfen ›") }
            Note("Websuche: kostenloser Tavily-Key von app.tavily.com (1000 Suchen pro Monat, keine Kreditkarte). Ohne Key sucht Boris nur über Reserve-Wege, die oft nichts finden.")
            PillField(tavInput, "Tavily-Key (tvly-…)", Modifier.fillMaxWidth(), secret = true) { tavInput = it }
            Setting("Such-Key speichern und testen", tavStatus, {
                val k = tavInput.trim()
                if (k.isNotBlank()) { prefs.edit().putString("tav_key", k).apply(); tavInput = "" }
                tavStatus = "teste …"
                Thread { val r = WebSearch.checkTavily(activity); activity.runOnUiThread { tavStatus = r } }.start()
            }) { ActionText("testen ›") }
            Setting("Tagesbudget", Providers.status(activity), null) { Text("heute", color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp) }
            Setting("Gelerntes zurücksetzen", "löscht recherchiertes Wissen und Regeln, nicht dein Gehirn", { Knowledge.clearLearned(); Learning.refresh() }) {
                ActionText("löschen ›")
            }
        }

        Section("Verbindungen & Zugriff", if (agentOn && notifOn) "alles verbunden" else "Zugriffe fehlen", "link", sel == 3, { toggle(3) }) {
            Note("Der Gemini-Key bleibt nur auf deinem Handy.")
            PillField(gemInput, "Neuer Gemini-API-Key", Modifier.fillMaxWidth(), secret = true) { gemInput = it }
            Setting("Gemini-Key speichern", if (gemSet) "gesetzt" else "nicht gesetzt", {
                val k = gemInput.trim()
                if (k.isNotBlank()) { prefs.edit().putString("key", k).apply(); gemSet = true; gemInput = ""; onKeyChanged(k) }
            }) { ActionText("speichern ›") }
            Setting("Benachrichtigungszugriff", if (notifOn) "aktiv" else "aus, hier aktivieren",
                { activity.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }) {
                if (notifOn) Ico("check", Pal.ok, 20.dp) else Ico("chev", Pal.accent2, 20.dp)
            }
            Setting("Agent-Zugriff", if (agentOn) "aktiv" else "aus, hier aktivieren",
                { activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) {
                if (agentOn) Ico("check", Pal.ok, 20.dp) else Ico("chev", Pal.accent2, 20.dp)
            }
        }

        Section("Darstellung", "Farbwelt: " + Pal.names[theme], "palette", sel == 4, { toggle(4) }) {
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp, horizontal = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pal.names.forEachIndexed { i, n ->
                    Chip(n, theme == i) { theme = i; Pal.use(i); prefs.edit().putInt("theme", i).apply() }
                }
            }
        }

        Section("Diagnose", if (crash != null) "letzter Absturz gespeichert" else "Selbsttest und Protokoll", "wrench", sel == 5, { toggle(5) }) {
            Setting("Selbsttest", if (testing) "läuft …" else "prüft alles, was Boris braucht", {
                if (!testing) {
                    testing = true; testResults.clear()
                    Thread {
                        val r = try { SelfTest.run(activity) } catch (e: Exception) { listOf(false to "Test-Fehler: ${e.message}") }
                        activity.runOnUiThread { testResults.addAll(r); testing = false }
                    }.start()
                }
            }) { ActionText("starten ›") }
            testResults.forEach {
                Text((if (it.first) "✓ " else "✗ ") + it.second, Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                    fontSize = 12.sp, color = if (it.first) Pal.ok else Pal.red)
            }
            val c = crash
            if (c != null) {
                Setting("Letzter Absturz", "antippen zum Löschen", { prefs.edit().remove("crash").apply(); crash = null }) { Text("löschen", color = Pal.red, fontSize = 13.sp) }
                Text(c.take(600), Modifier.padding(8.dp), fontSize = 9.sp, color = Pal.red.copy(alpha = 0.8f))
            }
            GroupLabel("Protokoll")
            Dbg.lines.takeLast(25).forEach {
                Text(it, Modifier.padding(horizontal = 8.dp, vertical = 1.dp), fontSize = 10.sp, color = Color.White.copy(alpha = 0.6f), fontFamily = FontFamily.Monospace)
            }
        }
    }
}
