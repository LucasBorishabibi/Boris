package com.boris.assistant

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** Aufgaben mit Zeitbezug: Erinnerungen, "sag Bescheid wenn X schreibt", tägliche und Lade-Routinen (z. B. Morgenbriefing). */
object Scheduler {
    private const val PREF = "boris_tasks"

    @Synchronized private fun load(ctx: Context): JSONArray = JSONArray(ctx.getSharedPreferences(PREF, 0).getString("t", "[]") ?: "[]")
    @Synchronized private fun save(ctx: Context, a: JSONArray) { ctx.getSharedPreferences(PREF, 0).edit().putString("t", a.toString()).apply() }

    fun all(ctx: Context): List<JSONObject> { val a = load(ctx); return (0 until a.length()).map { a.getJSONObject(it) } }

    private fun add(ctx: Context, o: JSONObject): JSONObject {
        val a = load(ctx); o.put("id", System.currentTimeMillis()); a.put(o); save(ctx, a); rearm(ctx); return o
    }

    fun addReminder(ctx: Context, text: String, at: Long) = add(ctx, JSONObject().put("type", "reminder").put("text", text).put("at", at))
    fun addWatch(ctx: Context, contact: String, say: String) = add(ctx, JSONObject().put("type", "watch").put("contact", contact).put("text", say))

    /** trigger: "daily HH:MM" oder "charging". */
    fun addRoutine(ctx: Context, trigger: String, action: String): String {
        val t = trigger.trim().lowercase()
        val o = JSONObject().put("type", "routine").put("text", action).put("trigger", t)
        if (t.startsWith("daily")) {
            val m = Regex("(\\d{1,2})[:.](\\d{2})").find(t) ?: return "Fehler: Uhrzeit nicht erkannt (Format: daily HH:MM)"
            o.put("hh", m.groupValues[1].toInt()).put("mm", m.groupValues[2].toInt())
        } else if (t != "charging") return "Fehler: unbekannter Auslöser (daily HH:MM oder charging)"
        add(ctx, o)
        return if (t == "charging") "Routine gespeichert: sobald das Handy geladen wird." else "Routine gespeichert: täglich um ${o.getInt("hh")}:${"%02d".format(o.getInt("mm"))}."
    }

    fun describe(ctx: Context): String {
        val l = all(ctx)
        if (l.isEmpty()) return "Keine geplanten Aufgaben."
        return l.joinToString("\n") {
            when (it.getString("type")) {
                "reminder" -> "Erinnerung ${java.text.SimpleDateFormat("dd.MM. HH:mm", java.util.Locale.GERMAN).format(java.util.Date(it.getLong("at")))}: ${it.getString("text")}"
                "watch" -> "Beobachte Nachrichten von ${it.getString("contact")}"
                else -> "Routine (${it.getString("trigger")}): ${it.getString("text").take(60)}"
            }
        }
    }

    fun cancel(ctx: Context, keyword: String): Int {
        val a = load(ctx); val keep = JSONArray(); var n = 0
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.toString().contains(keyword, true)) { n++; cancelAlarm(ctx, o.getLong("id")) } else keep.put(o)
        }
        save(ctx, keep); return n
    }

    /** Gibt einen Beobachtungs-Treffer zurück und entfernt ihn. */
    fun matchWatch(ctx: Context, title: String): JSONObject? {
        val a = load(ctx)
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.getString("type") == "watch" && title.contains(o.getString("contact"), true)) {
                val keep = JSONArray(); for (j in 0 until a.length()) if (j != i) keep.put(a.getJSONObject(j)); save(ctx, keep)
                return o
            }
        }
        return null
    }

    private fun pi(ctx: Context, id: Long) = PendingIntent.getBroadcast(ctx, (id % 1_000_000).toInt(),
        Intent(ctx, TaskReceiver::class.java).putExtra("id", id), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun cancelAlarm(ctx: Context, id: Long) { ctx.getSystemService(AlarmManager::class.java).cancel(pi(ctx, id)) }

    private fun nextDaily(hh: Int, mm: Int): Long {
        val c = Calendar.getInstance(); c.set(Calendar.HOUR_OF_DAY, hh); c.set(Calendar.MINUTE, mm); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        if (c.timeInMillis <= System.currentTimeMillis() + 1000) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    private fun setAt(ctx: Context, id: Long, at: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(ctx, id))
            else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(ctx, id))
        } catch (e: SecurityException) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(ctx, id)) }
    }

    fun rearm(ctx: Context) {
        for (o in all(ctx)) {
            val id = o.getLong("id")
            when {
                o.getString("type") == "reminder" && o.getLong("at") > System.currentTimeMillis() -> setAt(ctx, id, o.getLong("at"))
                o.getString("type") == "routine" && o.getString("trigger").startsWith("daily") -> setAt(ctx, id, nextDaily(o.getInt("hh"), o.getInt("mm")))
            }
        }
    }

    fun fire(ctx: Context, id: Long) {
        val o = all(ctx).firstOrNull { it.getLong("id") == id } ?: return
        when (o.getString("type")) {
            "reminder" -> {
                val a = load(ctx); val keep = JSONArray()
                for (i in 0 until a.length()) if (a.getJSONObject(i).getLong("id") != id) keep.put(a.getJSONObject(i)); save(ctx, keep)
                Core.announce(ctx, "Erinnerung: ${o.getString("text")}", false)
            }
            "routine" -> {
                Core.handle(ctx, o.getString("text"))
                if (o.getString("trigger").startsWith("daily")) setAt(ctx, id, nextDaily(o.getInt("hh"), o.getInt("mm")))
            }
        }
    }

    fun onCharging(ctx: Context) {
        for (o in all(ctx)) if (o.getString("type") == "routine" && o.getString("trigger") == "charging") Core.handle(ctx, o.getString("text"))
    }
}

class TaskReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        val id = i.getLongExtra("id", 0L)
        val p = goAsync()
        Thread { try { Scheduler.fire(ctx.applicationContext, id) } catch (e: Exception) { Dbg.d("Aufgabe: ${e.message}") } finally { p.finish() } }.start()
    }
}

/** Nach einem Neustart sind alle Alarme weg: Erinnerungen und tägliche Routinen werden neu gesetzt. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) try { Scheduler.rearm(ctx.applicationContext) } catch (e: Exception) { Dbg.d("Boot: ${e.message}") }
    }
}
