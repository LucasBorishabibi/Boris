package com.boris.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.ceil
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/** Abkühlzeiten pro Anbieter: nach einem Limit (429) fragt Boris diesen Anbieter eine Weile nicht mehr. */
object RateGuard {
    private val until = HashMap<String, Long>()
    @Synchronized fun cool(p: String, ms: Long) { val t = System.currentTimeMillis() + ms; if (t > (until[p] ?: 0L)) until[p] = t }
    @Synchronized fun ok(p: String): Boolean = System.currentTimeMillis() >= (until[p] ?: 0L)
}

/** Tagesbudgets (UTC-Tag wie bei OpenRouter). Hintergrundarbeit darf Gemini nie leerziehen. */
object Budget {
    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences("boris_budget", 0)
    private fun day(): String { val f = SimpleDateFormat("yyyyMMdd", Locale.US); f.timeZone = TimeZone.getTimeZone("UTC"); return f.format(Date()) }

    @Synchronized private fun roll(c: Context) {
        val p = prefs(c)
        if (p.getString("day", "") != day()) p.edit().clear().putString("day", day()).apply()
    }

    @Synchronized fun used(c: Context, k: String): Int { roll(c); return prefs(c).getInt(k, 0) }
    @Synchronized fun inc(c: Context, k: String, n: Int = 1) { roll(c); prefs(c).edit().putInt(k, prefs(c).getInt(k, 0) + n).apply() }

    fun limit(c: Context, k: String): Int = when (k) {
        "or" -> if (OpenRouter.isFreeTier(c)) 45 else 900   // Gratis-Stufe: 50 Anfragen pro Tag, 5 Reserve
        "gem_search" -> 8                                      // Websuche im Hintergrund
        "gem_light" -> 20                                      // einfache Hintergrundanfragen an Gemini
        "skill_auto" -> 1                                      // selbst programmierte Skills pro Tag
        else -> 10
    }

    fun left(c: Context, k: String): Int = (limit(c, k) - used(c, k)).coerceAtLeast(0)
}

/** OpenRouter: zweiter, unabhängiger Key. Nimmt dem Selbstlernen und dem Programmieren die Last von Gemini ab. */
object OpenRouter {
    private const val BASE = "https://openrouter.ai/api/v1"
    private var cache: JSONArray? = null
    private var cacheAt = 0L
    private var picked = HashMap<Boolean, Pair<Long, List<String>>>()

    fun key(c: Context): String = c.getSharedPreferences("boris", 0).getString("or_key", "") ?: ""
    fun hasKey(c: Context) = key(c).isNotBlank()
    fun isFreeTier(c: Context) = c.getSharedPreferences("boris", 0).getBoolean("or_free", true)
    fun usable(c: Context) = hasKey(c) && RateGuard.ok("or") && Budget.left(c, "or") > 0

    private class Resp(val code: Int, val body: String, val reset: Long)

    private fun http(method: String, url: String, key: String?, body: JSONObject?, readMs: Int): Resp {
        val cn = URL(url).openConnection() as HttpURLConnection
        cn.requestMethod = method
        cn.connectTimeout = 10000
        cn.readTimeout = readMs
        if (key != null) cn.setRequestProperty("Authorization", "Bearer $key")
        cn.setRequestProperty("HTTP-Referer", "https://boris.local")
        cn.setRequestProperty("X-Title", "Boris")
        if (body != null) {
            cn.setRequestProperty("content-type", "application/json")
            cn.doOutput = true
            cn.outputStream.use { it.write(body.toString().toByteArray()) }
        }
        val code = cn.responseCode
        val text = (if (code in 200..299) cn.inputStream else cn.errorStream)?.bufferedReader()?.readText() ?: ""
        val reset = cn.getHeaderField("X-RateLimit-Reset")?.toLongOrNull() ?: 0L
        return Resp(code, text, reset)
    }

    /** Prüft den Key und erkennt, ob schon Guthaben gekauft wurde (dann gilt ein viel höheres Tageslimit). */
    fun check(c: Context): String {
        val k = key(c)
        if (k.isBlank()) return "Kein Key gesetzt."
        return try {
            val r = http("GET", "$BASE/key", k, null, 12000)
            if (r.code !in 200..299) return "Fehler ${r.code}: Key ungültig oder gesperrt."
            val data = JSONObject(r.body).optJSONObject("data")
            val free = data?.optBoolean("is_free_tier", true) ?: true
            c.getSharedPreferences("boris", 0).edit().putBoolean("or_free", free).apply()
            RateGuard.cool("or", 0)
            if (free) "OK · Gratis-Stufe (ca. 50 Anfragen pro Tag)" else "OK · mit Guthaben (ca. 1000 Anfragen pro Tag)"
        } catch (e: Exception) { "Fehler: " + e.message?.take(60) }
    }

    private fun models(): JSONArray? {
        val now = System.currentTimeMillis()
        cache?.let { if (now - cacheAt < 6 * 3_600_000L) return it }
        return try {
            val r = http("GET", "$BASE/models", null, null, 15000)
            if (r.code !in 200..299) null
            else JSONObject(r.body).getJSONArray("data").also { cache = it; cacheAt = now }
        } catch (e: Exception) { null }
    }

    /** Die besten aktuell kostenlosen Textmodelle (Liste ändert sich ständig, deshalb live abgefragt). */
    @Synchronized fun pick(code: Boolean): List<String> {
        picked[code]?.let { if (System.currentTimeMillis() - it.first < 6 * 3_600_000L) return it.second }
        val arr = models() ?: return listOf("openrouter/free")
        val scored = ArrayList<Pair<Int, String>>()
        for (i in 0 until arr.length()) {
            val m = arr.optJSONObject(i) ?: continue
            val id = m.optString("id")
            val p = m.optJSONObject("pricing")
            val free = id.endsWith(":free") || (p != null && p.optString("prompt") == "0" && p.optString("completion") == "0")
            if (!free) continue
            val low = id.lowercase()
            if (listOf("embed", "guard", "vision", "image", "audio", "tts", "safeguard", "moderation", "-vl", "ocr").any { low.contains(it) }) continue
            val out = m.optJSONObject("architecture")?.optJSONArray("output_modalities")
            if (out != null && (0 until out.length()).any { out.optString(it) != "text" }) continue
            val ctxLen = m.optInt("context_length", 0)
            if (ctxLen < 16000) continue
            var s = 0
            val size = Regex("(\\d+)b").find(low)?.groupValues?.get(1)?.toIntOrNull() ?: 0
            s += min(size, 120) / 3
            val boosts = if (code)
                listOf("coder" to 80, "devstral" to 70, "codestral" to 60, "gpt-oss" to 45, "deepseek" to 40, "qwen3" to 40, "glm" to 30)
            else
                listOf("gpt-oss" to 55, "llama-3.3" to 50, "qwen3" to 40, "deepseek" to 35, "nemotron" to 30, "gemma" to 30, "glm" to 30, "mistral" to 25, "kimi" to 30)
            for ((k, v) in boosts) if (low.contains(k)) s += v
            if (low.contains("thinking") || low.contains("-r1")) s -= 10
            s += (ln(ctxLen.toDouble()) * 2).toInt()
            scored.add(s to id)
        }
        val res = if (scored.isEmpty()) listOf("openrouter/free") else scored.sortedByDescending { it.first }.map { it.second }.take(3)
        picked[code] = System.currentTimeMillis() to res
        return res
    }

    /** Eine Chat-Anfrage. Gibt null zurück, wenn Limit, Fehler oder kein Key (der Aufrufer weicht dann aus oder lässt es). */
    fun chat(c: Context, system: String, user: String, code: Boolean = false, maxTokens: Int = 1500, only: List<String>? = null): String? {
        val key = key(c)
        if (key.isBlank() || !RateGuard.ok("or") || Budget.left(c, "or") <= 0) return null
        val models = only ?: pick(code)
        for (attempt in 0..1) {
            val body = JSONObject()
                .put("messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", system))
                    .put(JSONObject().put("role", "user").put("content", user)))
                .put("max_tokens", maxTokens)
                .put("temperature", if (code) 0.2 else 0.3)
            if (models.size == 1) body.put("model", models[0]) else body.put("models", JSONArray(models))
            Budget.inc(c, "or")   // auch fehlgeschlagene Anfragen zählen bei OpenRouter zum Tageslimit
            val r = try { http("POST", "$BASE/chat/completions", key, body, 60000) }
            catch (e: Exception) { Dbg.d("OpenRouter: " + e.message?.take(60)); return null }
            when {
                r.code in 200..299 -> {
                    val j = try { JSONObject(r.body) } catch (e: Exception) { return null }
                    val text = j.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content").orEmpty().trim()
                    if (text.isNotBlank() && text != "null") return text
                    Dbg.d("OpenRouter: leere Antwort")
                    return null
                }
                r.code == 429 -> {
                    val wait = if (r.reset > 0) (r.reset - System.currentTimeMillis()).coerceIn(30_000L, 24 * 3_600_000L) else 90_000L
                    RateGuard.cool("or", wait)
                    Dbg.d("OpenRouter: Limit erreicht")
                    return null
                }
                r.code == 401 || r.code == 402 || r.code == 403 -> {
                    RateGuard.cool("or", 3_600_000L)
                    Dbg.d("OpenRouter ${r.code}: Key oder Guthaben prüfen")
                    return null
                }
                else -> { Dbg.d("OpenRouter ${r.code}"); if (attempt == 0) Thread.sleep(2000) }
            }
        }
        return null
    }
}

object Providers {
    fun anyKey(c: Context) = Core.key(c).isNotBlank() || OpenRouter.hasKey(c)

    /** Reicht das Tagesbudget für eine Lernsitzung? OpenRouter zuerst, Gemini nur mit eigenem kleinem Hintergrundbudget. */
    fun canLearn(c: Context): Boolean {
        val orOk = OpenRouter.usable(c) && Budget.left(c, "or") >= 3
        val gemOk = Core.key(c).isNotBlank() && RateGuard.ok("gem") && Budget.left(c, "gem_light") >= 2
        return orOk || gemOk
    }

    fun status(c: Context): String =
        "OpenRouter ${Budget.used(c, "or")}/${Budget.limit(c, "or")} · Gemini im Hintergrund ${Budget.used(c, "gem_light") + Budget.used(c, "gem_search")}"
}

/**
 * ElevenLabs-Credits einteilen: Boris verbraucht nie mehr als einen fairen Tagesanteil des Monatsguthabens.
 * Echte Werte kommen vom Konto (braucht beim Key das Recht user_read), sonst schätzt Boris anhand der gemeldeten Kosten pro Anfrage.
 */
object ElBudget {
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("boris_el", 0)
    private fun fmt(p: String) = SimpleDateFormat(p, Locale.US).format(Date())
    @Volatile private var refreshing = false

    @Synchronized private fun roll(c: Context) {
        val p = sp(c); val m = fmt("yyyyMM"); val d = fmt("yyyyMMdd")
        val e = p.edit()
        if (p.getString("m", "") != m) e.putString("m", m).putFloat("mu", 0f)
        if (p.getString("d", "") != d) e.putString("d", d).putFloat("du", 0f)
        e.apply()
    }

    fun plan(c: Context): Int = c.getSharedPreferences("boris", 0).getInt("el_credits", 30000)

    @Synchronized fun add(c: Context, credits: Float) {
        roll(c)
        val p = sp(c)
        p.edit().putFloat("mu", p.getFloat("mu", 0f) + credits).putFloat("du", p.getFloat("du", 0f) + credits)
            .putFloat("since", p.getFloat("since", 0f) + credits).apply()
    }

    /** Liest Verbrauch und Limit vom Konto. false = Key darf das nicht sehen (dann schätzt Boris selbst). */
    fun refresh(c: Context, key: String): Boolean = try {
        val cn = URL("https://api.elevenlabs.io/v1/user/subscription").openConnection() as HttpURLConnection
        cn.connectTimeout = 8000; cn.readTimeout = 10000
        cn.setRequestProperty("xi-api-key", key)
        if (cn.responseCode !in 200..299) false
        else {
            val j = JSONObject(cn.inputStream.bufferedReader().readText())
            val used = j.optDouble("character_count", -1.0)
            val lim = j.optDouble("character_limit", -1.0)
            if (used < 0 || lim <= 0) false
            else {
                sp(c).edit().putFloat("sub_used", used.toFloat()).putFloat("sub_limit", lim.toFloat())
                    .putLong("sub_reset", j.optLong("next_character_count_reset_unix", 0L))
                    .putFloat("since", 0f).putLong("sub_at", System.currentTimeMillis()).apply()
                true
            }
        }
    } catch (e: Exception) { false }

    private fun subValid(c: Context): Boolean {
        val p = sp(c)
        val at = p.getLong("sub_at", 0L)
        val reset = p.getLong("sub_reset", 0L)
        return at > 0 && !(reset > 0 && reset * 1000 < System.currentTimeMillis())
    }

    @Synchronized fun limit(c: Context): Float = if (subValid(c)) sp(c).getFloat("sub_limit", 0f) else plan(c).toFloat()

    @Synchronized fun remaining(c: Context): Float {
        roll(c)
        val p = sp(c)
        return if (subValid(c)) p.getFloat("sub_limit", 0f) - p.getFloat("sub_used", 0f) - p.getFloat("since", 0f)
        else plan(c) - p.getFloat("mu", 0f)
    }

    private fun daysLeft(c: Context): Int {
        val reset = sp(c).getLong("sub_reset", 0L) * 1000
        if (reset > System.currentTimeMillis()) return ceil((reset - System.currentTimeMillis()) / 86_400_000.0).toInt().coerceAtLeast(1)
        val cal = Calendar.getInstance()
        return (cal.getActualMaximum(Calendar.DAY_OF_MONTH) - cal.get(Calendar.DAY_OF_MONTH) + 1).coerceAtLeast(1)
    }

    /** Frischt die Kontowerte im Hintergrund auf, wenn sie älter als 12 Stunden sind. */
    private fun maybeRefresh(c: Context) {
        val key = c.getSharedPreferences("boris", 0).getString("el_key", "") ?: ""
        if (key.isBlank() || refreshing) return
        if (System.currentTimeMillis() - sp(c).getLong("sub_try", 0L) < 12 * 3_600_000L) return
        refreshing = true
        sp(c).edit().putLong("sub_try", System.currentTimeMillis()).apply()
        Thread { try { refresh(c, key) } finally { refreshing = false } }.start()
    }

    /** Darf Boris jetzt neue ElevenLabs-Sprache anfordern? Bereits gespeicherte Sätze sind immer erlaubt (kosten nichts). */
    @Synchronized fun allow(c: Context): Boolean {
        maybeRefresh(c)
        val rem = remaining(c)
        if (rem < 40f) return false
        val today = sp(c).getFloat("du", 0f)
        val fairShare = (rem + today) / daysLeft(c)
        return today < max(250f, fairShare * 1.6f)
    }

    fun summary(c: Context): String {
        val lim = limit(c); val rem = remaining(c)
        val today = sp(c).getFloat("du", 0f)
        return "${(lim - rem).toInt()} von ${lim.toInt()} Credits verbraucht, heute ${today.toInt()}" + if (subValid(c)) "" else " (geschätzt)"
    }
}
