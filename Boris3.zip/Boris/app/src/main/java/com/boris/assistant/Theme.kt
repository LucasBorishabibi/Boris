package com.boris.assistant

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

/** Farbwelten: 0 = Eis (Blau), 1 = Mono (Schwarz-Weiß), 2 = Glut (Orange, Standard). */
object Pal {
    var id by mutableIntStateOf(2)
    var bgTop by mutableStateOf(Color(0xFF1B0F09))
    var bg by mutableStateOf(Color(0xFF080504))
    var panel by mutableStateOf(Color(0xFF17110E))
    var accent by mutableStateOf(Color(0xFFFF7A1F))
    var accent2 by mutableStateOf(Color(0xFFFFC38A))
    var ok by mutableStateOf(Color(0xFF9BE8B8))
    var onAccent by mutableStateOf(Color(0xFF1A0B02))
    val red = Color(0xFFFF6B6B)
    val names = listOf("Eis", "Mono", "Glut")

    fun use(i: Int) {
        id = i
        when (i) {
            0 -> { bgTop = Color(0xFF0C1322); bg = Color(0xFF04060B); panel = Color(0xFF111724)
                accent = Color(0xFF5AA9FF); accent2 = Color(0xFFC9E4FF); ok = Color(0xFF6EE7C8); onAccent = Color.White }
            1 -> { bgTop = Color(0xFF121212); bg = Color(0xFF000000); panel = Color(0xFF131313)
                accent = Color(0xFFF2F2F2); accent2 = Color(0xFFBDBDBD); ok = Color(0xFFFFFFFF); onAccent = Color.Black }
            else -> { bgTop = Color(0xFF1B0F09); bg = Color(0xFF080504); panel = Color(0xFF17110E)
                accent = Color(0xFFFF7A1F); accent2 = Color(0xFFFFC38A); ok = Color(0xFF9BE8B8); onAccent = Color(0xFF1A0B02) }
        }
    }
}
