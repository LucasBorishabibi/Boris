package com.boris.assistant

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

data class Msg(val kind: Int, val text: String) // 0 = du, 1 = Boris, 2 = Aktion, 3 = Fehler

/** Kleines Protokoll für die Fehlersuche (sichtbar im SYSTEM-Reiter). */
object Dbg {
    val lines = mutableStateListOf<String>()
    fun d(s: String) {
        val t = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.GERMAN).format(java.util.Date())
        Handler(Looper.getMainLooper()).post { lines.add("$t $s"); while (lines.size > 40) lines.removeAt(0) }
    }
}

/** Das Zentrum: verarbeitet Befehle egal ob aus der App, vom Dauer-Zuhörer, von Erinnerungen oder Routinen. */
object Core {
    val messages = mutableStateListOf<Msg>()
    val history = JSONArray()
    var status by mutableStateOf("BEREIT")
    var busy by mutableStateOf(false)
    private var voiceModeState by mutableIntStateOf(0)
    /** 0 aus, 1 wartet auf „Boris“, 2 hört auf den Befehl. Sobald er zuhört, pausiert das Selbstlernen sofort. */
    var voiceMode: Int
        get() = voiceModeState
        set(v) { if (v == 2) Learning.userActive(); voiceModeState = v }
    @Volatile var listener: WakeListener? = null
    @Volatile var activityVisible = false
    /** True from the moment TTS is requested until playback completion; prevents queued recognizer callbacks becoming prompts. */
    @Volatile var voiceOutputActive = false
    @Volatile private var pending: Pair<String, JSONObject>? = null
    @Volatile private var responseGeneration = 0L
    private val ui = Handler(Looper.getMainLooper())

    fun onUi(b: () -> Unit) { ui.post(b) }
    fun key(ctx: Context): String = ctx.getSharedPreferences("boris", 0).getString("key", "") ?: ""

    private fun isStop(l: String) = l in setOf("stopp", "stop", "abbrechen", "halt", "boris stopp", "boris stop", "hör auf")
    private fun isYes(l: String) = l.trim('.', '!', ' ') in setOf("ja", "jo", "yes", "klar", "mach", "mach das", "okay", "ok", "gern", "los",
        "sende", "senden", "bestätigt", "passt", "ja bitte", "ja klar", "ja mach", "sicher", "gerne")
    private fun isNo(l: String) = l.trim('.', '!', ' ') in setOf("nein", "nö", "nee", "lass", "lass es", "nicht", "bloß nicht", "nein danke")

    /** Spricht, ohne sich selbst zuzuhören. Endet der Satz mit "?", hört Boris danach direkt auf die Antwort. */
    fun say(ctx: Context, text: String, listenAfter: Boolean, then: (() -> Unit)? = null, eco: Boolean = false) {
        // Set the guard BEFORE requesting TTS: playback may start before the next recognizer callback.
        voiceOutputActive = true
        // Hard half-duplex: stop/cancel recognition before any TTS audio starts.
        // This prevents the phone speaker from being transcribed as a new user command.
        listener?.pause(true)
        Hub.jarvis(ctx).speak(key(ctx), text, onDone = {
            voiceOutputActive = false
            val l = listener
            if (listenAfter) l?.resumeAndAwait() else l?.pause(false)
            then?.invoke()
        }, eco = eco)
    }

    /** Boris meldet sich von sich aus (Erinnerung, Beobachtung). */
    fun announce(ctx0: Context, text: String, question: Boolean, then: (() -> Unit)? = null, eco: Boolean = false) {
        val ctx = ctx0.applicationContext
        onUi { messages.add(Msg(1, text)) }
        if (question) {
            synchronized(history) {
                if (history.length() == 0) history.put(JSONObject().put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", "(Boris meldet sich von sich aus)"))))
                history.put(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", text))))
            }
        }
        say(ctx, text, question, then, eco)
        if (!activityVisible) Notify.post(ctx, "Boris", text)
    }

    fun ask(ctx: Context, q: String) = announce(ctx, q, true)

    fun handle(ctx0: Context, text: String) {
        val ctx = ctx0.applicationContext
        val t = text.trim()
        if (t.isBlank()) return
        Learning.userActive()
        val low = t.lowercase()
        if (isStop(low) && (busy || PhoneAgent.running || Hub.jarvis(ctx).speaking)) {
            responseGeneration++
            PhoneAgent.abort(); Hub.jarvis(ctx).stop(); voiceOutputActive = false
            onUi { busy = false; status = "BEREIT" }
            Dbg.d("Stopp per Sprache"); return
        }
        if (busy) return
        val p = pending
        if (p != null) {
            pending = null
            if (isYes(low)) {
                onUi { messages.add(Msg(0, t)); busy = true; status = statusFor(p.first, p.second).uppercase() }
                Thread {
                    val r = try { runTool(ctx, p.first, p.second) } catch (e: Exception) { "Fehler: ${e.message}" }
                    Safety.afterSuccess(ctx, p.first, p.second, r)
                    val out = r.removePrefix("INFO:").trim()
                    onUi { messages.add(Msg(2, out.take(120))); busy = false; status = "BEREIT" }
                    say(ctx, out, false)
                }.start()
                return
            }
            if (isNo(low)) {
                onUi { messages.add(Msg(0, t)); messages.add(Msg(1, "Verstanden, abgebrochen.")) }
                say(ctx, "Verstanden, abgebrochen.", false)
                return
            }
        }
        val key = key(ctx)
        Hub.jarvis(ctx).stop()
        voiceOutputActive = false
        val requestId = ++responseGeneration
        onUi { messages.add(Msg(0, t)); busy = true; status = "ANALYSIERE …" }
        synchronized(history) {
            history.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", t))))
        }
        agentApiKey = key
        statusSink = { s -> onUi { status = s.uppercase() } }
        Thread {
            var ok = true
            var reply = ""
            val used = ArrayList<String>()
            val failed = ArrayList<String>()
            try {
                reply = GeminiClient.chat(key, history, { s -> onUi { status = s.uppercase() } }) { n, a ->
                    used.add(n)
                    val r = guarded(ctx, n, a)
                    if (r.startsWith("Fehler")) failed.add(n)
                    r
                }
            } catch (e: Exception) { ok = false; reply = e.message ?: "Unbekannter Fehler"; Dbg.d("Fehler: ${e.message}") }
            if (requestId != responseGeneration) return@Thread
            onUi { messages.add(Msg(if (ok) 1 else 3, reply)); busy = false; status = "BEREIT" }
            if (ok && requestId == responseGeneration) say(ctx, reply, reply.trim().takeLast(80).contains("?"))
            // Erfahrung festhalten: daraus lernt Boris später in ruhigen Zeiten
            try { Knowledge.record(t, reply, ok && failed.isEmpty(), used, failed) } catch (e: Exception) {}
        }.start()
    }

    /** Antippen des Orbs: bricht Sprechen, Denken und Agent sofort ab und hört danach wieder zu. */
    fun interrupt(ctx0: Context) {
        val ctx = ctx0.applicationContext
        responseGeneration++
        PhoneAgent.abort(); Hub.jarvis(ctx).stop(); voiceOutputActive = false
        onUi { busy = false; status = "BEREIT" }
        listener?.pause(false)
        Dbg.d("Abbruch per Antippen")
    }

    private fun guarded(ctx: Context, name: String, args: JSONObject): String {
        val q = Safety.needsConfirm(ctx, name, args)
        if (q != null) { pending = name to args; return "ASK:$q" }
        onUi { status = statusFor(name, args).uppercase() }
        val r = try { runTool(ctx, name, args) } catch (e: Exception) { "Fehler: ${e.message}" }
        if (r.startsWith("Fehler")) Dbg.d("$name: $r")
        onUi { messages.add(Msg(2, r.removePrefix("INFO:").trim().take(120))) }
        Safety.afterSuccess(ctx, name, args, r)
        return r
    }
}
