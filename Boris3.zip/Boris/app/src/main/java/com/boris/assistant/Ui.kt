package com.boris.assistant

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

/** Milchglas-Karte: halbtransparentes Panel mit feiner Kante. */
fun Modifier.glass(shape: Shape = RoundedCornerShape(22.dp), alpha: Float = 0.72f): Modifier =
    this.clip(shape).background(Pal.panel.copy(alpha = alpha), shape).border(1.dp, Color.White.copy(alpha = 0.07f), shape)

// ------------------------------------------------------------------ Symbole (selbst gezeichnet)
@Composable
fun Ico(kind: String, color: Color, boxSize: Dp = 24.dp) {
    Canvas(Modifier.size(boxSize)) {
        val w = this.size.width
        val sw = w * 0.085f
        val st = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (kind) {
            "chat" -> {
                drawRoundRect(color, Offset(w * 0.12f, w * 0.14f), Size(w * 0.76f, w * 0.58f), CornerRadius(w * 0.2f), style = st)
                val tail = Path().apply { moveTo(w * 0.32f, w * 0.72f); lineTo(w * 0.27f, w * 0.9f); lineTo(w * 0.52f, w * 0.72f) }
                drawPath(tail, color, style = st)
                for (i in 0 until 3) drawCircle(color, w * 0.035f, Offset(w * (0.34f + 0.16f * i), w * 0.43f))
            }
            "mic" -> {
                drawRoundRect(color, Offset(w * 0.37f, w * 0.1f), Size(w * 0.26f, w * 0.47f), CornerRadius(w * 0.13f), style = st)
                drawArc(color, startAngle = 0f, sweepAngle = 180f, useCenter = false,
                    topLeft = Offset(w * 0.24f, w * 0.26f), size = Size(w * 0.52f, w * 0.46f), style = st)
                drawLine(color, Offset(w * 0.5f, w * 0.72f), Offset(w * 0.5f, w * 0.88f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * 0.36f, w * 0.9f), Offset(w * 0.64f, w * 0.9f), sw, StrokeCap.Round)
            }
            "send" -> {
                val p = Path().apply {
                    moveTo(w * 0.12f, w * 0.46f); lineTo(w * 0.9f, w * 0.12f); lineTo(w * 0.58f, w * 0.9f); lineTo(w * 0.46f, w * 0.58f); close()
                }
                drawPath(p, color, style = st)
                drawLine(color, Offset(w * 0.46f, w * 0.58f), Offset(w * 0.9f, w * 0.12f), sw, StrokeCap.Round)
            }
            "close" -> {
                drawLine(color, Offset(w * 0.27f, w * 0.27f), Offset(w * 0.73f, w * 0.73f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * 0.73f, w * 0.27f), Offset(w * 0.27f, w * 0.73f), sw, StrokeCap.Round)
            }
            "plus" -> {
                drawLine(color, Offset(w * 0.5f, w * 0.22f), Offset(w * 0.5f, w * 0.78f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * 0.22f, w * 0.5f), Offset(w * 0.78f, w * 0.5f), sw, StrokeCap.Round)
            }
            "stop" -> drawRoundRect(color, Offset(w * 0.28f, w * 0.28f), Size(w * 0.44f, w * 0.44f), CornerRadius(w * 0.1f))
            "chev" -> {
                val p = Path().apply { moveTo(w * 0.38f, w * 0.24f); lineTo(w * 0.64f, w * 0.5f); lineTo(w * 0.38f, w * 0.76f) }
                drawPath(p, color, style = st)
            }
            "check" -> {
                val p = Path().apply { moveTo(w * 0.2f, w * 0.54f); lineTo(w * 0.42f, w * 0.74f); lineTo(w * 0.8f, w * 0.3f) }
                drawPath(p, color, style = st)
            }
            "gear" -> {
                drawCircle(color, w * 0.17f, Offset(w * 0.5f, w * 0.5f), style = st)
                for (i in 0 until 8) {
                    val a = i * 0.7853982f
                    drawLine(color, Offset(w * (0.5f + 0.29f * cos(a)), w * (0.5f + 0.29f * sin(a))),
                        Offset(w * (0.5f + 0.41f * cos(a)), w * (0.5f + 0.41f * sin(a))), sw, StrokeCap.Round)
                }
            }
            "tasks" -> {
                for (i in 0 until 3) {
                    val y = w * (0.26f + 0.24f * i)
                    drawCircle(color, w * 0.045f, Offset(w * 0.18f, y))
                    drawLine(color, Offset(w * 0.36f, y), Offset(w * 0.86f, y), sw, StrokeCap.Round)
                }
            }
            "clock" -> {
                drawCircle(color, w * 0.36f, Offset(w * 0.5f, w * 0.5f), style = st)
                drawLine(color, Offset(w * 0.5f, w * 0.5f), Offset(w * 0.5f, w * 0.28f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * 0.5f, w * 0.5f), Offset(w * 0.66f, w * 0.58f), sw, StrokeCap.Round)
            }
            "spark" -> {
                val p = Path().apply {
                    moveTo(w * 0.5f, w * 0.1f)
                    quadraticBezierTo(w * 0.5f, w * 0.5f, w * 0.9f, w * 0.5f)
                    quadraticBezierTo(w * 0.5f, w * 0.5f, w * 0.5f, w * 0.9f)
                    quadraticBezierTo(w * 0.5f, w * 0.5f, w * 0.1f, w * 0.5f)
                    quadraticBezierTo(w * 0.5f, w * 0.5f, w * 0.5f, w * 0.1f)
                    close()
                }
                drawPath(p, color, style = st)
            }
            "voice" -> {
                for (i in 0 until 5) {
                    val h = w * floatArrayOf(0.22f, 0.5f, 0.7f, 0.42f, 0.26f)[i]
                    val x = w * (0.2f + 0.15f * i)
                    drawLine(color, Offset(x, w * 0.5f - h / 2f), Offset(x, w * 0.5f + h / 2f), sw, StrokeCap.Round)
                }
            }
            "link" -> {
                drawRoundRect(color, Offset(w * 0.1f, w * 0.34f), Size(w * 0.46f, w * 0.32f), CornerRadius(w * 0.16f), style = st)
                drawRoundRect(color, Offset(w * 0.44f, w * 0.34f), Size(w * 0.46f, w * 0.32f), CornerRadius(w * 0.16f), style = st)
            }
            "wrench" -> {
                drawLine(color, Offset(w * 0.22f, w * 0.78f), Offset(w * 0.6f, w * 0.4f), sw * 1.4f, StrokeCap.Round)
                drawCircle(color, w * 0.18f, Offset(w * 0.68f, w * 0.32f), style = st)
            }
            "shield" -> {
                val p = Path().apply {
                    moveTo(w * 0.5f, w * 0.1f); lineTo(w * 0.84f, w * 0.24f); lineTo(w * 0.8f, w * 0.56f)
                    quadraticBezierTo(w * 0.74f, w * 0.8f, w * 0.5f, w * 0.92f)
                    quadraticBezierTo(w * 0.26f, w * 0.8f, w * 0.2f, w * 0.56f)
                    lineTo(w * 0.16f, w * 0.24f); close()
                }
                drawPath(p, color, style = st)
            }
            "palette" -> {
                drawCircle(color, w * 0.38f, Offset(w * 0.5f, w * 0.5f), style = st)
                drawCircle(color, w * 0.05f, Offset(w * 0.36f, w * 0.42f))
                drawCircle(color, w * 0.05f, Offset(w * 0.52f, w * 0.32f))
                drawCircle(color, w * 0.05f, Offset(w * 0.66f, w * 0.46f))
            }
        }
    }
}

@Composable
fun RoundBtn(kind: String, diameter: Dp, filled: Boolean, halo: Float, onClick: () -> Unit) {
    val bg = if (filled) Modifier.background(Brush.linearGradient(listOf(Pal.accent, lerp(Pal.accent, Color.White, 0.3f))), CircleShape)
    else Modifier.background(Pal.panel.copy(alpha = 0.8f), CircleShape).border(1.dp, Color.White.copy(alpha = 0.12f), CircleShape)
    Box(Modifier.size(diameter)
        .drawBehind { if (halo > 0f) drawCircle(Pal.accent.copy(alpha = 0.30f * halo), this.size.minDimension / 2f * (1.1f + 0.45f * halo)) }
        .then(bg).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Ico(kind, if (filled) Pal.onAccent else Color.White, diameter * 0.44f)
    }
}

/** Kleiner Auswahl-Chip (Reiter, Farbwelt). */
@Composable
fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(label, Modifier.clip(RoundedCornerShape(50))
        .background(if (selected) Pal.accent.copy(alpha = 0.20f) else Color.White.copy(alpha = 0.05f))
        .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        fontSize = 13.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
        color = if (selected) Pal.accent else Color.White.copy(alpha = 0.6f), maxLines = 1)
}

@Composable
fun Toggle(on: Boolean, onChange: (Boolean) -> Unit) {
    Switch(on, onChange, colors = SwitchDefaults.colors(
        checkedThumbColor = Pal.onAccent, checkedTrackColor = Pal.accent,
        uncheckedThumbColor = Color(0xFFB0B0B0), uncheckedTrackColor = Color.White.copy(alpha = 0.15f), uncheckedBorderColor = Color.Transparent))
}

@Composable
fun PillField(value: String, hint: String, modifier: Modifier = Modifier, secret: Boolean = false, onSend: (() -> Unit)? = null, onChange: (String) -> Unit) {
    Box(modifier.clip(RoundedCornerShape(26.dp)).background(Color.White.copy(alpha = 0.07f))) {
        TextField(value, onChange, Modifier.fillMaxWidth(), singleLine = true,
            placeholder = { Text(hint, fontSize = 14.sp, color = Color.White.copy(alpha = 0.4f)) },
            textStyle = TextStyle(fontSize = 15.sp),
            visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
            keyboardOptions = if (onSend != null) KeyboardOptions(imeAction = ImeAction.Send) else KeyboardOptions.Default,
            keyboardActions = if (onSend != null) KeyboardActions(onSend = { onSend() }) else KeyboardActions.Default,
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Pal.accent))
    }
}

/** Eine Einstellung: Titel, optional Erklärung, rechts ein Schalter oder eine Aktion. */
@Composable
fun Setting(title: String, sub: String?, onClick: (() -> Unit)?, trailing: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = 0.05f))
        .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
        .padding(horizontal = 14.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 14.sp)
            if (sub != null) Text(sub, color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp, lineHeight = 14.sp)
        }
        Spacer(Modifier.width(8.dp))
        trailing()
    }
}

@Composable
fun ActionText(text: String) { Text(text, color = Pal.accent, fontSize = 13.sp, fontWeight = FontWeight.Medium) }

@Composable
fun Note(text: String) {
    Text(text, color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp, lineHeight = 15.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp))
}

/** Aufklappbare Gruppe in den Einstellungen. */
@Composable
fun Section(title: String, sub: String, icon: String, expanded: Boolean, onToggle: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 5.dp).glass(RoundedCornerShape(22.dp), 0.6f).animateContentSize()) {
        Row(Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(horizontal = 14.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(36.dp).clip(CircleShape).background(Pal.accent.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
                Ico(icon, Pal.accent, 20.dp)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Text(sub, color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Box(Modifier.rotate(if (expanded) 90f else 0f)) { Ico("chev", Color.White.copy(alpha = 0.5f), 18.dp) }
        }
        if (expanded) Column(Modifier.fillMaxWidth().padding(start = 10.dp, end = 10.dp, bottom = 10.dp), content = content)
    }
}

/** Zeile im Gehirn: Etikett, Text, Löschen. */
@Composable
fun BrainRow(label: String, labelColor: Color, text: String, onDelete: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = 0.05f))
        .padding(start = 14.dp, top = 8.dp, bottom = 8.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, color = labelColor, fontSize = 10.sp, letterSpacing = 0.6.sp)
            Text(text, color = Color.White, fontSize = 14.sp)
        }
        Box(Modifier.size(38.dp).clip(CircleShape).clickable(onClick = onDelete), contentAlignment = Alignment.Center) {
            Ico("close", Color.White.copy(alpha = 0.5f), 18.dp)
        }
    }
}

@Composable
fun GroupLabel(text: String) {
    Text(text, color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp, modifier = Modifier.padding(top = 14.dp, bottom = 4.dp, start = 4.dp))
}

/** Hinweis-Chip auf dem Startbildschirm, z. B. wenn ein Zugriff fehlt. */
@Composable
fun HintChip(text: String, onClick: () -> Unit, onDismiss: () -> Unit) {
    Row(Modifier.clip(RoundedCornerShape(50)).background(Pal.panel.copy(alpha = 0.85f)).border(1.dp, Pal.accent.copy(alpha = 0.35f), RoundedCornerShape(50))
        .clickable(onClick = onClick).padding(start = 14.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(text, color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Box(Modifier.size(32.dp).clip(CircleShape).clickable(onClick = onDismiss), contentAlignment = Alignment.Center) {
            Ico("close", Color.White.copy(alpha = 0.55f), 14.dp)
        }
    }
}
