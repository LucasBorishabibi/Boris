# Neu in dieser Version

- Websuche ohne Gemini: DuckDuckGo (Bing als Ersatz) + Wikipedia + Text der besten Seite, ausgewertet über OpenRouter.
  Ist OpenRouter am Limit, fasst der Hauptchat die Rohergebnisse selbst zusammen. Auch das Selbstlernen recherchiert so.
- Ist Gemini überlastet, übernimmt OpenRouter das Gespräch (ohne Werkzeuge, bei Bedarf mit Web-Ergebnissen).
- Neue Agenten-Maus: schlichter Pfeil, gleitet mit sanfter Kurve, startet am Mini-Fenster und kehrt dorthin zurück.
- Mini-Fenster (Bild im Bild) mit Boris' Gesicht: erscheint bei Benachrichtigungen, Sprechen, Zuhören und im Agentenmodus,
  frei verschiebbar, rastet am Rand ein, Antippen öffnet Boris, Stopp-Knopf beim Agenten. Weicht der Maus aus.
  Läuft über die Bedienungshilfe „Boris Auto-Senden“ (muss an sein). Abschaltbar unter Zuhören & Sicherheit.
