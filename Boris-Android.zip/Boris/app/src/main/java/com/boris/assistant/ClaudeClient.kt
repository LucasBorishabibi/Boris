package com.boris.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ClaudeClient {
    private const val MODEL = "claude-sonnet-5-5"

    private val tools = JSONArray(
        """[
        {"name":"set_timer","description":"Stellt einen Countdown-Timer auf dem Handy.",
         "input_schema":{"type":"object","properties":{
           "seconds":{"type":"integer","description":"Dauer in Sekunden"},
           "label":{"type":"string"}},"required":["seconds"]}},
        {"name":"set_alarm","description":"Stellt einen Wecker bzw. eine Erinnerung zu einer Uhrzeit (24h).",
         "input_schema":{"type":"object","properties":{
           "hour":{"type":"integer"},"minute":{"type":"integer"},
           "label":{"type":"string"}},"required":["hour","minute"]}}
        ]"""
    )

    private fun system(): String {
        val now = SimpleDateFormat("EEEE, dd.MM.yyyy HH:mm", Locale.GERMAN).format(Date())
        return "Du bist Boris, der persönliche Sprachassistent auf dem Android-Handy des Nutzers. " +
            "Antworte kurz und auf Deutsch, so dass es sich gut vorlesen lässt. " +
            "Für Timer, Wecker und Erinnerungen nutze die Tools. Aktuelle Zeit: $now."
    }

    /** history wird direkt erweitert (user/assistant/tool_result). Läuft blockierend – auf IO-Thread aufrufen. */
    fun chat(apiKey: String, history: JSONArray, runTool: (String, JSONObject) -> String): String {
        repeat(6) {
            val res = post(apiKey, history)
            val content = res.getJSONArray("content")
            history.put(JSONObject().put("role", "assistant").put("content", content))
            if (res.optString("stop_reason") != "tool_use") {
                val sb = StringBuilder()
                for (i in 0 until content.length()) {
                    val b = content.getJSONObject(i)
                    if (b.getString("type") == "text") sb.append(b.getString("text"))
                }
                return sb.toString().ifBlank { "Erledigt." }
            }
            val results = JSONArray()
            for (i in 0 until content.length()) {
                val b = content.getJSONObject(i)
                if (b.getString("type") == "tool_use") {
                    results.put(
                        JSONObject().put("type", "tool_result")
                            .put("tool_use_id", b.getString("id"))
                            .put("content", runTool(b.getString("name"), b.getJSONObject("input")))
                    )
                }
            }
            history.put(JSONObject().put("role", "user").put("content", results))
        }
        return "Das war mir zu viele Schritte auf einmal."
    }

    private fun post(apiKey: String, history: JSONArray): JSONObject {
        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 1024)
            .put("system", system())
            .put("tools", tools)
            .put("messages", history)
        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-api-key", apiKey)
        conn.setRequestProperty("anthropic-version", "2023-06-01")
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val ok = conn.responseCode in 200..299
        val text = (if (ok) conn.inputStream else conn.errorStream).bufferedReader().readText()
        if (!ok) throw RuntimeException("API ${conn.responseCode}: $text")
        return JSONObject(text)
    }
}
